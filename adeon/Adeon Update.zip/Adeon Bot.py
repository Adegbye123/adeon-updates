#!/usr/bin/env python3
"""
Adeon — LR Writers picker worker
================================
Reads the LR Writers DOM through a Chrome DevTools session and uses the visible
Windows mouse/keyboard for permitted actions. It never clicks Accept. If the
normal Chrome session was not started with DevTools enabled, Adeon can gracefully
restart Chrome through a private Adeon user-data directory. First setup copies only
limited login/session data into %LOCALAPPDATA%\Adeon\Chrome Data, then reuses it.

Run this worker through Adeon.exe / Adeon App.pyw.
"""
from __future__ import annotations

import atexit
import ctypes
import json
import os
import random
import re
import signal
import shutil
import subprocess
import sys
import threading
import time
import traceback
import urllib.request
from ctypes import wintypes
from datetime import datetime
from pathlib import Path

import pyautogui
import requests

try:
    from playwright.sync_api import sync_playwright
    HAS_PW = True
except Exception:
    HAS_PW = False

# ---------------- config ----------------
PUSHOVER_USER_KEY = "u4opq7uv7aycr25h8k9a52nq825n3k"
PUSHOVER_APP_TOKEN = "ae3yrpk924weovh45ssdy44hvrziap"
GMAIL_TO = "adegboyeoore@gmail.com"
GMAIL_WEBAPP_URL = (
    "https://script.google.com/macros/s/"
    "AKfycbzV8-YBPMp-1Kma7iMJTejcyKxXBnjfaJ6r6yhuBFyYLuOLTfDz8TCObCnqgnAXshU/exec"
)
GMAIL_WEBAPP_SECRET = "Adegboye2004%%"

MIN_PAY = 6.00
RELOAD_FAST_N = 3
RELOAD_SLOW_N = 2
# F5 timing: keep the varied 5-20 second rhythm, but never allow two actual
# F5 presses to be closer than 5 seconds. There is no extra burst cooldown.
RELOAD_FAST = (5.0, 10.0)
RELOAD_SLOW = (10.0, 20.0)
F5_HARD_MIN_GAP = 5.0
F5_SHORT_GAP_THRESHOLD = 0.0
F5_BURST_RECOVERY_GAP = 0.0
RESERVED_RELOAD = (5.0, 20.0)  # legacy value; actual F5 is intentionally held while reserved
RESERVED_INSPECTION_SCROLL_EVERY = 3.0
RESERVED_INSPECTION_SCROLL_UNTIL = 42.0
RESERVED_INSPECTION_RETURN_AT = 50.0
RESERVED_INSPECTION_WHEEL_DOWN = -5
RESERVED_INSPECTION_WHEEL_UP = 30
DOM_SCAN_INTERVAL = 0.10  # target live row/DOM scan cadence while the picker is active
IDLE_MOVE = (20.0, 60.0)
IDLE_CLICK = (120.0, 300.0)  # safe inert-background click only; never while an order panel is open
IDLE_ACTIVE_FOR = 5 * 60.0      # after 5 active minutes, pause idle mouse activity
IDLE_REST = (3 * 60.0, 20 * 60.0)  # random 3-20 minute idle-mouse rest
RESERVE_REMINDER_AFTER = 60.0       # first short reservation reminder, at 1 minute
RESERVE_REPEAT_START = 4 * 60.0 + 30.0  # from 4m30s, repeat while still genuinely reserved
RESERVE_REPEAT_EVERY = 20.0             # repeated "still reserved" cadence until reservation ends/times out
RESERVATION_STATUS_CHECK = 10.0      # verify every 10 seconds that the reservation still exists
NETWORK_RETRY_MIN = 5.0              # keep worker alive through temporary network loss
NETWORK_RETRY_MAX = 20.0
MY_ORDERS_VISIT = (40 * 60.0, 2 * 60 * 60.0)  # random 40 minutes to 2 hours
MIDNIGHT_RULE_START_HOUR = 0
MIDNIGHT_RULE_END_HOUR = 8       # local PC time: 00:00 <= time < 08:00
MIDNIGHT_REJECT_UNDER_MINUTES = 5 * 60
MIDNIGHT_REJECT_AFTER = 60.0     # keep it reserved for one minute, then Reject
FIND_ORDERS = "https://myaccount.lrwriters.com/findorders/all"
ROW_RETRY_SEC = 12.0
RESERVE_RETRY_SEC = 1.4

pyautogui.FAILSAFE = False
pyautogui.PAUSE = 0.0

_stop = False
_paused = False
_pause_reason = ""
_resume_requested = False
_resume_source = ""
_pause_lock = threading.Lock()
_alerted: set[str] = set()
_alert_last_try: dict[str, float] = {}
_alert_inflight: set[str] = set()
_alert_cancelled: set[str] = set()
_alert_lock = threading.Lock()
_done: set[str] = set()
_click_lock = threading.Lock()
_last_click = 0.0
_last_idle_dir = ""
_ctrl_handler_ref = None  # keep the Windows console callback alive
_debug_chrome_pid = 0
_debug_port = 0
_debug_endpoint = ""
_debug_user_data_dir = ""
_last_diag_shot = 0.0

# Persistent local controller. The controller itself never touches the webpage while
# STOPPED; it only keeps the tiny dashboard + Alt+S hotkey alive.
_controller_exit = threading.Event()
_controller_start_requested = threading.Event()
_controller_lock = threading.Lock()
_controller_worker: threading.Thread | None = None
_controller_active = False

# Tiny always-on-top status ticket shown on the Windows desktop.
_status_ticket_lock = threading.Lock()
_status_ticket_state = {
    "bot": "STARTING",
    "page": "WAITING",
    "job": "SEARCHING",
    "f5": "WAIT",
    "mouse": "WAIT",
}
_status_ticket_started = False
_status_ticket_stop = threading.Event()

# Window-management constants used only to guarantee that a real mouse click
# reaches the controlled Chrome window rather than a covering terminal/window.
HWND_TOPMOST = -1
HWND_NOTOPMOST = -2
SWP_NOSIZE = 0x0001
SWP_NOMOVE = 0x0002
SWP_SHOWWINDOW = 0x0040
GA_ROOT = 2


# ---------------- tiny desktop status ticket ----------------
def set_status_ticket(**fields) -> None:
    """Update the tiny desktop ticket and the app-visible runtime status."""
    global _runtime_file_last
    with _status_ticket_lock:
        for key, value in fields.items():
            if key in _status_ticket_state and value is not None:
                _status_ticket_state[key] = str(value)
        snapshot = dict(_status_ticket_state)
    try:
        snapshot["pid"] = os.getpid()
        snapshot["updated_at"] = time.time()
        payload = json.dumps(snapshot, ensure_ascii=False, sort_keys=True)
        if payload != _runtime_file_last:
            _runtime_file_last = payload
            _write_json_atomic(_APP_RUNTIME_FILE, snapshot)
    except Exception:
        pass


def show_action_popup(text: str, kind: str = "accept", duration: float = 2.2, bell: bool = False) -> None:
    """Show a tiny temporary Windows popup for ACCEPT / REJECT decisions."""
    label = str(text or "").strip().upper() or ("ACCEPT" if kind == "accept" else "REJECT")
    mode = str(kind or "accept").lower()

    def worker() -> None:
        try:
            if bell:
                try:
                    import winsound
                    # Short two-tone laptop bell. Never blocks the director loop.
                    winsound.Beep(988, 170)
                    time.sleep(0.10)
                    winsound.Beep(659, 420)
                except Exception:
                    try:
                        import winsound
                        winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
                    except Exception:
                        pass

            import tkinter as tk
            root = tk.Tk()
            root.overrideredirect(True)
            root.attributes("-topmost", True)
            try:
                root.attributes("-alpha", 0.96)
            except Exception:
                pass

            is_accept = mode == "accept"
            bg = "#159447" if is_accept else "#d62f2f"
            width = 235 if len(label) > 12 else 150
            height = 48
            sw = int(root.winfo_screenwidth() or 1920)
            root.geometry(f"{width}x{height}+{max(8, sw-width-24)}+24")
            root.configure(bg=bg)
            tk.Label(
                root, text=label, bg=bg, fg="white",
                font=("Segoe UI", 11, "bold"), padx=10, pady=8,
                anchor="center", justify="center",
            ).pack(fill="both", expand=True)
            root.after(max(700, int(float(duration) * 1000)), root.destroy)
            root.mainloop()
        except Exception as e:
            try:
                log(f"Action popup unavailable: {e}")
            except Exception:
                pass

    threading.Thread(target=worker, name="LR-Action-Popup", daemon=True).start()


def start_status_ticket() -> None:
    """Start a tiny draggable, always-on-top sticky-note status window."""
    global _status_ticket_started
    if _status_ticket_started:
        return
    _status_ticket_started = True
    _status_ticket_stop.clear()

    def worker() -> None:
        try:
            import tkinter as tk
        except Exception as e:
            log(f"Status ticket unavailable (tkinter): {e}")
            return
        try:
            root = tk.Tk()
            root.overrideredirect(True)
            root.attributes("-topmost", True)
            try:
                root.attributes("-alpha", 0.94)
            except Exception:
                pass

            width, height = 230, 104
            sh = int(root.winfo_screenheight() or 1080)
            # Bottom-left as requested; leave a small margin above the taskbar.
            root.geometry(f"{width}x{height}+18+{max(8, sh-height-58)}")
            root.configure(bg="#fff4b8")

            frame = tk.Frame(root, bg="#fff4b8", bd=1, relief="solid")
            frame.pack(fill="both", expand=True)
            header = tk.Label(
                frame, text="ADEON", anchor="w", justify="left",
                bg="#fff4b8", fg="#111111", font=("Segoe UI", 9, "bold"),
                padx=7, pady=3,
            )
            header.pack(fill="x")
            body = tk.Label(
                frame, text="", anchor="nw", justify="left",
                bg="#fff4b8", fg="#111111", font=("Segoe UI", 8),
                padx=7, pady=1,
            )
            body.pack(fill="both", expand=True)

            drag = {"x": 0, "y": 0}
            def drag_start(event):
                drag["x"] = int(event.x)
                drag["y"] = int(event.y)
            def drag_move(event):
                root.geometry(f"+{int(event.x_root)-drag['x']}+{int(event.y_root)-drag['y']}")
            for w in (frame, header, body):
                w.bind("<ButtonPress-1>", drag_start)
                w.bind("<B1-Motion>", drag_move)

            def refresh() -> None:
                if _status_ticket_stop.is_set():
                    try:
                        root.destroy()
                    except Exception:
                        pass
                    return
                with _status_ticket_lock:
                    st = dict(_status_ticket_state)
                bot = str(st.get("bot", "?")).upper()
                if bot == "CONNECTED":
                    status_color = "#138a36"
                elif bot == "STOPPED":
                    status_color = "#c62828"
                else:
                    status_color = "#6b5b00"
                header.config(text=f"ADEON  •  {bot}", fg=status_color)
                body.config(text=(
                    f"JOB    {st.get('job','?')}\n"
                    f"F5     {st.get('f5','?')}\n"
                    f"MOUSE  {st.get('mouse','?')}"
                ))
                try:
                    root.after(350, refresh)
                except Exception:
                    pass

            refresh()
            root.mainloop()
        except Exception as e:
            try:
                log(f"Status ticket failed: {e}")
            except Exception:
                pass

    threading.Thread(target=worker, name="LR-Status-Ticket", daemon=True).start()


# ---------------- diagnostics / session report ----------------
SESSION_STARTED_AT = time.time()
SESSION_ID = datetime.now().strftime("%Y%m%d_%H%M%S")
# All persistent Adeon state is anchored to LOCALAPPDATA, never to the folder
# where an installer ZIP or source file happens to be extracted/run.
_LOCAL_APPDATA = Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local")))
_BASE_DIR = _LOCAL_APPDATA / "Adeon"
try:
    _BASE_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    pass
_REPORT_DIR = _BASE_DIR / "adeon_reports"
try:
    _REPORT_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    _REPORT_DIR = Path.cwd()

# The installer records the folder that contains Install Adeon.bat/ps1.
# Every user-facing report is copied back to that visible setup folder so the
# user never has to hunt through AppData or Downloads for it.
_REPORT_DEST_FILE = _BASE_DIR / "Report Folder.txt"
try:
    _saved_report_dir = Path(_REPORT_DEST_FILE.read_text(encoding="utf-8-sig").strip()).expanduser()
    if not _saved_report_dir.is_dir():
        raise OSError("saved setup/report folder is unavailable")
    _VISIBLE_REPORT_DIR = _saved_report_dir
except Exception:
    _VISIBLE_REPORT_DIR = Path.home() / "Downloads"

_SESSION_LOG = _REPORT_DIR / f"Adeon Session {SESSION_ID}.log"
_REPORT_LOCAL = _REPORT_DIR / f"Adeon Report {SESSION_ID}.txt"
_REPORT_VISIBLE = _VISIBLE_REPORT_DIR / f"Adeon Report {SESSION_ID}.txt"
_RESERVATION_STATE_FILE = _BASE_DIR / "Adeon Reservation State.json"
_APP_STOP_FILE = _BASE_DIR / "Adeon Stop Request.flag"
_APP_RUNTIME_FILE = _BASE_DIR / "Adeon Runtime.json"
_APP_ACTIVITY_LOG = _BASE_DIR / "Adeon Activity.log"
_APP_LAST_ERROR_FILE = _BASE_DIR / "Adeon Last Error.txt"
_APP_WORKER_MODE = "--app-worker" in sys.argv
_ADEON_CHROME_DATA = _BASE_DIR / "Chrome Data"
_ADEON_CHROME_MARKER = _BASE_DIR / "Chrome Profile.json"
_runtime_file_last = ""


def _write_json_atomic(path: Path, data: dict) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(path)
    except Exception:
        pass


def save_reservation_state(data: dict) -> None:
    _write_json_atomic(_RESERVATION_STATE_FILE, data or {})


def load_reservation_state() -> dict:
    try:
        if not _RESERVATION_STATE_FILE.exists():
            return {}
        data = json.loads(_RESERVATION_STATE_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def clear_reservation_state() -> None:
    try:
        _RESERVATION_STATE_FILE.unlink(missing_ok=True)
    except Exception:
        pass


def app_stop_requested() -> bool:
    if not _APP_WORKER_MODE:
        return False
    try:
        return _APP_STOP_FILE.exists()
    except Exception:
        return False

_log_lock = threading.Lock()
_issue_lock = threading.Lock()
_issues: list[dict] = []
_issue_last: dict[str, float] = {}
_stats: dict[str, int] = {
    "dom_reads": 0, "brain_read_errors": 0, "reconnects": 0,
    "row_clicks": 0, "reserve_clicks": 0, "click_refusals": 0,
    "f5": 0, "reservations_confirmed": 0, "alerts_sent": 0,
    "alert_failures": 0, "loop_errors": 0, "left_find_orders": 0,
    "trusted_native_clicks": 0, "untrusted_clicks": 0, "manual_accepts": 0,
    "manual_rejects": 0, "reject_clicks": 0, "midnight_auto_rejects": 0,
    "soft_pauses": 0, "soft_resumes": 0, "logout_pauses": 0, "logout_stops": 0,
    "alerts_cancelled": 0, "idle_pause_cycles": 0,
    "nav_clicks": 0, "my_orders_visits": 0, "reservation_status_checks": 0,
    "panel_inspection_scrolls": 0, "panel_files_toggles": 0,
    "reservation_state_restores": 0,
}
_last_state: dict[str, object] = {}
_report_written = False
_stop_reason = "normal shutdown"


def record_stat(name: str, amount: int = 1) -> None:
    _stats[name] = int(_stats.get(name, 0)) + amount


def write_last_error(message: str) -> None:
    try:
        _APP_LAST_ERROR_FILE.write_text(str(message or "Unknown Adeon worker error"), encoding="utf-8")
    except Exception:
        pass


def log(msg: str) -> None:
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{stamp}] {msg}"
    # The installed worker is windowless, but direct/debug runs can inherit a
    # legacy Windows console encoding such as cp1252. Never let an emoji or
    # non-ASCII DOM character crash the automation merely because print()
    # cannot encode it. The UTF-8 log files below remain authoritative.
    try:
        if getattr(sys, "stdout", None) is not None:
            try:
                print(line, flush=True)
            except UnicodeEncodeError:
                enc = getattr(sys.stdout, "encoding", None) or "ascii"
                safe = line.encode(enc, errors="replace").decode(enc, errors="replace")
                print(safe, flush=True)
    except Exception:
        pass
    try:
        with _log_lock:
            with _SESSION_LOG.open("a", encoding="utf-8") as fh:
                fh.write(line + "\n")
            with _APP_ACTIVITY_LOG.open("a", encoding="utf-8") as fh:
                fh.write(line + "\n")
    except Exception:
        pass


def note_issue(code: str, message: str, severity: str = "WARN", details: str = "", throttle: float = 5.0) -> None:
    now = time.time()
    with _issue_lock:
        last = _issue_last.get(code, 0.0)
        if throttle and last and now - last < throttle:
            return
        _issue_last[code] = now
        _issues.append({
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "severity": severity, "code": code, "message": message,
            "details": str(details)[:1000],
        })
    log(f"{severity} [{code}] {message}" + (f" | {str(details)[:300]}" if details else ""))


def capture_diagnostic(label: str, min_interval: float = 8.0) -> str:
    """Save a full-screen diagnostic image without interrupting the bot."""
    global _last_diag_shot
    now = time.time()
    if _last_diag_shot and now - _last_diag_shot < min_interval:
        return ""
    _last_diag_shot = now
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(label))[:60] or "diagnostic"
    path = _REPORT_DIR / f"Adeon {SESSION_ID}_{datetime.now().strftime('%H%M%S')}_{safe}.png"
    try:
        pyautogui.screenshot(str(path))
        log(f"Diagnostic screenshot saved: {path}")
        return str(path)
    except Exception as e:
        log(f"Diagnostic screenshot failed: {e}")
        return ""


def update_last_state(snap: dict | None = None, **extra) -> None:
    if snap:
        _last_state.update({
            "url": str(snap.get("url") or "")[:300],
            "page_title": str(snap.get("pageTitle") or "")[:200],
            "rows_seen": len(snap.get("rows") or []),
            "panel_open": bool(snap.get("panelOpen")),
            "reserve_visible": bool(snap.get("reserve")),
            "accept_visible": bool(snap.get("accept")),
            "reject_visible": bool(snap.get("reject")),
            "reserve_disabled": bool(snap.get("reserveDisabled")),
            "accepted_gone": bool(snap.get("acceptedGone")),
            "panel_text_excerpt": str(snap.get("panelText") or "")[:500].replace("\\n", " "),
            "last_good_dom": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        })
    _last_state.update(extra)


def write_shutdown_report(reason: str | None = None) -> str:
    global _report_written
    if _report_written:
        return str(_REPORT_VISIBLE if _REPORT_VISIBLE.exists() else _REPORT_LOCAL)
    _report_written = True
    ended = time.time()
    duration = max(0.0, ended - SESSION_STARTED_AT)
    early_exit = duration < 5.0 and int(_stats.get("dom_reads", 0)) == 0
    status = "REVIEW NEEDED" if (early_exit or any(str(i.get("severity", "")).upper() in ("WARN", "ERROR") for i in _issues)) else "NO ACTIONABLE ANOMALIES RECORDED"
    lines = [
        "LR WRITERS BOT SESSION REPORT", "=" * 30,
        f"Session: {SESSION_ID}",
        f"Started: {datetime.fromtimestamp(SESSION_STARTED_AT).strftime('%Y-%m-%d %H:%M:%S')}",
        f"Ended: {datetime.fromtimestamp(ended).strftime('%Y-%m-%d %H:%M:%S')}",
        f"Duration: {duration / 60:.1f} minutes",
        f"Stop reason: {reason or _stop_reason}", f"Status: {status}", "",
        "CONFIGURATION", f"Minimum A+ level earns: ${MIN_PAY:.2f}",
        f"Fast refresh: {RELOAD_FAST[0]:.1f}-{RELOAD_FAST[1]:.1f}s x {RELOAD_FAST_N}",
        f"Slow refresh: {RELOAD_SLOW[0]:.1f}-{RELOAD_SLOW[1]:.1f}s x {RELOAD_SLOW_N}",
        f"Absolute minimum between any two F5 presses: {F5_HARD_MIN_GAP:.1f}s",
        f"Normal F5 range: {min(RELOAD_FAST[0], RELOAD_SLOW[0]):.1f}-{max(RELOAD_FAST[1], RELOAD_SLOW[1]):.1f}s",
        "Reserved F5: held completely until the reservation ends",
        "Allowed physical clicks: order row, Reserve, midnight-rule Reject, and DOM-verified inert background idle clicks",
        "Same order row: one successful physical click maximum per session",
        "Accept click: forbidden by code; trusted manual Accept is only observed",
        f"Idle mouse rhythm: active 5 min, then rests randomly {IDLE_REST[0]/60:.0f}-{IDLE_REST[1]/60:.0f} min; job clicks/F5 continue",
        f"Midnight rule: {MIDNIGHT_RULE_START_HOUR:02d}:00-{MIDNIGHT_RULE_END_HOUR:02d}:00 local; if remaining time is under {MIDNIGHT_REJECT_UNDER_MINUTES/60:.0f}h, Reject after {MIDNIGHT_REJECT_AFTER/60:.0f} min reserved",
        "Control: Alt+S toggles the active bot session START/STOP; there is no pause mode",
        "Logout safety: active session stops immediately; no automatic navigation/login/F5/mouse action occurs while stopped",
        "Alerts: unique per reservation and delivered in background so they do not pause F5", "", "COUNTERS",
    ]
    for key in sorted(_stats): lines.append(f"{key}: {_stats[key]}")
    lines += ["", "LAST KNOWN STATE"]
    if _last_state:
        for key in sorted(_last_state): lines.append(f"{key}: {_last_state[key]}")
    else:
        lines.append("No valid DOM snapshot was recorded.")
    lines += ["", f"ANOMALIES / NOTES ({len(_issues)})"]
    if _issues:
        for i, item in enumerate(_issues, 1):
            lines.append(f"{i}. [{item['time']}] {item['severity']} {item['code']} - {item['message']}")
            if item.get("details"): lines.append(f"   Details: {item['details']}")
    else:
        lines.append("None recorded.")

    if early_exit:
        lines += [
            "",
            "EARLY EXIT DIAGNOSTIC",
            "The worker ended before it completed a single DOM read.",
            "This report is intentionally marked REVIEW NEEDED even if no exception was recorded.",
        ]

    # Make the one report fully self-contained. Users should never need to hunt
    # for a separate .log file just to diagnose a failure.
    try:
        session_text = _SESSION_LOG.read_text(encoding="utf-8", errors="replace").strip()
    except Exception as e:
        session_text = f"(session log could not be read: {e})"
    if not session_text:
        session_text = "(no session log lines were recorded)"

    try:
        activity_lines = _APP_ACTIVITY_LOG.read_text(encoding="utf-8", errors="replace").splitlines()
        activity_tail = "\n".join(activity_lines[-120:]).strip()
    except Exception as e:
        activity_tail = f"(activity log could not be read: {e})"
    if not activity_tail:
        activity_tail = "(no activity log lines were recorded)"

    lines += [
        "", "FULL SESSION LOG (EMBEDDED)", session_text,
        "", "ACTIVITY LOG TAIL (LAST 120 LINES)", activity_tail,
        "", "REPORT / LOG FILE LOCATIONS",
        f"Visible report folder (same folder as Adeon setup): {_VISIBLE_REPORT_DIR}",
        f"Visible report: {_REPORT_VISIBLE}",
        f"Session log: {_SESSION_LOG}",
        f"Activity log: {_APP_ACTIVITY_LOG}",
        "",
        "This report already contains the diagnostic log needed for review.",
    ]
    text = "\n".join(lines) + "\n"
    paths=[]
    try:
        _REPORT_LOCAL.write_text(text, encoding="utf-8"); paths.append(_REPORT_LOCAL)
    except Exception:
        pass
    try:
        _VISIBLE_REPORT_DIR.mkdir(parents=True, exist_ok=True)
        _REPORT_VISIBLE.write_text(text, encoding="utf-8"); paths.append(_REPORT_VISIBLE)
    except Exception as e:
        try:
            with _SESSION_LOG.open("a", encoding="utf-8") as fh:
                fh.write(f"Report copy to setup folder failed: {e}\n")
        except Exception:
            pass
    result=str(paths[-1] if paths else _REPORT_LOCAL)
    try:
        if getattr(sys, "stdout", None) is not None:
            print(f"\nSession report saved: {result}", flush=True)
            print(f"Full session log: {_SESSION_LOG}", flush=True)
    except Exception:
        pass
    return result


def request_stop(reason: str = "") -> None:
    """Stop the active session without overwriting a more specific stop reason."""
    global _stop, _stop_reason
    wanted = str(reason or "").strip()
    if wanted:
        _stop_reason = wanted
    elif not str(_stop_reason or "").strip() or _stop_reason == "normal shutdown":
        _stop_reason = "Ctrl+C / console exit requested"
    _stop = True
    _controller_exit.set()


def hard_stop_logout(reason: str = "LR Writers logout detected") -> None:
    """Terminate this bot session immediately when LR Writers is logged out.

    No automatic navigation/login attempt is made. The active worker ends and the
    controller remains inert at STOPPED so the user can log in manually and press
    Alt+S to start a fresh session.
    """
    global _stop, _stop_reason, _paused, _resume_requested, _resume_source
    if _stop:
        return
    with _pause_lock:
        _paused = False
        _resume_requested = False
        _resume_source = ""
    _stop_reason = reason or "LR Writers logout detected — hard stop"
    _stop = True
    record_stat("logout_stops")
    set_status_ticket(bot="STOPPED", page="LOGGED OUT", job="-", f5="OFF", mouse="OFF")
    log(f"LOGOUT HARD STOP: {_stop_reason}. No automatic login/navigation will be attempted. Log back in manually, then press Alt+S to start a fresh session.")


def soft_pause(reason: str, *, logout: bool = False) -> None:
    """Manual pause only: pause browser input without exiting so Ctrl+A or Alt+A can resume later."""
    global _paused, _pause_reason, _resume_requested
    with _pause_lock:
        if _paused:
            if reason:
                _pause_reason = reason
            return
        _paused = True
        _pause_reason = reason or "manual hotkey pause"
        _resume_requested = False
    record_stat("soft_pauses")
    if logout:
        record_stat("logout_pauses")
    set_status_ticket(bot="PAUSED", page="LOGGED OUT" if logout else "ONLINE", f5="PAUSED", mouse="PAUSED")
    log(f"SOFT PAUSE: {_pause_reason}. No F5, mouse movement, clicks, or new alerts will be started until Ctrl+A or Alt+A resumes on Find Orders.")


def request_pause_toggle(source: str = "Ctrl+A") -> None:
    """Manual hotkey pause/resume. Logout never uses this path; logout hard-stops."""
    global _resume_requested, _resume_source
    if _stop:
        return
    source = str(source or "hotkey")
    with _pause_lock:
        paused = bool(_paused)
        if paused:
            if _resume_requested:
                return
            _resume_requested = True
            _resume_source = source
    if paused:
        log(f"{source} detected while paused. Resume requested; bot will continue only if the controlled tab is back on Find Orders and not logged out.")
    else:
        soft_pause(f"{source} manual pause")


def request_ctrl_a_toggle() -> None:
    request_pause_toggle("Ctrl+A")


# Only a real Adeon app-worker session should generate a session report.
# Launching Adeon Bot.py directly merely redirects to Adeon.exe and must not
# create a misleading zero-action "normal shutdown" report.
if _APP_WORKER_MODE:
    atexit.register(write_shutdown_report)


# ---------------- Windows DPI + Chrome window ----------------
user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32

EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)


class RECT(ctypes.Structure):
    _fields_ = [
        ("left", ctypes.c_long),
        ("top", ctypes.c_long),
        ("right", ctypes.c_long),
        ("bottom", ctypes.c_long),
    ]


class POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


class MSG(ctypes.Structure):
    _fields_ = [
        ("hwnd", wintypes.HWND),
        ("message", wintypes.UINT),
        ("wParam", wintypes.WPARAM),
        ("lParam", wintypes.LPARAM),
        ("time", wintypes.DWORD),
        ("pt", POINT),
        ("lPrivate", wintypes.DWORD),
    ]


# Explicit signatures avoid handle truncation/argument ambiguity on 64-bit Windows.
try:
    user32.WindowFromPoint.argtypes = [POINT]
    user32.WindowFromPoint.restype = wintypes.HWND
    user32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
    user32.GetAncestor.restype = wintypes.HWND
    user32.SetWindowPos.argtypes = [
        wintypes.HWND, wintypes.HWND,
        ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.UINT,
    ]
    user32.SetWindowPos.restype = wintypes.BOOL
    user32.BringWindowToTop.argtypes = [wintypes.HWND]
    user32.BringWindowToTop.restype = wintypes.BOOL
    user32.SetForegroundWindow.argtypes = [wintypes.HWND]
    user32.SetForegroundWindow.restype = wintypes.BOOL
except Exception:
    pass


def dpi_aware() -> None:
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            user32.SetProcessDPIAware()
        except Exception:
            pass


def _cls(hwnd) -> str:
    buf = ctypes.create_unicode_buffer(256)
    user32.GetClassNameW(hwnd, buf, 256)
    return buf.value


def _title(hwnd) -> str:
    n = user32.GetWindowTextLengthW(hwnd)
    buf = ctypes.create_unicode_buffer(n + 1)
    user32.GetWindowTextW(hwnd, buf, n + 1)
    return buf.value


def _visible(hwnd) -> bool:
    return bool(user32.IsWindowVisible(hwnd))


def chrome_debug_pid(port: int | None = None) -> int:
    """Return the Windows PID that owns Adeon's current local Chrome DevTools port."""
    target_port = int(port or _debug_port or 0)
    if target_port <= 0:
        return 0
    needle = f":{target_port}"
    try:
        out = subprocess.run(
            ["netstat", "-ano", "-p", "tcp"],
            capture_output=True, text=True, timeout=3, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
        ).stdout
        for line in out.splitlines():
            up = line.upper()
            if needle not in line or "LISTENING" not in up:
                continue
            parts = line.split()
            if parts and parts[-1].isdigit():
                return int(parts[-1])
    except Exception:
        pass
    return 0


def _window_pid(hwnd: int) -> int:
    try:
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        return int(pid.value)
    except Exception:
        return 0


def find_chrome_main(preferred_title: str = "") -> int:
    """Return the Chrome window owned by Adeon's connected DevTools browser whenever possible."""
    exact_pid: list[int] = []
    likely_pid: list[int] = []
    any_pid: list[int] = []
    exact: list[int] = []
    likely: list[int] = []
    want = (preferred_title or "").strip().lower()
    target_pid = int(_debug_chrome_pid or 0)

    def cb(hwnd, _):
        if not _visible(hwnd) or "Chrome_WidgetWin_1" not in _cls(hwnd):
            return True
        h = int(hwnd)
        title = _title(hwnd).lower()
        same_pid = bool(target_pid and _window_pid(h) == target_pid)
        is_exact = bool(want and want in title)
        is_likely = any(k in title for k in (
            "lrwriters", "lr writers", "find orders", "findorders",
            "myaccount", "livingston", "irlwriters"
        ))
        if same_pid:
            any_pid.append(h)
            if is_exact:
                exact_pid.append(h)
            if is_likely:
                likely_pid.append(h)
        if is_exact:
            exact.append(h)
        if is_likely:
            likely.append(h)
        return True

    user32.EnumWindows(EnumWindowsProc(cb), 0)
    # A PID match is strongest. Title is only the fallback when PID discovery fails.
    return (exact_pid or likely_pid or any_pid or exact or likely or [0])[0]


def find_render(parent: int) -> int:
    found: list[int] = []

    def cb(hwnd, _):
        if _cls(hwnd) == "Chrome_RenderWidgetHostHWND" and _visible(hwnd):
            found.append(int(hwnd))
        return True

    if parent:
        user32.EnumChildWindows(parent, EnumWindowsProc(cb), 0)
    best, area = 0, 0
    for h in found:
        r = RECT()
        user32.GetClientRect(h, ctypes.byref(r))
        a = max(0, r.right - r.left) * max(0, r.bottom - r.top)
        if a > area:
            best, area = h, a
    return best


def render_origin(hwnd: int) -> tuple[int, int]:
    pt = POINT(0, 0)
    user32.ClientToScreen(hwnd, ctypes.byref(pt))
    return int(pt.x), int(pt.y)


def focus_hwnd(hwnd: int) -> None:
    """Bring Chrome forward without changing its size/state or synthesizing Alt keys."""
    if not hwnd:
        return
    attached = []
    try:
        fg = int(user32.GetForegroundWindow() or 0)
        fg_tid = int(user32.GetWindowThreadProcessId(fg, None) or 0)
        target_tid = int(user32.GetWindowThreadProcessId(hwnd, None) or 0)
        my_tid = int(kernel32.GetCurrentThreadId())
        for tid in {fg_tid, target_tid}:
            if tid and tid != my_tid:
                try:
                    if user32.AttachThreadInput(my_tid, tid, True):
                        attached.append(tid)
                except Exception:
                    pass

        # IMPORTANT: SW_RESTORE (9) was restoring a maximized browser immediately
        # before a click. That changed the viewport after the DOM coordinates had
        # already been read and caused the mouse to tap the wrong place.
        if bool(user32.IsIconic(hwnd)):
            user32.ShowWindow(hwnd, 9)  # restore only when genuinely minimized
        else:
            user32.ShowWindow(hwnd, 5)  # SW_SHOW; preserve current size/state

        user32.BringWindowToTop(hwnd)
        user32.SetForegroundWindow(hwnd)
    except Exception:
        try:
            if bool(user32.IsIconic(hwnd)):
                user32.ShowWindow(hwnd, 9)
            else:
                user32.ShowWindow(hwnd, 5)
            user32.BringWindowToTop(hwnd)
            user32.SetForegroundWindow(hwnd)
        except Exception:
            pass
    finally:
        try:
            my_tid = int(kernel32.GetCurrentThreadId())
            for tid in attached:
                user32.AttachThreadInput(my_tid, tid, False)
        except Exception:
            pass


def _root_window_at(x: int, y: int) -> int:
    """Return the top-level window that would receive a physical click at x,y."""
    try:
        pt = POINT(int(x), int(y))
        hit = int(user32.WindowFromPoint(pt) or 0)
        if not hit:
            return 0
        return int(user32.GetAncestor(hit, GA_ROOT) or hit)
    except Exception:
        return 0


def _prepare_chrome_for_physical_click(main: int, x: int, y: int, label: str) -> bool:
    """Temporarily put Chrome above topmost terminals and verify click ownership."""
    if not main:
        return False
    try:
        if bool(user32.IsIconic(main)):
            user32.ShowWindow(main, 9)
        else:
            user32.ShowWindow(main, 5)
        user32.SetWindowPos(
            main, HWND_TOPMOST, 0, 0, 0, 0,
            SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW,
        )
        focus_hwnd(main)
        time.sleep(0.055)
        root = _root_window_at(x, y)
        if root != int(main):
            occ_title = _title(root) if root else "unknown"
            occ_cls = _cls(root) if root else "unknown"
            shot = capture_diagnostic("click_occluded", min_interval=3.0)
            note_issue(
                "CLICK_OCCLUDED",
                "Physical click was blocked because another window still covered the target",
                "ERROR",
                f"label={label} point=({x},{y}) expected_hwnd={main} actual_hwnd={root} "
                f"actual_class={occ_cls} actual_title={occ_title!r} screenshot={shot}",
                throttle=3.0,
            )
            return False
        return True
    except Exception as e:
        note_issue(
            "CLICK_WINDOW_PREP_FAILED",
            "Could not safely expose Chrome for the physical click",
            "ERROR",
            str(e),
            throttle=3.0,
        )
        return False


def _release_chrome_topmost(main: int) -> None:
    if not main:
        return
    try:
        user32.SetWindowPos(
            main, HWND_NOTOPMOST, 0, 0, 0, 0,
            SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW,
        )
    except Exception:
        pass

def install_ctrl_c() -> None:
    global _ctrl_handler_ref
    try:
        signal.signal(signal.SIGINT, request_stop)
    except Exception:
        pass
    if sys.platform == "win32":
        try:
            signal.signal(signal.SIGBREAK, request_stop)
        except Exception:
            pass
        Handler = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_uint)

        def _handler(ctrl):
            request_stop()
            return True

        _ctrl_handler_ref = Handler(_handler)
        kernel32.SetConsoleCtrlHandler(_ctrl_handler_ref, True)


def request_alt_s_toggle() -> None:
    """Alt+S is the only normal bot control: START when stopped, STOP when active."""
    global _stop, _stop_reason, _controller_active
    with _controller_lock:
        active = bool(_controller_active and _controller_worker and _controller_worker.is_alive())
        if active:
            _stop_reason = "Alt+S stop requested"
            _stop = True
            # Show the requested red STOPPED state immediately. The worker then
            # finishes its cleanup/report without performing another web action.
            set_status_ticket(bot="STOPPED", page="OFF", job="-", f5="OFF", mouse="OFF")
            log("ALT+S: STOP requested. Bot web activity is stopping now.")
        else:
            _controller_start_requested.set()
            log("ALT+S: START requested.")


def start_alt_s_monitor() -> threading.Thread:
    """Reserve Alt+S globally so the same key combination toggles START/STOP."""
    HOTKEY_ID = 0x4C54  # LT
    MOD_ALT = 0x0001
    MOD_NOREPEAT = 0x4000
    VK_S = 0x53
    WM_HOTKEY = 0x0312

    def worker() -> None:
        registered = False
        try:
            registered = bool(user32.RegisterHotKey(None, HOTKEY_ID, MOD_ALT | MOD_NOREPEAT, VK_S))
            if not registered:
                log("ERROR: Could not reserve Alt+S globally. Another program may already own that hotkey.")
                return
            msg = MSG()
            while not _controller_exit.is_set():
                result = int(user32.GetMessageW(ctypes.byref(msg), None, 0, 0))
                if result <= 0:
                    break
                if int(msg.message) == WM_HOTKEY and int(msg.wParam) == HOTKEY_ID:
                    request_alt_s_toggle()
        except Exception as e:
            log(f"ERROR: Global Alt+S monitor failed: {e}")
        finally:
            if registered:
                try:
                    user32.UnregisterHotKey(None, HOTKEY_ID)
                except Exception:
                    pass

    t = threading.Thread(target=worker, name="LR-AltS-StartStop", daemon=True)
    t.start()
    return t


# ---------------- brain (DOM) ----------------
SCAN_JS = r"""
() => {
  // Passive click audit only. It never blocks, changes, or creates a click.
  // It lets the log prove whether Chrome received a native/trusted click.
  if (!window.__lrBotClickAuditInstalled) {
    window.__lrBotClickAuditInstalled = true;
    window.__lrBotLastClick = null;
    try {
      const saved = sessionStorage.getItem("__lrBotLastClick");
      if (saved) window.__lrBotLastClick = JSON.parse(saved);
    } catch (_) {}
    document.addEventListener("click", (ev) => {
      try {
        const path = (typeof ev.composedPath === "function") ? ev.composedPath() : [ev.target];
        const clickable = path.find((e) => e && e.nodeType === 1 && e.matches &&
          e.matches('button, a, [role="button"], input[type="button"]'));
        const el = clickable || ev.target;
        const text = String((el && (el.innerText || el.value)) || "").replace(/\s+/g, " ").trim();
        window.__lrBotLastClick = {
          ts: Date.now(),
          trusted: !!ev.isTrusted,
          text: text.slice(0, 120),
          tag: String((el && el.tagName) || ""),
          clientX: Number(ev.clientX || 0),
          clientY: Number(ev.clientY || 0),
          screenX: Number(ev.screenX || 0),
          screenY: Number(ev.screenY || 0)
        };
        try { sessionStorage.setItem("__lrBotLastClick", JSON.stringify(window.__lrBotLastClick)); } catch (_) {}
      } catch (_) {}
    }, true);
  }

  const vp = (el) => {
    if (!el) return null;
    const r = el.getBoundingClientRect();
    if (r.width < 6 || r.height < 6) return null;
    if (r.bottom < 0 || r.top > (window.innerHeight || 0)) return null;
    return {
      vx: r.left + r.width / 2,
      vy: r.top + r.height / 2,
      w: r.width,
      h: r.height,
      top: r.top,
      left: r.left
    };
  };
  const chromeLeft = Math.max(0, (window.outerWidth - window.innerWidth) / 2);
  const chromeTop = Math.max(0, window.outerHeight - window.innerHeight);
  const screenOf = (p) => {
    if (!p) return null;
    return {
      ...p,
      sx: Math.round(window.screenX + chromeLeft + p.left + p.w / 2),
      sy: Math.round(window.screenY + chromeTop + p.top + p.h / 2)
    };
  };
  const exactBtns = (label) => {
    const want = String(label).toLowerCase();
    return [...document.querySelectorAll('button, a, [role="button"], input[type="button"]')].filter((el) => {
      const t = (el.innerText || el.value || "").replace(/\s+/g, " ").trim().toLowerCase();
      return t === want || t === want + " order";
    });
  };
  const rightmost = (els) => {
    const live = els.filter((el) => {
      const r = el.getBoundingClientRect();
      return r.width >= 8 && r.height >= 10 && r.bottom > 20;
    });
    if (!live.length) return null;
    live.sort((a, b) => b.getBoundingClientRect().x - a.getBoundingClientRect().x);
    return live[0];
  };
  const navPos = (label) => {
    const want = String(label).toLowerCase();
    const el = [...document.querySelectorAll("a, button, span")].find((e) => {
      const t = (e.innerText || "").replace(/\s+/g, " ").trim().toLowerCase();
      return t === want;
    });
    return vp(el);
  };
  const moneyValue = (text) => {
    const m = String(text || "").match(/\$\s*([0-9]+(?:\.[0-9]{1,2})?)/);
    return m ? parseFloat(m[1]) : 0;
  };
  const parseAPlusPay = (row, text) => {
    // The $6 eligibility rule is based ONLY on the A+ level earns column.
    // Prefer an explicitly labelled cell/element when the site exposes one.
    const labelled = [...row.querySelectorAll('[aria-label], [title], [data-label], [data-title], [headers]')];
    for (const el of labelled) {
      const label = [
        el.getAttribute('aria-label') || '',
        el.getAttribute('title') || '',
        el.getAttribute('data-label') || '',
        el.getAttribute('data-title') || '',
        el.getAttribute('headers') || ''
      ].join(' ').replace(/\s+/g, ' ').trim().toLowerCase();
      if (label.includes('a+ level earns') || label.includes('a + level earns')) {
        const v = moneyValue(el.innerText || el.textContent || '');
        if (v > 0) return v;
      }
    }

    // LR Writers displays You'll earn first and A+ level earns second.
    // If semantic labels are absent, use the SECOND dollar amount from the row,
    // never the first/lowest amount.
    const vals = [];
    const re = /\$\s*([0-9]+(?:\.[0-9]{1,2})?)/g;
    let m;
    while ((m = re.exec(text || ''))) vals.push(parseFloat(m[1]));
    if (vals.length >= 2) return vals[1];
    // If A+ cannot be identified, do not substitute You'll earn. Treat it as
    // not eligible until the A+ value is actually available in the row.
    return 0;
  };
  const rows = [];
  document.querySelectorAll(".table-row.row.vertical, .table-row.row").forEach((row) => {
    const text = (row.innerText || "").replace(/\s+/g, " ").trim();
    const rawText = (row.textContent || "").replace(/\s+/g, " ").trim();
    const metaText = [...row.querySelectorAll("[title], [aria-label], time")].map((el) => {
      return [el.getAttribute("title") || "", el.getAttribute("aria-label") || "", el.getAttribute("datetime") || "", el.textContent || ""].join(" ");
    }).join(" ").replace(/\s+/g, " ").trim();
    const deadlineText = [text, rawText, metaText].filter(Boolean).join(" | ").slice(0, 900);
    const low = text.toLowerCase();
    if (!text) return;
    if (low.includes("order number") && low.includes("you'll earn")) return;
    if (low.startsWith("order number")) return;
    const link = row.querySelector('a[href*="/order/"]');
    const href = link ? String(link.href || "") : "";
    const id = (href.match(/\/order\/([^/?#]+)/i) || [])[1] || "";
    const orderNo = (text.match(/\b[A-Z]{1,6}\d{6,}-\d+\b/i) || [])[0] || "";
    const p = vp(row);
    if (!p || p.top < 70) return;
    const clickP = {
      ...p,
      vx: p.left + Math.min(Math.max(p.w * 0.28, 80), 240),
      vy: p.top + p.h * 0.55
    };
    const sp = screenOf(clickP);
    rows.push({
      id,
      orderNo,
      text: text.slice(0, 180),
      deadlineText,
      pay: parseAPlusPay(row, text),
      tutor: low.includes("tutoring order") || /(^|[^a-z])tutor(ing)?([^a-z]|$)/.test(low),
      vx: sp.vx,
      vy: sp.vy,
      // Keep the original row rectangle as well as the chosen click point.
      // The physical-mouse safety layer needs these fields to prove that
      // the mapped click still lies inside this exact row.
      left: p.left,
      top: p.top,
      w: p.w,
      h: p.h,
      sx: sp.sx,
      sy: sp.sy
    });
  });
  const reserveBtn = rightmost(exactBtns("reserve"));
  const acceptBtn = rightmost(exactBtns("accept"));
  const rejectBtn = rightmost(exactBtns("reject"));
  const reserveDisabled = !!(
    reserveBtn && (reserveBtn.disabled || reserveBtn.getAttribute("disabled") != null)
  );
  const root = reserveBtn || acceptBtn || rejectBtn;
  const panel = root
    ? (root.closest(".order-tab-container, .order-tab, .drawer, aside, [class*='order']") || root.parentElement)
    : null;
  const panelText = panel ? String(panel.innerText || "") : "";

  // Reserved-panel inspection helpers. These expose only geometry/state; Python
  // performs the visible wheel/click actions and revalidates before each action.
  let panelScroll = null;
  let filesToggle = null;
  if (panel) {
    const candidates = [panel, ...panel.querySelectorAll("div, section, aside")];
    const scrollables = candidates.filter((el) => {
      try {
        const r = el.getBoundingClientRect();
        const cs = getComputedStyle(el);
        const oy = String(cs.overflowY || "");
        return r.width > 120 && r.height > 120 && r.bottom > 80 && r.top < window.innerHeight &&
          el.scrollHeight > el.clientHeight + 30 && /(auto|scroll)/i.test(oy);
      } catch (e) { return false; }
    });
    const scrollEl = scrollables.sort((a,b) => b.clientHeight - a.clientHeight)[0] || panel;
    try {
      const r = scrollEl.getBoundingClientRect();
      if (r.width > 80 && r.height > 80) {
        panelScroll = {
          vx: Math.max(r.left + 20, r.right - 28),
          vy: Math.max(r.top + 30, Math.min(r.bottom - 30, r.top + r.height * 0.52)),
          left:r.left, top:r.top, w:r.width, h:r.height,
          scrollTop:Number(scrollEl.scrollTop || 0),
          scrollHeight:Number(scrollEl.scrollHeight || 0),
          clientHeight:Number(scrollEl.clientHeight || 0)
        };
      }
    } catch (e) {}

    const toggleCandidates = [...panel.querySelectorAll('button, [role="button"], [aria-expanded]')].filter((el) => {
      try {
        if (el.closest('a[href]')) return false;
        const r = el.getBoundingClientRect();
        if (r.width < 20 || r.height < 12 || r.bottom < 70 || r.top > window.innerHeight) return false;
        const t = (el.innerText || el.textContent || '').replace(/\s+/g,' ').trim().toLowerCase();
        return t === 'files' || t === 'order files' || t === 'additional materials' ||
               t.startsWith('order files ') || t.startsWith('files ');
      } catch (e) { return false; }
    });
    if (toggleCandidates.length) {
      const el = toggleCandidates[0];
      const p = vp(el);
      if (p) {
        filesToggle = screenOf({ ...p, text:(el.innerText || el.textContent || '').replace(/\s+/g,' ').trim().slice(0,80), expanded:el.getAttribute('aria-expanded') });
      }
    }
  }

  const bodyText = String(document.body ? document.body.innerText : "");
  const url = location.href;
  let urlId = "";
  const mAll = url.match(/\/findorders\/all\/([^/?#]+)/i);
  const mOrd = url.match(/\/order\/([^/?#]+)/i);
  if (mAll && mAll[1] && mAll[1].toLowerCase() !== "all") urlId = mAll[1];
  else if (mOrd) urlId = mOrd[1];
  const acceptedGone = /upload final file|already accepted|you accepted|successfully accepted/i.test(
    bodyText + " " + panelText
  );
  const hasPasswordInput = !!document.querySelector('input[type="password"]');
  const loginUrl = /\/(?:login|log-in|signin|sign-in|auth)(?:[\/?#]|$)/i.test(url);
  const loginWords = /\b(?:log\s*in|sign\s*in)\b/i.test(bodyText);
  const loggedOut = !!(loginUrl || (hasPasswordInput && loginWords));

  // Safe idle points. These are deliberately NOT arbitrary page points.
  // Sample across the visible webpage and keep only coordinates whose
  // DOM target is non-interactive, outside order rows, and outside the
  // currently open order panel.
  const idleMovePoints = [];
  const idleClickPoints = [];
  const interactiveSel = [
    "a", "button", "input", "textarea", "select", "option",
    "[role='button']", "[role='link']", "[onclick]", "[contenteditable='true']",
    ".table-row.row", ".table-row.row.vertical"
  ].join(",");
  const pointSafe = (x, y) => {
    const el = document.elementFromPoint(x, y);
    if (!el) return null;
    if (el.closest && el.closest(interactiveSel)) return null;
    if (panel && panel.contains(el)) return null;
    const cs = getComputedStyle(el);
    if (!cs || cs.pointerEvents === "none" || cs.visibility === "hidden") return null;
    return el;
  };
  const clickTagOK = (el) => {
    if (!el) return false;
    const tag = String(el.tagName || "").toLowerCase();
    if (!["body", "main", "section", "div", "article"].includes(tag)) return false;
    const cs = getComputedStyle(el);
    if (cs && (cs.cursor === "pointer" || cs.cursor === "text")) return false;
    return true;
  };
  const xs = [0.10, 0.24, 0.38, 0.52, 0.66, 0.80, 0.92];
  const ys = [0.16, 0.28, 0.40, 0.52, 0.64, 0.76, 0.88];
  for (const xf of xs) {
    for (const yf of ys) {
      const x = Math.round(window.innerWidth * xf);
      const y = Math.round(window.innerHeight * yf);
      if (y < 120) continue;
      const el = pointSafe(x, y);
      if (!el) continue;
      idleMovePoints.push({vx:x, vy:y, tag:String(el.tagName || ""), cls:String(el.className || "").slice(0,80)});
      if (clickTagOK(el)) {
        idleClickPoints.push({vx:x, vy:y, tag:String(el.tagName || ""), cls:String(el.className || "").slice(0,80)});
      }
    }
  }

  return {
    url,
    urlId,
    pageTitle: document.title || "",
    innerW: window.innerWidth,
    innerH: window.innerHeight,
    rows,
    reserve: reserveDisabled ? null : screenOf(vp(reserveBtn)),
    accept: screenOf(vp(acceptBtn)),
    reject: screenOf(vp(rejectBtn)),
    reserveDisabled,
    panelOpen: !!(reserveBtn || acceptBtn || rejectBtn),
    panelText: panelText.slice(0, 16000),
    panelScroll,
    filesToggle,
    acceptedGone,
    loggedOut,
    bodyText: bodyText.slice(0, 1200),
    bodyTextExcerpt: bodyText.slice(0, 1000),
    lastClick: window.__lrBotLastClick || null,
    navFind: navPos("find orders"),
    navMy: navPos("my orders"),
    onFind: /\/findorders\//i.test(url),
    idleMovePoints,
    idleClickPoints
  };
}
"""


def chrome_user_data_dirs() -> list[Path]:
    """Likely DevTools user-data roots, with Adeon's managed Chrome first."""
    local = Path(os.environ.get("LOCALAPPDATA", ""))
    candidates = [
        _ADEON_CHROME_DATA,
        local / "Google" / "Chrome" / "User Data",
        local / "Google" / "Chrome Beta" / "User Data",
        local / "Google" / "Chrome Dev" / "User Data",
        local / "Google" / "Chrome SxS" / "User Data",
    ]
    out: list[Path] = []
    seen: set[str] = set()
    for item in candidates:
        key = os.path.normcase(os.path.abspath(str(item)))
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    return out


def _endpoint_http_live(port: int) -> bool:
    if int(port or 0) <= 0:
        return False
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{int(port)}/json/version", timeout=1.5) as r:
            return 200 <= int(getattr(r, "status", 200)) < 500
    except Exception:
        return False


def discover_chrome_debug_endpoint() -> tuple[str, int, str]:
    """Find a live local Chrome DevTools endpoint without navigating the browser."""
    global _debug_port, _debug_endpoint, _debug_user_data_dir

    for user_dir in chrome_user_data_dirs():
        active = user_dir / "DevToolsActivePort"
        try:
            if not active.is_file():
                continue
            lines = [x.strip() for x in active.read_text(encoding="utf-8", errors="ignore").splitlines() if x.strip()]
            if len(lines) < 2:
                continue
            port = int(lines[0])
            path = lines[1]
            if not (1 <= port <= 65535) or not path.startswith("/"):
                continue
            if not _endpoint_http_live(port):
                continue
            endpoint = f"ws://127.0.0.1:{port}{path}"
            _debug_port = port
            _debug_endpoint = endpoint
            _debug_user_data_dir = str(user_dir)
            return endpoint, port, str(user_dir)
        except Exception:
            continue

    # Compatibility fallback for a manually configured Chrome.
    if _endpoint_http_live(9222):
        try:
            with urllib.request.urlopen("http://127.0.0.1:9222/json/version", timeout=1.5) as r:
                info = json.loads(r.read().decode("utf-8", "ignore") or "{}")
            endpoint = str(info.get("webSocketDebuggerUrl") or "http://127.0.0.1:9222")
        except Exception:
            endpoint = "http://127.0.0.1:9222"
        _debug_port = 9222
        _debug_endpoint = endpoint
        _debug_user_data_dir = "manual-9222"
        return endpoint, 9222, "manual-9222"

    _debug_port = 0
    _debug_endpoint = ""
    _debug_user_data_dir = ""
    return "", 0, ""


def chrome_port_live() -> bool:
    endpoint, port, _ = discover_chrome_debug_endpoint()
    return bool(endpoint and port)


def find_chrome_exe() -> str:
    for path in (
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
    ):
        if os.path.isfile(path):
            return path
    return ""


def _chrome_browser_commandline() -> str:
    """Best-effort command line for Chrome's browser process (not renderer children)."""
    try:
        ps = (
            "$p=Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'chrome.exe' -and "
            "$_.CommandLine -and $_.CommandLine -notmatch '--type=' } | Select-Object -First 1; "
            "if($p){[Console]::Write($p.CommandLine)}"
        )
        cp = subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, timeout=4,
            creationflags=0x08000000,
        )
        return (cp.stdout or "").strip()
    except Exception:
        return ""


def _extract_switch(commandline: str, name: str) -> str:
    text = str(commandline or "")
    # Supports --name=value, --name="value with spaces", and --name value.
    patterns = [
        rf'--{re.escape(name)}=(?:"([^"]+)"|([^\s]+))',
        rf'--{re.escape(name)}\s+(?:"([^"]+)"|([^\s]+))',
    ]
    for pattern in patterns:
        m = re.search(pattern, text, re.I)
        if m:
            return next((g for g in m.groups() if g), "")
    return ""


def _normal_chrome_root_and_profile() -> tuple[Path | None, str]:
    """Locate the Chrome profile the user was using before Adeon restarts Chrome."""
    cmd = _chrome_browser_commandline()
    user_arg = _extract_switch(cmd, "user-data-dir")
    profile_arg = _extract_switch(cmd, "profile-directory")

    candidates: list[Path] = []
    if user_arg:
        candidates.append(Path(os.path.expandvars(user_arg)).expanduser())
    local = Path(os.environ.get("LOCALAPPDATA", ""))
    candidates.extend([
        local / "Google" / "Chrome" / "User Data",
        local / "Google" / "Chrome Beta" / "User Data",
        local / "Google" / "Chrome Dev" / "User Data",
        local / "Google" / "Chrome SxS" / "User Data",
    ])

    root = next((x for x in candidates if x.exists() and x.resolve() != _ADEON_CHROME_DATA.resolve()), None)
    if root is None:
        return None, "Default"

    profile = profile_arg.strip() if profile_arg else ""
    if not profile:
        try:
            state = json.loads((root / "Local State").read_text(encoding="utf-8", errors="ignore"))
            profile = str(((state.get("profile") or {}).get("last_used")) or "Default").strip()
        except Exception:
            profile = "Default"
    if not profile or not (root / profile).exists():
        profile = "Default" if (root / "Default").exists() else profile
    return root, profile or "Default"


def _chrome_running() -> bool:
    try:
        cp = subprocess.run(
            ["tasklist", "/FI", "IMAGENAME eq chrome.exe", "/FO", "CSV", "/NH"],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, timeout=3,
            creationflags=0x08000000,
        )
        out = (cp.stdout or "").lower()
        return "chrome.exe" in out
    except Exception:
        return False


def _close_chrome_windows_gracefully() -> None:
    """Ask visible Chrome windows to close so session/cookies are flushed before cloning."""
    try:
        WM_CLOSE = 0x0010
        EnumProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)

        def callback(hwnd, _lparam):
            try:
                cls = ctypes.create_unicode_buffer(256)
                user32.GetClassNameW(hwnd, cls, len(cls))
                if cls.value == "Chrome_WidgetWin_1" and user32.IsWindowVisible(hwnd):
                    user32.PostMessageW(hwnd, WM_CLOSE, 0, 0)
            except Exception:
                pass
            return True

        user32.EnumWindows(EnumProc(callback), 0)
    except Exception as e:
        log(f"Could not send Chrome a graceful close request: {e}")


def _wait_chrome_closed(timeout: float) -> bool:
    deadline = time.time() + max(0.5, timeout)
    while time.time() < deadline:
        if not _chrome_running():
            return True
        time.sleep(0.35)
    return not _chrome_running()


def _copy_profile_tree(source_root: Path, profile_name: str) -> bool:
    """Fast one-time bootstrap of login/session data into Adeon's CDP profile.

    The older build copied almost the whole Chrome profile and could spend minutes
    on cache, extensions, history, and other data Adeon does not need.  For the
    LR Writers hand-off we only copy the pieces that can carry the current profile
    identity, cookies/site storage and session state.  The user's original Chrome
    profile is never modified.
    """
    source_profile = source_root / profile_name
    if not source_profile.exists():
        log(f"Chrome profile bootstrap source is missing: {source_profile}")
        return False

    try:
        if _ADEON_CHROME_MARKER.exists() and (_ADEON_CHROME_DATA / profile_name).exists():
            log(f"Adeon Chrome profile already prepared ({profile_name}); preserving its current login/session.")
            return True
    except Exception:
        pass

    try:
        set_status_ticket(bot="STARTING", page="PREPARING CHROME", job="-", f5="OFF", mouse="OFF")
        started = time.time()
        log(f"Preparing fast Adeon Chrome profile from {source_profile}")
        _ADEON_CHROME_DATA.mkdir(parents=True, exist_ok=True)
        target_profile = _ADEON_CHROME_DATA / profile_name
        target_profile.mkdir(parents=True, exist_ok=True)

        # Chrome's encryption/profile metadata.  On the same Windows account this
        # lets the copied Cookies database remain usable when Chrome permits it.
        local_state = source_root / "Local State"
        if local_state.exists():
            shutil.copy2(local_state, _ADEON_CHROME_DATA / "Local State")

        # Small profile files that can matter for identity/login/site behavior.
        files = (
            "Preferences", "Secure Preferences", "Cookies", "Cookies-journal",
            "Login Data", "Login Data-journal", "Login Data For Account",
            "Web Data", "Web Data-journal", "Shortcuts", "Top Sites",
        )
        for name in files:
            src = source_profile / name
            dst = target_profile / name
            try:
                if src.is_file():
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(src, dst)
            except Exception as e:
                log(f"Fast profile copy skipped {name}: {e}")

        # Site/session storage.  These are normally far smaller than a full Chrome
        # profile and are the parts most likely to matter to an already logged-in
        # LR Writers session.
        dirs = (
            "Network", "Local Storage", "Session Storage", "WebStorage",
        )
        ignore = shutil.ignore_patterns(
            "Cache", "Code Cache", "GPUCache", "DawnCache", "GrShaderCache", "ShaderCache",
            "Crashpad", "BrowserMetrics", "Media Cache", "LOCK", "lockfile", "Singleton*", "*.tmp"
        )
        for name in dirs:
            src = source_profile / name
            dst = target_profile / name
            try:
                if src.is_dir():
                    shutil.copytree(src, dst, dirs_exist_ok=True, ignore=ignore)
            except Exception as e:
                log(f"Fast profile copy skipped {name}: {e}")

        # Copy only LR Writers-specific IndexedDB entries when present instead of
        # cloning every site's database. This keeps first activation fast.
        idx_src = source_profile / "IndexedDB"
        idx_dst = target_profile / "IndexedDB"
        try:
            if idx_src.is_dir():
                for child in idx_src.iterdir():
                    low = child.name.lower()
                    if "lrwriters" not in low and "liv-research" not in low:
                        continue
                    if child.is_dir():
                        shutil.copytree(child, idx_dst / child.name, dirs_exist_ok=True, ignore=ignore)
                    elif child.is_file():
                        idx_dst.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(child, idx_dst / child.name)
        except Exception as e:
            log(f"Fast profile copy skipped LR Writers IndexedDB: {e}")

        _write_json_atomic(_ADEON_CHROME_MARKER, {
            "source_root": str(source_root),
            "profile": profile_name,
            "prepared_at": time.time(),
            "mode": "fast-login-session-copy-v3-localappdata",
        })
        elapsed = time.time() - started
        log(f"Adeon Chrome profile prepared successfully in {elapsed:.1f}s: {target_profile}")
        return True
    except Exception as e:
        write_last_error("Adeon could not prepare the Chrome profile. See VIEW ACTIVITY LOG.")
        log(f"Chrome profile bootstrap failed: {e}")
        note_issue("CHROME_PROFILE_COPY", "Could not prepare Chrome profile for DevTools restart", "ERROR", str(e), throttle=0)
        return False


def _prepared_profile_name(default: str = "Default") -> str:
    try:
        data = json.loads(_ADEON_CHROME_MARKER.read_text(encoding="utf-8"))
        name = str(data.get("profile") or "").strip()
        if name and (_ADEON_CHROME_DATA / name).exists():
            return name
    except Exception:
        pass
    return default or "Default"


def start_chrome() -> bool:
    """
    Ensure a CDP-enabled Chrome exists.

    If the user's ordinary Chrome is open without DevTools, Adeon asks Chrome to
    close, makes a one-time local profile copy after Chrome has flushed its state,
    then reopens Chrome with a non-default Adeon user-data directory and a random
    localhost DevTools port. This keeps the same Chrome executable and carries the
    user's LR Writers login/session into the managed Chrome profile when Chrome's
    stored credentials permit it.
    """
    if discover_chrome_debug_endpoint()[0]:
        return True

    chrome = find_chrome_exe()
    if not chrome:
        write_last_error("Google Chrome was not found on this laptop.")
        note_issue("CHROME_NOT_FOUND", "Adeon could not find Google Chrome", "ERROR", throttle=0)
        return False

    source_root, source_profile = _normal_chrome_root_and_profile()
    prepared_profile = _prepared_profile_name(source_profile)

    # If this is the first Adeon Chrome setup, close normal Chrome first so its
    # Cookies/Sessions databases are complete before copying them.
    need_bootstrap = not (_ADEON_CHROME_MARKER.exists() and (_ADEON_CHROME_DATA / prepared_profile).exists())
    if need_bootstrap:
        if source_root is None:
            write_last_error("Adeon could not locate your existing Chrome profile.")
            note_issue("CHROME_PROFILE_MISSING", "Existing Chrome profile could not be located", "ERROR", throttle=0)
            return False

        if _chrome_running():
            set_status_ticket(bot="STARTING", page="RESTARTING CHROME", job="-", f5="OFF", mouse="OFF")
            log("Chrome has no DevTools link. Adeon is closing Chrome once so the current session can be preserved and restarted with CDP.")
            _close_chrome_windows_gracefully()
            if not _wait_chrome_closed(4.0):
                log("Chrome did not close after the normal window-close request; asking taskkill for a normal process shutdown.")
                try:
                    subprocess.run(["taskkill", "/IM", "chrome.exe", "/T"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5, creationflags=0x08000000)
                except Exception:
                    pass
            if not _wait_chrome_closed(2.0):
                log("Chrome was still running; forcing closure so the DevTools restart can complete.")
                try:
                    subprocess.run(["taskkill", "/F", "/IM", "chrome.exe", "/T"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5, creationflags=0x08000000)
                except Exception:
                    pass
            if not _wait_chrome_closed(2.0):
                write_last_error("Chrome could not be restarted because an existing Chrome process would not close.")
                note_issue("CHROME_CLOSE_FAILED", "Existing Chrome would not close for the DevTools restart", "ERROR", throttle=0)
                return False

        if not _copy_profile_tree(source_root, source_profile):
            return False
        prepared_profile = _prepared_profile_name(source_profile)
    else:
        # A prepared profile already exists. If normal Chrome is open, close it so
        # the user sees one Chrome experience rather than two competing windows.
        if _chrome_running():
            set_status_ticket(bot="STARTING", page="RESTARTING CHROME", job="-", f5="OFF", mouse="OFF")
            log("Chrome is open without Adeon's DevTools link. Closing it and reopening the prepared Adeon Chrome profile.")
            _close_chrome_windows_gracefully()
            if not _wait_chrome_closed(4.0):
                try:
                    subprocess.run(["taskkill", "/IM", "chrome.exe", "/T"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5, creationflags=0x08000000)
                except Exception:
                    pass
            if not _wait_chrome_closed(2.0):
                try:
                    subprocess.run(["taskkill", "/F", "/IM", "chrome.exe", "/T"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5, creationflags=0x08000000)
                except Exception:
                    pass
            if not _wait_chrome_closed(2.0):
                write_last_error("Chrome could not be restarted because an existing Chrome process would not close.")
                return False

    try:
        set_status_ticket(bot="STARTING", page="OPENING CHROME", job="-", f5="OFF", mouse="OFF")
        try:
            (_ADEON_CHROME_DATA / "DevToolsActivePort").unlink(missing_ok=True)
        except Exception:
            pass
        args = [
            chrome,
            "--remote-debugging-port=0",
            "--remote-debugging-address=127.0.0.1",
            f"--user-data-dir={_ADEON_CHROME_DATA}",
            f"--profile-directory={prepared_profile}",
            "--no-first-run",
            "--no-default-browser-check",
            FIND_ORDERS,
        ]
        subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, close_fds=True)
        log(f"Chrome restart launched with Adeon's DevTools profile ({prepared_profile}). Waiting for CDP...")
    except Exception as e:
        write_last_error("Adeon could not reopen Chrome with the DevTools connection.")
        note_issue("CHROME_START_FAILED", "Chrome could not be restarted with DevTools", "ERROR", str(e), throttle=0)
        return False

    deadline = time.time() + 25.0
    while time.time() < deadline and not _stop:
        endpoint, port, user_dir = discover_chrome_debug_endpoint()
        if endpoint and port:
            log(f"Adeon Chrome DevTools is ready on local port {port} ({user_dir}).")
            return True
        time.sleep(0.35)

    write_last_error("Chrome reopened, but its DevTools connection did not become ready. See VIEW ACTIVITY LOG.")
    note_issue("CHROME_CDP_TIMEOUT", "Chrome reopened but DevTools did not become ready", "ERROR", throttle=0)
    return False


class Brain:
    def __init__(self) -> None:
        self._pw = None
        self._browser = None
        self._page = None

    def attach(self) -> bool:
        if not HAS_PW:
            write_last_error("Playwright is missing. Re-run the Adeon installer.")
            log("Install playwright:  py -m pip install playwright")
            return False
        endpoint, port, user_dir = discover_chrome_debug_endpoint()
        if not endpoint:
            log("No usable DevTools endpoint is active. Adeon will prepare/restart Chrome automatically.")
            if not start_chrome():
                set_status_ticket(bot="STOPPED", page="CHROME START FAILED", job="-", f5="OFF", mouse="OFF")
                return False
            endpoint, port, user_dir = discover_chrome_debug_endpoint()
            if not endpoint:
                write_last_error("Adeon restarted Chrome, but could not find its DevTools connection.")
                return False
        global _debug_chrome_pid
        _debug_chrome_pid = chrome_debug_pid(port)
        log(f"Chrome DevTools endpoint found on local port {port} ({user_dir}).")
        if _debug_chrome_pid:
            log(f"Debug Chrome PID: {_debug_chrome_pid}")
        else:
            log(f"Warning: could not resolve DevTools port {port} PID; title matching will be used")
        try:
            self._pw = sync_playwright().start()
            cdp_url = f"http://127.0.0.1:{port}" if port else endpoint
            self._browser = self._pw.chromium.connect_over_cdp(cdp_url, timeout=8000)
            ctx = self._browser.contexts[0] if self._browser.contexts else None
            if not ctx or not ctx.pages:
                log("Chrome open but no tab. Open Find Orders first.")
                return False
            self._page = next((p for p in ctx.pages if "findorders" in (p.url or "").lower()), None)
            if not self._page:
                self._page = next((p for p in ctx.pages if "lrwriters" in (p.url or "").lower()), None)
            self._page = self._page or ctx.pages[0]
            log("Brain attached to " + self._page.url)
            # Keep the user's existing Chrome window size/state unchanged.
            return True
        except Exception as e:
            write_last_error("Adeon could not attach to the Chrome DevTools session. See VIEW ACTIVITY LOG.")
            log("Brain could not attach: " + str(e))
            return False

    def maximize(self) -> None:
        if not self._page:
            return
        try:
            cdp = self._page.context.new_cdp_session(self._page)
            info = cdp.send("Browser.getWindowForTarget")
            cdp.send(
                "Browser.setWindowBounds",
                {"windowId": info["windowId"], "bounds": {"windowState": "maximized"}},
            )
            log("Chrome window maximized")
        except Exception as e:
            log("CDP maximize failed: " + str(e)[:80])
        try:
            main, _ = chrome_handles()
            if main:
                # Keep the browser maximized. Do not immediately SW_RESTORE it.
                user32.ShowWindow(main, 3)
        except Exception:
            pass
        time.sleep(0.35)

    def reconnect(self) -> None:
        try:
            ctx = self._browser.contexts[0] if self._browser and self._browser.contexts else None
            if not ctx:
                return
            for p in ctx.pages:
                if "findorders" in (p.url or "").lower():
                    self._page = p
                    return
            for p in ctx.pages:
                if "lrwriters" in (p.url or "").lower():
                    self._page = p
                    return
            if ctx.pages:
                self._page = ctx.pages[0]
        except Exception:
            pass

    def read(self) -> dict:
        if not self._page:
            record_stat("brain_read_errors")
            note_issue("NO_ACTIVE_PAGE", "Brain has no active Chrome page", "ERROR")
            return {}
        try:
            snap = self._page.evaluate(SCAN_JS) or {}
            if snap:
                record_stat("dom_reads")
            return snap
        except Exception as e:
            msg = str(e)
            # F5 destroys the old JavaScript execution context for a moment.
            # That is expected navigation, not a Chrome/brain failure.
            navigation_reload = (
                "Execution context was destroyed" in msg
                or "Cannot find context with specified id" in msg
                or "Most likely the page has been closed" in msg and chrome_port_live()
            )
            if navigation_reload:
                note_issue(
                    "DOM_RELOADING",
                    "DOM was briefly unavailable during F5/navigation; the bot will read it again",
                    "INFO",
                    msg[:180],
                    throttle=60.0,
                )
                time.sleep(0.06)
                return {}

            record_stat("brain_read_errors")
            note_issue("BRAIN_READ_ERROR", "DOM read failed; reconnecting", "WARN", msg)
            record_stat("reconnects")
            self.reconnect()
            try:
                snap = self._page.evaluate(SCAN_JS) or {}
                if snap:
                    record_stat("dom_reads")
                return snap
            except Exception as e2:
                record_stat("brain_read_errors")
                note_issue("BRAIN_READ_RETRY_FAILED", "DOM read still failed after reconnect", "ERROR", str(e2))
                return {}

    def stay_on_find_orders(self) -> None:
        """Disabled by design: this bot never navigates LR Writers automatically."""
        if not self._page:
            return
        try:
            url = (self._page.url or "")
        except Exception:
            url = ""
        if "findorders" not in url.lower():
            note_issue("AUTO_NAV_DISABLED", "Automatic navigation is disabled; bot will not return to Find Orders or attempt login", "INFO", url[:250], throttle=30.0)

    def activate(self) -> str:
        """Bring the exact Playwright-controlled LR Writers tab/window to the front."""
        if not self._page:
            return ""
        title = ""
        try:
            self._page.bring_to_front()
            title = str(self._page.title() or "")
        except Exception:
            self.reconnect()
            try:
                if self._page:
                    self._page.bring_to_front()
                    title = str(self._page.title() or "")
            except Exception:
                return ""
        try:
            main = find_chrome_main(title)
            if main:
                focus_hwnd(main)
                time.sleep(0.03)
        except Exception:
            pass
        return title

    def validate_click(self, pos: dict | None, kind: str) -> bool:
        """Confirm stale coordinates still point at the intended DOM target before physical click."""
        if not self._page or not pos:
            return False
        try:
            vx = float(pos.get("vx"))
            vy = float(pos.get("vy"))
        except Exception:
            return False
        try:
            expected_id = str(pos.get("id") or "")
            expected_order = str(pos.get("orderNo") or "")
            expected_text = str(pos.get("text") or "")[:80]
            return bool(self._page.evaluate(
                """([x, y, kind, expectedId, expectedOrder, expectedText]) => {
                    const el = document.elementFromPoint(x, y);
                    if (!el) return false;
                    if (kind === 'reserve' || kind === 'midnight_reject') {
                        const b = el.closest('button, a, [role=\"button\"], input[type=\"button\"]');
                        if (!b) return false;
                        const t = (b.innerText || b.value || '').replace(/\\s+/g, ' ').trim().toLowerCase();
                        const disabled = !!(b.disabled || b.getAttribute('disabled') != null || b.getAttribute('aria-disabled') === 'true');
                        const want = kind === 'reserve' ? 'reserve' : 'reject';
                        return !disabled && (t === want || t === want + ' order');
                    }
                    if (kind === 'row') {
                        const row = el.closest('.table-row.row.vertical, .table-row.row');
                        if (!row) return false;
                        const link = row.querySelector('a[href*=\"/order/\"]');
                        const href = link ? String(link.href || '') : '';
                        if (expectedId) return href.includes('/order/' + expectedId);
                        if (expectedText) {
                            const actual = (row.innerText || '').replace(/\\s+/g, ' ').trim();
                            return actual.includes(expectedText.slice(0, 40));
                        }
                        return false;
                    }
                    if (kind === 'files_toggle') {
                        const b = el.closest('button, [role="button"], [aria-expanded]');
                        if (!b || b.closest('a[href]')) return false;
                        const t = (b.innerText || b.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
                        return t === 'files' || t === 'order files' || t === 'additional materials' ||
                               t.startsWith('order files ') || t.startsWith('files ');
                    }
                    if (kind === 'nav_my' || kind === 'nav_find') {
                        const want = kind === 'nav_my' ? 'my orders' : 'find orders';
                        let cur = el;
                        for (let i = 0; i < 5 && cur; i++, cur = cur.parentElement) {
                            const t = (cur.innerText || cur.textContent || '').replace(/\\s+/g, ' ').trim().toLowerCase();
                            if (t === want) return true;
                            const role = (cur.getAttribute && cur.getAttribute('role')) || '';
                            if ((cur.tagName === 'A' || cur.tagName === 'BUTTON' || role === 'button') && t.includes(want)) return true;
                        }
                        return false;
                    }
                    return false;
                }""",
                [vx, vy, kind, expected_id, expected_order, expected_text],
            ))
        except Exception:
            return False

    def close(self) -> None:
        try:
            if self._pw:
                self._pw.stop()
        except Exception:
            pass


# ---------------- motor ----------------
_enum_keep = []


def chrome_handles(preferred_title: str = "") -> tuple[int, int]:
    try:
        main = find_chrome_main(preferred_title)
        rend = find_render(main) if main else 0
        return main, rend
    except Exception:
        return 0, 0


def _screen_rect(hwnd: int) -> tuple[int, int, int, int] | None:
    """Return a window rectangle in physical screen pixels."""
    if not hwnd:
        return None
    try:
        r = RECT()
        if not user32.GetWindowRect(hwnd, ctypes.byref(r)):
            return None
        left, top, right, bottom = int(r.left), int(r.top), int(r.right), int(r.bottom)
        if right <= left or bottom <= top:
            return None
        return left, top, right, bottom
    except Exception:
        return None


def _viewport_mapping(
    inner_w: float, inner_h: float, preferred_title: str = ""
) -> dict | None:
    """
    Map Chrome CSS viewport pixels to physical Windows screen pixels.

    DOM getBoundingClientRect() returns CSS pixels. Windows mouse APIs use
    physical screen pixels. Browser zoom, Windows DPI scaling, and a resized
    window mean those units are not always 1:1.
    """
    try:
        iw, ih = float(inner_w or 0), float(inner_h or 0)
        if iw < 100 or ih < 100:
            return None
        main, rend = chrome_handles(preferred_title)
        if not main or not rend:
            return None
        rr = _screen_rect(rend)
        mr = _screen_rect(main)
        if not rr or not mr:
            return None

        left, top, right, bottom = rr
        rw, rh = float(right - left), float(bottom - top)
        scale_x, scale_y = rw / iw, rh / ih

        # Broad valid range so unusual DPI/zoom settings still work, while
        # rejecting a clearly wrong render widget.
        if not (0.35 <= scale_x <= 3.5 and 0.35 <= scale_y <= 3.5):
            note_issue(
                "BAD_VIEWPORT_SCALE",
                "Physical/CSS viewport scale is not plausible, so mouse mapping was refused",
                "ERROR",
                f"css={iw:.0f}x{ih:.0f} render={rw:.0f}x{rh:.0f} scale={scale_x:.3f},{scale_y:.3f}",
                throttle=5.0,
            )
            return None

        # X and Y can differ slightly because of scrollbars, but a large
        # mismatch usually means we selected the wrong renderer.
        mismatch = abs(scale_x - scale_y) / max(scale_x, scale_y)
        if mismatch > 0.18:
            note_issue(
                "VIEWPORT_SCALE_MISMATCH",
                "Horizontal and vertical viewport scales disagree too much; click mapping was refused",
                "ERROR",
                f"scale_x={scale_x:.3f} scale_y={scale_y:.3f} render={rr} main={mr}",
                throttle=5.0,
            )
            return None

        return {
            "main": int(main),
            "render": int(rend),
            "left": left,
            "top": top,
            "right": right,
            "bottom": bottom,
            "scale_x": scale_x,
            "scale_y": scale_y,
            "inner_w": iw,
            "inner_h": ih,
            "render_rect": rr,
            "main_rect": mr,
        }
    except Exception as e:
        note_issue(
            "VIEWPORT_MAPPING_ERROR",
            "Could not calculate CSS-to-screen mouse mapping",
            "ERROR",
            str(e),
            throttle=5.0,
        )
        return None


def viewport_to_screen(
    vx: float,
    vy: float,
    preferred_title: str = "",
    inner_w: float = 0,
    inner_h: float = 0,
) -> tuple[int, int] | None:
    """Convert a DOM viewport point to a real Windows mouse coordinate."""
    m = _viewport_mapping(inner_w, inner_h, preferred_title)
    if not m:
        return None
    try:
        x = int(round(m["left"] + float(vx) * m["scale_x"]))
        y = int(round(m["top"] + float(vy) * m["scale_y"]))
        # A valid DOM point must map inside the actual renderer.
        if not (m["left"] <= x < m["right"] and m["top"] <= y < m["bottom"]):
            note_issue(
                "MAPPED_POINT_OUTSIDE_RENDER",
                "DOM point mapped outside Chrome's visible page area, so the click was refused",
                "ERROR",
                f"dom=({vx:.1f},{vy:.1f}) screen=({x},{y}) render={m['render_rect']}",
                throttle=3.0,
            )
            return None
        return x, y
    except Exception:
        return None


def _mapped_dom_rect(
    el: dict | None, snap: dict, preferred_title: str = ""
) -> tuple[int, int, int, int] | None:
    """Map a DOM element rectangle to physical screen pixels."""
    if not el:
        return None
    try:
        m = _viewport_mapping(
            float(snap.get("innerW") or 0),
            float(snap.get("innerH") or 0),
            preferred_title,
        )
        if not m:
            return None
        left = float(el.get("left"))
        top = float(el.get("top"))
        width = float(el.get("w") or 0)
        height = float(el.get("h") or 0)
        if width <= 0 or height <= 0:
            return None
        x1 = int(round(m["left"] + left * m["scale_x"]))
        y1 = int(round(m["top"] + top * m["scale_y"]))
        x2 = int(round(m["left"] + (left + width) * m["scale_x"]))
        y2 = int(round(m["top"] + (top + height) * m["scale_y"]))
        return x1, y1, x2, y2
    except Exception:
        return None


def forbidden(x: int, y: int, kind: str, inner_w: float, inner_h: float) -> bool:
    w, h = pyautogui.size()
    if x < 2 or y < 2 or x > w - 2 or y > h - 2:
        return True
    if kind in ("reserve", "midnight_reject"):
        return y < 180
    if kind in ("row", "idle", "files_toggle"):
        return y < 100
    if kind in ("nav_my", "nav_find"):
        return y < 35
    return True


def _near_dom_button(
    x: int,
    y: int,
    btn: dict | None,
    snap: dict,
    preferred_title: str,
    margin: int = 12,
) -> bool:
    rect = _mapped_dom_rect(btn, snap, preferred_title)
    if not rect:
        return False
    x1, y1, x2, y2 = rect
    return (x1 - margin) <= x <= (x2 + margin) and (y1 - margin) <= y <= (y2 + margin)



def motor_click(pos: dict | None, label: str, kind: str, snap: dict, brain: Brain) -> bool:
    """Physically click only freshly verified LR Writers action or navigation targets."""
    global _last_click
    if kind not in ("row", "reserve", "midnight_reject", "nav_my", "nav_find", "files_toggle"):
        record_stat("click_refusals")
        note_issue(
            "BLOCKED_CLICK_TYPE",
            "Blocked a forbidden click type",
            "ERROR",
            f"label={label} kind={kind}",
            throttle=0,
        )
        return False
    if not pos:
        record_stat("click_refusals")
        note_issue("NO_CLICK_COORDS", "Target had no usable coordinates", "WARN", label)
        return False

    # Bringing Chrome forward must never resize it. Then take a NEW DOM snapshot
    # so the physical mapping uses the viewport that exists at click time.
    title = brain.activate() or str(snap.get("pageTitle") or "")
    fresh = brain.read()
    if not fresh:
        record_stat("click_refusals")
        note_issue("CLICK_FRESH_READ_FAILED", "Could not refresh DOM state immediately before click", "WARN", label)
        return False

    current = None
    if kind == "reserve":
        current = fresh.get("reserve")
    elif kind == "midnight_reject":
        current = fresh.get("reject")
    elif kind == "nav_my":
        current = fresh.get("navMy")
    elif kind == "nav_find":
        current = fresh.get("navFind")
    elif kind == "files_toggle":
        current = fresh.get("filesToggle")
    else:
        want_order = str(pos.get("orderNo") or "").strip().upper()
        want_id = str(pos.get("id") or "")
        want_text = str(pos.get("text") or "")
        for row in fresh.get("rows") or []:
            row_order = str(row.get("orderNo") or "").strip().upper()
            rid = str(row.get("id") or "")
            text = str(row.get("text") or "")
            if want_order and row_order == want_order:
                current = row
                break
            if want_id and rid == want_id:
                current = row
                break
            if not want_order and not want_id and want_text and text[:50] == want_text[:50]:
                current = row
                break

    if not current:
        record_stat("click_refusals")
        note_issue("STALE_TARGET", "Target disappeared or moved before click, so the click was blocked", "WARN", label)
        return False

    pos = current
    snap = fresh
    title = str(snap.get("pageTitle") or title)

    if not brain.validate_click(pos, kind):
        record_stat("click_refusals")
        note_issue("STALE_TARGET", "Fresh target did not validate in the DOM, so the click was blocked", "WARN", label)
        return False

    try:
        vx, vy = float(pos.get("vx")), float(pos.get("vy"))
    except Exception:
        record_stat("click_refusals")
        note_issue("NO_VIEWPORT_POINT", "Fresh target had no usable DOM center point", "WARN", label)
        return False

    inner_w = float(snap.get("innerW") or 0)
    inner_h = float(snap.get("innerH") or 0)
    mapped = viewport_to_screen(vx, vy, title, inner_w, inner_h)
    if not mapped:
        record_stat("click_refusals")
        note_issue("NO_SAFE_CLICK_POINT", "Could not map the DOM target to a physical screen point", "ERROR", label)
        return False

    x, y = mapped
    if forbidden(x, y, kind, inner_w, inner_h):
        record_stat("click_refusals")
        note_issue("FORBIDDEN_CLICK_POINT", "Mapped point failed the screen safety bounds", "ERROR", f"{label} ({x},{y})")
        return False

    target_rect = _mapped_dom_rect(pos, snap, title)
    if not target_rect:
        record_stat("click_refusals")
        note_issue("TARGET_RECT_MAPPING_FAILED", "Could not map the target rectangle to the screen", "ERROR", label)
        return False
    tx1, ty1, tx2, ty2 = target_rect
    if not (tx1 <= x <= tx2 and ty1 <= y <= ty2):
        record_stat("click_refusals")
        note_issue(
            "TARGET_CENTER_OUTSIDE_RECT",
            "Calculated click point was not inside the target's physical rectangle",
            "ERROR",
            f"label={label} point=({x},{y}) rect={target_rect}",
            throttle=0,
        )
        return False

    # Accept is never a physical target. Reject is allowed only for the explicit
    # midnight-rule action; all row/Reserve clicks are still kept away from it.
    near_accept = _near_dom_button(x, y, snap.get("accept"), snap, title)
    near_reject = _near_dom_button(x, y, snap.get("reject"), snap, title)
    if near_accept or (near_reject and kind != "midnight_reject"):
        record_stat("click_refusals")
        note_issue(
            "NEAR_ACCEPT_REJECT",
            "Click blocked because the mapped point overlaps a forbidden Accept/Reject target",
            "ERROR",
            f"{label} ({x},{y})",
            throttle=0,
        )
        return False

    mapping = _viewport_mapping(inner_w, inner_h, title)
    if not mapping:
        record_stat("click_refusals")
        return False
    main = int(mapping["main"])
    main_rect = mapping["main_rect"]
    ml, mt, mr, mb = main_rect
    if not (ml <= x < mr and mt <= y < mb):
        record_stat("click_refusals")
        note_issue(
            "MAPPED_POINT_OUTSIDE_CHROME",
            "Mapped target point was outside the controlled Chrome window; click was refused",
            "ERROR",
            f"label={label} point=({x},{y}) main_rect={main_rect}",
            throttle=0,
        )
        return False

    # Log the real conversion. This is useful when browser zoom/DPI is involved.
    note_issue(
        "VIEWPORT_SCALE_APPLIED",
        "DOM coordinates were converted to real Windows pixels using the live viewport scale",
        "INFO",
        f"label={label} scale={mapping['scale_x']:.3f},{mapping['scale_y']:.3f} "
        f"dom=({vx:.1f},{vy:.1f}) screen=({x},{y})",
        throttle=60.0,
    )

    with _click_lock:
        prepared = False
        try:
            prepared = _prepare_chrome_for_physical_click(main, x, y, label)
            if not prepared:
                record_stat("click_refusals")
                return False

            # Revalidate the same DOM point after Chrome has been exposed.
            if not brain.validate_click(pos, kind):
                record_stat("click_refusals")
                note_issue(
                    "LAST_SECOND_TARGET_CHANGE",
                    "Target changed immediately before click, so the click was blocked",
                    "WARN",
                    label,
                )
                return False

            before = pyautogui.position()
            move_seconds = random.uniform(0.035, 0.075)
            log(
                f"PHYSICAL MOUSE {label}: move ({int(before.x)},{int(before.y)}) -> "
                f"({x},{y}) in {move_seconds:.3f}s, then real mouse down/up"
            )
            pyautogui.moveTo(x, y, duration=move_seconds)

            root = _root_window_at(x, y)
            if root != int(main):
                record_stat("click_refusals")
                shot = capture_diagnostic("target_became_occluded", min_interval=3.0)
                note_issue(
                    "TARGET_BECAME_OCCLUDED",
                    "Another window covered the verified target while the mouse was moving; click was cancelled",
                    "ERROR",
                    f"label={label} expected_hwnd={main} actual_hwnd={root} screenshot={shot}",
                    throttle=3.0,
                )
                return False

            if not brain.validate_click(pos, kind):
                record_stat("click_refusals")
                note_issue(
                    "TARGET_CHANGED_DURING_MOUSE_MOVE",
                    "Target changed while the mouse was moving, so the click was blocked",
                    "WARN",
                    label,
                )
                return False

            pyautogui.mouseDown()
            try:
                time.sleep(0.045)
            finally:
                pyautogui.mouseUp()
            _last_click = time.time()
        finally:
            if prepared:
                time.sleep(0.025)
            _release_chrome_topmost(main)

    if kind == "reserve":
        record_stat("reserve_clicks")
    elif kind == "midnight_reject":
        record_stat("reject_clicks")
    elif kind in ("nav_my", "nav_find"):
        record_stat("nav_clicks")
    elif kind == "files_toggle":
        record_stat("panel_files_toggles")
    else:
        record_stat("row_clicks")
    log(f"CLICK {label} (scaled-hwnd) at ({x}, {y})")

    # For action buttons, immediately read Chrome's passive click audit so the
    # log proves whether the browser received the OS-level mouse event as trusted.
    if kind in ("reserve", "midnight_reject"):
        expected = "Reserve" if kind == "reserve" else "Reject"
        context = "bot physical Reserve" if kind == "reserve" else "bot midnight-rule Reject"
        time.sleep(0.06)
        audit_snap = brain.read()
        audit = consume_click_audit(audit_snap, context=context, expected_label=expected)
        if not audit:
            code = "RESERVE_CLICK_AUDIT_MISSING" if kind == "reserve" else "REJECT_CLICK_AUDIT_MISSING"
            note_issue(
                code,
                f"{expected} mouse-down/up was sent but Chrome's click audit did not capture a new click event",
                "WARN",
                f"screen=({x},{y})",
                throttle=0,
            )
    return True


def scroll_reserved_panel(snap: dict, brain: Brain, wheel_amount: int, label: str) -> bool:
    """Use the visible mouse wheel inside the verified order panel; never click a job action."""
    global _last_click
    if _paused or _stop or not wheel_amount:
        return False
    try:
        title = brain.activate() or str(snap.get("pageTitle") or "")
        fresh = brain.read() or {}
        pos = fresh.get("panelScroll")
        if not pos or not fresh.get("panelOpen"):
            return False
        mapped = viewport_to_screen(
            float(pos.get("vx") or 0), float(pos.get("vy") or 0),
            str(fresh.get("pageTitle") or title),
            float(fresh.get("innerW") or 0), float(fresh.get("innerH") or 0),
        )
        if not mapped:
            return False
        x, y = mapped
        main, _ = chrome_handles(str(fresh.get("pageTitle") or title))
        if not main:
            return False
        with _click_lock:
            focus_hwnd(main)
            pyautogui.moveTo(x, y, duration=0.05)
            pyautogui.scroll(int(wheel_amount))
            _last_click = time.time()
        record_stat("panel_inspection_scrolls")
        log(f"RESERVED PANEL INSPECTION: {label} wheel={int(wheel_amount)}")
        return True
    except Exception as e:
        note_issue("PANEL_INSPECTION_SCROLL_FAILED", "Reserved panel scroll could not be completed", "WARN", str(e), throttle=5.0)
        return False


def send_f5(brain: Brain) -> None:
    if _paused or _stop:
        return
    # Just before any keyboard refresh, check whether LR Writers has logged out.
    # Logout is a hard stop: never navigate, retry login, or press F5 afterward.
    try:
        pre = brain.read() or {}
        if bool(pre.get("loggedOut")):
            hard_stop_logout("LR Writers logout/login page detected before F5")
            return
    except Exception:
        pass
    with _click_lock:
        title = brain.activate()
        main, _ = chrome_handles(title)
        if not main:
            note_issue("F5_WINDOW_MISSING", "Refresh was skipped because controlled Chrome could not be found", "WARN", throttle=5.0)
            return
        try:
            user32.SetWindowPos(
                main, HWND_TOPMOST, 0, 0, 0, 0,
                SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW,
            )
            focus_hwnd(main)
            time.sleep(0.04)
            if int(user32.GetForegroundWindow() or 0) != int(main):
                note_issue("F5_NOT_FOREGROUND", "Refresh was skipped because Chrome could not get keyboard focus", "WARN", throttle=5.0)
                return
            pyautogui.press("f5")
        finally:
            _release_chrome_topmost(main)
    record_stat("f5")
    log("F5")

def _idle_point_to_screen(snap: dict, point: dict) -> tuple[int, int] | None:
    """Map one DOM-vetted idle point to the real Chrome render surface."""
    try:
        return viewport_to_screen(
            float(point.get("vx")),
            float(point.get("vy")),
            str(snap.get("pageTitle") or ""),
            float(snap.get("innerW") or 0),
            float(snap.get("innerH") or 0),
        )
    except Exception:
        return None


def idle_mouse(snap: dict, allow_click: bool = False) -> bool:
    """Move through a random DOM-vetted non-interactive point.

    If allow_click=True, make one physical click only on a point that the
    live page classified as inert background. Never background-click while
    an order panel is open.
    """
    global _last_idle_dir

    if _paused or _stop:
        return False
    if snap.get("panelOpen") or snap.get("reserve") or snap.get("accept") or snap.get("reject"):
        return False

    points = list(snap.get("idleClickPoints") or []) if allow_click else list(snap.get("idleMovePoints") or [])
    if not points:
        return False

    random.shuffle(points)
    chosen = None
    for pt in points:
        mapped = _idle_point_to_screen(snap, pt)
        if not mapped:
            continue
        x, y = mapped
        if forbidden(x, y, "idle", float(snap.get("innerW") or 0), float(snap.get("innerH") or 0)):
            continue
        key = f"{x},{y}"
        if key == _last_idle_dir and len(points) > 1:
            continue
        chosen = (pt, x, y, key)
        break

    if not chosen:
        return False

    pt, x, y, key = chosen
    duration = random.uniform(0.35, 1.20)
    pyautogui.moveTo(x, y, duration=duration)
    log(
        f"IDLE MOUSE: moved across webpage to safe DOM point ({x},{y}) "
        f"in {duration:.2f}s tag={pt.get('tag') or '?'}"
    )
    _last_idle_dir = key

    if not allow_click:
        return True

    main, _ = chrome_handles()
    if not main:
        return False
    point_obj = POINT(x, y)
    actual = int(user32.WindowFromPoint(point_obj) or 0)
    GA_ROOT = 2
    root_actual = int(user32.GetAncestor(actual, GA_ROOT) or actual) if actual else 0
    root_main = int(user32.GetAncestor(main, GA_ROOT) or main)
    if root_actual != root_main:
        note_issue(
            "IDLE_CLICK_OCCLUDED",
            "Safe idle click skipped because Chrome did not own the physical point",
            "INFO",
            f"point=({x},{y}) actual={root_actual} expected={root_main}",
            throttle=30.0,
        )
        return False

    pyautogui.mouseDown()
    time.sleep(random.uniform(0.035, 0.070))
    pyautogui.mouseUp()
    record_stat("idle_background_clicks")
    log(
        f"IDLE SAFE CLICK: physical mouse clicked verified inert webpage background "
        f"at ({x},{y}) tag={pt.get('tag') or '?'}"
    )
    return True




def perform_my_orders_visit(brain: Brain, snap: dict) -> bool:
    """Physical My Orders -> inert background click -> Find Orders round trip."""
    if _stop or _paused or not snap or snap.get("loggedOut"):
        return False
    if snap.get("panelOpen") or snap.get("reserve") or snap.get("accept") or snap.get("reject"):
        return False
    nav_my = snap.get("navMy")
    if not nav_my:
        note_issue("MY_ORDERS_NAV_MISSING", "My Orders navigation target was not visible; scheduled visit skipped", "INFO", throttle=60.0)
        return False

    set_status_ticket(job="MY ORDERS CHECK", f5="WAIT", mouse="VISIT")
    log("MY ORDERS VISIT: physically clicking My Orders.")
    if not motor_click(nav_my, "My Orders", "nav_my", snap, brain):
        return False

    deadline = time.time() + 12.0
    my_snap = {}
    while time.time() < deadline and not _stop and not _paused:
        time.sleep(0.20)
        my_snap = brain.read() or {}
        if my_snap.get("loggedOut"):
            hard_stop_logout("LR Writers logout/login page detected during My Orders visit")
            return False
        if my_snap and not bool(my_snap.get("onFind")):
            break
    if not my_snap or bool(my_snap.get("onFind")):
        note_issue("MY_ORDERS_NAV_FAILED", "My Orders did not become active after the physical navigation click", "WARN", str(my_snap.get("url") or ""), throttle=30.0)
        return False

    # One deliberate inert-background click on My Orders. The point is chosen from
    # the same DOM-vetted non-interactive pool used by the normal idle clicker.
    idle_mouse(my_snap, allow_click=True)
    time.sleep(random.uniform(0.45, 1.20))

    # Re-read so Find Orders coordinates are fresh on the My Orders page.
    my_snap = brain.read() or my_snap
    nav_find = my_snap.get("navFind")
    if not nav_find:
        note_issue("FIND_ORDERS_NAV_MISSING", "Find Orders navigation target was not visible during scheduled return", "WARN", str(my_snap.get("url") or ""), throttle=30.0)
        return False
    log("MY ORDERS VISIT: physically clicking Find Orders to return.")
    if not motor_click(nav_find, "Find Orders", "nav_find", my_snap, brain):
        return False

    deadline = time.time() + 12.0
    while time.time() < deadline and not _stop and not _paused:
        time.sleep(0.20)
        back = brain.read() or {}
        if back.get("loggedOut"):
            hard_stop_logout("LR Writers logout/login page detected while returning from My Orders")
            return False
        if back.get("onFind"):
            record_stat("my_orders_visits")
            log("MY ORDERS VISIT COMPLETE: back on Find Orders; normal scanning resumes.")
            return True
    note_issue("FIND_ORDERS_RETURN_FAILED", "Scheduled My Orders visit could not confirm return to Find Orders", "WARN", throttle=30.0)
    return False



def is_network_error_snapshot(snap: dict | None) -> bool:
    """True only for browser/network error pages, never for an LR login/logout page."""
    if not snap:
        return False
    url = str(snap.get("url") or "").strip().lower()
    title = str(snap.get("pageTitle") or "").strip().lower()
    text = str(snap.get("bodyText") or snap.get("panelText") or "").strip().lower()
    if url.startswith("chrome-error://") or url.startswith("chrome://network-error"):
        return True
    if any(x in title for x in ("site can't be reached", "no internet", "offline", "network error")):
        return True
    if any(x in text for x in ("this site can’t be reached", "this site can't be reached", "no internet", "err_internet_disconnected", "err_network_changed")):
        return True
    return False


# ---------------- alerts ----------------
def send_gmail(title: str, message: str) -> bool:
    if not GMAIL_WEBAPP_URL:
        return False
    try:
        r = requests.post(
            GMAIL_WEBAPP_URL,
            json={"secret": GMAIL_WEBAPP_SECRET, "to": GMAIL_TO, "subject": title, "body": message},
            timeout=15,
        )
        ok = 200 <= r.status_code < 300
        log("Gmail: " + str(r.status_code))
        if not ok:
            note_issue("GMAIL_HTTP_ERROR", "Gmail alert returned a non-success status", "WARN", str(r.status_code), throttle=30)
        return ok
    except Exception as e:
        note_issue("GMAIL_FAILED", "Gmail alert delivery failed", "WARN", str(e), throttle=30)
        return False



def cancel_alert_keys(keys: list[str]) -> None:
    """Cancel queued reminder keys for a reservation that was accepted/rejected/cleared."""
    clean = [k for k in keys if k]
    if not clean:
        return
    with _alert_lock:
        before = len(_alert_cancelled)
        _alert_cancelled.update(clean)
        added = len(_alert_cancelled) - before
    if added:
        record_stat("alerts_cancelled", added)

def _alert_is_cancelled(key: str) -> bool:
    with _alert_lock:
        return key in _alert_cancelled

def _deliver_alert_worker(title: str, message: str, key: str) -> None:
    """Deliver Pushover/Gmail off the director thread so F5 never waits on network I/O."""
    push_ok = False
    mail_ok = False
    try:
        if _alert_is_cancelled(key):
            log(f"Alert cancelled before delivery: {title}")
            return
        try:
            r = requests.post(
                "https://api.pushover.net/1/messages.json",
                data={"token": PUSHOVER_APP_TOKEN, "user": PUSHOVER_USER_KEY, "title": title[:80],
                      "message": (message or title)[:1000], "sound": "siren"}, timeout=15,
            )
            push_ok = 200 <= r.status_code < 300
            log("Pushover: " + title + " (" + str(r.status_code) + ")")
            if not push_ok:
                note_issue("PUSHOVER_HTTP_ERROR", "Pushover returned a non-success status", "WARN", str(r.status_code), throttle=30)
        except Exception as e:
            note_issue("PUSHOVER_FAILED", "Pushover alert delivery failed", "WARN", str(e), throttle=30)

        if _alert_is_cancelled(key):
            log(f"Alert cancelled before Gmail delivery: {title}")
            return
        mail_ok = send_gmail(title, message or title)
        with _alert_lock:
            if push_ok or mail_ok:
                _alerted.add(key)
                record_stat("alerts_sent")
            else:
                record_stat("alert_failures")
                note_issue("ALERT_DELIVERY_FAILED", "Both alert methods failed; bot will retry later", "WARN", title, throttle=30)
    finally:
        with _alert_lock:
            _alert_inflight.discard(key)


def send_alert(title: str, message: str, key: str) -> bool:
    """Queue an alert without blocking row scanning, mouse actions, or F5."""
    if _paused or _stop:
        return False
    if not key:
        return False
    now = time.time()
    with _alert_lock:
        if key in _alert_cancelled:
            return False
        if key in _alerted:
            return True
        if key in _alert_inflight:
            return False
        last_try = _alert_last_try.get(key, 0.0)
        if last_try and now - last_try < 30.0:
            return False
        _alert_last_try[key] = now
        _alert_inflight.add(key)

    threading.Thread(
        target=_deliver_alert_worker,
        args=(title, message, key),
        name="LR-Alert-" + re.sub(r"[^A-Za-z0-9_-]+", "_", key)[:30],
        daemon=True,
    ).start()
    log(f"Alert queued in background: {title}")
    return False



def in_midnight_rule_window(dt: datetime | None = None) -> bool:
    """Use the PC's local clock. The rule is active from midnight until 08:00."""
    dt = dt or datetime.now()
    h = dt.hour + dt.minute / 60.0 + dt.second / 3600.0
    start = float(MIDNIGHT_RULE_START_HOUR)
    end = float(MIDNIGHT_RULE_END_HOUR)
    if start <= end:
        return start <= h < end
    return h >= start or h < end


def parse_remaining_minutes(text: str) -> float | None:
    """Parse only explicit relative-deadline wording; ignore generic '60 minutes - 300 words'."""
    t = re.sub(r"\s+", " ", str(text or "").lower().replace("’", "'")).strip()
    if not t:
        return None

    # Normalize natural singular phrases used by the site.
    t = re.sub(r"\ban hour\b", "1 hour", t)
    t = re.sub(r"\ba hour\b", "1 hour", t)
    t = re.sub(r"\ba day\b", "1 day", t)
    t = re.sub(r"\ban? minute\b", "1 minute", t)

    # Only consider text close to a relative-deadline cue. This avoids treating
    # assignment-production hints such as '60 minutes - 300 words' as deadlines.
    candidates: list[str] = []
    cue_patterns = [
        r"(?:in\s+)?[^|.;]{0,80}?\bfrom now\b",
        r"(?:in\s+)?[^|.;]{0,80}?\b(?:left|remaining)\b",
        r"\b(?:deadline|final ddl|ddl)\b[^|.;]{0,100}",
        r"\bin\s+\d+(?:\.\d+)?\s*(?:days?|d|hours?|hrs?|hr|h|minutes?|mins?|min|m)\b",
    ]
    for pat in cue_patterns:
        for m in re.finditer(pat, t, re.I):
            candidates.append(m.group(0))

    if not candidates:
        return None

    best: float | None = None
    for seg in candidates:
        days = hours = minutes = 0.0
        found = False
        for val, unit in re.findall(r"(\d+(?:\.\d+)?)\s*(days?|d|hours?|hrs?|hr|h|minutes?|mins?|min|m)\b", seg, re.I):
            found = True
            n = float(val)
            u = unit.lower()
            if u.startswith("d"):
                days += n
            elif u.startswith("h"):
                hours += n
            else:
                minutes += n
        if found:
            total = days * 1440.0 + hours * 60.0 + minutes
            if total >= 0 and (best is None or total < best):
                best = total
    return best


def deadline_source_for_row(row: dict | None) -> str:
    if not row:
        return ""
    return " ".join(str(row.get(k) or "") for k in ("deadlineText", "text"))


def _one_line(text: str) -> str:
    return re.sub(r"\s+", " ", str(text or "")).strip()


def _extract_named_section(raw: str, heading_pattern: str, stop_headings: tuple[str, ...]) -> str:
    m = re.search(heading_pattern, raw or "", re.I)
    if not m:
        return ""
    tail = (raw or "")[m.end():]
    cut = len(tail)
    low = tail.lower()
    for stop in stop_headings:
        i = low.find(stop.lower())
        if i >= 0:
            cut = min(cut, i)
    return tail[:cut].strip()


def capture_reservation_details(snap: dict | None, rid: str, hint: str = "") -> dict:
    """Capture the same useful fields the older full Accept Pushover contained."""
    snap = snap or {}
    raw = str(snap.get("panelText") or "")
    combined = raw + "\n" + str(hint or "")
    order_match = _ORDER_NO_RE.search(combined)
    task_no = (order_match.group(0).upper() if order_match else str(rid or "").strip().upper())

    prices = re.findall(r"\$\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)", combined)
    price = ""
    if prices:
        try:
            price = f"${float(prices[0].replace(',', '')):.2f}"
        except Exception:
            price = "$" + prices[0]

    final_ddl = ""
    m = re.search(r"Final\s*DDL\s*:\s*([^\n]+)", raw, re.I)
    if m:
        final_ddl = _one_line(m.group(1))
    mins = parse_remaining_minutes(combined)
    if mins is None:
        deadline_display = final_ddl or "unknown"
    elif mins < 60:
        deadline_display = f"{max(0, round(mins))} min"
    else:
        hrs = mins / 60.0
        deadline_display = (f"{hrs:.1f}".rstrip("0").rstrip(".") + "hrs")

    size = ""
    for pat, unit in ((r"\b(\d+)\s*pages?\b", "pages"), (r"\b(\d+)\s*slides?\b", "slides"), (r"\b(\d{2,6})\s*words?\b", "words")):
        sm = re.search(pat, raw, re.I)
        if sm:
            size = f"{sm.group(1)} {unit}"
            break

    title = ""
    lines = [_one_line(x) for x in raw.splitlines() if _one_line(x)]
    stop_starts = ("final ddl", "order info", "operator messages", "more order details", "order files", "upload final", "task summary", "full order description")
    for i, line in enumerate(lines[:50]):
        candidate = line
        if task_no and task_no.lower() in candidate.lower():
            candidate = re.sub(re.escape(task_no), "", candidate, flags=re.I).strip(" -:|")
        candidate = re.sub(r"\$\s*[0-9][0-9,]*(?:\.[0-9]{1,2})?", "", candidate).strip(" -:|")
        low = candidate.lower()
        if not candidate or any(low.startswith(x) for x in stop_starts):
            continue
        if re.fullmatch(r"(?:essay|excel|problem solving|project|task|presentation|discussion|writing)(?:\s*\+\s*\w+)?", low):
            continue
        if task_no and line.lower().startswith(task_no.lower()) and candidate:
            title = candidate
            break
        if i <= 8 and len(candidate) >= 4 and not re.match(r"^\d+\s+(?:pages?|words?|slides?|hours?)$", low):
            title = candidate
            break
    if not title:
        title = _one_line(hint)[:160] or task_no or "unknown"
    if size and size.lower() not in title.lower():
        title = f"{title} ({size})"

    task_summary = _extract_named_section(
        raw, r"Task\s*summary\s*:?",
        ("Full order description", "Order files", "Upload final files", "Order Info", "Operator messages", "More order details"),
    )
    full_desc = _extract_named_section(
        raw, r"Full\s*order\s*description\s*:?",
        ("Order files", "Upload final files", "Order Info", "Operator messages", "More order details"),
    )
    return {
        "taskNo": task_no or "unknown",
        "price": price,
        "title": title[:180],
        "deadline": deadline_display,
        "ddlText": final_ddl,
        "taskSummary": task_summary,
        "fullDesc": full_desc,
    }


def build_reserved_pushover_message(details: dict) -> str:
    """Full reservation Pushover, modeled on the older full Accepted report."""
    now = datetime.now().strftime("%H:%M")
    task_no = str(details.get("taskNo") or "unknown")
    price = str(details.get("price") or "")
    deadline = str(details.get("deadline") or details.get("ddlText") or "unknown")
    title = str(details.get("title") or "unknown")
    header = (
        f"LR job reserved at {now}\n\n"
        f"With task number {task_no}{(' ' + price) if price else ''}\n\n"
        f"With final deadline {deadline}\n\n"
        f"Task title {title}\n\n"
    )
    body_parts = []
    summary = str(details.get("taskSummary") or "").strip()
    full_desc = str(details.get("fullDesc") or "").strip()
    if summary:
        body_parts.append("Task summary\n" + summary)
    if full_desc:
        body_parts.append("Full order description\n" + full_desc)
    if not body_parts:
        body_parts.append("Task summary\n(no task summary found)")
    msg = header + "\n\n".join(body_parts)
    return msg if len(msg) <= 980 else msg[:976] + "\n..."


def has_do_not_accept(text: str) -> bool:
    t = (text or "").lower().replace("’", "'").replace("‘", "'")
    return any(
        p in t
        for p in (
            "do not accept",
            "don't accept",
            "dont accept",
            "do not reserve",
            "don't reserve",
            "dont reserve",
            "do not take this order",
            "don't take this order",
            "dont take this order",
            "you will be fined",
            "you'll be fined",
        )
    )


_ORDER_NO_RE = re.compile(r"\b[A-Z]{1,6}\d{6,}-\d+\b", re.I)
_last_click_audit_ts = 0


def row_key(row: dict | None) -> str:
    """Stable public order identity when possible, otherwise the internal row id."""
    if not row:
        return ""
    order_no = str(row.get("orderNo") or "").strip()
    if order_no:
        return order_no.upper()
    text = str(row.get("text") or "")
    m = _ORDER_NO_RE.search(text)
    if m:
        return m.group(0).upper()
    rid = str(row.get("id") or "").strip()
    if rid:
        return rid
    return text[:80]


def consume_click_audit(snap: dict | None, context: str = "", expected_label: str = "") -> dict | None:
    """Consume the newest browser click audit event once and log isTrusted."""
    global _last_click_audit_ts
    click = (snap or {}).get("lastClick") or {}
    try:
        ts = int(click.get("ts") or 0)
    except Exception:
        ts = 0
    if not ts or ts <= _last_click_audit_ts:
        return None
    age_ms = int(time.time() * 1000) - ts
    if age_ms > 10000:
        _last_click_audit_ts = ts
        return None
    _last_click_audit_ts = ts
    trusted = bool(click.get("trusted"))
    text = str(click.get("text") or "").strip()
    if trusted:
        record_stat("trusted_native_clicks")
    else:
        record_stat("untrusted_clicks")
    log(
        f"DOM CLICK AUDIT | context={context or 'page'} target={text!r} "
        f"isTrusted={trusted} client=({int(click.get('clientX') or 0)},{int(click.get('clientY') or 0)})"
    )
    if expected_label and expected_label.lower() not in text.lower():
        note_issue(
            "CLICK_AUDIT_TARGET_MISMATCH",
            "Chrome received the physical click on a different labelled target than expected",
            "ERROR",
            f"expected={expected_label!r} actual={text!r} trusted={trusted}",
            throttle=0,
        )
    if expected_label and not trusted:
        note_issue(
            "CLICK_NOT_TRUSTED",
            "Chrome reported that the expected click was not a trusted native user-input event",
            "ERROR",
            f"expected={expected_label!r} actual={text!r}",
            throttle=0,
        )
    return click


def job_id(row: dict | None, snap: dict) -> str:
    # The open page/panel is more authoritative than some other eligible row.
    uid = str(snap.get("urlId") or "")
    if uid and uid.lower() not in ("all", "findorders"):
        return uid
    key = row_key(row)
    if key:
        return key
    return ""


def job_still_held(snap: dict, rid: str, hint: str) -> bool:
    """Strong reservation proof only. A row merely existing is never proof that it is still reserved."""
    if not snap or snap.get("acceptedGone"):
        return False
    rid_norm = str(rid or "").strip().upper()
    uid = str(snap.get("urlId") or "").strip().upper()
    url = str(snap.get("url") or "").upper()
    panel = str(snap.get("panelText") or "").upper()
    rows = snap.get("rows") or []
    keys = [row_key(r).upper() for r in rows]
    texts = [str(r.get("text") or "").upper() for r in rows]

    identity_matches = bool(rid_norm and (uid == rid_norm or rid_norm in url or rid_norm in panel))
    row_matches = bool(rid_norm and rid_norm in keys)
    hint_token = str(hint or "").strip().upper()[:24]
    hint_matches = bool(hint_token and any(hint_token in t for t in texts))

    # A verified Reject button tied to THIS order is the positive proof that the
    # reservation is still alive. A normal list row by itself is never enough.
    if snap.get("reject") and (identity_matches or row_matches or hint_matches):
        return True

    # Accepted state or the same order returning to Reserve are definite end states.
    if snap.get("reserve") and identity_matches and not snap.get("reject"):
        return False

    return False


def reservation_definitely_ended(snap: dict, rid: str) -> bool:
    """Return True only for a strong, same-order accepted/rejected/end-state signal."""
    if not snap:
        return False
    if snap.get("acceptedGone"):
        return True
    rid_norm = str(rid or "").strip().upper()
    if not rid_norm:
        return False
    uid = str(snap.get("urlId") or "").strip().upper()
    url = str(snap.get("url") or "").upper()
    panel = str(snap.get("panelText") or "").upper()
    identity_matches = bool(uid == rid_norm or rid_norm in url or rid_norm in panel)
    # Manual Reject normally returns this exact order to a Reserve state.
    return bool(identity_matches and snap.get("reserve") and not snap.get("reject"))


def pick_row(rows, reserved_id: str, tapped: dict[str, float], opened_once: set[str]):
    now = time.time()
    best = None
    reserved_norm = str(reserved_id or "").strip().upper()
    done_norm = {str(x).strip().upper() for x in _done}
    opened_norm = {str(x).strip().upper() for x in opened_once}
    for r in rows or []:
        key = row_key(r)
        key_norm = key.strip().upper()
        if not key:
            continue
        if r.get("tutor"):
            continue
        # If the list row itself already exposes a DO NOT ACCEPT / fine warning,
        # do not even open it, much less Reserve it. The panel is checked again
        # immediately before every Reserve click as a second hard gate.
        if has_do_not_accept(str(r.get("text") or "")):
            _done.add(key_norm)
            log(f"DO NOT ACCEPT warning visible in row {key}; skipping without Reserve.")
            continue
        pay = float(r.get("pay") or 0)
        if pay < MIN_PAY:
            continue
        if key_norm in done_norm:
            continue
        if reserved_norm and key_norm == reserved_norm:
            continue
        # Once a physical row click has been sent successfully for this exact
        # order during this session, never click that same row again. F5 does
        # all future refreshing. A different/new order can still be opened.
        if key_norm in opened_norm:
            continue
        last = tapped.get(key)
        if last and now - last < ROW_RETRY_SEC:
            continue
        if best is None or pay > float(best.get("pay") or 0):
            best = r
    return best


def next_reload(i: int, last: float | None = None) -> float:
    lo, hi = RELOAD_FAST if i % (RELOAD_FAST_N + RELOAD_SLOW_N) < RELOAD_FAST_N else RELOAD_SLOW
    delay = random.uniform(lo, hi)
    for _ in range(30):
        if last is None or abs(delay - last) >= 2.0:
            return delay
        delay = random.uniform(lo, hi)
    if last is not None:
        cand = last + 2.0
        if lo <= cand <= hi:
            return cand
        cand = last - 2.0
        if lo <= cand <= hi:
            return cand
    return delay


# ---------------- health checks ----------------
def startup_self_check(brain: Brain) -> bool:
    ok = True
    if not chrome_port_live():
        note_issue(
            "SELF_CHECK_PORT",
            "Startup check failed because the Chrome DevTools connection is not live",
            "ERROR",
            throttle=0,
        )
        ok = False

    snap = brain.read()
    if not snap:
        note_issue(
            "SELF_CHECK_DOM",
            "Startup check could not read the LR Writers page",
            "ERROR",
            throttle=0,
        )
        return False

    if bool(snap.get("loggedOut")):
        hard_stop_logout("LR Writers was already logged out when the bot started")
        return False

    url = str(snap.get("url") or "")
    if "findorders" not in url.lower():
        note_issue(
            "SELF_CHECK_PAGE",
            "Startup is not on Find Orders; bot will not navigate automatically",
            "WARN",
            url,
            throttle=0,
        )
        return False

    title = str(snap.get("pageTitle") or "")
    main, rend = chrome_handles(title)
    if not main or not rend:
        note_issue(
            "SELF_CHECK_WINDOW",
            "Could not identify the controlled Chrome window and its page renderer",
            "ERROR",
            title,
            throttle=0,
        )
        ok = False

    inner_w = float(snap.get("innerW") or 0)
    inner_h = float(snap.get("innerH") or 0)
    if inner_w < 500 or inner_h < 300:
        note_issue(
            "SELF_CHECK_VIEWPORT",
            "Chrome viewport looks unexpectedly small",
            "ERROR",
            f"{snap.get('innerW')}x{snap.get('innerH')}",
            throttle=0,
        )
        ok = False

    mapping = _viewport_mapping(inner_w, inner_h, title) if ok else None
    if not mapping:
        note_issue(
            "SELF_CHECK_MAPPING",
            "Could not establish a reliable DOM-to-physical mouse mapping",
            "ERROR",
            throttle=0,
        )
        ok = False
    else:
        log(
            "Viewport mapping ready: "
            f"CSS {inner_w:.0f}x{inner_h:.0f} -> render "
            f"{mapping['right']-mapping['left']}x{mapping['bottom']-mapping['top']} "
            f"scale {mapping['scale_x']:.3f},{mapping['scale_y']:.3f}"
        )

        # Probe one currently visible actionable element. This catches exactly
        # the old failure where a DOM point mapped outside the actual browser.
        probe = snap.get("reserve")
        probe_name = "Reserve"
        if not probe:
            rows = snap.get("rows") or []
            probe = rows[0] if rows else None
            probe_name = "ROW"

        if probe and probe.get("vx") is not None and probe.get("vy") is not None:
            p = viewport_to_screen(
                float(probe["vx"]),
                float(probe["vy"]),
                title,
                inner_w,
                inner_h,
            )
            rect = _mapped_dom_rect(probe, snap, title)
            if not p or not rect:
                note_issue(
                    "SELF_CHECK_PROBE_MAPPING",
                    "Visible target could not be mapped to the physical browser",
                    "ERROR",
                    probe_name,
                    throttle=0,
                )
                ok = False
            else:
                x, y = p
                x1, y1, x2, y2 = rect
                if not (x1 <= x <= x2 and y1 <= y <= y2):
                    note_issue(
                        "SELF_CHECK_PROBE_OUTSIDE",
                        "Mapped target center was outside its physical target rectangle",
                        "ERROR",
                        f"{probe_name} point={p} rect={rect}",
                        throttle=0,
                    )
                    ok = False

    update_last_state(snap, startup_check="passed" if ok else "failed")
    if ok:
        log(
            "Startup self-check PASSED. Controlled Chrome, Find Orders, "
            "live viewport scale, and physical mouse mapping are ready."
        )
    return ok


# ---------------- director ----------------
def run_bot_session() -> None:
    global _stop_reason
    set_status_ticket(bot="STARTING", page="CONNECTING", job="SEARCHING", f5="WAIT", mouse="WAIT")
    log("Adeon session starting. Physical clicks: order row, Reserve, and rule-authorized midnight Reject. Accept is forbidden.")
    log(f"Live page scan target: every {DOM_SCAN_INTERVAL*1000:.0f} ms while active; F5 is 5-20 seconds only while searching and is held completely during an active reservation. Temporary network loss never terminates the worker.")
    log(f"Midnight rule: {MIDNIGHT_RULE_START_HOUR:02d}:00-{MIDNIGHT_RULE_END_HOUR:02d}:00 local, under {MIDNIGHT_REJECT_UNDER_MINUTES/60:.0f}h -> Reject after {MIDNIGHT_REJECT_AFTER/60:.0f} min reserved.")
    brain = Brain()
    try:
        if not brain.attach():
            _stop_reason = "startup failed: Chrome DevTools connection unavailable"
            if not _APP_LAST_ERROR_FILE.exists():
                write_last_error("Adeon could not prepare/connect to Chrome. See VIEW ACTIVITY LOG.")
            note_issue("STARTUP_ABORT", "Adeon stopped because it could not prepare or attach safely to Chrome", "ERROR", throttle=0)
            return
        if not startup_self_check(brain):
            _stop_reason = "startup self-check failed"
            write_last_error("Adeon connected to Chrome, but its startup safety check failed. See VIEW ACTIVITY LOG.")
            note_issue("STARTUP_ABORT", "Bot stopped because startup self-check did not pass", "ERROR", throttle=0)
            return

        last_reload=time.time(); cycle=0; next_in=next_reload(0)
        last_f5_press_at=0.0; burst_guard_until=0.0
        last_idle=time.time(); next_idle=random.uniform(*IDLE_MOVE)
        last_idle_click=time.time(); next_idle_click=random.uniform(*IDLE_CLICK)
        idle_active_started=time.time(); idle_pause_until=0.0
        last_reserve_try=0.0; last_row_key=None
        tapped: dict[str,float]={}; opened_once:set[str]=set(); refresh_pause_until=0.0; force_refresh=False; active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""; hold_missing_since=0.0; post_accept_ready=False; last_accepted_id=""
        blank_since=0.0; busy_since=0.0; last_health_log=time.time(); last_port_check=0.0
        reserved=False; reserved_at=0.0; reserved_id=""; reserved_hint=""; reserved_flags:set[str]=set()
        reservation_serial=0; reservation_alert_prefix=""; reserved_remaining_minutes:float|None=None; reserved_midnight_window=False; reserved_midnight_reject=False; last_midnight_reject_try=0.0
        reserved_details:dict={}; last_reservation_status_check=0.0; reservation_missing_checks=0
        late_reminder_slot=-1; late_reservation_alert_keys:set[str]=set()
        reserved_waiting_keys:set[str]=set()
        inspection_last_scroll=0.0; inspection_files_opened=False; inspection_returned_top=False
        next_my_orders_visit=time.time()+random.uniform(*MY_ORDERS_VISIT)

        def refresh_status_ticket(page_state: str = "ONLINE") -> None:
            now_ticket = time.time()
            if _paused:
                with _pause_lock:
                    reason = str(_pause_reason or "PAUSED")
                page_label = "LOGGED OUT" if "logout" in reason.lower() or "login" in reason.lower() else page_state
                job_label = (f"RESERVED {reserved_id[:16]}" if reserved and reserved_id else "SEARCHING")
                set_status_ticket(bot="PAUSED", page=page_label, job=job_label, f5="PAUSED", mouse="PAUSED")
                return
            job_label = (f"RESERVED {reserved_id[:16]}" if reserved and reserved_id else "SEARCHING")
            scheduled_left = next_in - (now_ticket - last_reload)
            burst_left = burst_guard_until - now_ticket
            f5_left = max(0.0, scheduled_left, burst_left)
            f5_label = "HOLD RESERVED" if reserved else f"{int(round(f5_left))}s NORMAL"
            if idle_pause_until and now_ticket < idle_pause_until:
                mins = max(1, int((idle_pause_until - now_ticket + 59.0) // 60.0))
                mouse_label = f"REST {mins}m"
            else:
                active_left = max(0.0, IDLE_ACTIVE_FOR - (now_ticket - idle_active_started))
                mins = max(1, int((active_left + 59.0) // 60.0))
                mouse_label = f"ACTIVE {mins}m"
            set_status_ticket(bot="CONNECTED", page=page_state, job=job_label, f5=f5_label, mouse=mouse_label)

        refresh_status_ticket("ONLINE")

        def maybe_f5() -> None:
            nonlocal last_reload, cycle, next_in, force_refresh, last_f5_press_at, burst_guard_until
            if _stop or _paused:
                return
            # Once Reserve is confirmed, do not refresh at all. Keep the live DOM
            # scanner/watchdog active and resume F5 only after Accept/Reject/timeout.
            if reserved:
                force_refresh = False
                return

            now_f5 = time.time()

            # Hard floor only: every actual F5 must be at least 5 seconds after
            # the previous actual F5, including queued/forced refreshes.
            if last_f5_press_at and now_f5 - last_f5_press_at < F5_HARD_MIN_GAP:
                return

            def note_f5_press(sent_at: float) -> None:
                nonlocal last_f5_press_at, burst_guard_until
                if last_f5_press_at:
                    actual_gap = sent_at - last_f5_press_at
                    burst_guard_until = 0.0
                last_f5_press_at = sent_at

            if force_refresh:
                force_refresh = False
                send_f5(brain)
                sent_at = time.time()
                note_f5_press(sent_at)
                last_reload = sent_at
                cycle += 1
                next_in = random.uniform(*RESERVED_RELOAD) if reserved else next_reload(cycle, next_in)
                next_in = max(F5_HARD_MIN_GAP, next_in)
                mode = "reserved" if reserved else "normal"
                log(f"Queued forced F5 sent. Next scheduled F5 in {next_in:.1f}s ({mode} refresh mode)")
                return

            if now_f5 < refresh_pause_until or now_f5-_last_click < 1.20 or now_f5-last_reload < max(F5_HARD_MIN_GAP, next_in):
                return
            send_f5(brain)
            sent_at = time.time()
            note_f5_press(sent_at)
            last_reload=sent_at
            cycle+=1
            next_in = random.uniform(*RESERVED_RELOAD) if reserved else next_reload(cycle,next_in)
            next_in = max(F5_HARD_MIN_GAP, next_in)
            mode = "reserved" if reserved else "normal"
            log(f"Next F5 in {next_in:.1f}s ({mode} refresh mode)")

        def clear_reserved(why: str) -> None:
            nonlocal reserved,reserved_at,reserved_id,reserved_hint,reserved_flags,hold_missing_since
            nonlocal reservation_alert_prefix,reserved_remaining_minutes,reserved_midnight_window,reserved_midnight_reject,last_midnight_reject_try
            nonlocal last_reload,next_in,cycle,reserved_details,last_reservation_status_check,reservation_missing_checks
            nonlocal late_reminder_slot,late_reservation_alert_keys
            nonlocal active_opened_id,active_opened_hint,active_opened_deadline_text
            nonlocal force_refresh,refresh_pause_until,reserved_waiting_keys
            nonlocal inspection_last_scroll,inspection_files_opened,inspection_returned_top
            old_prefix = reservation_alert_prefix
            log(why)
            if reserved_id:
                _done.add(str(reserved_id).strip().upper())
                opened_once.add(str(reserved_id).strip().upper())
            if old_prefix:
                cancel_alert_keys([old_prefix+":still1", old_prefix+":still5", old_prefix+":reserved"] + list(late_reservation_alert_keys))
            clear_reservation_state()
            reserved=False; reserved_at=0.0; reserved_id=""; reserved_hint=""; reserved_flags=set(); hold_missing_since=0.0
            reservation_alert_prefix=""; reserved_remaining_minutes=None; reserved_midnight_window=False; reserved_midnight_reject=False; last_midnight_reject_try=0.0
            reserved_details={}; last_reservation_status_check=0.0; reservation_missing_checks=0; reserved_waiting_keys=set()
            late_reminder_slot=-1; late_reservation_alert_keys=set()
            inspection_last_scroll=0.0; inspection_files_opened=False; inspection_returned_top=False
            # A reservation that ended must never leave the dashboard attached to
            # the old order. The next live DOM scan decides what is actually open.
            active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""
            # Return to search immediately when the reservation ends. The queued F5
            # still obeys the global 5-second minimum between real F5 presses.
            refresh_pause_until = 0.0
            force_refresh = True
            last_reload = time.time()
            next_in = next_reload(cycle, None)
            log("SEARCH MODE: reservation ended; new-order scanning is active again and a safe F5 is queued.")
            update_last_state(reserved=False,reserved_id="",reserved_remaining_minutes="",midnight_reject_pending=False,next_refresh_seconds=round(next_in,1))

        def mark_reserved(rid: str, hint: str, reserve_snap: dict|None=None, deadline_text: str="") -> None:
            nonlocal reserved,reserved_at,reserved_id,reserved_hint,reserved_flags,hold_missing_since
            nonlocal reservation_serial,reservation_alert_prefix,reserved_remaining_minutes,reserved_midnight_window,reserved_midnight_reject,last_midnight_reject_try
            nonlocal last_reload,next_in,reserved_details,last_reservation_status_check,reservation_missing_checks
            nonlocal late_reminder_slot,late_reservation_alert_keys
            nonlocal inspection_last_scroll,inspection_files_opened,inspection_returned_top,force_refresh
            reserved=True; reserved_at=time.time(); reserved_id=(rid or hint or "job").strip().upper(); reserved_hint=hint or reserved_id; reserved_flags=set(); hold_missing_since=0.0
            last_reservation_status_check=0.0; reservation_missing_checks=0
            late_reminder_slot=-1; late_reservation_alert_keys=set()
            inspection_last_scroll=0.0; inspection_files_opened=False; inspection_returned_top=False
            # Reservation hold: no F5 is allowed until this reservation ends.
            # The 100ms DOM scanner and 10-second reservation watchdog remain live.
            force_refresh = False
            last_reload = reserved_at
            next_in = 999999.0
            log("RESERVED F5 HOLD: refresh is disabled until this order is accepted, rejected, or no longer reserved.")
            reservation_serial += 1
            reservation_alert_prefix = f"{reserved_id}:{int(reserved_at)}:{reservation_serial}"
            last_midnight_reject_try=0.0
            source = " ".join([deadline_text or "", str((reserve_snap or {}).get("panelText") or ""), reserved_hint])
            reserved_remaining_minutes = parse_remaining_minutes(source)
            reserved_midnight_window = in_midnight_rule_window()
            reserved_midnight_reject = bool(
                reserved_midnight_window
                and reserved_remaining_minutes is not None
                and reserved_remaining_minutes < MIDNIGHT_REJECT_UNDER_MINUTES
            )
            reserved_details = capture_reservation_details(reserve_snap, reserved_id, reserved_hint)
            opened_once.add(reserved_id)
            record_stat("reservations_confirmed")
            update_last_state(
                reserved=True,reserved_id=reserved_id,reserved_hint=reserved_hint[:180],opened_once_count=len(opened_once),
                reserved_remaining_minutes=(round(reserved_remaining_minutes,1) if reserved_remaining_minutes is not None else "unknown"),
                midnight_window_at_reserve=reserved_midnight_window,midnight_reject_pending=reserved_midnight_reject,
            )
            if reserved_midnight_reject:
                log(f"MIDNIGHT RULE ARMED: {reserved_id} has about {reserved_remaining_minutes:.1f} min remaining; it will stay reserved for 1 minute, then the bot will physically click Reject.")
                # Local laptop cue, separate from Pushover: red decision ticket + two-tone bell.
                show_action_popup("REJECT IN 1 MINUTE", "reject", duration=3.0, bell=True)
            elif reserved_midnight_window and reserved_remaining_minutes is None:
                note_issue("MIDNIGHT_DEADLINE_UNKNOWN","Midnight window is active but remaining deadline could not be parsed; automatic Reject is not armed","WARN",reserved_hint,throttle=0)
                show_action_popup("ACCEPT", "accept")
            else:
                # The bot never clicks Accept. This is only the same small green
                # decision cue used by the older script to tell the user what to do.
                show_action_popup("ACCEPT", "accept")
            # Reservation Pushovers: full report now, one short reminder at 1 minute, then from 4m30s one short 'still reserved' every 20s while this exact reservation remains active.
            full_message = build_reserved_pushover_message(reserved_details)
            send_alert("Reserved", full_message, reservation_alert_prefix+":reserved")
            save_reservation_state({
                "reserved_id": reserved_id, "reserved_hint": reserved_hint, "reserved_at": reserved_at,
                "reservation_alert_prefix": reservation_alert_prefix, "reminder_sent": False,
                "late_reminder_slot": -1,
                "reserve_notice_started": True, "details": reserved_details,
                "remaining_minutes": reserved_remaining_minutes, "midnight_window": reserved_midnight_window,
                "midnight_reject": reserved_midnight_reject,
            })

        def panel_identity(snap: dict, fallback_id: str="", fallback_hint: str="") -> tuple[str,str]:
            uid=str(snap.get("urlId") or ""); rid=uid.upper() if uid and uid.lower() not in ("all","findorders") else (fallback_id or active_opened_id)
            hint=fallback_hint or active_opened_hint
            if not hint: hint=str(snap.get("panelText") or "").replace("\n"," ").strip()[:180]
            return rid or hint or "job", hint or rid or "job"

        def wait_reject(seconds: float=3.6) -> dict:
            nonlocal refresh_pause_until
            deadline=time.time()+seconds; refresh_pause_until=max(refresh_pause_until,deadline+0.75); last={}
            while time.time()<deadline and not _stop and not _paused:
                last=brain.read()
                if last: update_last_state(last,reserved=reserved,reserved_id=reserved_id)
                if last.get("reject") or last.get("acceptedGone"): return last
                time.sleep(0.16)
            return last

        def wait_for_panel_identity(expected_id: str, seconds: float=2.4) -> tuple[dict, bool]:
            """After a new row click, never act on the old panel. Return only when URL/panel identity matches the clicked order."""
            nonlocal refresh_pause_until
            expected = str(expected_id or "").strip().upper()
            deadline = time.time() + seconds
            # F5 must not interrupt the row -> matching panel -> Reserve handoff.
            refresh_pause_until = max(refresh_pause_until, deadline + 0.25)
            last = {}
            while time.time() < deadline and not _stop and not _paused:
                last = brain.read() or {}
                if not last:
                    time.sleep(0.06)
                    continue
                uid = str(last.get("urlId") or "").strip().upper()
                url = str(last.get("url") or "").upper()
                panel_text = str(last.get("panelText") or "").upper()
                url_matches = bool(expected and (uid == expected or f"/{expected}" in url))
                public_order = bool(_ORDER_NO_RE.fullmatch(expected))
                # For normal public order numbers, require BOTH the URL identity and the
                # visible panel text to contain the new order number. This prevents the
                # previous panel's Reserve button from being mistaken for the new one.
                identity_matches = bool(url_matches and ((expected in panel_text) if public_order else True))
                if identity_matches:
                    return last, True
                time.sleep(0.06)
            return last, False

        # Recover a reservation across app STOP/START. Before restoring any lock,
        # verify the live page. If the user accepted/rejected while the bot was off,
        # discard the stale state immediately and continue searching.
        persisted = load_reservation_state()
        if persisted:
            persisted_id = str(persisted.get("reserved_id") or "").strip().upper()
            persisted_hint = str(persisted.get("reserved_hint") or persisted_id)
            first_snap = brain.read() or {}
            still_held = job_still_held(first_snap, persisted_id, persisted_hint)
            if not still_held:
                time.sleep(0.7)
                second_snap = brain.read() or {}
                still_held = job_still_held(second_snap, persisted_id, persisted_hint)
            if still_held and persisted_id:
                reserved = True
                reserved_id = persisted_id
                reserved_hint = persisted_hint
                try:
                    reserved_at = float(persisted.get("reserved_at") or time.time())
                except Exception:
                    reserved_at = time.time()
                reservation_alert_prefix = str(persisted.get("reservation_alert_prefix") or f"{reserved_id}:{int(reserved_at)}:restored")
                reserved_details = persisted.get("details") if isinstance(persisted.get("details"), dict) else {}
                try:
                    v = persisted.get("remaining_minutes")
                    reserved_remaining_minutes = None if v is None else float(v)
                except Exception:
                    reserved_remaining_minutes = None
                reserved_midnight_window = bool(persisted.get("midnight_window"))
                reserved_midnight_reject = bool(persisted.get("midnight_reject"))
                if bool(persisted.get("reminder_sent")):
                    reserved_flags.add("1")
                try:
                    late_reminder_slot = int(persisted.get("late_reminder_slot", -1))
                except Exception:
                    late_reminder_slot = -1
                late_reservation_alert_keys = set()
                opened_once.add(reserved_id)
                last_reload = time.time()
                next_in = random.uniform(*RESERVED_RELOAD)
                last_reservation_status_check = 0.0
                reservation_missing_checks = 0
                restored_waited = max(0.0, time.time() - reserved_at)
                inspection_last_scroll = 0.0
                inspection_files_opened = restored_waited >= RESERVED_INSPECTION_RETURN_AT
                inspection_returned_top = restored_waited >= RESERVED_INSPECTION_RETURN_AT
                record_stat("reservation_state_restores")
                log(f"RESERVATION RESTORED: {reserved_id} is still reserved. Original timer retained; status will be checked every 10 seconds.")
                update_last_state(reserved=True, reserved_id=reserved_id, restored_reservation=True)
            else:
                if persisted_id:
                    _done.add(persisted_id)
                    opened_once.add(persisted_id)
                clear_reservation_state()
                log(f"RESERVATION RECONCILED ON START: {persisted_id or 'previous order'} is no longer reserved. Stale timer cleared; searching resumes.")

        while not _stop:
            try:
                scan_cycle_started = time.perf_counter()
                if app_stop_requested():
                    try:
                        _APP_STOP_FILE.unlink(missing_ok=True)
                    except Exception:
                        pass
                    request_stop("Adeon app deactivate requested")
                    break
                # Legacy pause code is kept only for direct-script compatibility; the installed app uses START/STOP only.
                # mouse movement/clicks, or new alert scheduling occurs. A resume request
                # is validated once against the live tab before any automation restarts.
                if _paused:
                    if _resume_requested:
                        with _pause_lock:
                            globals()["_resume_requested"] = False
                            resume_source = str(globals().get("_resume_source") or "hotkey")
                            globals()["_resume_source"] = ""
                        resume_snap = brain.read() or {}
                        resume_url = str(resume_snap.get("url") or "")
                        if resume_snap and not bool(resume_snap.get("loggedOut")) and "findorders" in resume_url.lower():
                            # Re-run the full mapping/window safety check after a logout or long pause.
                            # The paused flag stays set during the check, so no mouse/F5 action can leak through.
                            resume_ok = startup_self_check(brain)
                            if resume_ok:
                                with _pause_lock:
                                    globals()["_paused"] = False
                                    globals()["_pause_reason"] = ""
                                record_stat("soft_resumes")
                                last_reload=time.time(); next_in=next_reload(cycle,next_in); force_refresh=False
                                idle_active_started=time.time(); idle_pause_until=0.0
                                last_idle=time.time(); last_idle_click=time.time()
                                log(f"{resume_source} RESUME CONFIRMED: Find Orders is open, logged in, and the safety mapping passed. Bot activity is continuing now.")
                            else:
                                log(f"{resume_source} RESUME REFUSED: Find Orders was visible but the startup safety check failed. Bot remains paused.")
                        else:
                            if bool(resume_snap.get("loggedOut")):
                                hard_stop_logout(f"LR Writers logout/login page detected during {resume_source} resume check")
                                break
                            reason = f"not on Find Orders ({resume_url or 'unknown page'})"
                            log(f"{resume_source} RESUME REFUSED: {reason}. Bot remains paused until Find Orders is open and you press Ctrl+A or Alt+A again.")
                    refresh_status_ticket("ONLINE")
                    time.sleep(0.12)
                    continue

                refresh_status_ticket("ONLINE")
                maybe_f5()
                if _paused or _stop:
                    continue
                snap=brain.read(); now=time.time()
                if not snap:
                    if not blank_since: blank_since=now
                    elif now-blank_since>=3.0: note_issue("DOM_BLIND","No usable DOM snapshot for at least 3 seconds; worker remains alive","WARN",f"blind_for={now-blank_since:.1f}s", throttle=30.0)
                    if blank_since and now-blank_since>=10.0:
                        record_stat("reconnects"); brain.reconnect()
                        set_status_ticket(bot="CONNECTED", page="WAITING NETWORK", job=("RESERVED " + str(reserved_id or "")) if reserved else "SEARCHING", f5="WAITING", mouse="OFF")
                    time.sleep(0.2); continue
                blank_since=0.0
                if bool(snap.get("loggedOut")):
                    update_last_state(snap,reserved=reserved,reserved_id=reserved_id,logged_out=True,soft_paused=False)
                    hard_stop_logout("LR Writers logout/login page detected")
                    break

                rows=snap.get("rows") or []

                # Live-open reconciliation. Never keep JOB OPEN pinned to an order
                # after its panel was closed, accepted, rejected, or replaced.
                # This runs on every DOM scan, so the dashboard follows the live page
                # instead of remembering an old task number.
                if not reserved and active_opened_id:
                    live_panel_open = bool(snap.get("panelOpen"))
                    live_id, live_hint = panel_identity(snap) if live_panel_open else ("", "")
                    live_id_norm = str(live_id or "").strip().upper()
                    active_norm = str(active_opened_id or "").strip().upper()
                    if not live_panel_open or bool(snap.get("acceptedGone")):
                        old_open = active_opened_id
                        active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""
                        log(f"OPEN STATE CLEARED: {old_open} is no longer open on the live page.")
                    elif live_id_norm and active_norm and live_id_norm != active_norm:
                        old_open = active_opened_id
                        active_opened_id = live_id_norm
                        active_opened_hint = str(live_hint or live_id_norm)
                        active_opened_deadline_text = ""
                        log(f"OPEN STATE SWITCHED: {old_open} -> {active_opened_id} from the live DOM.")

                update_last_state(snap,reserved=reserved,reserved_id=reserved_id,active_opened_id=active_opened_id,opened_once_count=len(opened_once),next_refresh_seconds=round(max(0.0,next_in-(now-last_reload)),1),idle_mouse_paused=bool(idle_pause_until and now<idle_pause_until),idle_pause_remaining_seconds=round(max(0.0,idle_pause_until-now),1) if idle_pause_until else 0.0,logged_out=False,soft_paused=False)
                refresh_status_ticket("ONLINE")

                # Observe real user clicks without creating them. If you manually
                # click Accept, stop reservation alerts immediately and lock this
                # order so it can never be row-clicked again in this session.
                audit = consume_click_audit(snap, context="page")
                if audit and bool(audit.get("trusted")):
                    audit_text = str(audit.get("text") or "").strip().lower()
                    if audit_text in ("accept", "accept order"):
                        record_stat("manual_accepts")
                        accepted_id, _accepted_hint = panel_identity(snap)
                        last_accepted_id = str(accepted_id or "").strip().upper()
                        post_accept_ready = True
                        # No post-Accept delay. Cancel any row/panel pause and make the very next loop press F5.
                        refresh_pause_until = 0.0
                        force_refresh = True
                        if reserved:
                            log("Trusted manual Accept click detected. Reservation alerts stopped; old row stays locked. Immediate F5 queued; next NEW row may replace the still-open old panel.")
                            clear_reserved("You manually accepted the reserved order. No more alerts for it.")
                        else:
                            old_open = active_opened_id
                            active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""
                            log(f"Trusted manual Accept click detected. OPEN state cleared for {old_open or 'current order'}; immediate F5 queued and searching resumes.")
                        continue
                    if audit_text in ("reject", "reject order") and reserved:
                        record_stat("manual_rejects")
                        refresh_pause_until = 0.0
                        force_refresh = True
                        clear_reserved("Trusted manual Reject click detected. Reservation reminders were cancelled immediately; this order stays locked and will not be reserved again this session.")
                        continue

                if now-last_port_check>=15.0:
                    last_port_check=now
                    if not chrome_port_live(): note_issue("DEBUG_PORT_LOST","Chrome DevTools connection stopped responding","ERROR")
                if snap.get("reserve") and snap.get("reject"): note_issue("AMBIGUOUS_RESERVE_REJECT","Reserve and Reject are visible at the same time","WARN",str(snap.get("url") or ""))
                if rows:
                    missing_ids=sum(1 for r in rows if not r.get("id"))
                    if missing_ids==len(rows): note_issue("ROW_IDS_MISSING","All visible order rows are missing IDs; site HTML may have changed","WARN",f"rows={len(rows)}")
                    zero_pay=sum(1 for r in rows if float(r.get("pay") or 0)<=0 and "$" in str(r.get("text") or ""))
                    if zero_pay: note_issue("PAY_PARSE_FAILED","A visible row contains a dollar amount but pay parsed as zero","WARN",f"rows={zero_pay}")
                if now-last_health_log>=60.0:
                    last_health_log=now; log(f"HEALTH OK | rows={len(rows)} reserved={reserved} issues={len(_issues)} reads={_stats.get('dom_reads',0)}")

                row_list_key="|".join(str(r.get("id") or r.get("text") or "")[:24] for r in rows)
                if row_list_key!=last_row_key:
                    last_row_key=row_list_key
                    if rows: log("Rows: "+" | ".join(f"${float(r.get('pay') or 0):.2f} {str(r.get('text') or '')[:34]}" for r in rows[:6]))
                    else: log("Rows: none")

                url=str(snap.get("url") or "")
                if "findorders" not in url.lower():
                    # Temporary network loss must NEVER terminate the picker. Chrome can
                    # replace the LR page with chrome-error://chromewebdata while offline.
                    # Keep the worker/reservation state alive and use the existing physical
                    # F5 mechanism at a safe 5-20 second cadence until the same tab recovers.
                    if is_network_error_snapshot(snap):
                        record_stat("left_find_orders")
                        update_last_state(snap, reserved=reserved, reserved_id=reserved_id, network_wait=True)
                        set_status_ticket(bot="CONNECTED", page="WAITING NETWORK", job=("RESERVED " + str(reserved_id or "")) if reserved else "SEARCHING", f5="WAITING", mouse="OFF")
                        note_issue("NETWORK_WAIT", "Network/browser error page detected; Adeon stays alive and will recover automatically", "INFO", url[:250], throttle=30.0)
                        # Never release the reservation lock just because the network vanished.
                        # A refresh is allowed while offline so Chrome can retry the same page
                        # when connectivity returns.
                        if now-last_reload >= max(F5_HARD_MIN_GAP, next_in):
                            send_f5(brain)
                            last_reload=time.time()
                            next_in=random.uniform(NETWORK_RETRY_MIN, NETWORK_RETRY_MAX)
                            log(f"NETWORK RECOVERY: F5 sent; next retry in {next_in:.1f}s if still offline.")
                        time.sleep(DOM_SCAN_INTERVAL)
                        continue
                    record_stat("left_find_orders")
                    hard_stop_logout(f"Controlled LR Writers tab left Find Orders ({url or 'unknown page'}); automatic navigation is disabled")
                    break

                # Scheduled low-impact tab round trip. Never interrupt an open/reserved order.
                if now >= next_my_orders_visit and not reserved and not snap.get("panelOpen"):
                    if perform_my_orders_visit(brain, snap):
                        next_my_orders_visit = time.time() + random.uniform(*MY_ORDERS_VISIT)
                        last_reload = time.time()
                        next_in = next_reload(cycle, None)
                        active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""
                        continue
                    else:
                        # If the nav was temporarily unavailable, try again in five minutes.
                        next_my_orders_visit = time.time() + 5 * 60.0

                if reserved:
                    waited=time.time()-reserved_at

                    # FUNCTIONAL RESERVED-PANEL INSPECTION. There is no F5 while held.
                    # During the first minute, use the visible wheel to reveal lower
                    # panel content and open the Files accordion once when it is a safe
                    # non-link toggle. Before one minute, return to the top and wait.
                    if waited < RESERVED_INSPECTION_SCROLL_UNTIL and not inspection_returned_top:
                        if (not inspection_files_opened) and snap.get("filesToggle"):
                            ft = snap.get("filesToggle")
                            if motor_click(ft, "Files section", "files_toggle", snap, brain):
                                inspection_files_opened = True
                                log("RESERVED PANEL INSPECTION: Files section opened once for content inspection.")
                                snap = brain.read() or snap
                        if now - inspection_last_scroll >= RESERVED_INSPECTION_SCROLL_EVERY:
                            if scroll_reserved_panel(snap, brain, RESERVED_INSPECTION_WHEEL_DOWN, "scrolling down through reserved panel"):
                                inspection_last_scroll = now
                                snap = brain.read() or snap
                    elif waited >= RESERVED_INSPECTION_RETURN_AT and not inspection_returned_top:
                        # If the Files accordion is still expanded and its safe toggle is
                        # visible, close it; then return the panel to its upper view.
                        ft = snap.get("filesToggle")
                        if ft and str(ft.get("expanded") or "").lower() == "true":
                            motor_click(ft, "Files section", "files_toggle", snap, brain)
                            snap = brain.read() or snap
                        scroll_reserved_panel(snap, brain, RESERVED_INSPECTION_WHEEL_UP, "returning reserved panel to top")
                        inspection_returned_top = True
                        log("RESERVED PANEL INSPECTION COMPLETE: panel returned to the top; waiting only for Accept/Reject/reservation end.")

                    # HARD RESERVATION HOLD: rows are still scanned every 100 ms, but
                    # while one order is genuinely reserved Adeon must not click/open
                    # any other job. New jobs simply wait in the list until the current
                    # reservation ends through manual Accept/Reject, auto-Reject, expiry,
                    # or the 10-second reservation watchdog.
                    waiting_now=set()
                    current_norm=str(reserved_id or "").strip().upper()
                    done_now={str(x).strip().upper() for x in _done}
                    for wr in rows:
                        wk=row_key(wr).strip().upper()
                        if not wk or wk == current_norm or wk in done_now:
                            continue
                        if wr.get("tutor") or has_do_not_accept(str(wr.get("text") or "")):
                            continue
                        try:
                            if float(wr.get("pay") or 0) < MIN_PAY:
                                continue
                        except Exception:
                            continue
                        waiting_now.add(wk)
                    if waiting_now != reserved_waiting_keys:
                        reserved_waiting_keys = waiting_now
                        if reserved_waiting_keys:
                            log(f"RESERVED HOLD: {len(reserved_waiting_keys)} other eligible job(s) visible; none will be clicked until {reserved_id} is accepted/rejected or otherwise leaves reserved state.")
                        else:
                            log("RESERVED HOLD: no other eligible jobs are currently waiting.")

                    # Independent reservation watchdog. Every 10 seconds, verify that
                    # THIS exact order is still reserved. Two consecutive misses are
                    # required to survive a brief F5/DOM transition, then stale state
                    # is cleared and normal searching resumes automatically.
                    if now-last_reservation_status_check >= RESERVATION_STATUS_CHECK:
                        last_reservation_status_check = now
                        record_stat("reservation_status_checks")
                        held_now = job_still_held(snap,reserved_id,reserved_hint)
                        if reservation_definitely_ended(snap, reserved_id):
                            if snap.get("acceptedGone"):
                                last_accepted_id = str(reserved_id or "").strip().upper()
                                post_accept_ready = True
                            refresh_pause_until = 0.0
                            force_refresh = True
                            clear_reserved("10-second reservation check found a definite accepted/rejected end state. Stale reservation state cleared; searching resumes.")
                            continue
                        if held_now:
                            reservation_missing_checks = 0
                            hold_missing_since = 0.0
                        else:
                            reservation_missing_checks += 1
                            log(f"RESERVATION CHECK: {reserved_id} not confirmed reserved ({reservation_missing_checks}/2).")
                            if reservation_missing_checks >= 2:
                                old_id = reserved_id
                                refresh_pause_until = 0.0
                                force_refresh = True
                                clear_reserved(f"10-second reservation checks confirmed {old_id} is no longer reserved (accepted/rejected/expired). Stale timer cleared; searching resumes.")
                                continue

                    # If the deadline was not readable at the instant of reservation, try again
                    # from the live reserved panel/row while the midnight window snapshot is active.
                    if reserved_midnight_window and reserved_remaining_minutes is None:
                        live_source = str(snap.get("panelText") or "")
                        for rr in rows:
                            if row_key(rr).strip().upper() == str(reserved_id).strip().upper():
                                live_source += " " + deadline_source_for_row(rr)
                                break
                        maybe_minutes = parse_remaining_minutes(live_source)
                        if maybe_minutes is not None:
                            reserved_remaining_minutes = maybe_minutes
                            reserved_midnight_reject = maybe_minutes < MIDNIGHT_REJECT_UNDER_MINUTES
                            st = load_reservation_state()
                            if st:
                                st["remaining_minutes"] = maybe_minutes
                                st["midnight_reject"] = reserved_midnight_reject
                                save_reservation_state(st)
                            update_last_state(reserved_remaining_minutes=round(maybe_minutes,1),midnight_reject_pending=reserved_midnight_reject)
                            if reserved_midnight_reject:
                                log(f"MIDNIGHT RULE ARMED LATE: {reserved_id} has about {maybe_minutes:.1f} min remaining; Reject is due at the 1-minute reservation mark.")

                    # Midnight rule remains independent of the notification schedule.
                    if reserved_midnight_reject and waited >= MIDNIGHT_REJECT_AFTER:
                        expected = str(reserved_id or "").strip().upper()
                        panel_text_upper = str(snap.get("panelText") or "").upper()
                        url_upper = str(snap.get("url") or "").upper()
                        uid_upper = str(snap.get("urlId") or "").upper()
                        same_panel = bool(expected and (uid_upper == expected or expected in url_upper or expected in panel_text_upper))
                        if snap.get("reject") and same_panel and (time.time()-last_midnight_reject_try >= 15.0):
                            last_midnight_reject_try = time.time()
                            log(f"MIDNIGHT RULE: 1 minute reached for {reserved_id}; physically clicking the verified Reject button now.")
                            show_action_popup("REJECT", "reject", duration=2.2, bell=False)
                            if motor_click(snap.get("reject"),"Reject (midnight rule)","midnight_reject",snap,brain):
                                record_stat("midnight_auto_rejects")
                                rejected_id = reserved_id
                                rejected_hint = reserved_hint
                                reject_notice_key = f"midnight-rejected:{reservation_alert_prefix or rejected_id}:{int(time.time()*1000)}"
                                clear_reserved(f"MIDNIGHT RULE COMPLETE: {rejected_id} was rejected after 1 minute because its remaining time was under 5 hours.")
                                send_alert("Midnight auto-rejected",rejected_hint,reject_notice_key)
                                refresh_pause_until = 0.0
                                force_refresh = True
                                continue
                        elif not same_panel:
                            note_issue("MIDNIGHT_REJECT_PANEL_MISMATCH","Midnight Reject is due, but the visible panel identity does not match the reserved order; Reject was not clicked","WARN",f"expected={expected} url={snap.get('url')}",throttle=10.0)
                        elif not snap.get("reject"):
                            note_issue("MIDNIGHT_REJECT_BUTTON_MISSING","Midnight Reject is due, but the verified Reject button is not currently visible; bot will keep checking","WARN",reserved_id,throttle=10.0)

                    # Reservation notifications:
                    # 1) full report at Reserve (sent in mark_reserved)
                    # 2) one short "still reserved" at 1 minute
                    # 3) normal jobs: from 4m30s onward, another short "still reserved" every 20 seconds
                    #    midnight <5h jobs: after the 1-minute reject point, repeat every 20 seconds
                    #    while the reservation is still alive. Every reminder gets two fresh,
                    #    strong checks first so an accepted/rejected order cannot keep producing
                    #    stale queued reminders.
                    if waited >= RESERVE_REMINDER_AFTER and "1" not in reserved_flags and reservation_alert_prefix:
                        reminder_key = reservation_alert_prefix+":still1"
                        if reminder_key in _alerted:
                            reserved_flags.add("1")
                            st = load_reservation_state()
                            if st:
                                st["reminder_sent"] = True
                                save_reservation_state(st)
                        else:
                            confirm1 = job_still_held(snap,reserved_id,reserved_hint)
                            confirm_snap = {}
                            if confirm1:
                                time.sleep(DOM_SCAN_INTERVAL)
                                confirm_snap = brain.read() or {}
                            confirm2 = bool(confirm_snap and job_still_held(confirm_snap,reserved_id,reserved_hint))
                            if confirm1 and confirm2 and reserved and reservation_alert_prefix:
                                send_alert("still reserved","still reserved",reminder_key)
                            elif reservation_definitely_ended(confirm_snap or snap, reserved_id):
                                refresh_pause_until = 0.0
                                force_refresh = True
                                clear_reserved("1-minute reminder check found the order already accepted/rejected. Reminder cancelled; searching resumes.")
                                continue

                    # For a midnight <5h reservation that should have been rejected at
                    # the 1-minute mark, begin the repeating warning immediately after that
                    # first minute. If Reject cannot complete (for example because the DOM
                    # or network is temporarily unavailable), keep sending every 20 seconds
                    # until this exact reservation actually ends/times out. Normal reserved
                    # jobs keep the existing 4m30s repeat start.
                    repeat_start = (RESERVE_REMINDER_AFTER + RESERVE_REPEAT_EVERY) if reserved_midnight_reject else RESERVE_REPEAT_START
                    if waited >= repeat_start and reservation_alert_prefix:
                        current_late_slot = int((waited - repeat_start) // RESERVE_REPEAT_EVERY)
                        if current_late_slot > late_reminder_slot:
                            late_key = reservation_alert_prefix + f":still-late-{current_late_slot}"
                            confirm1 = job_still_held(snap,reserved_id,reserved_hint)
                            confirm_snap = {}
                            if confirm1:
                                time.sleep(DOM_SCAN_INTERVAL)
                                confirm_snap = brain.read() or {}
                            confirm2 = bool(confirm_snap and job_still_held(confirm_snap,reserved_id,reserved_hint))
                            if confirm1 and confirm2 and reserved and reservation_alert_prefix:
                                # Mark this 20-second slot as consumed as soon as it is queued so
                                # the 100ms loop cannot produce duplicate reminders for the same slot.
                                late_reminder_slot = current_late_slot
                                late_reservation_alert_keys.add(late_key)
                                send_alert("still reserved", "still reserved", late_key)
                                st = load_reservation_state()
                                if st:
                                    st["late_reminder_slot"] = late_reminder_slot
                                    save_reservation_state(st)
                                log(f"LATE RESERVATION REMINDER: still reserved at {waited:.0f}s; next reminder is due in {RESERVE_REPEAT_EVERY:.0f}s if the reservation is still active.")
                            elif reservation_definitely_ended(confirm_snap or snap, reserved_id):
                                refresh_pause_until = 0.0
                                force_refresh = True
                                clear_reserved("Late reminder check found the order already accepted/rejected/timed out. All remaining reminders cancelled; searching resumes.")
                                continue

                # Never select/click another row while the current reservation is alive.
                # The rows are still being scanned above so a waiting job is noticed, but
                # it cannot be opened until clear_reserved() returns the bot to SEARCHING.
                extra=None if reserved else pick_row(rows,reserved_id,tapped,opened_once); panel=snap.get("panelText") or ""
                # After a trusted/manual Accept, LR Writers may leave the accepted order panel open.
                # If a different NEW eligible row exists, ignore only that stale old panel and click the new row once.
                post_accept_new_row = bool((not reserved) and post_accept_ready and extra and row_key(extra).strip().upper() != last_accepted_id)
                if reserved:
                    # Reservation logic above owns the session. Keep DOM scanning and
                    # health checks, but do not F5 or touch any other order.
                    busy_since=0.0
                elif post_accept_new_row:
                    busy_since=0.0
                    log(f"POST-ACCEPT NEW ROW: old panel may still be open, but new order {row_key(extra)} is available; opening it immediately with the physical mouse.")
                elif has_do_not_accept(panel):
                    rid,_=panel_identity(snap); log("DO NOT ACCEPT. Skipping this exact open order. Never clicking Accept.")
                    if rid:
                        rid_norm=str(rid).strip().upper(); _done.add(rid_norm); opened_once.add(rid_norm)
                    active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""; extra=pick_row(rows,reserved_id,tapped,opened_once); busy_since=0.0
                elif snap.get("reject"):
                    busy_since=0.0
                    if not reserved:
                        rid,hint=panel_identity(snap); log("Reject is showing. Reserved. Never clicking Accept."); mark_reserved(rid,hint,snap,active_opened_deadline_text)
                elif snap.get("reserve"):
                    busy_since=0.0; pos=snap["reserve"]; rid,hint=panel_identity(snap)
                    if time.time()-last_reserve_try>=RESERVE_RETRY_SEC:
                        last_reserve_try=time.time()
                        preview = viewport_to_screen(
                            float(pos.get("vx") or 0),
                            float(pos.get("vy") or 0),
                            str(snap.get("pageTitle") or ""),
                            float(snap.get("innerW") or 0),
                            float(snap.get("innerH") or 0),
                        )
                        log(
                            f"Reserve visible at DOM ({int(pos.get('vx') or 0)}, {int(pos.get('vy') or 0)}) "
                            f"mapped {preview} — attempting"
                        )
                        # HARD PRE-RESERVE WARNING GATE: re-read the live panel at the
                        # last possible moment. A DO NOT ACCEPT / fine warning means
                        # Reserve is forbidden, even if it appeared after the prior scan.
                        pre_reserve = brain.read() or snap
                        if has_do_not_accept(pre_reserve.get("panelText") or ""):
                            log(f"DO NOT ACCEPT appeared immediately before Reserve for {rid}; Reserve cancelled and order locked out.")
                            rid_norm=str(rid or "").strip().upper()
                            if rid_norm:
                                _done.add(rid_norm); opened_once.add(rid_norm)
                            active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""
                            continue
                        if pre_reserve.get("reserve"):
                            pos = pre_reserve["reserve"]
                            snap = pre_reserve
                        if motor_click(pos,"Reserve","reserve",snap,brain):
                            check=wait_reject(3.6)
                            if check.get("reject"):
                                rid2,hint2=panel_identity(check,rid,hint); log("Reject appeared. Reserved confirmed. Never clicking Accept."); mark_reserved(rid2,hint2,check,active_opened_deadline_text)
                            elif check.get("acceptedGone"): note_issue("RESERVE_STATE_UNEXPECTED","Page moved to accepted state while waiting for Reserve confirmation","WARN",rid,throttle=0)
                            else:
                                shot = capture_diagnostic("reserve_unconfirmed", min_interval=6.0)
                                note_issue(
                                    "RESERVE_UNCONFIRMED",
                                    "Reserve was clicked but Reject confirmation was not seen within 3.6 seconds",
                                    "WARN",
                                    f"{rid} screenshot={shot}",
                                    throttle=0,
                                )
                    continue
                elif snap.get("accept") or (snap.get("panelOpen") and snap.get("reserveDisabled")):
                    # An unreserved unresolved/stale panel must never pin Adeon to that
                    # order. Keep the row scanner alive; if another eligible job exists
                    # it may be opened, otherwise normal F5 searching continues.
                    if not busy_since:
                        busy_since=now
                    elif now-busy_since>=2.0:
                        note_issue("UNRESERVED_PANEL_IGNORED","Unreserved panel stayed unresolved; Adeon is continuing to search instead of staying fixed to it","INFO",str(snap.get("url") or ""),throttle=10.0)
                        if active_opened_id:
                            old_open=active_opened_id
                            active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""
                            log(f"SEARCH MODE: stopped displaying OPEN {old_open}; no active reservation exists, so row scanning continues.")
                else: busy_since=0.0

                if extra:
                    rid=row_key(extra); log("Opening row once "+str(extra.get("text") or "")[:50]); tapped[rid]=time.time()
                    active_opened_id=rid; active_opened_hint=str(extra.get("text") or rid); active_opened_deadline_text=deadline_source_for_row(extra); refresh_pause_until=max(refresh_pause_until,time.time()+2.5)
                    if motor_click(extra,"ROW","row",snap,brain):
                        opened_once.add(str(rid).strip().upper())
                        log(f"ROW ONE-CLICK LOCK: {rid} will not be clicked again this session. F5 will refresh it; another new order can be opened only while no order is actively reserved.")
                        update_last_state(active_opened_id=active_opened_id,opened_once_count=len(opened_once))
                        # Critical stale-panel protection: do not inspect/click Reserve until the URL/panel identity
                        # proves that the newly clicked row has actually replaced any previously open panel.
                        opened, identity_ok = wait_for_panel_identity(rid, 2.4)
                        if not identity_ok:
                            note_issue(
                                "NEW_ROW_PANEL_IDENTITY_NOT_READY",
                                "New row was clicked, but the open panel never proved it belonged to that order; Reserve was not touched",
                                "WARN",
                                f"expected={rid} current_url={str((opened or {}).get('url') or '')}",
                                throttle=0,
                            )
                            snap=opened or snap; rows=snap.get("rows") or rows
                        else:
                            if post_accept_ready:
                                post_accept_ready=False
                                log(f"POST-ACCEPT PANEL SWITCH CONFIRMED: {rid}. Old accepted panel has been replaced by the new order.")
                            snap=opened or snap; rows=snap.get("rows") or rows; update_last_state(snap,active_opened_id=active_opened_id)
                        if identity_ok and has_do_not_accept(snap.get("panelText") or ""):
                            log("DO NOT ACCEPT after open. Skipping this exact order."); _done.add(str(rid).strip().upper()); opened_once.add(str(rid).strip().upper()); active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""
                        elif identity_ok and snap.get("reject"):
                            if not reserved: log("Reject after open. Reserved."); mark_reserved(rid,str(extra.get("text") or rid),snap,deadline_source_for_row(extra))
                        elif identity_ok and snap.get("reserve"):
                            # HARD PRE-RESERVE WARNING GATE again after row-open identity proof.
                            pre_reserve = brain.read() or snap
                            if has_do_not_accept(pre_reserve.get("panelText") or ""):
                                log(f"DO NOT ACCEPT appeared immediately before Reserve for {rid}; skipping without Reserve.")
                                _done.add(str(rid).strip().upper()); opened_once.add(str(rid).strip().upper())
                                active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""
                                continue
                            if pre_reserve.get("reserve"):
                                snap = pre_reserve
                            pos=snap["reserve"]; log("Reserve appeared after row open — clicking"); last_reserve_try=time.time()
                            if motor_click(pos,"Reserve","reserve",snap,brain):
                                check=wait_reject(3.6)
                                if check.get("reject"):
                                    rid2,hint2=panel_identity(check,rid,str(extra.get("text") or rid)); log("Reject appeared. Reserved confirmed."); mark_reserved(rid2,hint2,check,active_opened_deadline_text)
                                elif check.get("acceptedGone"): note_issue("RESERVE_STATE_UNEXPECTED","Page moved to accepted state while waiting for Reserve confirmation","WARN",rid,throttle=0)
                                else:
                                    shot = capture_diagnostic("reserve_unconfirmed_after_open", min_interval=6.0)
                                    note_issue(
                                        "RESERVE_UNCONFIRMED",
                                        "Reserve clicked after opening row but confirmation was not seen",
                                        "WARN",
                                        f"{rid} screenshot={shot}",
                                        throttle=0,
                                    )
                        elif identity_ok:
                            note_issue("ROW_PANEL_NOT_READY","New row panel identity matched, but Reserve/Reject did not appear during initial wait","INFO",rid)

                # Idle-only mouse rhythm: roam/click normally for five minutes, then
                # stop ALL idle mouse activity for a random 3-20 minutes. Job row,
                # Reserve/Reject safety actions and F5 are NOT paused by this rest.
                idle_now = time.time()
                if idle_pause_until:
                    if idle_now >= idle_pause_until:
                        idle_pause_until = 0.0
                        idle_active_started = idle_now
                        last_idle = idle_now
                        last_idle_click = idle_now
                        next_idle = random.uniform(*IDLE_MOVE)
                        next_idle_click = random.uniform(*IDLE_CLICK)
                        log("IDLE MOUSE RESUMED after random rest; new 1-minute active window started.")
                elif idle_now - idle_active_started >= IDLE_ACTIVE_FOR:
                    rest_for = random.uniform(*IDLE_REST)
                    idle_pause_until = idle_now + rest_for
                    record_stat("idle_pause_cycles")
                    log(f"IDLE MOUSE PAUSED for {rest_for/60:.1f} minutes after 5 active minutes. F5 and real job clicks continue.")
                else:
                    if idle_now-last_idle>=next_idle:
                        idle_mouse(snap, allow_click=False)
                        last_idle=idle_now
                        next_idle=random.uniform(*IDLE_MOVE)

                    if idle_now-last_idle_click>=next_idle_click:
                        idle_mouse(snap, allow_click=True)
                        last_idle_click=idle_now
                        next_idle_click=random.uniform(*IDLE_CLICK)

                refresh_status_ticket("ONLINE")
                maybe_f5()
                # Target one live DOM/row scan every 100 ms during ordinary
                # operation. Action/reload transitions may briefly take longer, but
                # we never intentionally sleep past the 100 ms scan cadence here.
                scan_elapsed = time.perf_counter() - scan_cycle_started
                if scan_elapsed < DOM_SCAN_INTERVAL:
                    time.sleep(DOM_SCAN_INTERVAL - scan_elapsed)
            except KeyboardInterrupt:
                request_stop(); break
            except Exception:
                record_stat("loop_errors"); note_issue("LOOP_ERROR","Unexpected main-loop error; bot continued","ERROR",traceback.format_exc(),throttle=0); time.sleep(0.6)

        if _stop_reason=="normal shutdown": _stop_reason="stop flag requested"
        final_page = "LOGGED OUT" if "logout" in str(_stop_reason).lower() or "login" in str(_stop_reason).lower() else "OFF"
        set_status_ticket(bot="STOPPED", page=final_page, f5="OFF", mouse="OFF")
        log("Stopped.")
    finally:
        final_page = "LOGGED OUT" if "logout" in str(_stop_reason).lower() or "login" in str(_stop_reason).lower() else "OFF"
        set_status_ticket(bot="STOPPED", page=final_page, f5="OFF", mouse="OFF")
        try: brain.close()
        except Exception as e: note_issue("BRAIN_CLOSE_ERROR","Error while closing browser connection","WARN",str(e),throttle=0)
        write_shutdown_report(_stop_reason)


def reset_session_state() -> None:
    """Reset per-run state so every Alt+S START is a clean new bot session/report."""
    global SESSION_STARTED_AT, SESSION_ID, _SESSION_LOG, _REPORT_LOCAL, _REPORT_VISIBLE
    global _report_written, _stop_reason, _stop, _paused, _pause_reason, _resume_requested, _resume_source
    global _last_click, _last_idle_dir, _last_diag_shot, _debug_chrome_pid, _debug_port, _debug_endpoint, _debug_user_data_dir

    SESSION_STARTED_AT = time.time()
    SESSION_ID = datetime.now().strftime("%Y%m%d_%H%M%S")
    _SESSION_LOG = _REPORT_DIR / f"Adeon Session {SESSION_ID}.log"
    _REPORT_LOCAL = _REPORT_DIR / f"Adeon Report {SESSION_ID}.txt"
    _REPORT_VISIBLE = _VISIBLE_REPORT_DIR / f"Adeon Report {SESSION_ID}.txt"
    _report_written = False
    _stop_reason = "normal shutdown"
    _stop = False
    _paused = False
    _pause_reason = ""
    _resume_requested = False
    _resume_source = ""
    _last_click = 0.0
    _last_idle_dir = ""
    _last_diag_shot = 0.0
    _debug_chrome_pid = 0
    _debug_port = 0
    _debug_endpoint = ""
    _debug_user_data_dir = ""
    _done.clear()
    with _alert_lock:
        _alerted.clear()
        _alert_last_try.clear()
        _alert_inflight.clear()
        _alert_cancelled.clear()
    with _issue_lock:
        _issues.clear()
        _issue_last.clear()
    _last_state.clear()
    for key in list(_stats):
        _stats[key] = 0


def _session_thread_entry() -> None:
    global _controller_active
    try:
        run_bot_session()
    finally:
        with _controller_lock:
            _controller_active = False
        set_status_ticket(bot="STOPPED", page="OFF", job="-", f5="OFF", mouse="OFF")


def main() -> None:
    """Adeon Bot is worker-only. The visible controller is Adeon.exe / Adeon App.pyw.

    This deliberately removes the old source-controller mode that could leave a
    black Python/CMD window open. If this .py file is accidentally launched by
    itself, it simply asks Windows to open the Adeon app and exits.
    """
    global _stop
    dpi_aware()
    if _APP_WORKER_MODE:
        try:
            _APP_STOP_FILE.unlink(missing_ok=True)
            _APP_LAST_ERROR_FILE.unlink(missing_ok=True)
        except Exception:
            pass
        # Reset first so every lifecycle line belongs to the same report/log.
        reset_session_state()
        log("WORKER | Activate received; starting fresh Adeon worker.")
        log(f"WORKER | PID={os.getpid()} mode=app-worker base={_BASE_DIR}")
        # The visible Adeon app owns the persistent bottom-left dashboard so it
        # remains visible even after this worker is DEACTIVATED.
        set_status_ticket(bot="STARTING", page="CONNECTING", job="SEARCHING", f5="WAIT", mouse="WAIT")
        run_bot_session()
        return

    # Never run the legacy Alt+S/source-controller loop from the editable script.
    # Starting the source directly should result in the real Adeon app, not a terminal.
    try:
        base = _BASE_DIR
        exe = base / "Adeon.exe"
        app = base / "Adeon App.pyw"
        if exe.exists():
            subprocess.Popen(
                [str(exe)], cwd=str(base),
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
        elif app.exists():
            pyw = Path(sys.executable).with_name("pythonw.exe")
            runner = str(pyw if pyw.exists() else sys.executable)
            subprocess.Popen(
                [runner, str(app)], cwd=str(base),
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass
    return


if __name__ == "__main__":
    main()
