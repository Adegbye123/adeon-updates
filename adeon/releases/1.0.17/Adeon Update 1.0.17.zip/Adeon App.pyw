from __future__ import annotations

import ctypes
import http.client
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
import socket
import zipfile
from pathlib import Path
import tkinter as tk
from tkinter import messagebox


def base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def redirect_source_copy_to_installed_app() -> bool:
    """If someone opens the extracted source copy, use the installed Adeon shortcut/app instead."""
    if getattr(sys, "frozen", False):
        return False
    try:
        installed = Path(os.environ.get("LOCALAPPDATA", "")) / "Adeon" / "Adeon.exe"
        here = Path(__file__).resolve().parent
        if installed.is_file() and here != installed.parent.resolve():
            subprocess.Popen([str(installed)], cwd=str(installed.parent),
                             creationflags=0x08000000, stdin=subprocess.DEVNULL,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
    except Exception:
        pass
    return False


BASE = base_dir()
BOT = BASE / "Adeon Bot.py"
PYTHON_PATH_FILE = BASE / "Python Path.txt"
PID_FILE = BASE / "Adeon Worker PID.txt"
STOP_FILE = BASE / "Adeon Stop Request.flag"
RUNTIME_FILE = BASE / "Adeon Runtime.json"
PIN_HELP_FLAG = BASE / "Show Pin Help.flag"
ACTIVITY_LOG = BASE / "Adeon Activity.log"
LAST_ERROR_FILE = BASE / "Adeon Last Error.txt"

# Self-updater.  Every updater-enabled Adeon can jump directly to the newest
# published version; updates are full program-file releases, not incremental
# patches.  User data (Chrome Data, reports, logs, local state) is never part of
# an update package and is therefore preserved.
ADEON_VERSION = "1.0.17"
UPDATE_FEED_FILE = BASE / "Update Feed URL.txt"
OFFICIAL_UPDATE_FEED = "https://raw.githubusercontent.com/Adegbye123/adeon-updates/main/adeon/manifest.json"
UPDATE_HELPER = BASE / "Adeon Update Helper.py"
UPDATE_PENDING_FILE = BASE / "Adeon Pending Update.json"
UPDATE_STATUS_FILE = BASE / "Adeon Update Status.json"
UPDATE_STAGE_DIR = BASE / "Update Staging"
UPDATE_CHECK_INTERVAL = 5.0  # online clients poll the manifest every ~5 seconds

# Updater diagnostics are mirrored to Downloads so users can send one obvious
# file when update discovery or installation is not working.
def _downloads_dir() -> Path:
    try:
        p = Path(os.environ.get("USERPROFILE", str(Path.home()))) / "Downloads"
        p.mkdir(parents=True, exist_ok=True)
        return p
    except Exception:
        return Path.home()

UPDATE_DIAGNOSTIC_LOG = _downloads_dir() / "Adeon Update Diagnostic.log"


CREATE_NEW_PROCESS_GROUP = 0x00000200
DETACHED_PROCESS = 0x00000008
PROCESS_SYNCHRONIZE = 0x00100000
WAIT_TIMEOUT = 0x00000102
SW_RESTORE = 9


def set_windows_app_identity() -> None:
    """Give Windows a stable Adeon identity so the taskbar uses Adeon's icon."""
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Adeon.Picker.DesktopApp")
    except Exception:
        pass


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8").strip()
    except Exception:
        return ""


def app_log(message: str) -> None:
    try:
        stamp = time.strftime("%Y-%m-%d %H:%M:%S")
        with ACTIVITY_LOG.open("a", encoding="utf-8") as fh:
            fh.write(f"[{stamp}] APP | {str(message)}\n")
    except Exception:
        pass


def update_diag(message: str) -> None:
    try:
        stamp = time.strftime("%Y-%m-%d %H:%M:%S")
        with UPDATE_DIAGNOSTIC_LOG.open("a", encoding="utf-8") as fh:
            fh.write(f"[{stamp}] {str(message)}\n")
    except Exception:
        pass


def worker_pid() -> int:
    try:
        return int(read_text(PID_FILE) or "0")
    except Exception:
        return 0


def pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        k32 = ctypes.windll.kernel32
        h = k32.OpenProcess(PROCESS_SYNCHRONIZE, False, int(pid))
        if not h:
            return False
        try:
            return int(k32.WaitForSingleObject(h, 0)) == WAIT_TIMEOUT
        finally:
            k32.CloseHandle(h)
    except Exception:
        return False


def runtime_state() -> dict:
    try:
        obj = json.loads(RUNTIME_FILE.read_text(encoding="utf-8"))
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def foreground_window_title() -> str:
    """Return the title of the Windows foreground window."""
    try:
        user32 = ctypes.windll.user32
        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return ""
        length = int(user32.GetWindowTextLengthW(hwnd))
        if length <= 0:
            return ""
        buf = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buf, length + 1)
        return str(buf.value or "")
    except Exception:
        return ""


def foreground_is_lr_page() -> bool:
    """Only show the small dashboard while LR Writers is the foreground page."""
    title = foreground_window_title().strip().lower()
    if not title:
        return False
    # LR Writers currently exposes the active page as Writer Tool in Chrome's
    # window title.  Keep a domain/name fallback for future title changes.
    return (
        "writer tool" in title
        or "lr writers" in title
        or "lrwriters" in title
        or "myaccount.lrwriters.com" in title
    )


def pythonw_path() -> str:
    p = read_text(PYTHON_PATH_FILE)
    if p and Path(p).is_file():
        return p
    exe = Path(sys.executable)
    if exe.name.lower().startswith("python"):
        pw = exe.with_name("pythonw.exe")
        return str(pw if pw.exists() else exe)
    return "pythonw.exe"





def update_feed_url() -> str:
    raw = read_text(UPDATE_FEED_FILE).strip()
    if not raw or raw.startswith("#") or "OWNER/REPOSITORY" in raw:
        return OFFICIAL_UPDATE_FEED
    return raw




def manifest_feed_candidates(feed: str) -> list[str]:
    """Return public GitHub manifest URLs that can have independent CDN cache keys.

    GitHub's raw CDN can briefly serve an older branch view after the Contents API
    has accepted a commit.  Adeon probes equivalent public endpoints and uses the
    newest valid manifest it sees.  No private token is required on client laptops.
    """
    out = []
    def add(url: str):
        url = str(url or '').strip()
        if url and url not in out:
            out.append(url)
    add(feed)
    try:
        u = urllib.parse.urlparse(feed)
        if u.netloc.lower() == 'raw.githubusercontent.com':
            parts = [x for x in u.path.split('/') if x]
            if len(parts) >= 4:
                owner, repo, branch = parts[0], parts[1], parts[2]
                rel = '/'.join(parts[3:])
                add(f'https://raw.githubusercontent.com/{owner}/{repo}/refs/heads/{branch}/{rel}')
                add(f'https://github.com/{owner}/{repo}/raw/refs/heads/{branch}/{rel}')
                add(f'https://github.com/{owner}/{repo}/raw/{branch}/{rel}')
    except Exception:
        pass
    return out


def fetch_newest_manifest(feed: str) -> tuple[dict, str]:
    """Read equivalent public feeds and return the highest valid Adeon version."""
    best = None
    best_url = ''
    errors = []
    for i, url in enumerate(manifest_feed_candidates(feed)):
        try:
            # The primary feed keeps the full retry/fallback behavior. Alternate
            # cache paths use a shorter timeout so the 5-second polling loop stays responsive.
            timeout = 8.0 if i == 0 else 4.0
            obj = fetch_json_url(url, timeout=timeout)
            if str(obj.get('product') or '') != 'Adeon LR Picker':
                continue
            ver = str(obj.get('version') or '').strip()
            if not ver:
                continue
            update_diag(f'MANIFEST SOURCE | url={url} version={ver}')
            if best is None or version_tuple(ver) > version_tuple(str(best.get('version') or '0')):
                best = obj
                best_url = url
        except Exception as e:
            errors.append(f'{url}: {e}')
            update_diag(f'MANIFEST SOURCE FAILED | url={url} error={e}')
    if best is None:
        raise RuntimeError('No public update feed responded with a valid manifest' + (f' | {errors[-1]}' if errors else ''))
    return best, best_url

def fetch_manifest_quick(feed: str) -> tuple[dict, str]:
    """Fast single-endpoint probe used by the 5-second background poll.

    The previous build could keep the update state busy for many seconds because
    every automatic poll used the full retry/fallback routine across several
    GitHub URLs.  That made CHECK FOR UPDATE look unclickable.  Background
    checks now probe just one cache-busted public endpoint with a short timeout.
    Manual checks still use the robust multi-endpoint routine.
    """
    candidates = manifest_feed_candidates(feed)
    if not candidates:
        raise RuntimeError('No update feed is configured')
    # Rotate equivalent GitHub URLs between polls so a stale CDN edge does not
    # permanently hide a newly published manifest.
    idx = int(time.time() // max(1.0, UPDATE_CHECK_INTERVAL)) % len(candidates)
    url = candidates[idx]
    request_url = _cache_busted_url(url)
    req = urllib.request.Request(
        request_url,
        headers={
            "User-Agent": f"Adeon-LR-Picker/{ADEON_VERSION}",
            "Cache-Control": "no-cache, no-store",
            "Pragma": "no-cache",
            "Connection": "close",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=2.5) as resp:
            data = resp.read(1024 * 1024 + 1)
        if len(data) > 1024 * 1024:
            raise RuntimeError('Update manifest exceeded the allowed size')
        obj = json.loads(data.decode('utf-8-sig'))
        if not isinstance(obj, dict):
            raise RuntimeError('Update manifest is not a JSON object')
        if str(obj.get('product') or '') != 'Adeon LR Picker':
            raise RuntimeError('Update feed is for a different product')
        update_diag(f'FAST MANIFEST SOURCE | url={url} version={obj.get("version","")}')
        return obj, url
    except Exception as e:
        update_diag(f'FAST MANIFEST FAILED | url={url} error={e}')
        raise

def version_tuple(value: str) -> tuple[int, ...]:
    parts = []
    for piece in str(value or "0").strip().lstrip("vV").split("."):
        digits = "".join(ch for ch in piece if ch.isdigit())
        parts.append(int(digits or 0))
    while len(parts) < 4:
        parts.append(0)
    return tuple(parts[:4])


def is_newer_version(candidate: str, current: str = ADEON_VERSION) -> bool:
    return version_tuple(candidate) > version_tuple(current)


def _cache_busted_url(url: str) -> str:
    text = str(url or "")
    sep = "&" if "?" in text else "?"
    return f"{text}{sep}adeon_cb={int(time.time() * 1000)}"


def _curl_public_https(url: str, timeout: float, max_bytes: int) -> bytes:
    """Public-read fallback for Windows machines where urllib/TLS is interrupted."""
    curl = shutil.which("curl.exe") or shutil.which("curl")
    if not curl:
        raise RuntimeError("curl fallback is not available")
    cmd = [
        curl, "-L", "--fail", "--silent", "--show-error",
        "--connect-timeout", str(max(3, min(15, int(timeout)))),
        "--max-time", str(max(5, int(timeout))),
        "-H", "Cache-Control: no-cache, no-store",
        "-H", "Pragma: no-cache",
        "-A", f"Adeon-LR-Picker/{ADEON_VERSION}",
        url,
    ]
    cp = subprocess.run(cmd, capture_output=True, timeout=max(8, timeout + 5), creationflags=CREATE_NO_WINDOW)
    if cp.returncode != 0:
        err = cp.stderr.decode("utf-8", errors="replace").strip()
        raise RuntimeError(f"curl failed ({cp.returncode}): {err[:300]}")
    data = bytes(cp.stdout or b"")
    if len(data) > max_bytes:
        raise RuntimeError("Update response exceeded the allowed size")
    return data


def _public_https_bytes(url: str, timeout: float, max_bytes: int, purpose: str) -> bytes:
    if not str(url).lower().startswith("https://"):
        raise RuntimeError(f"{purpose} must use HTTPS")
    attempts = 4
    last = None
    for attempt in range(1, attempts + 1):
        request_url = _cache_busted_url(str(url))
        req = urllib.request.Request(
            request_url,
            headers={
                "User-Agent": f"Adeon-LR-Picker/{ADEON_VERSION}",
                "Cache-Control": "no-cache, no-store",
                "Pragma": "no-cache",
                "Connection": "close",
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = resp.read(max_bytes + 1)
            if len(data) > max_bytes:
                raise RuntimeError("Update response exceeded the allowed size")
            if attempt > 1:
                update_diag(f"NETWORK RECOVERED | {purpose} succeeded on attempt {attempt}/{attempts}")
            return data
        except urllib.error.HTTPError as e:
            last = e
            # 4xx responses other than timeout/rate-limit are not transient.
            if e.code not in (408, 429, 500, 502, 503, 504):
                raise RuntimeError(f"{purpose} HTTP {e.code}")
        except (urllib.error.URLError, http.client.RemoteDisconnected, ConnectionResetError,
                ConnectionAbortedError, TimeoutError, socket.timeout, OSError) as e:
            last = e
        except RuntimeError:
            raise
        if attempt < attempts:
            delay = min(8.0, 1.0 * (2 ** (attempt - 1)))
            update_diag(f"NETWORK RETRY | {purpose} attempt={attempt}/{attempts} reason={last} waiting={delay:.1f}s")
            time.sleep(delay)

    # GitHub raw/public downloads need no secret, so curl is a safe alternate
    # transport when Python's urllib connection is being interrupted locally.
    try:
        update_diag(f"NETWORK FALLBACK | {purpose} trying Windows curl after urllib retries")
        return _curl_public_https(_cache_busted_url(str(url)), timeout, max_bytes)
    except Exception as curl_error:
        update_diag(f"NETWORK FALLBACK FAILED | {purpose} | {curl_error}")
        raise RuntimeError(f"{purpose} connection failed after retries: {last or curl_error}")


def fetch_json_url(url: str, timeout: float = 12.0) -> dict:
    data = _public_https_bytes(url, timeout, 1024 * 1024, "Update manifest")
    obj = json.loads(data.decode("utf-8-sig"))
    if not isinstance(obj, dict):
        raise RuntimeError("Update manifest is not a JSON object")
    return obj


def download_bytes(url: str, timeout: float = 45.0) -> bytes:
    return _public_https_bytes(url, timeout, 100 * 1024 * 1024, "Update package")


def flash_taskbar(hwnd: int, count: int = 8) -> None:
    """Flash Adeon's own taskbar button so an available update is visible."""
    try:
        class FLASHWINFO(ctypes.Structure):
            _fields_ = [
                ("cbSize", ctypes.c_uint),
                ("hwnd", ctypes.c_void_p),
                ("dwFlags", ctypes.c_uint),
                ("uCount", ctypes.c_uint),
                ("dwTimeout", ctypes.c_uint),
            ]
        info = FLASHWINFO(ctypes.sizeof(FLASHWINFO), int(hwnd), 0x00000003 | 0x0000000C, int(count), 0)
        ctypes.windll.user32.FlashWindowEx(ctypes.byref(info))
    except Exception:
        pass


def cleanup_legacy_controllers() -> None:
    """Close obsolete console-based LR/Adeon controllers without touching app workers."""
    try:
        ps = (
            "$me=$PID; "
            "$ps=Get-CimInstance Win32_Process | Where-Object { "
            "$_.ProcessId -ne $me -and $_.CommandLine -and "
            "((($_.CommandLine -match 'Adeon Bot\\.py') -and ($_.CommandLine -notmatch '--app-worker')) "
            "-or ($_.CommandLine -match 'LR Picker Bot\\.py') "
            "-or ($_.CommandLine -match 'lr_mouse_bot\\.py') "
            "-or ($_.CommandLine -match 'lr_alt_s_launcher\\.pyw')) }; "
            "foreach($p in $ps){ try { Invoke-CimMethod -InputObject $p -MethodName Terminate | Out-Null } catch {} }"
        )
        subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5,
            creationflags=0x08000000,
        )
    except Exception:
        pass

def launch_worker() -> tuple[bool, str]:
    if pid_alive(worker_pid()):
        app_log("Activate requested but worker is already active.")
        return True, "Already active"
    if not BOT.exists():
        return False, f"Missing {BOT.name}"
    for p in (STOP_FILE, LAST_ERROR_FILE):
        try:
            p.unlink(missing_ok=True)
        except Exception:
            pass
    try:
        proc = subprocess.Popen(
            [pythonw_path(), str(BOT), "--app-worker"],
            cwd=str(BASE),
            creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP,
            close_fds=True,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        PID_FILE.write_text(str(proc.pid), encoding="utf-8")
        app_log(f"Worker launched. PID={proc.pid}. Waiting for Chrome/LR Writers checks.")
        return True, "Preparing Chrome and connecting..."
    except Exception as e:
        app_log(f"Worker launch failed: {e}")
        return False, str(e)


def request_stop() -> tuple[bool, str]:
    pid = worker_pid()
    if not pid_alive(pid):
        try:
            PID_FILE.unlink(missing_ok=True)
        except Exception:
            pass
        return True, "Already stopped"
    try:
        STOP_FILE.write_text(str(time.time()), encoding="utf-8")
        app_log(f"Deactivate requested for worker PID={pid}.")
        return True, "Stopping..."
    except Exception as e:
        return False, str(e)


def bring_existing_adeon_to_front() -> bool:
    try:
        hwnd = ctypes.windll.user32.FindWindowW(None, "Adeon")
        if hwnd:
            ctypes.windll.user32.ShowWindow(hwnd, SW_RESTORE)
            ctypes.windll.user32.SetForegroundWindow(hwnd)
            return True
    except Exception:
        pass
    return False


def single_instance_or_focus() -> object | None:
    try:
        k32 = ctypes.windll.kernel32
        mutex = k32.CreateMutexW(None, False, "Local\\AdeonPickerAppMutex")
        if ctypes.get_last_error() == 183:  # ERROR_ALREADY_EXISTS
            bring_existing_adeon_to_front()
            return None
        return mutex
    except Exception:
        return object()


class AdeonApp:
    def __init__(self) -> None:
        set_windows_app_identity()
        self.root = tk.Tk()
        self.root.title("Adeon")
        self.root.geometry("350x430")
        self.root.resizable(False, False)
        self.root.configure(bg="#f7f8f7")
        self.root.protocol("WM_DELETE_WINDOW", self.close_everything)
        try:
            ico = BASE / "Adeon.ico"
            if ico.exists():
                self.root.iconbitmap(default=str(ico))
                # Re-apply after Windows has created the native window handle.
                self.root.after(250, lambda: self.root.iconbitmap(default=str(ico)))
        except Exception:
            pass

        top = tk.Frame(self.root, bg="#f7f8f7")
        top.pack(pady=(18, 4))

        logo = tk.Canvas(top, width=48, height=48, bg="#f7f8f7", highlightthickness=0)
        logo.pack(side="left", padx=(0, 9))
        logo.create_oval(2, 2, 46, 46, fill="#12863a", outline="#12863a")
        logo.create_text(24, 24, text="A", fill="white", font=("Segoe UI", 24, "bold"))

        tk.Label(
            top, text="ADEON", bg="#f7f8f7", fg="#111111",
            font=("Segoe UI", 19, "bold")
        ).pack(side="left")

        self.status = tk.Label(
            self.root, text="STOPPED", bg="#f7f8f7", fg="#c62828",
            font=("Segoe UI", 13, "bold")
        )
        self.status.pack(pady=(6, 5))

        self.version_label = tk.Label(
            self.root, text=f"INSTALLED VERSION  {ADEON_VERSION}", bg="#f7f8f7", fg="#777777",
            font=("Segoe UI", 8)
        )
        self.version_label.pack(pady=(0, 8))

        self.update_status = tk.Label(
            self.root, text="UPDATE  •  CHECKING", bg="#f7f8f7", fg="#777777",
            font=("Segoe UI", 8, "bold")
        )
        self.update_status.pack(pady=(0, 4))

        self.update_button = tk.Button(
            self.root, text="CHECK FOR UPDATE", width=25, height=1,
            font=("Segoe UI", 9, "bold"), command=lambda: self.check_for_updates(force=True),
            relief="flat", cursor="hand2", bg="#e8ece9", fg="#1f1f1f",
            activebackground="#d7ddd9", activeforeground="#111111"
        )
        self.update_button.pack(pady=(0, 8))

        # Persistent bottom-left dashboard owned by Adeon.exe itself.  The worker
        # can stop completely and this small ticket still remains visible as STOPPED.
        self.ticket = tk.Toplevel(self.root)
        self.ticket.overrideredirect(True)
        self.ticket.attributes("-topmost", True)
        try:
            self.ticket.attributes("-alpha", 0.94)
        except Exception:
            pass
        tw, th = 230, 104
        sh = int(self.ticket.winfo_screenheight() or 1080)
        self.ticket.geometry(f"{tw}x{th}+18+{max(8, sh-th-58)}")
        self.ticket.configure(bg="#fff4b8")
        tframe = tk.Frame(self.ticket, bg="#fff4b8", bd=1, relief="solid")
        tframe.pack(fill="both", expand=True)
        self.ticket_header = tk.Label(
            tframe, text="ADEON  •  STOPPED", anchor="w", justify="left",
            bg="#fff4b8", fg="#c62828", font=("Segoe UI", 9, "bold"), padx=7, pady=3
        )
        self.ticket_header.pack(fill="x")
        self.ticket_body = tk.Label(
            tframe, text="JOB    -\nF5     OFF\nMOUSE  OFF", anchor="nw", justify="left",
            bg="#fff4b8", fg="#111111", font=("Segoe UI", 8), padx=7, pady=1
        )
        self.ticket_body.pack(fill="both", expand=True)
        drag = {"x": 0, "y": 0}
        def ticket_drag_start(event):
            drag["x"], drag["y"] = int(event.x), int(event.y)
        def ticket_drag_move(event):
            self.ticket.geometry(f"+{int(event.x_root)-drag['x']}+{int(event.y_root)-drag['y']}")
        for widget in (tframe, self.ticket_header, self.ticket_body):
            widget.bind("<ButtonPress-1>", ticket_drag_start)
            widget.bind("<B1-Motion>", ticket_drag_move)

        self.toggle = tk.Button(
            self.root, text="ACTIVATE PICKER", width=25, height=2,
            font=("Segoe UI", 11, "bold"), command=self.toggle_picker,
            relief="flat", cursor="hand2", bg="#12863a", fg="white",
            activebackground="#0e6d2e", activeforeground="white"
        )
        self.toggle.pack()

        self.log_button = tk.Button(
            self.root, text="VIEW ACTIVITY LOG", width=25, height=1,
            font=("Segoe UI", 9, "bold"), command=self.open_activity_log,
            relief="flat", cursor="hand2", bg="#e8ece9", fg="#1f1f1f",
            activebackground="#d7ddd9", activeforeground="#111111"
        )
        self.log_button.pack(pady=(8, 0))

        self.note = tk.Label(
            self.root,
            text="Adeon uses Chrome DevTools. First setup copies only limited login/session data into Adeon’s private local folder, then reuses it.",
            bg="#f7f8f7", fg="#555555", font=("Segoe UI", 8),
            wraplength=292, justify="center"
        )
        self.note.pack(pady=(12, 0))

        self.hotkey_note = tk.Label(
            self.root, text="ALT+S also toggles START / STOP",
            bg="#f7f8f7", fg="#777777", font=("Segoe UI", 8)
        )
        self.hotkey_note.pack(pady=(5, 0))

        self.last_event = tk.Label(
            self.root, text="Log: waiting", bg="#f7f8f7", fg="#555555",
            font=("Segoe UI", 7), wraplength=320, justify="center"
        )
        self.last_event.pack(pady=(8, 0))

        self.busy = False
        self.last_alive = False
        self._hotkey_latched = False
        self._last_runtime_page = ""
        self._closing = False
        self._ticket_visible = True
        self.pending_update: dict | None = None
        self.update_checking = False
        self.update_installing = False
        self.manual_update_requested = False
        self.last_update_check = 0.0
        self.last_update_notified = ""
        update_diag(f"ADEON START | installed={ADEON_VERSION} feed={update_feed_url() or '[not configured]'}")
        self.root.after(200, self.refresh)
        self.root.after(2200, lambda: self.check_for_updates(force=True))
        self.root.after(5000, self.periodic_update_check)
        self.root.after(900, self.show_last_update_result)
        self.root.after(300, self.poll_alt_s)
        self.root.after(700, self.maybe_show_pin_help)

    def show_last_update_result(self) -> None:
        try:
            if not UPDATE_STATUS_FILE.exists():
                return
            obj = json.loads(UPDATE_STATUS_FILE.read_text(encoding="utf-8"))
            UPDATE_STATUS_FILE.unlink(missing_ok=True)
            if not isinstance(obj, dict):
                return
            if obj.get("ok"):
                installed = str(obj.get('version') or ADEON_VERSION)
                update_diag(f"LAST INSTALL RESULT | success version={installed}")
                self.version_label.config(text=f"INSTALLED VERSION  {installed}")
                self.update_status.config(text=f"INSTALLED VERSION  {installed}  •  UP TO DATE", fg="#12863a")
                self.set_message(f"Updated successfully to {installed}.")
                app_log(f"Update completed successfully: {obj}")
            else:
                update_diag(f"LAST INSTALL RESULT | failed details={obj}")
                self.set_message("The last update could not be installed. Adeon restored the previous version.")
                app_log(f"Update failed and rollback was attempted: {obj}")
        except Exception as e:
            app_log(f"Could not read update result: {e}")

    def periodic_update_check(self) -> None:
        try:
            self.check_for_updates(force=False)
        finally:
            self.root.after(5000, self.periodic_update_check)

    def check_for_updates(self, force: bool = False) -> None:
        if self.update_installing:
            update_diag("CHECK SKIPPED | update installation is in progress")
            if force:
                self.set_message("An update is already being installed.")
            return
        if self.update_checking:
            update_diag(f"CHECK REQUESTED WHILE BUSY | force={force}")
            if force:
                # Give immediate visual feedback instead of making the button
                # appear dead.  The in-flight check will update the result.
                self.manual_update_requested = True
                self.update_status.config(text="UPDATE  •  CHECKING NOW", fg="#777777")
                self.update_button.config(text="CHECKING...", state="normal")
                self.set_message("Checking for the newest Adeon version now...")
            return
        feed = update_feed_url()
        update_diag(f"CHECK START | installed={ADEON_VERSION} force={force} feed={feed or '[not configured]'}")
        if not feed:
            update_diag("CHECK RESULT | update channel is not configured")
            self.update_status.config(text="UPDATE  •  CHANNEL NOT SET", fg="#777777")
            self.update_button.config(text="CHECK FOR UPDATE", state="normal", bg="#e8ece9", fg="#1f1f1f")
            if force:
                self.set_message("Update channel is not configured yet. The administrator only needs to configure it once.")
            return
        now = time.time()
        if not force and now - self.last_update_check < UPDATE_CHECK_INTERVAL:
            return
        self.last_update_check = now
        self.update_checking = True
        self.manual_update_requested = bool(force)
        if force:
            self.update_status.config(text="UPDATE  •  CHECKING NOW", fg="#777777")
            # Do not disable the button.  A disabled Tk button looked like it
            # could not be clicked on slower networks.
            self.update_button.config(text="CHECKING...", state="normal")
            self.set_message("Checking for the newest Adeon version...")
        threading.Thread(target=self._check_update_thread, args=(feed, force), daemon=True).start()

    def _check_update_thread(self, feed: str, force: bool) -> None:
        try:
            update_diag(f"FETCH MANIFEST | {feed} mode={'manual' if force else 'fast-background'}")
            if force:
                manifest, manifest_source = fetch_newest_manifest(feed)
            else:
                manifest, manifest_source = fetch_manifest_quick(feed)
            update_diag(f"MANIFEST SELECTED | source={manifest_source} version={manifest.get('version','')}")
            product = str(manifest.get("product") or "")
            version = str(manifest.get("version") or "").strip()
            package_url = str(manifest.get("package_url") or "").strip()
            sha256 = str(manifest.get("sha256") or "").strip().lower()
            update_diag(f"MANIFEST RECEIVED | product={product or '[blank]'} version={version or '[blank]'} package_url={package_url or '[blank]'} sha256={'present' if len(sha256)==64 else 'invalid/missing'}")
            if product and product.lower() not in ("adeon", "adeon lr picker"):
                raise RuntimeError("The update feed is for a different product")
            if not version or not package_url or len(sha256) != 64:
                raise RuntimeError("Update manifest is incomplete")
            if is_newer_version(version):
                update_diag(f"CHECK RESULT | UPDATE AVAILABLE installed={ADEON_VERSION} available={version}")
                self.root.after(0, lambda: self._update_available(manifest))
            else:
                update_diag(f"CHECK RESULT | UP TO DATE installed={ADEON_VERSION} published={version}")
                self.root.after(0, lambda v=version: self._update_current(v))
        except Exception as e:
            msg = str(e)
            update_diag(f"CHECK FAILED | {msg}")
            app_log(f"Update check failed: {msg}")
            self.root.after(0, lambda m=msg, manual=force: self._update_check_failed(m, manual))

    def _update_available(self, manifest: dict) -> None:
        self.update_checking = False
        self.manual_update_requested = False
        self.pending_update = dict(manifest)
        ver = str(manifest.get("version") or "")
        update_diag(f"UI NOTICE | showing update available {ver}")
        self.update_status.config(text=f"AVAILABLE VERSION  {ver}", fg="#b45f06")
        self.set_message(f"Installed {ADEON_VERSION}. Version {ver} is available. Tap INSTALL UPDATE to apply it.")
        self.update_button.config(
            text=f"INSTALL UPDATE {ver}", state="normal", command=self.install_update,
            bg="#f2a100", fg="white", activebackground="#d18b00", activeforeground="white"
        )
        self.root.title("Adeon  •  UPDATE AVAILABLE")
        if self.last_update_notified != ver:
            self.last_update_notified = ver
            app_log(f"Update available: {ver}. Taskbar notification triggered.")
            try:
                flash_taskbar(self.root.winfo_id(), 10)
                self.root.bell()
            except Exception:
                pass
            self.show_update_toast(ver, str(manifest.get("summary") or ""))

    def _update_current(self, published_version: str = "") -> None:
        published = str(published_version or ADEON_VERSION).strip() or ADEON_VERSION
        update_diag(f"UI STATUS | installed={ADEON_VERSION} published={published} up_to_date=true")
        self.update_checking = False
        self.manual_update_requested = False
        self.pending_update = None
        self.update_status.config(text=f"INSTALLED {ADEON_VERSION}  •  PUBLISHED {published}  •  UP TO DATE", fg="#12863a")
        self.update_button.config(
            text="CHECK FOR UPDATE", state="normal", command=lambda: self.check_for_updates(force=True),
            bg="#e8ece9", fg="#1f1f1f", activebackground="#d7ddd9", activeforeground="#111111"
        )
        self.root.title("Adeon")

    def _update_check_failed(self, message: str, manual: bool = True) -> None:
        update_diag(f"UI STATUS | update check failed manual={manual}: {message}")
        requested_during_background = bool(self.manual_update_requested and not manual)
        self.update_checking = False
        self.manual_update_requested = False
        # If the user tapped CHECK while a quick background probe was already
        # running and that quick probe failed, immediately honor the user's
        # request with the full robust manual check.
        if requested_during_background:
            update_diag("MANUAL CHECK ESCALATION | quick background probe failed; starting robust manual check")
            self.update_button.config(text="CHECKING...", state="normal")
            self.root.after(25, lambda: self.check_for_updates(force=True))
            return
        # Background 5-second probes are intentionally quiet. A momentary
        # network miss must not make the app look broken or lock the button.
        if not manual:
            self.update_button.config(
                text="CHECK FOR UPDATE", state="normal", command=lambda: self.check_for_updates(force=True),
                bg="#e8ece9", fg="#1f1f1f"
            )
            return
        self.update_status.config(text="UPDATE  •  CHECK FAILED", fg="#9a6a00")
        self.update_button.config(
            text="CHECK FOR UPDATE", state="normal", command=lambda: self.check_for_updates(force=True),
            bg="#e8ece9", fg="#1f1f1f"
        )
        self.set_message("Could not reach the update service. See Downloads\\Adeon Update Diagnostic.log for details.")

    def show_update_toast(self, version: str, summary: str) -> None:
        try:
            toast = tk.Toplevel(self.root)
            toast.title("Adeon Update")
            toast.attributes("-topmost", True)
            toast.resizable(False, False)
            toast.configure(bg="#fff6df")
            w, h = 320, 120
            sw, sh = toast.winfo_screenwidth(), toast.winfo_screenheight()
            toast.geometry(f"{w}x{h}+{max(10, sw-w-20)}+{max(10, sh-h-70)}")
            tk.Label(toast, text=f"ADEON UPDATE {version} AVAILABLE", bg="#fff6df", fg="#8a5200", font=("Segoe UI", 10, "bold")).pack(pady=(12, 3))
            txt = (summary or "Open Adeon from the taskbar and tap INSTALL UPDATE.")[:120]
            tk.Label(toast, text=txt, bg="#fff6df", fg="#333333", font=("Segoe UI", 8), wraplength=285, justify="center").pack()
            tk.Button(toast, text="OPEN ADEON", command=lambda: (self.root.deiconify(), self.root.lift(), self.root.focus_force(), toast.destroy()), bg="#12863a", fg="white", relief="flat").pack(pady=(8, 0))
            toast.after(12000, lambda: toast.destroy() if toast.winfo_exists() else None)
        except Exception:
            pass

    def install_update(self) -> None:
        if self.update_installing or not self.pending_update:
            return
        if not UPDATE_HELPER.exists():
            self.set_message("Update helper is missing. Reinstall the updater-enabled Adeon package once.")
            return
        self.update_installing = True
        manifest = dict(self.pending_update)
        ver = str(manifest.get("version") or "")
        update_diag(f"INSTALL REQUESTED | installed={ADEON_VERSION} target={ver}")
        self.update_status.config(text=f"UPDATE  •  DOWNLOADING {ver}", fg="#b45f06")
        self.update_button.config(text="DOWNLOADING UPDATE...", state="disabled")
        self.set_message("Downloading and verifying the Adeon update. No other action is needed.")
        threading.Thread(target=self._stage_update_thread, args=(manifest,), daemon=True).start()

    def _stage_update_thread(self, manifest: dict) -> None:
        try:
            package_url = str(manifest.get("package_url") or "")
            expected = str(manifest.get("sha256") or "").lower()
            update_diag(f"DOWNLOAD START | version={manifest.get('version','')} url={package_url}")
            data = download_bytes(package_url)
            update_diag(f"DOWNLOAD COMPLETE | bytes={len(data)}")
            actual = hashlib.sha256(data).hexdigest().lower()
            if actual != expected:
                raise RuntimeError("Downloaded update failed the SHA-256 integrity check")
            update_diag(f"VERIFY OK | sha256={actual}")
            if UPDATE_STAGE_DIR.exists():
                shutil.rmtree(UPDATE_STAGE_DIR, ignore_errors=True)
            UPDATE_STAGE_DIR.mkdir(parents=True, exist_ok=True)
            zip_path = UPDATE_STAGE_DIR / "Adeon Update.zip"
            zip_path.write_bytes(data)
            extract_dir = UPDATE_STAGE_DIR / "payload"
            extract_dir.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(zip_path, "r") as zf:
                for name in zf.namelist():
                    pp = Path(name)
                    if pp.is_absolute() or ".." in pp.parts:
                        raise RuntimeError("Update archive contains an unsafe path")
                zf.extractall(extract_dir)
            for required in ("Adeon App.pyw", "Adeon Bot.py", "Adeon.ico"):
                if not (extract_dir / required).is_file():
                    raise RuntimeError(f"Update package is missing {required}")
            pending = {
                "version": str(manifest.get("version") or ""),
                "summary": str(manifest.get("summary") or ""),
                "payload": str(extract_dir),
                "target": str(BASE),
                "app_pid": os.getpid(),
                "created_at": time.time(),
            }
            UPDATE_PENDING_FILE.write_text(json.dumps(pending, indent=2), encoding="utf-8")
            app_log(f"Update {pending['version']} downloaded and verified. Starting update helper.")
            update_diag(f"STAGED | update {pending['version']} verified; starting update helper")
            subprocess.Popen(
                [pythonw_path(), str(UPDATE_HELPER), "--apply", str(UPDATE_PENDING_FILE)],
                cwd=str(BASE), creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP,
                close_fds=True, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
            self.root.after(0, self._exit_for_update)
        except Exception as e:
            msg = str(e)
            update_diag(f"INSTALL FAILED | {msg}")
            app_log(f"Update staging failed: {msg}")
            self.root.after(0, lambda: self._update_stage_failed(msg))

    def _update_stage_failed(self, message: str) -> None:
        self.update_installing = False
        self.update_status.config(text="UPDATE  •  INSTALL FAILED", fg="#c62828")
        self.update_button.config(text="TRY UPDATE AGAIN", state="normal", command=self.install_update, bg="#f2a100", fg="white")
        self.set_message(f"Update was not installed: {message[:110]}")

    def _exit_for_update(self) -> None:
        self.set_message("Installing update. Adeon will restart automatically.")
        self.close_everything()

    def open_activity_log(self) -> None:
        try:
            if not ACTIVITY_LOG.exists():
                app_log("Activity log opened before any worker activity.")
            os.startfile(str(ACTIVITY_LOG))
        except Exception as e:
            try:
                subprocess.Popen(["notepad.exe", str(ACTIVITY_LOG)])
            except Exception:
                messagebox.showerror("Adeon", f"Could not open the activity log.\n\n{e}")

    def latest_log_line(self) -> str:
        try:
            lines = ACTIVITY_LOG.read_text(encoding="utf-8", errors="replace").splitlines()
            return lines[-1] if lines else "Log: waiting"
        except Exception:
            return "Log: waiting"

    def close_everything(self) -> None:
        """Fully exit Adeon and stop every Adeon-owned background component.

        Chrome is intentionally left open for the user; only Adeon.exe, its worker,
        dashboard, hotkey loop, and runtime files are stopped/closed.
        """
        if getattr(self, "_closing", False):
            return
        self._closing = True
        try:
            app_log("Adeon window close requested; stopping worker and exiting completely.")
        except Exception:
            pass

        pid = worker_pid()
        if pid_alive(pid):
            try:
                STOP_FILE.write_text(str(time.time()), encoding="utf-8")
            except Exception:
                pass
            deadline = time.time() + 2.5
            while time.time() < deadline and pid_alive(pid):
                time.sleep(0.10)
            if pid_alive(pid):
                try:
                    subprocess.run(
                        ["taskkill", "/PID", str(pid), "/T", "/F"],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=4,
                        creationflags=0x08000000,
                    )
                except Exception:
                    pass

        for p in (PID_FILE, STOP_FILE, RUNTIME_FILE):
            try:
                p.unlink(missing_ok=True)
            except Exception:
                pass

        try:
            self.ticket.destroy()
        except Exception:
            pass
        try:
            self.root.quit()
        except Exception:
            pass
        try:
            self.root.destroy()
        except Exception:
            pass

    def maybe_show_pin_help(self) -> None:
        if not PIN_HELP_FLAG.exists():
            return
        try:
            PIN_HELP_FLAG.unlink(missing_ok=True)
        except Exception:
            pass
        try:
            self.root.deiconify()
            self.root.lift()
            self.root.focus_force()
        except Exception:
            pass
        messagebox.showinfo(
            "Pin Adeon",
            "Adeon is installed and open.\n\n"
            "Right-click the green A icon on the Windows taskbar and choose ‘Pin to taskbar’.\n\n"
            "After that, you can open Adeon from the taskbar and press ACTIVATE PICKER."
        )

    def set_message(self, msg: str) -> None:
        self.note.config(text=str(msg or "")[:150])

    def toggle_picker(self) -> None:
        if self.busy:
            return
        app_log("ACTIVATE/DEACTIVATE button or Alt+S toggle received.")
        pid = worker_pid()
        if pid_alive(pid):
            ok, msg = request_stop()
            self.set_message(msg)
            if ok:
                self.busy = True
                threading.Thread(target=self.wait_for_stop, args=(pid,), daemon=True).start()
        else:
            ok, msg = launch_worker()
            self.set_message(msg)
            if ok:
                self.busy = True
                self.root.after(1200, self.clear_start_busy)
            else:
                self.busy = False

    def clear_start_busy(self) -> None:
        self.busy = False

    def wait_for_stop(self, pid: int) -> None:
        deadline = time.time() + 12.0
        while time.time() < deadline and pid_alive(pid):
            time.sleep(0.25)
        if pid_alive(pid):
            try:
                subprocess.run(
                    ["taskkill", "/PID", str(pid), "/T", "/F"],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5,
                    creationflags=0x08000000,  # CREATE_NO_WINDOW
                )
            except Exception:
                pass
        try:
            PID_FILE.unlink(missing_ok=True)
            STOP_FILE.unlink(missing_ok=True)
        except Exception:
            pass
        self.busy = False

    def poll_alt_s(self) -> None:
        try:
            user32 = ctypes.windll.user32
            alt = bool(user32.GetAsyncKeyState(0x12) & 0x8000)  # VK_MENU
            s_key = bool(user32.GetAsyncKeyState(ord("S")) & 0x8000)
            down = alt and s_key
            if down and not self._hotkey_latched:
                self._hotkey_latched = True
                self.toggle_picker()
            elif not down:
                self._hotkey_latched = False
        except Exception:
            pass
        self.root.after(70, self.poll_alt_s)

    def update_ticket_visibility(self) -> None:
        """Hide the tiny dashboard unless LR Writers is the foreground page."""
        try:
            should_show = foreground_is_lr_page()
            if should_show and not self._ticket_visible:
                self.ticket.deiconify()
                self.ticket.lift()
                self._ticket_visible = True
                app_log("Dashboard shown: LR Writers is the foreground page.")
            elif not should_show and self._ticket_visible:
                self.ticket.withdraw()
                self._ticket_visible = False
                app_log("Dashboard hidden: foreground is not LR Writers.")
        except Exception:
            pass

    def update_ticket(self, alive: bool, runtime: dict) -> None:
        try:
            state = str(runtime.get("bot") or "").upper() if alive else "STOPPED"
            if not state:
                state = "CONNECTING" if alive else "STOPPED"
            if state == "CONNECTED":
                color = "#138a36"
            elif state == "STOPPED":
                color = "#c62828"
            else:
                color = "#6b5b00"
            job = str(runtime.get("job") or ("SEARCHING" if alive else "-"))
            f5 = str(runtime.get("f5") or ("WAIT" if alive else "OFF"))
            mouse = str(runtime.get("mouse") or ("WAIT" if alive else "OFF"))
            self.ticket_header.config(text=f"ADEON  •  {state}", fg=color)
            self.ticket_body.config(text=f"JOB    {job}\nF5     {f5}\nMOUSE  {mouse}")
        except Exception:
            pass

    def refresh(self) -> None:
        pid = worker_pid()
        alive = pid_alive(pid)
        runtime = runtime_state()
        self.update_ticket_visibility()
        self.update_ticket(alive, runtime)
        bot_state = str(runtime.get("bot") or "").upper()
        page_state = str(runtime.get("page") or "").upper()
        self._last_runtime_page = page_state or self._last_runtime_page
        try:
            latest = self.latest_log_line()
            if len(latest) > 135:
                latest = latest[-135:]
            self.last_event.config(text=latest)
        except Exception:
            pass

        if alive and bot_state == "CONNECTED":
            self.status.config(text="CONNECTED", fg="#12863a")
            self.toggle.config(text="DEACTIVATE PICKER", bg="#c62828", fg="white", activebackground="#a91f1f")
            self.set_message("CONNECTED to the LR Writers Chrome tab.")
            self.busy = False
            if time.time() - self.last_update_check >= UPDATE_CHECK_INTERVAL:
                self.check_for_updates(force=False)
        elif alive:
            self.status.config(text="CONNECTING", fg="#b27800")
            self.toggle.config(text="DEACTIVATE PICKER", bg="#c62828", fg="white", activebackground="#a91f1f")
            if not self.busy:
                self.set_message("Preparing Chrome and connecting...")
        else:
            self.status.config(text="STOPPED", fg="#c62828")
            self.toggle.config(text="ACTIVATE PICKER", bg="#12863a", fg="white", activebackground="#0e6d2e")
            last_error = read_text(LAST_ERROR_FILE)
            if last_error:
                self.set_message(last_error[:150])
            elif "CHROME NOT LINKED" in self._last_runtime_page:
                self.set_message("Chrome could not be prepared for Adeon. Open VIEW ACTIVITY LOG for the exact reason.")
            elif self.last_alive and not self.busy:
                self.set_message("STOPPED. Chrome remains available for you.")
            if self.last_alive:
                app_log(f"Worker ended. Last runtime page={self._last_runtime_page or 'unknown'}. Error={last_error or 'none'}")
            try:
                PID_FILE.unlink(missing_ok=True)
            except Exception:
                pass
            self.busy = False

        self.last_alive = alive
        self.root.after(450, self.refresh)

    def run(self) -> None:
        self.root.mainloop()


if __name__ == "__main__":
    if redirect_source_copy_to_installed_app():
        raise SystemExit(0)
    set_windows_app_identity()
    app_log("Adeon app opened.")
    cleanup_legacy_controllers()
    _mutex = single_instance_or_focus()
    if _mutex is not None:
        AdeonApp().run()
