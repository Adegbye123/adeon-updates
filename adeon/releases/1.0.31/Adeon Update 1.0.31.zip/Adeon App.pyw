from __future__ import annotations

import ctypes
from ctypes import wintypes
import http.client
import http.server
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
import urllib.parse
import socket
import socketserver
import zipfile
from pathlib import Path
import tkinter as tk
from tkinter import messagebox


def base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def redirect_source_copy_to_installed_app() -> bool:
    """If someone opens the extracted source copy, use the installed Adeon shortcut/app instead."""
    if getattr(sys, "frozen", False):
        return False
    try:
        installed = Path(os.environ.get("LOCALAPPDATA", "")) / "Adeon" / "Adeon.exe"
        here = Path(__file__).resolve().parent
        if installed.is_file() and here != installed.parent.resolve():
            subprocess.Popen([str(installed)], cwd=str(installed.parent),
                             creationflags=0x08000000, stdin=subprocess.DEVNULL,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
    except Exception:
        pass
    return False


BASE = base_dir()
BOT = BASE / "Adeon Bot.py"
PYTHON_PATH_FILE = BASE / "Python Path.txt"
PICKER_PID_FILE = BASE / "Adeon Worker PID.txt"
LABELS_PID_FILE = BASE / "Adeon Labels Worker PID.txt"
PICKER_STOP_FILE = BASE / "Adeon Stop Request.flag"
LABELS_STOP_FILE = BASE / "Adeon Labels Stop Request.flag"
PICKER_RUNTIME_FILE = BASE / "Adeon Runtime.json"
LABELS_RUNTIME_FILE = BASE / "Adeon Labels Runtime.json"
LABELS_REFRESH_FILE = BASE / "Adeon Labels Refresh Request.flag"
PIN_HELP_FLAG = BASE / "Show Pin Help.flag"
ACTIVITY_LOG = BASE / "Adeon Activity.log"
LAST_ERROR_FILE = BASE / "Adeon Last Error.txt"

# Normal-Chrome browser bridge. Adeon's Chrome extension sends live LR Writers
# snapshots here and receives commands for the exact tab that is already open.
# This bridge never launches, closes, or replaces Chrome and never creates a
# second Chrome profile/environment.
BROWSER_BRIDGE_PORT = 17329
BROWSER_EXTENSION_ID = "efnloiohfchcnkmiindjmlbmnmbdkifo"
BROWSER_EXTENSION_VERSION = "1.0.31"
BROWSER_EXTENSION_CRX_VERSION = "1.0.30"  # bundled legacy CRX; unmanaged Chrome uses the unpacked folder
BROWSER_INTEGRATION_DIR = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "Adeon Browser Integration"
BROWSER_EXTENSION_CRX = BROWSER_INTEGRATION_DIR / "Adeon Browser Integration.crx"
_bridge_lock = threading.RLock()
_bridge_tabs: dict[int, dict] = {}
_bridge_commands: dict[int, list[dict]] = {}
_bridge_results: dict[str, dict] = {}


def _bridge_json_bytes(payload: dict) -> bytes:
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def _bridge_cleanup_locked(now: float | None = None) -> None:
    now = float(now or time.time())
    for tab_id in list(_bridge_tabs):
        if now - float((_bridge_tabs.get(tab_id) or {}).get("received_at") or 0.0) > 30.0:
            _bridge_tabs.pop(tab_id, None)
            _bridge_commands.pop(tab_id, None)
    for rid in list(_bridge_results):
        if now - float((_bridge_results.get(rid) or {}).get("received_at") or 0.0) > 30.0:
            _bridge_results.pop(rid, None)
    for tab_id, queue in list(_bridge_commands.items()):
        fresh = [c for c in queue if now - float(c.get("created_at") or now) <= 20.0]
        if fresh:
            _bridge_commands[tab_id] = fresh[-100:]
        else:
            _bridge_commands.pop(tab_id, None)


class _AdeonBridgeHandler(http.server.BaseHTTPRequestHandler):
    server_version = "AdeonBridge/1.0"
    protocol_version = "HTTP/1.1"

    def log_message(self, format, *args):
        return

    def _send(self, code: int, data: bytes, content_type: str) -> None:
        self.send_response(int(code))
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(data)

    def _json(self, code: int, payload: dict) -> None:
        self._send(code, _bridge_json_bytes(payload), "application/json; charset=utf-8")

    def _read_json(self, limit: int = 4 * 1024 * 1024) -> dict:
        length = max(0, min(int(self.headers.get("Content-Length", "0") or "0"), int(limit)))
        raw = self.rfile.read(length) if length else b"{}"
        obj = json.loads(raw.decode("utf-8", "replace") or "{}")
        return obj if isinstance(obj, dict) else {}

    def do_GET(self):
        parsed = urllib.parse.urlsplit(self.path)
        path = parsed.path
        if path == "/v1/health":
            self._json(200, {
                "ok": True,
                "version": ADEON_VERSION,
                "integration_version": BROWSER_EXTENSION_VERSION,
                "extension_id": BROWSER_EXTENSION_ID,
            })
            return
        if path == "/v1/tabs":
            now = time.time()
            with _bridge_lock:
                _bridge_cleanup_locked(now)
                tabs = list(_bridge_tabs.values())
            self._json(200, {"ok": True, "now": now, "tabs": tabs})
            return
        if path == "/v1/result":
            params = urllib.parse.parse_qs(parsed.query or "")
            rid = str((params.get("id") or [""])[0])[:128]
            with _bridge_lock:
                _bridge_cleanup_locked()
                item = _bridge_results.pop(rid, None) if rid else None
            self._json(200, {"ok": True, "ready": bool(item), "item": item or {}})
            return
        if path == "/extension/update.xml":
            # Chrome's extension updater can use this endpoint after the one-time
            # browser integration is registered. It is local-only and does not
            # disturb the user's current Chrome window/session.
            codebase = f"http://127.0.0.1:{BROWSER_BRIDGE_PORT}/extension/adeon.crx"
            xml = (
                '<?xml version="1.0" encoding="UTF-8"?>\n'
                '<gupdate xmlns="http://www.google.com/update2/response" protocol="2.0">\n'
                f'  <app appid="{BROWSER_EXTENSION_ID}"><updatecheck codebase="{codebase}" version="{BROWSER_EXTENSION_CRX_VERSION}" /></app>\n'
                '</gupdate>\n'
            ).encode("utf-8")
            self._send(200, xml, "text/xml; charset=utf-8")
            return
        if path == "/extension/adeon.crx":
            try:
                data = BROWSER_EXTENSION_CRX.read_bytes()
                self._send(200, data, "application/x-chrome-extension")
            except Exception:
                self._json(404, {"ok": False, "error": "extension package unavailable"})
            return
        self._json(404, {"ok": False})

    def do_POST(self):
        parsed = urllib.parse.urlsplit(self.path)
        path = parsed.path
        if path == "/v1/snapshot":
            try:
                obj = self._read_json()
                tab_id = int(obj.get("tabId") or 0)
                if tab_id <= 0:
                    self._json(400, {"ok": False, "error": "missing tab"})
                    return
                now = time.time()
                snap = obj.get("snap") if isinstance(obj.get("snap"), dict) else {}
                record = {
                    "received_at": now,
                    "tabId": tab_id,
                    "windowId": int(obj.get("windowId") or 0),
                    "active": bool(obj.get("active")),
                    "url": str(obj.get("url") or snap.get("url") or ""),
                    "title": str(obj.get("title") or snap.get("pageTitle") or ""),
                    "seq": int(obj.get("seq") or 0),
                    "snap": snap,
                }
                with _bridge_lock:
                    _bridge_tabs[tab_id] = record
                    results = obj.get("results") if isinstance(obj.get("results"), dict) else {}
                    for rid, result in results.items():
                        key = ''.join(ch for ch in str(rid) if ch.isalnum() or ch in '-_')[:128]
                        if key:
                            _bridge_results[key] = {
                                "received_at": now,
                                "tabId": tab_id,
                                "value": result,
                            }
                    _bridge_cleanup_locked(now)
                    queue = _bridge_commands.pop(tab_id, [])
                    # Commands are short-lived. A stale UI action is always safer to
                    # discard than to replay against a later page.
                    commands = [c for c in queue if now - float(c.get("created_at") or now) <= 20.0][:30]
                self._json(200, {"ok": True, "commands": commands})
            except Exception as e:
                self._json(500, {"ok": False, "error": str(e)[:180]})
            return
        if path == "/v1/command":
            try:
                obj = self._read_json(512 * 1024)
                tab_id = int(obj.get("tabId") or 0)
                ctype = str(obj.get("type") or "").strip()
                if tab_id <= 0 or not ctype:
                    self._json(400, {"ok": False, "error": "missing tab/type"})
                    return
                cmd = dict(obj)
                cmd["tabId"] = tab_id
                cmd["type"] = ctype
                cmd["created_at"] = time.time()
                with _bridge_lock:
                    _bridge_commands.setdefault(tab_id, []).append(cmd)
                    _bridge_commands[tab_id] = _bridge_commands[tab_id][-100:]
                self._json(200, {"ok": True})
            except Exception as e:
                self._json(500, {"ok": False, "error": str(e)[:180]})
            return
        self._json(404, {"ok": False})


class _AdeonBridgeServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def start_browser_bridge_server() -> None:
    def worker() -> None:
        try:
            srv = _AdeonBridgeServer(("127.0.0.1", BROWSER_BRIDGE_PORT), _AdeonBridgeHandler)
            app_log(f"Normal-Chrome bridge listening on 127.0.0.1:{BROWSER_BRIDGE_PORT}")
            srv.serve_forever(poll_interval=0.10)
        except OSError as e:
            app_log(f"Normal-Chrome bridge could not bind port {BROWSER_BRIDGE_PORT}: {e}")
        except Exception as e:
            app_log(f"Normal-Chrome bridge stopped: {e}")
    threading.Thread(target=worker, name="AdeonNormalChromeBridge", daemon=True).start()


def browser_integration_live(max_age: float = 3.0) -> bool:
    """True only when the extension is actively reporting an LR Writers tab."""
    try:
        req = urllib.request.Request(
            f"http://127.0.0.1:{BROWSER_BRIDGE_PORT}/v1/tabs",
            headers={"Cache-Control": "no-store"},
            method="GET",
        )
        with urllib.request.urlopen(req, timeout=0.45) as r:
            obj = json.loads(r.read(2 * 1024 * 1024).decode("utf-8", "replace") or "{}")
        now = float(obj.get("now") or time.time()) if isinstance(obj, dict) else time.time()
        for rec in (obj.get("tabs") or []) if isinstance(obj, dict) else []:
            if not isinstance(rec, dict):
                continue
            age = now - float(rec.get("received_at") or 0.0)
            url = str(rec.get("url") or "").lower()
            if age <= max(0.5, float(max_age)) and "myaccount.lrwriters.com" in url:
                return True
    except Exception:
        pass
    return False


def rerun_browser_registration() -> None:
    """Refresh the installed integration files/registration without touching Chrome."""
    script = BASE / "Register Browser Integration.ps1"
    if not script.is_file():
        return
    try:
        subprocess.run(
            ["powershell.exe", "-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script)],
            cwd=str(BASE), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=12,
            creationflags=0x08000000,
        )
    except Exception as e:
        app_log(f"Browser integration registration refresh skipped: {e}")


def find_normal_chrome_exe() -> str:
    candidates = [
        Path(os.environ.get("PROGRAMFILES", r"C:\Program Files")) / "Google/Chrome/Application/chrome.exe",
        Path(os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)")) / "Google/Chrome/Application/chrome.exe",
        Path(os.environ.get("LOCALAPPDATA", "")) / "Google/Chrome/Application/chrome.exe",
    ]
    for path in candidates:
        try:
            if path.is_file():
                return str(path)
        except Exception:
            pass
    return "chrome.exe"


def open_browser_integration_repair_pages() -> None:
    """Open only the existing normal Chrome's extensions page plus the unpacked folder."""
    try:
        os.startfile(str(BROWSER_INTEGRATION_DIR))
    except Exception:
        pass
    try:
        subprocess.Popen(
            [find_normal_chrome_exe(), "chrome://extensions/"],
            creationflags=0x08000000, stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
    except Exception as e:
        app_log(f"Could not open Chrome extensions page for browser-link repair: {e}")

# Self-updater.  Every updater-enabled Adeon can jump directly to the newest
# published version; updates are full program-file releases, not incremental
# patches.  User data (Chrome Data, reports, logs, local state) is never part of
# an update package and is therefore preserved.
ADEON_VERSION = "1.0.31"
UPDATE_FEED_FILE = BASE / "Update Feed URL.txt"
OFFICIAL_UPDATE_FEED = "https://raw.githubusercontent.com/Adegbye123/adeon-updates/main/adeon/manifest.json"
UPDATE_HELPER = BASE / "Adeon Update Helper.py"
UPDATE_PENDING_FILE = BASE / "Adeon Pending Update.json"
UPDATE_STATUS_FILE = BASE / "Adeon Update Status.json"
UPDATE_STAGE_DIR = BASE / "Update Staging"
UPDATE_CHECK_INTERVAL = 5.0  # online clients poll the manifest every ~5 seconds

# Updater diagnostics are mirrored to Downloads so users can send one obvious
# file when update discovery or installation is not working.
def _downloads_dir() -> Path:
    try:
        p = Path(os.environ.get("USERPROFILE", str(Path.home()))) / "Downloads"
        p.mkdir(parents=True, exist_ok=True)
        return p
    except Exception:
        return Path.home()

UPDATE_DIAGNOSTIC_LOG = _downloads_dir() / "Adeon Update Diagnostic.log"


CREATE_NEW_PROCESS_GROUP = 0x00000200
DETACHED_PROCESS = 0x00000008
PROCESS_SYNCHRONIZE = 0x00100000
WAIT_TIMEOUT = 0x00000102
SW_RESTORE = 9


def set_windows_app_identity() -> None:
    """Give Windows a stable Adeon identity so the taskbar uses Adeon's icon."""
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Adeon.Picker.DesktopApp")
    except Exception:
        pass


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8").strip()
    except Exception:
        return ""


def app_log(message: str) -> None:
    try:
        stamp = time.strftime("%Y-%m-%d %H:%M:%S")
        with ACTIVITY_LOG.open("a", encoding="utf-8") as fh:
            fh.write(f"[{stamp}] APP | {str(message)}\n")
    except Exception:
        pass


def update_diag(message: str) -> None:
    try:
        stamp = time.strftime("%Y-%m-%d %H:%M:%S")
        with UPDATE_DIAGNOSTIC_LOG.open("a", encoding="utf-8") as fh:
            fh.write(f"[{stamp}] {str(message)}\n")
    except Exception:
        pass


def _pid_file(mode: str = "picker") -> Path:
    return LABELS_PID_FILE if str(mode).lower() == "labels" else PICKER_PID_FILE

def _stop_file(mode: str = "picker") -> Path:
    return LABELS_STOP_FILE if str(mode).lower() == "labels" else PICKER_STOP_FILE

def _runtime_file(mode: str = "picker") -> Path:
    return LABELS_RUNTIME_FILE if str(mode).lower() == "labels" else PICKER_RUNTIME_FILE

def worker_pid(mode: str = "picker") -> int:
    try:
        return int(read_text(_pid_file(mode)) or "0")
    except Exception:
        return 0


def pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        k32 = ctypes.windll.kernel32
        h = k32.OpenProcess(PROCESS_SYNCHRONIZE, False, int(pid))
        if not h:
            return False
        try:
            return int(k32.WaitForSingleObject(h, 0)) == WAIT_TIMEOUT
        finally:
            k32.CloseHandle(h)
    except Exception:
        return False


def runtime_state(mode: str = "picker") -> dict:
    try:
        obj = json.loads(_runtime_file(mode).read_text(encoding="utf-8"))
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def foreground_window_title() -> str:
    """Return the title of the Windows foreground window."""
    try:
        user32 = ctypes.windll.user32
        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return ""
        length = int(user32.GetWindowTextLengthW(hwnd))
        if length <= 0:
            return ""
        buf = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buf, length + 1)
        return str(buf.value or "")
    except Exception:
        return ""


def foreground_is_lr_page() -> bool:
    """Only show the small dashboard while LR Writers is the foreground page."""
    title = foreground_window_title().strip().lower()
    if not title:
        return False
    # LR Writers currently exposes the active page as Writer Tool in Chrome's
    # window title.  Keep a domain/name fallback for future title changes.
    return (
        "writer tool" in title
        or "lr writers" in title
        or "lrwriters" in title
        or "myaccount.lrwriters.com" in title
    )


def pythonw_path() -> str:
    p = read_text(PYTHON_PATH_FILE)
    if p and Path(p).is_file():
        return p
    exe = Path(sys.executable)
    if exe.name.lower().startswith("python"):
        pw = exe.with_name("pythonw.exe")
        return str(pw if pw.exists() else exe)
    return "pythonw.exe"





def update_feed_url() -> str:
    raw = read_text(UPDATE_FEED_FILE).strip()
    if not raw or raw.startswith("#") or "OWNER/REPOSITORY" in raw:
        return OFFICIAL_UPDATE_FEED
    return raw




def manifest_feed_candidates(feed: str) -> list[str]:
    """Return public GitHub manifest URLs that can have independent CDN cache keys.

    GitHub's raw CDN can briefly serve an older branch view after the Contents API
    has accepted a commit.  Adeon probes equivalent public endpoints and uses the
    newest valid manifest it sees.  No private token is required on client laptops.
    """
    out = []
    def add(url: str):
        url = str(url or '').strip()
        if url and url not in out:
            out.append(url)
    add(feed)
    try:
        u = urllib.parse.urlparse(feed)
        if u.netloc.lower() == 'raw.githubusercontent.com':
            parts = [x for x in u.path.split('/') if x]
            if len(parts) >= 4:
                owner, repo, branch = parts[0], parts[1], parts[2]
                rel = '/'.join(parts[3:])
                add(f'https://raw.githubusercontent.com/{owner}/{repo}/refs/heads/{branch}/{rel}')
                add(f'https://github.com/{owner}/{repo}/raw/refs/heads/{branch}/{rel}')
                add(f'https://github.com/{owner}/{repo}/raw/{branch}/{rel}')
    except Exception:
        pass
    return out


def fetch_newest_manifest(feed: str) -> tuple[dict, str]:
    """Read equivalent public feeds and return the highest valid Adeon version."""
    best = None
    best_url = ''
    errors = []
    for i, url in enumerate(manifest_feed_candidates(feed)):
        try:
            # The primary feed keeps the full retry/fallback behavior. Alternate
            # cache paths use a shorter timeout so the 5-second polling loop stays responsive.
            timeout = 8.0 if i == 0 else 4.0
            obj = fetch_json_url(url, timeout=timeout)
            if str(obj.get('product') or '') != 'Adeon LR Picker':
                continue
            ver = str(obj.get('version') or '').strip()
            if not ver:
                continue
            update_diag(f'MANIFEST SOURCE | url={url} version={ver}')
            if best is None or version_tuple(ver) > version_tuple(str(best.get('version') or '0')):
                best = obj
                best_url = url
        except Exception as e:
            errors.append(f'{url}: {e}')
            update_diag(f'MANIFEST SOURCE FAILED | url={url} error={e}')
    if best is None:
        raise RuntimeError('No public update feed responded with a valid manifest' + (f' | {errors[-1]}' if errors else ''))
    return best, best_url

def fetch_manifest_quick(feed: str) -> tuple[dict, str]:
    """Fast single-endpoint probe used by the 5-second background poll.

    The previous build could keep the update state busy for many seconds because
    every automatic poll used the full retry/fallback routine across several
    GitHub URLs.  That made CHECK FOR UPDATE look unclickable.  Background
    checks now probe just one cache-busted public endpoint with a short timeout.
    Manual checks still use the robust multi-endpoint routine.
    """
    candidates = manifest_feed_candidates(feed)
    if not candidates:
        raise RuntimeError('No update feed is configured')
    # Rotate equivalent GitHub URLs between polls so a stale CDN edge does not
    # permanently hide a newly published manifest.
    idx = int(time.time() // max(1.0, UPDATE_CHECK_INTERVAL)) % len(candidates)
    url = candidates[idx]
    request_url = _cache_busted_url(url)
    req = urllib.request.Request(
        request_url,
        headers={
            "User-Agent": f"Adeon-LR-Picker/{ADEON_VERSION}",
            "Cache-Control": "no-cache, no-store",
            "Pragma": "no-cache",
            "Connection": "close",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=2.5) as resp:
            data = resp.read(1024 * 1024 + 1)
        if len(data) > 1024 * 1024:
            raise RuntimeError('Update manifest exceeded the allowed size')
        obj = json.loads(data.decode('utf-8-sig'))
        if not isinstance(obj, dict):
            raise RuntimeError('Update manifest is not a JSON object')
        if str(obj.get('product') or '') != 'Adeon LR Picker':
            raise RuntimeError('Update feed is for a different product')
        update_diag(f'FAST MANIFEST SOURCE | url={url} version={obj.get("version","")}')
        return obj, url
    except Exception as e:
        update_diag(f'FAST MANIFEST FAILED | url={url} error={e}')
        raise

def version_tuple(value: str) -> tuple[int, ...]:
    parts = []
    for piece in str(value or "0").strip().lstrip("vV").split("."):
        digits = "".join(ch for ch in piece if ch.isdigit())
        parts.append(int(digits or 0))
    while len(parts) < 4:
        parts.append(0)
    return tuple(parts[:4])


def is_newer_version(candidate: str, current: str = ADEON_VERSION) -> bool:
    return version_tuple(candidate) > version_tuple(current)


def _cache_busted_url(url: str) -> str:
    text = str(url or "")
    sep = "&" if "?" in text else "?"
    return f"{text}{sep}adeon_cb={int(time.time() * 1000)}"


def _curl_public_https(url: str, timeout: float, max_bytes: int) -> bytes:
    """Public-read fallback for Windows machines where urllib/TLS is interrupted."""
    curl = shutil.which("curl.exe") or shutil.which("curl")
    if not curl:
        raise RuntimeError("curl fallback is not available")
    cmd = [
        curl, "-L", "--fail", "--silent", "--show-error",
        "--connect-timeout", str(max(3, min(15, int(timeout)))),
        "--max-time", str(max(5, int(timeout))),
        "-H", "Cache-Control: no-cache, no-store",
        "-H", "Pragma: no-cache",
        "-A", f"Adeon-LR-Picker/{ADEON_VERSION}",
        url,
    ]
    cp = subprocess.run(cmd, capture_output=True, timeout=max(8, timeout + 5), creationflags=CREATE_NO_WINDOW)
    if cp.returncode != 0:
        err = cp.stderr.decode("utf-8", errors="replace").strip()
        raise RuntimeError(f"curl failed ({cp.returncode}): {err[:300]}")
    data = bytes(cp.stdout or b"")
    if len(data) > max_bytes:
        raise RuntimeError("Update response exceeded the allowed size")
    return data


def _public_https_bytes(url: str, timeout: float, max_bytes: int, purpose: str) -> bytes:
    if not str(url).lower().startswith("https://"):
        raise RuntimeError(f"{purpose} must use HTTPS")
    attempts = 4
    last = None
    for attempt in range(1, attempts + 1):
        request_url = _cache_busted_url(str(url))
        req = urllib.request.Request(
            request_url,
            headers={
                "User-Agent": f"Adeon-LR-Picker/{ADEON_VERSION}",
                "Cache-Control": "no-cache, no-store",
                "Pragma": "no-cache",
                "Connection": "close",
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = resp.read(max_bytes + 1)
            if len(data) > max_bytes:
                raise RuntimeError("Update response exceeded the allowed size")
            if attempt > 1:
                update_diag(f"NETWORK RECOVERED | {purpose} succeeded on attempt {attempt}/{attempts}")
            return data
        except urllib.error.HTTPError as e:
            last = e
            # 4xx responses other than timeout/rate-limit are not transient.
            if e.code not in (408, 429, 500, 502, 503, 504):
                raise RuntimeError(f"{purpose} HTTP {e.code}")
        except (urllib.error.URLError, http.client.RemoteDisconnected, ConnectionResetError,
                ConnectionAbortedError, TimeoutError, socket.timeout, OSError) as e:
            last = e
        except RuntimeError:
            raise
        if attempt < attempts:
            delay = min(8.0, 1.0 * (2 ** (attempt - 1)))
            update_diag(f"NETWORK RETRY | {purpose} attempt={attempt}/{attempts} reason={last} waiting={delay:.1f}s")
            time.sleep(delay)

    # GitHub raw/public downloads need no secret, so curl is a safe alternate
    # transport when Python's urllib connection is being interrupted locally.
    try:
        update_diag(f"NETWORK FALLBACK | {purpose} trying Windows curl after urllib retries")
        return _curl_public_https(_cache_busted_url(str(url)), timeout, max_bytes)
    except Exception as curl_error:
        update_diag(f"NETWORK FALLBACK FAILED | {purpose} | {curl_error}")
        raise RuntimeError(f"{purpose} connection failed after retries: {last or curl_error}")


def fetch_json_url(url: str, timeout: float = 12.0) -> dict:
    data = _public_https_bytes(url, timeout, 1024 * 1024, "Update manifest")
    obj = json.loads(data.decode("utf-8-sig"))
    if not isinstance(obj, dict):
        raise RuntimeError("Update manifest is not a JSON object")
    return obj


def download_bytes(url: str, timeout: float = 45.0) -> bytes:
    return _public_https_bytes(url, timeout, 100 * 1024 * 1024, "Update package")


def flash_taskbar(hwnd: int, count: int = 8) -> None:
    """Flash Adeon's own taskbar button so an available update is visible."""
    try:
        class FLASHWINFO(ctypes.Structure):
            _fields_ = [
                ("cbSize", ctypes.c_uint),
                ("hwnd", ctypes.c_void_p),
                ("dwFlags", ctypes.c_uint),
                ("uCount", ctypes.c_uint),
                ("dwTimeout", ctypes.c_uint),
            ]
        info = FLASHWINFO(ctypes.sizeof(FLASHWINFO), int(hwnd), 0x00000003 | 0x0000000C, int(count), 0)
        ctypes.windll.user32.FlashWindowEx(ctypes.byref(info))
    except Exception:
        pass


def cleanup_legacy_controllers() -> None:
    """Close obsolete console-based LR/Adeon controllers without touching app workers."""
    try:
        ps = (
            "$me=$PID; "
            "$ps=Get-CimInstance Win32_Process | Where-Object { "
            "$_.ProcessId -ne $me -and $_.CommandLine -and "
            "((($_.CommandLine -match 'Adeon Bot\\.py') -and ($_.CommandLine -notmatch '--app-worker')) "
            "-or ($_.CommandLine -match 'LR Picker Bot\\.py') "
            "-or ($_.CommandLine -match 'lr_mouse_bot\\.py') "
            "-or ($_.CommandLine -match 'lr_alt_s_launcher\\.pyw')) }; "
            "foreach($p in $ps){ try { Invoke-CimMethod -InputObject $p -MethodName Terminate | Out-Null } catch {} }"
        )
        subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5,
            creationflags=0x08000000,
        )
    except Exception:
        pass

def launch_worker(mode: str = "picker") -> tuple[bool, str]:
    mode = "labels" if str(mode).lower() == "labels" else "picker"
    if pid_alive(worker_pid(mode)):
        if mode == "labels":
            try:
                LABELS_REFRESH_FILE.write_text(str(time.time()), encoding="utf-8")
            except Exception:
                pass
            app_log("Labels ON requested while the label worker is already active; refresh/re-inject requested.")
            return True, "Labels are already on. Refreshing the existing LR Writers tab in place..."
        app_log("Picker launch requested but picker worker is already active.")
        return True, "Picker already active"
    if not BOT.exists():
        return False, f"Missing {BOT.name}"
    for p in (_stop_file(mode), LAST_ERROR_FILE):
        try:
            p.unlink(missing_ok=True)
        except Exception:
            pass
    try:
        args = [pythonw_path(), str(BOT), "--app-worker"]
        if mode == "labels":
            args.append("--labels-only")
        proc = subprocess.Popen(
            args,
            cwd=str(BASE),
            creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP,
            close_fds=True,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        _pid_file(mode).write_text(str(proc.pid), encoding="utf-8")
        app_log(f"Worker launched. PID={proc.pid}. mode={mode}. Waiting for Chrome/LR Writers checks.")
        if mode == "labels":
            return True, "Turning labels on in the existing LR Writers Chrome/tab..."
        return True, "Connecting to the existing normal Chrome tab..."
    except Exception as e:
        app_log(f"Worker launch failed: {e}")
        return False, str(e)


def request_stop(mode: str = "picker") -> tuple[bool, str]:
    mode = "labels" if str(mode).lower() == "labels" else "picker"
    pid = worker_pid(mode)
    if not pid_alive(pid):
        try:
            _pid_file(mode).unlink(missing_ok=True)
        except Exception:
            pass
        return True, "Already stopped"
    try:
        _stop_file(mode).write_text(str(time.time()), encoding="utf-8")
        app_log(f"Deactivate requested for {mode} worker PID={pid}.")
        return True, "Stopping..."
    except Exception as e:
        return False, str(e)


def bring_existing_adeon_to_front() -> bool:
    try:
        hwnd = ctypes.windll.user32.FindWindowW(None, "Adeon")
        if hwnd:
            ctypes.windll.user32.ShowWindow(hwnd, SW_RESTORE)
            ctypes.windll.user32.SetForegroundWindow(hwnd)
            return True
    except Exception:
        pass
    return False


def single_instance_or_focus() -> object | None:
    try:
        k32 = ctypes.windll.kernel32
        mutex = k32.CreateMutexW(None, False, "Local\\AdeonPickerAppMutex")
        if ctypes.get_last_error() == 183:  # ERROR_ALREADY_EXISTS
            bring_existing_adeon_to_front()
            return None
        return mutex
    except Exception:
        return object()


class AdeonApp:
    def __init__(self) -> None:
        set_windows_app_identity()
        start_browser_bridge_server()
        self.root = tk.Tk()
        self.root.title("Adeon")
        self.root.geometry("350x470")
        self.root.resizable(False, False)
        self.root.configure(bg="#f7f8f7")
        self.root.protocol("WM_DELETE_WINDOW", self.close_everything)
        try:
            ico = BASE / "Adeon.ico"
            if ico.exists():
                self.root.iconbitmap(default=str(ico))
                # Re-apply after Windows has created the native window handle.
                self.root.after(250, lambda: self.root.iconbitmap(default=str(ico)))
        except Exception:
            pass

        top = tk.Frame(self.root, bg="#f7f8f7")
        top.pack(pady=(18, 4))

        logo = tk.Canvas(top, width=48, height=48, bg="#f7f8f7", highlightthickness=0)
        logo.pack(side="left", padx=(0, 9))
        logo.create_oval(2, 2, 46, 46, fill="#12863a", outline="#12863a")
        logo.create_text(24, 24, text="A", fill="white", font=("Segoe UI", 24, "bold"))

        tk.Label(
            top, text="ADEON", bg="#f7f8f7", fg="#111111",
            font=("Segoe UI", 19, "bold")
        ).pack(side="left")

        self.status = tk.Label(
            self.root, text="STOPPED", bg="#f7f8f7", fg="#c62828",
            font=("Segoe UI", 13, "bold")
        )
        self.status.pack(pady=(6, 5))

        self.version_label = tk.Label(
            self.root, text=f"INSTALLED VERSION  {ADEON_VERSION}", bg="#f7f8f7", fg="#777777",
            font=("Segoe UI", 8)
        )
        self.version_label.pack(pady=(0, 8))

        self.update_status = tk.Label(
            self.root, text="UPDATE  •  CHECKING", bg="#f7f8f7", fg="#777777",
            font=("Segoe UI", 8, "bold")
        )
        self.update_status.pack(pady=(0, 4))

        self.update_button = tk.Button(
            self.root, text="CHECK FOR UPDATE", width=25, height=1,
            font=("Segoe UI", 9, "bold"), command=lambda: self.check_for_updates(force=True),
            relief="flat", cursor="hand2", bg="#e8ece9", fg="#1f1f1f",
            activebackground="#d7ddd9", activeforeground="#111111"
        )
        self.update_button.pack(pady=(0, 8))

        # Persistent bottom-left dashboard owned by Adeon.exe itself. It is a real
        # Tk window with native text widgets, not an image. The rounded shape is
        # applied with a Windows region so the text remains crisp at normal DPI.
        self.ticket = tk.Toplevel(self.root)
        self.ticket.overrideredirect(True)
        self.ticket.attributes("-topmost", True)
        try:
            self.ticket.attributes("-alpha", 1.0)
        except Exception:
            pass
        self._ticket_width, self._ticket_height = 252, 126
        sh = int(self.ticket.winfo_screenheight() or 1080)
        self.ticket.geometry(f"{self._ticket_width}x{self._ticket_height}+18+{max(8, sh-self._ticket_height-58)}")
        self.ticket.configure(bg="#fff7d6")

        tframe = tk.Frame(self.ticket, bg="#fff7d6", bd=0, highlightthickness=0)
        tframe.pack(fill="both", expand=True, padx=1, pady=1)

        header_row = tk.Frame(tframe, bg="#fff7d6")
        header_row.pack(fill="x", padx=(12, 7), pady=(8, 2))
        self.ticket_header = tk.Label(
            header_row, text="ADEON  •  STOPPED", anchor="w", justify="left",
            bg="#fff7d6", fg="#c62828", font=("Bahnschrift SemiBold", 10, "bold")
        )
        self.ticket_header.pack(side="left", fill="x", expand=True)
        self.ticket_close = tk.Button(
            header_row, text="×", command=self.minimize_dashboard,
            bg="#fff7d6", fg="#111111", activebackground="#f3e7b3", activeforeground="#111111",
            relief="flat", bd=0, highlightthickness=0, cursor="hand2",
            font=("Segoe UI", 12, "bold"), padx=3, pady=0,
        )
        self.ticket_close.pack(side="right")

        body = tk.Frame(tframe, bg="#fff7d6")
        body.pack(fill="both", expand=True, padx=12, pady=(3, 8))
        self.ticket_value_labels = {}
        for r, key in enumerate(("JOB", "F5", "MOUSE")):
            left = tk.Label(
                body, text=key, anchor="w", bg="#fff7d6", fg="#111111",
                font=("Bahnschrift SemiBold", 9, "bold")
            )
            left.grid(row=r, column=0, sticky="w", pady=2)
            value = tk.Label(
                body, text="-" if key == "JOB" else "OFF", anchor="w",
                bg="#fff7d6", fg="#111111", font=("Bahnschrift SemiBold", 9, "bold")
            )
            value.grid(row=r, column=1, sticky="w", padx=(28, 0), pady=2)
            self.ticket_value_labels[key] = value
        body.grid_columnconfigure(1, weight=1)

        self.ticket_restore = tk.Toplevel(self.root)
        self.ticket_restore.overrideredirect(True)
        self.ticket_restore.attributes("-topmost", True)
        self.ticket_restore.configure(bg="#fff7d6")
        self.ticket_restore.geometry(f"38x30+18+{max(8, sh-30-58)}")
        self.ticket_restore_button = tk.Button(
            self.ticket_restore, text="A", command=self.restore_dashboard,
            bg="#c62828", fg="white", activebackground="#a91f1f", activeforeground="white",
            relief="flat", bd=0, highlightthickness=0, cursor="hand2",
            font=("Bahnschrift SemiBold", 10, "bold")
        )
        self.ticket_restore_button.pack(fill="both", expand=True)
        self.ticket_restore.withdraw()

        drag = {"x": 0, "y": 0}
        def ticket_drag_start(event):
            drag["x"], drag["y"] = int(event.x), int(event.y)
        def ticket_drag_move(event):
            self.ticket.geometry(f"+{int(event.x_root)-drag['x']}+{int(event.y_root)-drag['y']}")
        for widget in (tframe, header_row, self.ticket_header, body, *self.ticket_value_labels.values()):
            widget.bind("<ButtonPress-1>", ticket_drag_start)
            widget.bind("<B1-Motion>", ticket_drag_move)
        self.root.after(50, self.apply_dashboard_rounding)

        self.toggle = tk.Button(
            self.root, text="ACTIVATE PICKER", width=25, height=2,
            font=("Segoe UI", 11, "bold"), command=self.toggle_picker,
            relief="flat", cursor="hand2", bg="#12863a", fg="white",
            activebackground="#0e6d2e", activeforeground="white"
        )
        self.toggle.pack()

        self.labels_button = tk.Button(
            self.root, text="ON LABELS", width=25, height=1,
            font=("Segoe UI", 9, "bold"), command=self.toggle_labels,
            relief="flat", cursor="hand2", bg="#dfeee3", fg="#176b34",
            activebackground="#cfe5d5", activeforeground="#145a2d"
        )
        self.labels_button.pack(pady=(7, 0))

        self.log_button = tk.Button(
            self.root, text="VIEW ACTIVITY LOG", width=25, height=1,
            font=("Segoe UI", 9, "bold"), command=self.open_activity_log,
            relief="flat", cursor="hand2", bg="#e8ece9", fg="#1f1f1f",
            activebackground="#d7ddd9", activeforeground="#111111"
        )
        self.log_button.pack(pady=(8, 0))

        self.note = tk.Label(
            self.root,
            text="Adeon uses the browser integration inside your normal Chrome. It never opens a separate Chrome profile.",
            bg="#f7f8f7", fg="#555555", font=("Segoe UI", 8),
            wraplength=292, justify="center"
        )
        self.note.pack(pady=(12, 0))

        self.hotkey_note = tk.Label(
            self.root, text="ALT+S also toggles START / STOP",
            bg="#f7f8f7", fg="#777777", font=("Segoe UI", 8)
        )
        self.hotkey_note.pack(pady=(5, 0))

        self.last_event = tk.Label(
            self.root, text="Log: waiting", bg="#f7f8f7", fg="#555555",
            font=("Segoe UI", 7), wraplength=320, justify="center"
        )
        self.last_event.pack(pady=(8, 0))

        self.busy = False
        self.last_alive = False
        self._hotkey_exit = threading.Event()
        self._hotkey_thread_id = 0
        self._hotkey_registered = False
        self._picker_forced_red = False
        self._last_runtime_page = ""
        self._closing = False
        self._ticket_visible = True
        self._ticket_user_minimized = False
        self._last_picker_connected_at = 0.0
        self._browser_connect_mode = ""
        self._browser_connect_started_at = 0.0
        self._browser_helper_opened = False
        self.pending_update: dict | None = None
        self.update_checking = False
        self.update_installing = False
        self.manual_update_requested = False
        self.last_update_check = 0.0
        self.last_update_notified = ""
        update_diag(f"ADEON START | installed={ADEON_VERSION} feed={update_feed_url() or '[not configured]'}")
        self.root.after(200, self.refresh)
        self.root.after(2200, lambda: self.check_for_updates(force=True))
        self.root.after(5000, self.periodic_update_check)
        self.root.after(900, self.show_last_update_result)
        self.start_global_alt_s_hotkey()
        self.root.after(700, self.maybe_show_pin_help)

    def apply_dashboard_rounding(self) -> None:
        """Give the native dashboard/restore pill rounded Windows edges."""
        try:
            for win, radius in ((self.ticket, 22), (self.ticket_restore, 16)):
                hwnd = int(win.winfo_id())
                win.update_idletasks()
                w = max(1, int(win.winfo_width()))
                h = max(1, int(win.winfo_height()))
                rgn = ctypes.windll.gdi32.CreateRoundRectRgn(0, 0, w + 1, h + 1, radius, radius)
                ctypes.windll.user32.SetWindowRgn(hwnd, rgn, True)
        except Exception:
            pass

    def minimize_dashboard(self) -> None:
        self._ticket_user_minimized = True
        try:
            self.ticket.withdraw()
            self.ticket_restore.deiconify()
            self.ticket_restore.lift()
            self.apply_dashboard_rounding()
        except Exception:
            pass

    def restore_dashboard(self) -> None:
        self._ticket_user_minimized = False
        try:
            self.ticket_restore.withdraw()
            if foreground_is_lr_page():
                self.ticket.deiconify()
                self.ticket.lift()
                self._ticket_visible = True
                self.apply_dashboard_rounding()
        except Exception:
            pass

    def show_last_update_result(self) -> None:
        try:
            if not UPDATE_STATUS_FILE.exists():
                return
            obj = json.loads(UPDATE_STATUS_FILE.read_text(encoding="utf-8"))
            UPDATE_STATUS_FILE.unlink(missing_ok=True)
            if not isinstance(obj, dict):
                return
            if obj.get("ok"):
                installed = str(obj.get('version') or ADEON_VERSION)
                update_diag(f"LAST INSTALL RESULT | success version={installed}")
                self.version_label.config(text=f"INSTALLED VERSION  {installed}")
                self.update_status.config(text=f"INSTALLED VERSION  {installed}  •  UP TO DATE", fg="#12863a")
                self.set_message(f"Updated successfully to {installed}.")
                app_log(f"Update completed successfully: {obj}")
            else:
                update_diag(f"LAST INSTALL RESULT | failed details={obj}")
                self.set_message("The last update could not be installed. Adeon restored the previous version.")
                app_log(f"Update failed and rollback was attempted: {obj}")
        except Exception as e:
            app_log(f"Could not read update result: {e}")

    def periodic_update_check(self) -> None:
        try:
            self.check_for_updates(force=False)
        finally:
            self.root.after(5000, self.periodic_update_check)

    def check_for_updates(self, force: bool = False) -> None:
        if self.update_installing:
            update_diag("CHECK SKIPPED | update installation is in progress")
            if force:
                self.set_message("An update is already being installed.")
            return
        if self.update_checking:
            update_diag(f"CHECK REQUESTED WHILE BUSY | force={force}")
            if force:
                # Give immediate visual feedback instead of making the button
                # appear dead.  The in-flight check will update the result.
                self.manual_update_requested = True
                self.update_status.config(text="UPDATE  •  CHECKING NOW", fg="#777777")
                self.update_button.config(text="CHECKING...", state="normal")
                self.set_message("Checking for the newest Adeon version now...")
            return
        feed = update_feed_url()
        update_diag(f"CHECK START | installed={ADEON_VERSION} force={force} feed={feed or '[not configured]'}")
        if not feed:
            update_diag("CHECK RESULT | update channel is not configured")
            self.update_status.config(text="UPDATE  •  CHANNEL NOT SET", fg="#777777")
            self.update_button.config(text="CHECK FOR UPDATE", state="normal", bg="#e8ece9", fg="#1f1f1f")
            if force:
                self.set_message("Update channel is not configured yet. The administrator only needs to configure it once.")
            return
        now = time.time()
        if not force and now - self.last_update_check < UPDATE_CHECK_INTERVAL:
            return
        self.last_update_check = now
        self.update_checking = True
        self.manual_update_requested = bool(force)
        if force:
            self.update_status.config(text="UPDATE  •  CHECKING NOW", fg="#777777")
            # Do not disable the button.  A disabled Tk button looked like it
            # could not be clicked on slower networks.
            self.update_button.config(text="CHECKING...", state="normal")
            self.set_message("Checking for the newest Adeon version...")
        threading.Thread(target=self._check_update_thread, args=(feed, force), daemon=True).start()

    def _check_update_thread(self, feed: str, force: bool) -> None:
        try:
            update_diag(f"FETCH MANIFEST | {feed} mode={'manual' if force else 'fast-background'}")
            if force:
                manifest, manifest_source = fetch_newest_manifest(feed)
            else:
                manifest, manifest_source = fetch_manifest_quick(feed)
            update_diag(f"MANIFEST SELECTED | source={manifest_source} version={manifest.get('version','')}")
            product = str(manifest.get("product") or "")
            version = str(manifest.get("version") or "").strip()
            package_url = str(manifest.get("package_url") or "").strip()
            sha256 = str(manifest.get("sha256") or "").strip().lower()
            update_diag(f"MANIFEST RECEIVED | product={product or '[blank]'} version={version or '[blank]'} package_url={package_url or '[blank]'} sha256={'present' if len(sha256)==64 else 'invalid/missing'}")
            if product and product.lower() not in ("adeon", "adeon lr picker"):
                raise RuntimeError("The update feed is for a different product")
            if not version or not package_url or len(sha256) != 64:
                raise RuntimeError("Update manifest is incomplete")
            if is_newer_version(version):
                update_diag(f"CHECK RESULT | UPDATE AVAILABLE installed={ADEON_VERSION} available={version}")
                self.root.after(0, lambda: self._update_available(manifest))
            else:
                update_diag(f"CHECK RESULT | UP TO DATE installed={ADEON_VERSION} published={version}")
                self.root.after(0, lambda v=version: self._update_current(v))
        except Exception as e:
            msg = str(e)
            update_diag(f"CHECK FAILED | {msg}")
            app_log(f"Update check failed: {msg}")
            self.root.after(0, lambda m=msg, manual=force: self._update_check_failed(m, manual))

    def _update_available(self, manifest: dict) -> None:
        self.update_checking = False
        self.manual_update_requested = False
        self.pending_update = dict(manifest)
        ver = str(manifest.get("version") or "")
        update_diag(f"UI NOTICE | showing update available {ver}")
        self.update_status.config(text=f"AVAILABLE VERSION  {ver}", fg="#b45f06")
        self.set_message(f"Installed {ADEON_VERSION}. Version {ver} is available. Tap INSTALL UPDATE to apply it.")
        self.update_button.config(
            text=f"INSTALL UPDATE {ver}", state="normal", command=self.install_update,
            bg="#f2a100", fg="white", activebackground="#d18b00", activeforeground="white"
        )
        self.root.title("Adeon  •  UPDATE AVAILABLE")
        if self.last_update_notified != ver:
            self.last_update_notified = ver
            app_log(f"Update available: {ver}. Taskbar notification triggered.")
            try:
                flash_taskbar(self.root.winfo_id(), 10)
                self.root.bell()
            except Exception:
                pass
            self.show_update_toast(ver, str(manifest.get("summary") or ""))

    def _update_current(self, published_version: str = "") -> None:
        published = str(published_version or ADEON_VERSION).strip() or ADEON_VERSION
        update_diag(f"UI STATUS | installed={ADEON_VERSION} published={published} up_to_date=true")
        self.update_checking = False
        self.manual_update_requested = False
        self.pending_update = None
        self.update_status.config(text=f"INSTALLED {ADEON_VERSION}  •  PUBLISHED {published}  •  UP TO DATE", fg="#12863a")
        self.update_button.config(
            text="CHECK FOR UPDATE", state="normal", command=lambda: self.check_for_updates(force=True),
            bg="#e8ece9", fg="#1f1f1f", activebackground="#d7ddd9", activeforeground="#111111"
        )
        self.root.title("Adeon")

    def _update_check_failed(self, message: str, manual: bool = True) -> None:
        update_diag(f"UI STATUS | update check failed manual={manual}: {message}")
        requested_during_background = bool(self.manual_update_requested and not manual)
        self.update_checking = False
        self.manual_update_requested = False
        # If the user tapped CHECK while a quick background probe was already
        # running and that quick probe failed, immediately honor the user's
        # request with the full robust manual check.
        if requested_during_background:
            update_diag("MANUAL CHECK ESCALATION | quick background probe failed; starting robust manual check")
            self.update_button.config(text="CHECKING...", state="normal")
            self.root.after(25, lambda: self.check_for_updates(force=True))
            return
        # Background 5-second probes are intentionally quiet. A momentary
        # network miss must not make the app look broken or lock the button.
        if not manual:
            self.update_button.config(
                text="CHECK FOR UPDATE", state="normal", command=lambda: self.check_for_updates(force=True),
                bg="#e8ece9", fg="#1f1f1f"
            )
            return
        self.update_status.config(text="UPDATE  •  CHECK FAILED", fg="#9a6a00")
        self.update_button.config(
            text="CHECK FOR UPDATE", state="normal", command=lambda: self.check_for_updates(force=True),
            bg="#e8ece9", fg="#1f1f1f"
        )
        self.set_message("Could not reach the update service. See Downloads\\Adeon Update Diagnostic.log for details.")

    def show_update_toast(self, version: str, summary: str) -> None:
        try:
            toast = tk.Toplevel(self.root)
            toast.title("Adeon Update")
            toast.attributes("-topmost", True)
            toast.resizable(False, False)
            toast.configure(bg="#fff6df")
            w, h = 320, 120
            sw, sh = toast.winfo_screenwidth(), toast.winfo_screenheight()
            toast.geometry(f"{w}x{h}+{max(10, sw-w-20)}+{max(10, sh-h-70)}")
            tk.Label(toast, text=f"ADEON UPDATE {version} AVAILABLE", bg="#fff6df", fg="#8a5200", font=("Segoe UI", 10, "bold")).pack(pady=(12, 3))
            txt = (summary or "Open Adeon from the taskbar and tap INSTALL UPDATE.")[:120]
            tk.Label(toast, text=txt, bg="#fff6df", fg="#333333", font=("Segoe UI", 8), wraplength=285, justify="center").pack()
            tk.Button(toast, text="OPEN ADEON", command=lambda: (self.root.deiconify(), self.root.lift(), self.root.focus_force(), toast.destroy()), bg="#12863a", fg="white", relief="flat").pack(pady=(8, 0))
            toast.after(12000, lambda: toast.destroy() if toast.winfo_exists() else None)
        except Exception:
            pass

    def install_update(self) -> None:
        if self.update_installing or not self.pending_update:
            return
        if not UPDATE_HELPER.exists():
            self.set_message("Update helper is missing. Reinstall the updater-enabled Adeon package once.")
            return
        self.update_installing = True
        manifest = dict(self.pending_update)
        ver = str(manifest.get("version") or "")
        update_diag(f"INSTALL REQUESTED | installed={ADEON_VERSION} target={ver}")
        self.update_status.config(text=f"UPDATE  •  DOWNLOADING {ver}", fg="#b45f06")
        self.update_button.config(text="DOWNLOADING UPDATE...", state="disabled")
        self.set_message("Downloading and verifying the Adeon update. No other action is needed.")
        threading.Thread(target=self._stage_update_thread, args=(manifest,), daemon=True).start()

    def _stage_update_thread(self, manifest: dict) -> None:
        try:
            package_url = str(manifest.get("package_url") or "")
            expected = str(manifest.get("sha256") or "").lower()
            update_diag(f"DOWNLOAD START | version={manifest.get('version','')} url={package_url}")
            data = download_bytes(package_url)
            update_diag(f"DOWNLOAD COMPLETE | bytes={len(data)}")
            actual = hashlib.sha256(data).hexdigest().lower()
            if actual != expected:
                raise RuntimeError("Downloaded update failed the SHA-256 integrity check")
            update_diag(f"VERIFY OK | sha256={actual}")
            if UPDATE_STAGE_DIR.exists():
                shutil.rmtree(UPDATE_STAGE_DIR, ignore_errors=True)
            UPDATE_STAGE_DIR.mkdir(parents=True, exist_ok=True)
            zip_path = UPDATE_STAGE_DIR / "Adeon Update.zip"
            zip_path.write_bytes(data)
            extract_dir = UPDATE_STAGE_DIR / "payload"
            extract_dir.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(zip_path, "r") as zf:
                for name in zf.namelist():
                    pp = Path(name)
                    if pp.is_absolute() or ".." in pp.parts:
                        raise RuntimeError("Update archive contains an unsafe path")
                zf.extractall(extract_dir)
            for required in ("Adeon App.pyw", "Adeon Bot.py", "Adeon.ico"):
                if not (extract_dir / required).is_file():
                    raise RuntimeError(f"Update package is missing {required}")
            pending = {
                "version": str(manifest.get("version") or ""),
                "summary": str(manifest.get("summary") or ""),
                "payload": str(extract_dir),
                "target": str(BASE),
                "app_pid": os.getpid(),
                "created_at": time.time(),
            }
            UPDATE_PENDING_FILE.write_text(json.dumps(pending, indent=2), encoding="utf-8")
            app_log(f"Update {pending['version']} downloaded and verified. Starting update helper.")
            update_diag(f"STAGED | update {pending['version']} verified; starting update helper")
            subprocess.Popen(
                [pythonw_path(), str(UPDATE_HELPER), "--apply", str(UPDATE_PENDING_FILE)],
                cwd=str(BASE), creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP,
                close_fds=True, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
            self.root.after(0, self._exit_for_update)
        except Exception as e:
            msg = str(e)
            update_diag(f"INSTALL FAILED | {msg}")
            app_log(f"Update staging failed: {msg}")
            self.root.after(0, lambda: self._update_stage_failed(msg))

    def _update_stage_failed(self, message: str) -> None:
        self.update_installing = False
        self.update_status.config(text="UPDATE  •  INSTALL FAILED", fg="#c62828")
        self.update_button.config(text="TRY UPDATE AGAIN", state="normal", command=self.install_update, bg="#f2a100", fg="white")
        self.set_message(f"Update was not installed: {message[:110]}")

    def _exit_for_update(self) -> None:
        self.set_message("Installing update. Adeon will restart automatically.")
        self.close_everything()

    def open_activity_log(self) -> None:
        try:
            if not ACTIVITY_LOG.exists():
                app_log("Activity log opened before any worker activity.")
            os.startfile(str(ACTIVITY_LOG))
        except Exception as e:
            try:
                subprocess.Popen(["notepad.exe", str(ACTIVITY_LOG)])
            except Exception:
                messagebox.showerror("Adeon", f"Could not open the activity log.\n\n{e}")

    def latest_log_line(self) -> str:
        try:
            lines = ACTIVITY_LOG.read_text(encoding="utf-8", errors="replace").splitlines()
            return lines[-1] if lines else "Log: waiting"
        except Exception:
            return "Log: waiting"

    def close_everything(self) -> None:
        """Fully exit Adeon and stop both independent workers. Chrome stays open."""
        if getattr(self, "_closing", False):
            return
        self._closing = True
        try:
            app_log("Adeon window close requested; stopping picker + labels workers and exiting completely.")
        except Exception:
            pass

        try:
            self._hotkey_exit.set()
            if self._hotkey_thread_id:
                ctypes.windll.user32.PostThreadMessageW(int(self._hotkey_thread_id), 0x0012, 0, 0)
        except Exception:
            pass

        for mode in ("picker", "labels"):
            pid = worker_pid(mode)
            if pid_alive(pid):
                try:
                    _stop_file(mode).write_text(str(time.time()), encoding="utf-8")
                except Exception:
                    pass
                deadline = time.time() + 2.5
                while time.time() < deadline and pid_alive(pid):
                    time.sleep(0.10)
                if pid_alive(pid):
                    try:
                        subprocess.run(
                            ["taskkill", "/PID", str(pid), "/T", "/F"],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=4,
                            creationflags=0x08000000,
                        )
                    except Exception:
                        pass
            for q in (_pid_file(mode), _stop_file(mode), _runtime_file(mode)):
                try:
                    q.unlink(missing_ok=True)
                except Exception:
                    pass
        try:
            LABELS_REFRESH_FILE.unlink(missing_ok=True)
        except Exception:
            pass

        for win in (getattr(self, "ticket_restore", None), getattr(self, "ticket", None)):
            try:
                if win is not None:
                    win.destroy()
            except Exception:
                pass
        try:
            self.root.quit()
        except Exception:
            pass
        try:
            self.root.destroy()
        except Exception:
            pass

    def maybe_show_pin_help(self) -> None:
        if not PIN_HELP_FLAG.exists():
            return
        try:
            PIN_HELP_FLAG.unlink(missing_ok=True)
        except Exception:
            pass
        try:
            self.root.deiconify()
            self.root.lift()
            self.root.focus_force()
        except Exception:
            pass
        messagebox.showinfo(
            "Pin Adeon",
            "Adeon is installed and open.\n\n"
            "Right-click the green A icon on the Windows taskbar and choose ‘Pin to taskbar’.\n\n"
            "After that, you can open Adeon from the taskbar and press ACTIVATE PICKER."
        )

    def set_message(self, msg: str) -> None:
        self.note.config(text=str(msg or "")[:150])

    def _launch_after_browser_ready(self, mode: str) -> None:
        mode = "labels" if str(mode).lower() == "labels" else "picker"
        ok, msg = launch_worker(mode)
        self.set_message(msg)
        if ok:
            if mode == "picker":
                self.busy = True
                self.root.after(1200, self.clear_start_busy)
            else:
                self.root.after(800, self.refresh)
        else:
            self.busy = False

    def _finish_browser_connect(self, mode: str, ok: bool) -> None:
        if self._closing:
            return
        if self._browser_connect_mode != mode:
            return
        self._browser_connect_mode = ""
        self._browser_connect_started_at = 0.0
        self.busy = False
        if ok:
            self._browser_helper_opened = False
            self.note.config(
                text="Adeon is linked to the LR Writers tab inside your normal Chrome. It never creates a separate Chrome profile.",
                fg="#555555",
            )
            app_log(f"Browser integration recovered and is live. Continuing requested mode={mode} automatically.")
            self._launch_after_browser_ready(mode)
        else:
            self.note.config(
                text="Chrome link is still off. In chrome://extensions reload Adeon Browser Integration, or Load unpacked and choose the Adeon Browser Integration folder that was opened.",
                fg="#a85b00",
            )
            self.set_message("Browser Integration is still not active. Chrome was not replaced or moved to another profile.")
            app_log(f"Browser integration repair timed out for mode={mode}; worker was not started.")

    def _open_browser_repair_helper(self, mode: str) -> None:
        if self._closing or self._browser_connect_mode != mode:
            return
        self._browser_helper_opened = True
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(str(BROWSER_INTEGRATION_DIR))
            self.root.update_idletasks()
        except Exception:
            pass
        self.note.config(
            text=(
                "ONE-TIME CHROME LINK: Chrome Extensions and the Adeon Browser Integration folder were opened. "
                "If Adeon Browser Integration is already listed, click its Reload button. Otherwise turn Developer mode on, "
                "click Load unpacked, and choose that folder. Adeon will continue automatically."
            ),
            fg="#a85b00",
        )
        self.set_message("Waiting for the browser link. The integration folder path is also copied to your clipboard.")
        open_browser_integration_repair_pages()
        app_log("Browser integration helper opened in the existing normal Chrome; waiting for live LR Writers snapshot.")

    def _browser_connect_worker(self, mode: str) -> None:
        # First refresh registration and give an already-installed extension a moment
        # to wake up. This avoids opening any repair UI for a transient service-worker sleep.
        rerun_browser_registration()
        warm_deadline = time.time() + 3.0
        while time.time() < warm_deadline and not self._closing and self._browser_connect_mode == mode:
            if browser_integration_live(max_age=4.0):
                self.root.after(0, lambda m=mode: self._finish_browser_connect(m, True))
                return
            time.sleep(0.20)

        if self._closing or self._browser_connect_mode != mode:
            return
        self.root.after(0, lambda m=mode: self._open_browser_repair_helper(m))

        # Keep waiting while the user completes the one-time Chrome permission.
        # The 1.0.31 extension injects itself into an already-open LR Writers tab,
        # so no second Adeon click or separate Chrome profile is needed afterward.
        deadline = time.time() + 180.0
        while time.time() < deadline and not self._closing and self._browser_connect_mode == mode:
            if browser_integration_live(max_age=4.0):
                self.root.after(0, lambda m=mode: self._finish_browser_connect(m, True))
                return
            time.sleep(0.25)
        if not self._closing and self._browser_connect_mode == mode:
            self.root.after(0, lambda m=mode: self._finish_browser_connect(m, False))

    def ensure_browser_then_launch(self, mode: str) -> None:
        mode = "labels" if str(mode).lower() == "labels" else "picker"
        if browser_integration_live(max_age=4.0):
            self._launch_after_browser_ready(mode)
            return
        if self._browser_connect_mode:
            self.set_message(
                f"Finishing the normal Chrome browser link for {self._browser_connect_mode.upper()} first..."
            )
            return
        self._browser_connect_mode = mode
        self._browser_connect_started_at = time.time()
        self.busy = (mode == "picker")
        self.set_message(f"Checking the normal Chrome browser link before starting {mode.upper()}...")
        self.note.config(
            text="Adeon is checking Browser Integration before it starts. No picker/label worker will be launched against the wrong Chrome environment.",
            fg="#555555",
        )
        threading.Thread(target=self._browser_connect_worker, args=(mode,), daemon=True).start()

    def toggle_picker(self) -> None:
        if self.busy and not self._browser_connect_mode:
            return
        app_log("ACTIVATE/DEACTIVATE PICKER button or Alt+S toggle received.")
        pid = worker_pid("picker")
        if pid_alive(pid):
            self._picker_forced_red = True
            ok, msg = request_stop("picker")
            self.set_message(msg)
            if ok:
                self.busy = True
                self.update_ticket(False, {"bot": "STOPPED", "job": "-", "f5": "OFF", "mouse": "OFF"})
                threading.Thread(target=self.wait_for_stop, args=(pid, "picker"), daemon=True).start()
        else:
            self._picker_forced_red = False
            self.ensure_browser_then_launch("picker")

    def toggle_labels(self) -> None:
        # Labels and Picker share the exact same normal-Chrome preflight. This is
        # intentional: a broken browser link must never affect only one button.
        app_log("ON LABELS button received.")
        if pid_alive(worker_pid("labels")):
            ok, msg = launch_worker("labels")
            self.set_message(msg)
            if ok:
                self.root.after(800, self.refresh)
            return
        self.ensure_browser_then_launch("labels")

    def clear_start_busy(self) -> None:
        self.busy = False

    def wait_for_stop(self, pid: int, mode: str = "picker") -> None:
        deadline = time.time() + 12.0
        while time.time() < deadline and pid_alive(pid):
            time.sleep(0.25)
        if pid_alive(pid):
            try:
                subprocess.run(
                    ["taskkill", "/PID", str(pid), "/T", "/F"],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5,
                    creationflags=0x08000000,
                )
            except Exception:
                pass
        for q in (_pid_file(mode), _stop_file(mode), _runtime_file(mode)):
            try:
                q.unlink(missing_ok=True)
            except Exception:
                pass
        self.busy = False

    def start_global_alt_s_hotkey(self) -> None:
        """Register Alt+S with Windows so a short keypress cannot be missed.

        The previous key-state poll could miss a quick chord. WM_HOTKEY is
        event-driven and remains reliable even while Chrome has focus.
        """
        HOTKEY_ID = 0xADE0
        MOD_ALT = 0x0001
        MOD_NOREPEAT = 0x4000
        VK_S = 0x53
        WM_HOTKEY = 0x0312

        def worker() -> None:
            registered = False
            try:
                user32 = ctypes.windll.user32
                kernel32 = ctypes.windll.kernel32
                self._hotkey_thread_id = int(kernel32.GetCurrentThreadId())
                registered = bool(user32.RegisterHotKey(None, HOTKEY_ID, MOD_ALT | MOD_NOREPEAT, VK_S))
                self._hotkey_registered = registered
                if not registered:
                    app_log("ALT+S global hotkey could not be registered. The main picker button still works.")
                    try:
                        self.root.after(0, lambda: self.hotkey_note.config(
                            text="ALT+S unavailable on this PC • use ACTIVATE/DEACTIVATE PICKER"
                        ))
                    except Exception:
                        pass
                    return
                app_log("ALT+S global hotkey registered with Windows.")
                msg = wintypes.MSG()
                while not self._hotkey_exit.is_set():
                    rv = int(user32.GetMessageW(ctypes.byref(msg), None, 0, 0))
                    if rv <= 0:
                        break
                    if int(msg.message) == WM_HOTKEY and int(msg.wParam) == HOTKEY_ID:
                        try:
                            self.root.after(0, self.toggle_picker)
                        except Exception:
                            break
            except Exception as e:
                app_log(f"ALT+S global hotkey failed: {e}")
            finally:
                self._hotkey_registered = False
                if registered:
                    try:
                        ctypes.windll.user32.UnregisterHotKey(None, HOTKEY_ID)
                    except Exception:
                        pass

        threading.Thread(target=worker, name="AdeonAltSHotkey", daemon=True).start()

    def update_ticket_visibility(self) -> None:
        """Show the dashboard only on LR Writers, while respecting user minimization."""
        try:
            should_show = foreground_is_lr_page()
            if not should_show:
                if self._ticket_visible:
                    self.ticket.withdraw()
                    self._ticket_visible = False
                self.ticket_restore.withdraw()
                return
            if self._ticket_user_minimized:
                self.ticket.withdraw()
                self.ticket_restore.deiconify()
                self.ticket_restore.lift()
                self._ticket_visible = False
                return
            self.ticket_restore.withdraw()
            if not self._ticket_visible:
                self.ticket.deiconify()
                self.ticket.lift()
                self._ticket_visible = True
                self.apply_dashboard_rounding()
        except Exception:
            pass

    def update_ticket(self, alive: bool, runtime: dict) -> None:
        try:
            raw_state = str(runtime.get("bot") or "").upper() if alive else "STOPPED"
            if raw_state == "CONNECTED":
                self._last_picker_connected_at = time.time()
            # Do not visually blink away from CONNECTED during a short F5/DOM
            # transition. This only smooths the display; worker liveness remains real.
            if alive and raw_state != "CONNECTED" and self._last_picker_connected_at and time.time() - self._last_picker_connected_at < 5.0:
                state = "CONNECTED"
            else:
                state = raw_state or ("CONNECTING" if alive else "STOPPED")
            if state == "CONNECTED":
                color = "#138a36"
            elif state == "STOPPED":
                color = "#c62828"
            else:
                color = "#8a6500"
            job = str(runtime.get("job") or ("SEARCHING" if alive else "-"))
            f5 = str(runtime.get("f5") or ("WAIT" if alive else "OFF"))
            mouse = str(runtime.get("mouse") or ("WAIT" if alive else "OFF"))
            self.ticket_header.config(text=f"ADEON  •  {state}", fg=color)
            # The minimized A is a strict picker-health light. Green means the
            # picker is genuinely CONNECTED now. OFF, connecting, browser-link
            # loss, or any worker fault is red. Labels do not control this light.
            fault_page = str(runtime.get("page") or "").upper()
            fault_tokens = ("ERROR", "FAILED", "OFF", "LOGGED OUT", "BROWSER LINK OFF", "WAITING NETWORK")
            has_fault = any(tok in fault_page for tok in fault_tokens)
            restore_ok = bool(alive and raw_state == "CONNECTED" and not has_fault and not self._picker_forced_red)
            self.ticket_restore_button.config(
                bg=("#12863a" if restore_ok else "#c62828"),
                activebackground=("#0e6d2e" if restore_ok else "#a91f1f"),
                fg="white", activeforeground="white"
            )
            self.ticket_value_labels["JOB"].config(text=job, fg="#111111")
            self.ticket_value_labels["F5"].config(text=f5, fg="#111111")
            self.ticket_value_labels["MOUSE"].config(text=mouse, fg="#111111")
        except Exception:
            pass

    def refresh(self) -> None:
        picker_pid = worker_pid("picker")
        picker_alive = pid_alive(picker_pid)
        picker_runtime = runtime_state("picker")
        labels_pid = worker_pid("labels")
        labels_alive = pid_alive(labels_pid)
        labels_runtime = runtime_state("labels")

        self.update_ticket_visibility()
        self.update_ticket(picker_alive, picker_runtime)

        bot_state = str(picker_runtime.get("bot") or "").upper()
        page_state = str(picker_runtime.get("page") or "").upper()
        self._last_runtime_page = page_state or self._last_runtime_page
        labels_state = str(labels_runtime.get("bot") or "").upper()
        labels_page = str(labels_runtime.get("page") or "").upper()

        try:
            latest = self.latest_log_line()
            if len(latest) > 135:
                latest = latest[-135:]
            self.last_event.config(text=latest)
        except Exception:
            pass

        # Picker controls are based only on the picker worker. Labels never stop it.
        if picker_alive and bot_state == "CONNECTED":
            self.status.config(text="CONNECTED", fg="#12863a")
            self.toggle.config(text="DEACTIVATE PICKER", bg="#c62828", fg="white", activebackground="#a91f1f")
            self.busy = False
        elif picker_alive:
            self.status.config(text="CONNECTING", fg="#b27800")
            self.toggle.config(text="DEACTIVATE PICKER", bg="#c62828", fg="white", activebackground="#a91f1f")
        else:
            self.status.config(text="STOPPED", fg="#c62828")
            self.toggle.config(text="ACTIVATE PICKER", bg="#12863a", fg="white", activebackground="#0e6d2e")
            try:
                PICKER_PID_FILE.unlink(missing_ok=True)
            except Exception:
                pass
            self.busy = False

        # ON LABELS is intentionally permanent. When already on it becomes a
        # refresh/re-inject action rather than disappearing or turning into OFF.
        if labels_alive and labels_state == "CONNECTED":
            self.labels_button.config(text="ON LABELS", bg="#12863a", fg="white", activebackground="#0e6d2e", activeforeground="white")
            if labels_page == "MY ORDERS":
                self.set_message("Labels are on in the existing My Orders tab. ON LABELS never opens another Chrome/tab.")
            elif labels_page == "LABELS WAIT":
                self.set_message("Labels are waiting. Open My Orders in the existing normal Chrome, then press ON LABELS again. No new Chrome/tab will open.")
        elif labels_alive:
            self.labels_button.config(text="ON LABELS", bg="#e7b94a", fg="#111111", activebackground="#d9a62c", activeforeground="#111111")
        else:
            self.labels_button.config(text="ON LABELS", bg="#dfeee3", fg="#176b34", activebackground="#cfe5d5", activeforeground="#145a2d")
            try:
                LABELS_PID_FILE.unlink(missing_ok=True)
            except Exception:
                pass

        if not picker_alive and not labels_alive:
            last_error = read_text(LAST_ERROR_FILE)
            if last_error:
                self.set_message(last_error[:150])
            elif self.last_alive and not self.busy:
                self.set_message("STOPPED. Chrome remains available for you.")
        elif picker_alive and bot_state == "CONNECTED" and not labels_alive:
            self.set_message("CONNECTED to LR Writers. ON LABELS is available separately below.")

        if (picker_alive and bot_state == "CONNECTED") or (labels_alive and labels_state == "CONNECTED"):
            if time.time() - self.last_update_check >= UPDATE_CHECK_INTERVAL:
                self.check_for_updates(force=False)

        self.last_alive = picker_alive
        self.root.after(300, self.refresh)

    def run(self) -> None:
        self.root.mainloop()


if __name__ == "__main__":
    if redirect_source_copy_to_installed_app():
        raise SystemExit(0)
    set_windows_app_identity()
    app_log("Adeon app opened.")
    cleanup_legacy_controllers()
    _mutex = single_instance_or_focus()
    if _mutex is not None:
        AdeonApp().run()
