from __future__ import annotations

import ctypes
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import winreg
from pathlib import Path
import tkinter as tk

CREATE_NO_WINDOW = 0x08000000
SW_SHOWNORMAL = 1

EXTENSION_ID = 'efnloiohfchcnkmiindjmlbmnmbdkifo'
EXTENSION_VERSION = '1.0.33'
EXTENSION_UPDATE_URL = 'http://127.0.0.1:17329/extension/update.xml'


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding='utf-8').strip()
    except Exception:
        return ''


def pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        k32 = ctypes.windll.kernel32
        h = k32.OpenProcess(0x00100000, False, int(pid))
        if not h:
            return False
        try:
            return int(k32.WaitForSingleObject(h, 0)) == 0x00000102
        finally:
            k32.CloseHandle(h)
    except Exception:
        return False


def python_exe(target: Path) -> Path:
    p = Path(read_text(target / 'Python Path.txt') or sys.executable)
    if p.name.lower() == 'pythonw.exe':
        candidate = p.with_name('python.exe')
        if candidate.exists():
            return candidate
    return p


def write_status(target: Path, ok: bool, version: str, message: str) -> None:
    try:
        (target / 'Adeon Update Status.json').write_text(
            json.dumps({'ok': bool(ok), 'version': version, 'message': message, 'time': time.time()}, indent=2),
            encoding='utf-8',
        )
    except Exception:
        pass


def copy_program_files(src: Path, target: Path) -> None:
    allowed = [
        'Adeon App.pyw', 'Adeon Bot.py', 'Adeon.ico',
        'Adeon Update Helper.py', 'Read Me Adeon.txt', 'Built In Label Sync URL.txt',
        'Enable Browser Integration.bat', 'Register Browser Integration.ps1',
        'Label Sync Secret.txt', 'Configure Label Sync.bat', 'Label Sync Setup.txt',
    ]
    for name in allowed:
        sp = src / name
        if sp.is_file():
            shutil.copy2(sp, target / name)



def _set_reg_string(root, key_path: str, name: str, value: str) -> None:
    with winreg.CreateKeyEx(root, key_path, 0, winreg.KEY_SET_VALUE | winreg.KEY_QUERY_VALUE) as key:
        winreg.SetValueEx(key, name, 0, winreg.REG_SZ, str(value))


def register_browser_integration() -> None:
    """Prepare Chromium-family discovery without opening or restarting a browser."""
    local = Path(os.environ.get('LOCALAPPDATA', ''))
    ext_dir = local / 'Adeon Browser Integration'
    manifest = ext_dir / 'manifest.json'
    if not manifest.is_file():
        raise RuntimeError('Adeon Browser Integration manifest is missing after update')

    # Chromium/Thorium watches this external-extension registry area while running.
    # Use the localhost update manifest while Adeon's bridge is alive. Chrome on
    # unmanaged PCs may still refuse off-store installation; the app's one-time
    # Load unpacked pairing remains the explicit fallback.
    key_path = rf'Software\Google\Chrome\Extensions\{EXTENSION_ID}'
    _set_reg_string(winreg.HKEY_CURRENT_USER, key_path, 'update_url', EXTENSION_UPDATE_URL)
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0,
                            winreg.KEY_SET_VALUE | winreg.KEY_QUERY_VALUE) as key:
            for value_name in ('path', 'version'):
                try:
                    winreg.DeleteValue(key, value_name)
                except OSError:
                    pass
    except OSError:
        pass


def copy_browser_integration(src: Path, target: Path) -> None:
    src_dir = src / 'Adeon Browser Integration'
    if not src_dir.is_dir():
        return
    legacy = Path(os.environ.get('LOCALAPPDATA', '')) / 'Adeon Browser Integration'
    canonical = target / 'Adeon Browser Integration'
    legacy.mkdir(parents=True, exist_ok=True)
    canonical.mkdir(parents=True, exist_ok=True)
    # Replace only integration program files. User label data lives elsewhere.
    for name in ('manifest.json', 'background.js', 'content.js',
                 'Adeon Browser Integration.crx', 'Extension ID.txt', 'Extension Public Key.txt'):
        sp = src_dir / name
        if sp.is_file():
            shutil.copy2(sp, legacy / name)
            shutil.copy2(sp, canonical / name)
    (target / 'Browser Integration Path.txt').write_text(str(canonical), encoding='utf-8')
    try:
        register_browser_integration()
    except Exception:
        # Browser security can still require one explicit Load unpacked approval.
        # The update itself remains valid and Adeon never opens/restarts a browser.
        pass

def build_exe(target: Path, py: Path, progress) -> None:
    # If the publisher supplied a ready Adeon.exe, use it. Otherwise rebuild
    # locally. Every normal Adeon installation already has PyInstaller because
    # the installer used it to create the first Adeon.exe.
    supplied = target / 'Update Staging' / 'payload' / 'Adeon.exe'
    if supplied.is_file():
        shutil.copy2(supplied, target / 'Adeon.exe')
        return

    progress('Building the updated Adeon app...')
    build = Path(tempfile.gettempdir()) / f'Adeon Update Build {os.getpid()}'
    shutil.rmtree(build, ignore_errors=True)
    (build / 'dist').mkdir(parents=True, exist_ok=True)
    (build / 'work').mkdir(parents=True, exist_ok=True)
    (build / 'spec').mkdir(parents=True, exist_ok=True)
    runtime_dir = target / 'Runtime'
    runtime_dir.mkdir(parents=True, exist_ok=True)
    cmd = [
        str(py), '-m', 'PyInstaller', '--noconfirm', '--clean', '--onefile', '--windowed', '--noupx',
        '--runtime-tmpdir', str(runtime_dir),
        '--name', 'Adeon', '--icon', str(target / 'Adeon.ico'),
        '--distpath', str(build / 'dist'), '--workpath', str(build / 'work'), '--specpath', str(build / 'spec'),
        str(target / 'Adeon App.pyw'),
    ]
    proc = subprocess.run(cmd, cwd=str(target), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                          creationflags=CREATE_NO_WINDOW, timeout=240)
    if proc.returncode != 0 or not (build / 'dist' / 'Adeon.exe').is_file():
        raise RuntimeError('Could not build the updated Adeon.exe')
    shutil.copy2(build / 'dist' / 'Adeon.exe', target / 'Adeon.exe')
    shutil.rmtree(build, ignore_errors=True)


def relaunch(target: Path) -> None:
    # Immediately after an update, launch the editable app source with pythonw
    # instead of the freshly rebuilt PyInstaller one-file executable. This avoids
    # a Windows/AV race where the one-file bootloader can fail to load python*.dll
    # from its temporary _MEI extraction folder on the first launch only. The
    # normal pinned shortcut still uses Adeon.exe on later user launches.
    try:
        pyw = Path(read_text(target / 'Python Path.txt'))
        app = target / 'Adeon App.pyw'
        if pyw.is_file() and app.is_file():
            subprocess.Popen(
                [str(pyw), str(app)], cwd=str(target), creationflags=CREATE_NO_WINDOW,
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
            return
    except Exception:
        pass

    # Fallback: allow security software a short settling period before launching
    # the one-file executable.
    time.sleep(3.0)
    start_menu = Path(os.environ.get('APPDATA', '')) / 'Microsoft' / 'Windows' / 'Start Menu' / 'Programs' / 'Adeon.lnk'
    try:
        if start_menu.is_file():
            os.startfile(str(start_menu))
            return
    except Exception:
        pass
    subprocess.Popen([str(target / 'Adeon.exe')], cwd=str(target), creationflags=CREATE_NO_WINDOW)


class UpdateWindow:
    def __init__(self) -> None:
        self.root = tk.Tk()
        self.root.title('Adeon Update')
        self.root.geometry('410x180')
        self.root.resizable(False, False)
        self.root.configure(bg='#f7f8f7')
        self.root.attributes('-topmost', True)
        try:
            ico = Path(os.environ.get('LOCALAPPDATA', '')) / 'Adeon' / 'Adeon.ico'
            if ico.exists():
                self.root.iconbitmap(default=str(ico))
        except Exception:
            pass
        tk.Label(self.root, text='ADEON UPDATE', bg='#f7f8f7', fg='#12863a', font=('Segoe UI', 16, 'bold')).pack(pady=(20, 10))
        self.label = tk.Label(self.root, text='Preparing update...', bg='#f7f8f7', fg='#333333', font=('Segoe UI', 10), wraplength=360)
        self.label.pack(pady=(0, 12))
        self.step = tk.Label(self.root, text='1 / 3', bg='#f7f8f7', fg='#777777', font=('Segoe UI', 9, 'bold'))
        self.step.pack()
        self.root.update_idletasks()

    def set(self, text: str, step: int | None = None) -> None:
        try:
            self.label.config(text=text)
            if step is not None:
                self.step.config(text=f'{step} / 3')
            self.root.update()
        except Exception:
            pass

    def close(self) -> None:
        try:
            self.root.destroy()
        except Exception:
            pass


def apply_update(pending_path: Path) -> int:
    ui = UpdateWindow()
    pending = json.loads(pending_path.read_text(encoding='utf-8'))
    target = Path(pending['target']).resolve()
    payload = Path(pending['payload']).resolve()
    version = str(pending.get('version') or '')
    app_pid = int(pending.get('app_pid') or 0)
    backup = target / 'Update Backup' / f"before {version or 'update'} {time.strftime('%Y%m%d %H%M%S')}"
    backup.mkdir(parents=True, exist_ok=True)
    browser_ext = Path(os.environ.get('LOCALAPPDATA', '')) / 'Adeon Browser Integration'
    browser_backup = backup / 'Adeon Browser Integration'
    program_names = ['Adeon.exe', 'Adeon App.pyw', 'Adeon Bot.py', 'Adeon.ico', 'Adeon Update Helper.py', 'Read Me Adeon.txt', 'Built In Label Sync URL.txt', 'Enable Browser Integration.bat', 'Register Browser Integration.ps1', 'Browser Integration Path.txt']

    try:
        ui.set('Stopping the current Adeon session safely...', 1)
        deadline = time.time() + 25
        while pid_alive(app_pid) and time.time() < deadline:
            time.sleep(0.2)
            ui.root.update()
        if pid_alive(app_pid):
            subprocess.run(['taskkill', '/PID', str(app_pid), '/T', '/F'], stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, timeout=8, creationflags=CREATE_NO_WINDOW)
            time.sleep(0.8)

        for name in program_names:
            src = target / name
            if src.is_file():
                shutil.copy2(src, backup / name)
        if browser_ext.is_dir():
            shutil.copytree(browser_ext, browser_backup, dirs_exist_ok=True)

        ui.set('Installing the new Adeon files...', 2)
        copy_program_files(payload, target)
        copy_browser_integration(payload, target)
        py = python_exe(target)
        build_exe(target, py, lambda text: ui.set(text, 2))

        (target / 'Adeon Version.json').write_text(
            json.dumps({'version': version, 'updated_at': time.time()}, indent=2), encoding='utf-8'
        )
        ui.set('Update installed. Restarting Adeon...', 3)
        write_status(target, True, version, 'Update installed successfully')
        try:
            pending_path.unlink(missing_ok=True)
        except Exception:
            pass
        time.sleep(0.8)
        relaunch(target)
        time.sleep(1.0)
        ui.close()
        return 0
    except Exception as e:
        err = str(e)
        ui.set('Update failed. Restoring the previous Adeon version...', 3)
        try:
            for name in program_names:
                old = backup / name
                if old.is_file():
                    shutil.copy2(old, target / name)
            if browser_backup.is_dir():
                shutil.copytree(browser_backup, browser_ext, dirs_exist_ok=True)
                try:
                    register_browser_integration()
                except Exception:
                    pass
        except Exception as rollback_error:
            err += f' | rollback error: {rollback_error}'
        write_status(target, False, version, err)
        time.sleep(1.0)
        try:
            relaunch(target)
        except Exception:
            pass
        time.sleep(1.5)
        ui.close()
        return 1


def main() -> int:
    if len(sys.argv) >= 3 and sys.argv[1] == '--apply':
        return apply_update(Path(sys.argv[2]))
    return 2


if __name__ == '__main__':
    raise SystemExit(main())
