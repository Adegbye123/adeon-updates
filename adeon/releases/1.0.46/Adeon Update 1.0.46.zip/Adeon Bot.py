#!/usr/bin/env python3
r"""
Adeon — LR Writers picker worker
================================
Reads the LR Writers DOM through Adeon's browser integration inside the user's
an already-open Chrome or Thorium LR Writers tab and uses the visible Windows mouse/keyboard for permitted
actions. It never clicks Accept and never launches a separate browser window/profile.
Persistent automation data lives under %LOCALAPPDATA%\Adeon.

Run this worker through Adeon.exe / Adeon App.pyw.
"""
from __future__ import annotations

import atexit
import ctypes
import json
import hashlib
import os
import random
import re
import signal
import shutil
import subprocess
import sys
import threading
import time
import traceback
import urllib.request
import urllib.parse
import uuid
from ctypes import wintypes
from datetime import datetime
from pathlib import Path

import pyautogui
import requests

# ---------------- config ----------------
PUSHOVER_USER_KEY = "u4opq7uv7aycr25h8k9a52nq825n3k"
PUSHOVER_APP_TOKEN = "ae3yrpk924weovh45ssdy44hvrziap"
GMAIL_TO = "adegboyeoore@gmail.com"
GMAIL_WEBAPP_URL = (
    "https://script.google.com/macros/s/"
    "AKfycbzV8-YBPMp-1Kma7iMJTejcyKxXBnjfaJ6r6yhuBFyYLuOLTfDz8TCObCnqgnAXshU/exec"
)
GMAIL_WEBAPP_SECRET = "Adegboye2004%%"

MIN_PAY = 6.00
RELOAD_FAST_N = 3
RELOAD_SLOW_N = 2
# F5 timing: choose a fresh random delay in the requested 3-5 second range.
# Every main-loop cycle reads/scans the live DOM before F5 is considered, so a
# newly appeared order can lock refresh before the keyboard refresh is allowed.
RELOAD_FAST = (3.0, 5.0)
RELOAD_SLOW = (3.0, 5.0)
F5_HARD_MIN_GAP = 3.0
F5_SHORT_GAP_THRESHOLD = 0.0
F5_BURST_RECOVERY_GAP = 0.0
RESERVED_RELOAD = (3.0, 5.0)  # legacy value; actual visible F5 is intentionally held while reserved
RESERVED_SCROLLBAR_PASS_AT = (12.0, 36.0)  # two quick visible scrollbar down/up passes during the first reservation minute
RESERVED_SCROLLBAR_DRAG_SECONDS = 0.24
DOM_SCAN_INTERVAL = 0.10  # target live row/DOM scan cadence while the picker is active
IDLE_MOVE = (20.0, 60.0)
IDLE_CLICK = (120.0, 300.0)  # safe inert-background click only; never while an order panel is open
IDLE_ACTIVE_FOR = 5 * 60.0      # after 5 active minutes, pause idle mouse activity
IDLE_REST = (3 * 60.0, 20 * 60.0)  # random 3-20 minute idle-mouse rest
RESERVE_REMINDER_AFTER = 60.0       # first short reservation reminder, at 1 minute
RESERVE_CRITICAL_START = 4 * 60.0       # critical phase begins exactly 4:00 after Reserve
RESERVE_CRITICAL_ESCALATE = 5.5 * 60.0  # from 5:30, increase alert frequency
RESERVE_CRITICAL_STAGE3 = 6 * 60.0       # further escalation
RESERVE_CRITICAL_STAGE4 = 6.5 * 60.0     # final high-frequency phase until reservation ends
RESERVE_CRITICAL_CADENCE_1 = 15.0        # 4:00-5:30
RESERVE_CRITICAL_CADENCE_2 = 10.0        # 5:30-6:00
RESERVE_CRITICAL_CADENCE_3 = 7.5         # 6:00-6:30
RESERVE_CRITICAL_CADENCE_4 = 5.0         # 6:30 onward
RESERVATION_STATUS_CHECK = 10.0      # verify every 10 seconds that the reservation still exists
NETWORK_RETRY_MIN = 3.0              # keep worker alive through temporary network loss
NETWORK_RETRY_MAX = 5.0
SCHEDULED_NAV_VISIT = (40 * 60.0, 2 * 60 * 60.0)  # random 40 minutes to 2 hours between safe navigation detours
SCHEDULED_NAV_SEQUENCE = ("my_orders", "inbox", "my_progress")
SCHEDULED_NAV_DWELL = 2 * 60.0  # stay on each scheduled destination for two full minutes
SCHEDULED_NAV_SCROLL_AT = (30.0, 90.0)  # while dwelling, try one small down scroll then one small up scroll
MIDNIGHT_RULE_START_HOUR = 0
MIDNIGHT_RULE_END_HOUR = 8       # local PC time: 00:00 <= time < 08:00
MIDNIGHT_REJECT_UNDER_MINUTES = 5 * 60
MIDNIGHT_REJECT_AFTER = 60.0     # keep it reserved for one minute, then Reject
FIND_ORDERS = "https://myaccount.lrwriters.com/findorders/all"
MY_ORDERS = "https://myaccount.lrwriters.com/myorders/inprogress"
ROW_RETRY_SEC = 12.0
RESERVE_RETRY_SEC = 1.4

pyautogui.FAILSAFE = False
pyautogui.PAUSE = 0.0

_stop = False
_paused = False
_pause_reason = ""
_resume_requested = False
_resume_source = ""
_pause_lock = threading.Lock()
_alerted: set[str] = set()
_alert_last_try: dict[str, float] = {}
_alert_inflight: set[str] = set()
_alert_cancelled: set[str] = set()
_alert_lock = threading.Lock()
_critical_receipt_lock = threading.Lock()
_critical_receipts: dict[str, str] = {}
_done: set[str] = set()
_pay_audit_seen: set[str] = set()
_click_lock = threading.Lock()
_last_click = 0.0
_last_idle_dir = ""
_ctrl_handler_ref = None  # keep the Windows console callback alive
_debug_chrome_pid = 0
_debug_port = 0
_debug_endpoint = ""
_debug_user_data_dir = ""
_last_diag_shot = 0.0

# Persistent local controller. The controller itself never touches the webpage while
# STOPPED; it only keeps the tiny dashboard + Alt+S hotkey alive.
_controller_exit = threading.Event()
_controller_start_requested = threading.Event()
_controller_lock = threading.Lock()
_controller_worker: threading.Thread | None = None
_controller_active = False

# Tiny always-on-top status ticket shown on the Windows desktop.
_status_ticket_lock = threading.Lock()
_status_ticket_state = {
    "bot": "STARTING",
    "page": "WAITING",
    "job": "SEARCHING",
    "f5": "WAIT",
    "mouse": "WAIT",
    "mode": "PICKER",
}
_status_ticket_started = False
_status_ticket_stop = threading.Event()

# Window-management constants used only to guarantee that a real mouse click
# reaches the existing Chromium browser window rather than a covering terminal/window.
HWND_TOPMOST = -1
HWND_NOTOPMOST = -2
SWP_NOSIZE = 0x0001
SWP_NOMOVE = 0x0002
SWP_SHOWWINDOW = 0x0040
GA_ROOT = 2


# ---------------- tiny desktop status ticket ----------------
def set_status_ticket(**fields) -> None:
    """Update the tiny desktop ticket and the app-visible runtime status."""
    global _runtime_file_last
    with _status_ticket_lock:
        for key, value in fields.items():
            if key in _status_ticket_state and value is not None:
                _status_ticket_state[key] = str(value)
        snapshot = dict(_status_ticket_state)
    try:
        snapshot["pid"] = os.getpid()
        snapshot["updated_at"] = time.time()
        payload = json.dumps(snapshot, ensure_ascii=False, sort_keys=True)
        if payload != _runtime_file_last:
            _runtime_file_last = payload
            _write_json_atomic(_APP_RUNTIME_FILE, snapshot)
    except Exception:
        pass


def show_action_popup(text: str, kind: str = "accept", duration: float = 2.2, bell: bool = False) -> None:
    """Show a tiny temporary Windows popup for ACCEPT / REJECT decisions."""
    label = str(text or "").strip().upper() or ("ACCEPT" if kind == "accept" else "REJECT")
    mode = str(kind or "accept").lower()

    def worker() -> None:
        try:
            if bell:
                try:
                    import winsound
                    # Short two-tone laptop bell. Never blocks the director loop.
                    winsound.Beep(988, 170)
                    time.sleep(0.10)
                    winsound.Beep(659, 420)
                except Exception:
                    try:
                        import winsound
                        winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
                    except Exception:
                        pass

            import tkinter as tk
            root = tk.Tk()
            root.overrideredirect(True)
            root.attributes("-topmost", True)
            try:
                root.attributes("-alpha", 0.96)
            except Exception:
                pass

            is_accept = mode == "accept"
            bg = "#159447" if is_accept else "#d62f2f"
            width = 235 if len(label) > 12 else 150
            height = 48
            sw = int(root.winfo_screenwidth() or 1920)
            root.geometry(f"{width}x{height}+{max(8, sw-width-24)}+24")
            root.configure(bg=bg)
            tk.Label(
                root, text=label, bg=bg, fg="white",
                font=("Segoe UI", 11, "bold"), padx=10, pady=8,
                anchor="center", justify="center",
            ).pack(fill="both", expand=True)
            root.after(max(700, int(float(duration) * 1000)), root.destroy)
            root.mainloop()
        except Exception as e:
            try:
                log(f"Action popup unavailable: {e}")
            except Exception:
                pass

    threading.Thread(target=worker, name="LR-Action-Popup", daemon=True).start()


def start_status_ticket() -> None:
    """Start a tiny draggable, always-on-top sticky-note status window."""
    global _status_ticket_started
    if _status_ticket_started:
        return
    _status_ticket_started = True
    _status_ticket_stop.clear()

    def worker() -> None:
        try:
            import tkinter as tk
        except Exception as e:
            log(f"Status ticket unavailable (tkinter): {e}")
            return
        try:
            root = tk.Tk()
            root.overrideredirect(True)
            root.attributes("-topmost", True)
            try:
                root.attributes("-alpha", 0.94)
            except Exception:
                pass

            width, height = 230, 104
            sh = int(root.winfo_screenheight() or 1080)
            # Bottom-left as requested; leave a small margin above the taskbar.
            root.geometry(f"{width}x{height}+18+{max(8, sh-height-58)}")
            root.configure(bg="#fff4b8")

            frame = tk.Frame(root, bg="#fff4b8", bd=1, relief="solid")
            frame.pack(fill="both", expand=True)
            header = tk.Label(
                frame, text="ADEON", anchor="w", justify="left",
                bg="#fff4b8", fg="#111111", font=("Segoe UI", 9, "bold"),
                padx=7, pady=3,
            )
            header.pack(fill="x")
            body = tk.Label(
                frame, text="", anchor="nw", justify="left",
                bg="#fff4b8", fg="#111111", font=("Segoe UI", 8),
                padx=7, pady=1,
            )
            body.pack(fill="both", expand=True)

            drag = {"x": 0, "y": 0}
            def drag_start(event):
                drag["x"] = int(event.x)
                drag["y"] = int(event.y)
            def drag_move(event):
                root.geometry(f"+{int(event.x_root)-drag['x']}+{int(event.y_root)-drag['y']}")
            for w in (frame, header, body):
                w.bind("<ButtonPress-1>", drag_start)
                w.bind("<B1-Motion>", drag_move)

            def refresh() -> None:
                if _status_ticket_stop.is_set():
                    try:
                        root.destroy()
                    except Exception:
                        pass
                    return
                with _status_ticket_lock:
                    st = dict(_status_ticket_state)
                bot = str(st.get("bot", "?")).upper()
                if bot == "CONNECTED":
                    status_color = "#138a36"
                elif bot == "STOPPED":
                    status_color = "#c62828"
                else:
                    status_color = "#6b5b00"
                header.config(text=f"ADEON  •  {bot}", fg=status_color)
                body.config(text=(
                    f"JOB    {st.get('job','?')}\n"
                    f"F5     {st.get('f5','?')}\n"
                    f"MOUSE  {st.get('mouse','?')}"
                ))
                try:
                    root.after(350, refresh)
                except Exception:
                    pass

            refresh()
            root.mainloop()
        except Exception as e:
            try:
                log(f"Status ticket failed: {e}")
            except Exception:
                pass

    threading.Thread(target=worker, name="LR-Status-Ticket", daemon=True).start()


# ---------------- diagnostics / session report ----------------
SESSION_STARTED_AT = time.time()
SESSION_ID = datetime.now().strftime("%Y%m%d_%H%M%S")
# All persistent Adeon state is anchored to LOCALAPPDATA, never to the folder
# where an installer ZIP or source file happens to be extracted/run.
_LOCAL_APPDATA = Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local")))
_BASE_DIR = _LOCAL_APPDATA / "Adeon"
try:
    _BASE_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    pass
_REPORT_DIR = _BASE_DIR / "adeon_reports"
try:
    _REPORT_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    _REPORT_DIR = Path.cwd()

# The installer records the folder that contains Install Adeon.bat/ps1.
# Every user-facing report is copied back to that visible setup folder so the
# user never has to hunt through AppData or Downloads for it.
_REPORT_DEST_FILE = _BASE_DIR / "Report Folder.txt"
try:
    _saved_report_dir = Path(_REPORT_DEST_FILE.read_text(encoding="utf-8-sig").strip()).expanduser()
    if not _saved_report_dir.is_dir():
        raise OSError("saved setup/report folder is unavailable")
    _VISIBLE_REPORT_DIR = _saved_report_dir
except Exception:
    _VISIBLE_REPORT_DIR = Path.home() / "Downloads"

_SESSION_LOG = _REPORT_DIR / f"Adeon Session {SESSION_ID}.log"
_REPORT_LOCAL = _REPORT_DIR / f"Adeon Report {SESSION_ID}.txt"
_REPORT_VISIBLE = _VISIBLE_REPORT_DIR / f"Adeon Report {SESSION_ID}.txt"
_RESERVATION_STATE_FILE = _BASE_DIR / "Adeon Reservation State.json"
_APP_WORKER_MODE = "--app-worker" in sys.argv
_LABELS_ONLY_MODE = "--labels-only" in sys.argv
_FORCE_CHROME_RESTART = "--force-chrome-restart" in sys.argv  # legacy flag, no longer required for labels
_APP_STOP_FILE = _BASE_DIR / ("Adeon Labels Stop Request.flag" if _LABELS_ONLY_MODE else "Adeon Stop Request.flag")
_APP_RUNTIME_FILE = _BASE_DIR / ("Adeon Labels Runtime.json" if _LABELS_ONLY_MODE else "Adeon Runtime.json")
_APP_ACTIVITY_LOG = _BASE_DIR / "Adeon Activity.log"
_APP_LAST_ERROR_FILE = _BASE_DIR / "Adeon Last Error.txt"
_LABEL_REFRESH_FILE = _BASE_DIR / "Adeon Labels Refresh Request.flag"
_PICKER_PID_FILE = _BASE_DIR / "Adeon Worker PID.txt"
_LABEL_DATA_DIR = _LOCAL_APPDATA / "Adeon Data"
try:
    _LABEL_DATA_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    pass
_LABEL_LOCAL_FILE = _LABEL_DATA_DIR / "Labels.json"
_LABEL_DEVICE_FILE = _LABEL_DATA_DIR / "Device ID.txt"
_LABEL_SYNC_URL_FILE = _LABEL_DATA_DIR / "Label Sync URL.txt"
_LABEL_SYNC_SECRET_FILE = _LABEL_DATA_DIR / "Label Sync Secret.txt"
_LABEL_HISTORY_FILE = _LABEL_DATA_DIR / "Label History.jsonl"
_LABEL_OUTBOX_FILE = _LABEL_DATA_DIR / "Label Outbox.json"
_LABEL_CONFLICT_FILE = _LABEL_DATA_DIR / "Label Conflicts.jsonl"
_LABEL_BACKUP_DIR = _LABEL_DATA_DIR / "Label Backups"
_BUILTIN_LABEL_SYNC_URL_FILE = _BASE_DIR / "Built In Label Sync URL.txt"
_BUILTIN_LABEL_SYNC_SECRET_FILE = _BASE_DIR / "Label Sync Secret.txt"
_LABEL_UPDATE_FEED_FILE = _BASE_DIR / "Update Feed URL.txt"
_LABEL_OFFICIAL_UPDATE_FEED = "https://raw.githubusercontent.com/Adegbye123/adeon-updates/main/adeon/manifest.json"
_LABEL_REMOTE_FALLBACK_POLL = 45.0
_LABEL_BACKUP_MIN_INTERVAL = 60.0
_LABEL_BACKUP_KEEP = 20
_LABEL_NOTIFY_BASE = "https://ntfy.sh"
_ADEON_CHROME_DATA = _BASE_DIR / "Chrome Data"
_ADEON_CHROME_MARKER = _BASE_DIR / "Chrome Profile.json"
# Existing-browser bridge. The installed Chromium integration sends live
# LR Writers DOM snapshots from Chrome or Thorium through Adeon.exe's loopback service. Picker/labels
# never launch or switch to a separate visible browser profile.
_BROWSER_BRIDGE_PORT = 17329
_BROWSER_BRIDGE_BASE = f"http://127.0.0.1:{_BROWSER_BRIDGE_PORT}"
_runtime_file_last = ""


def _picker_worker_is_alive() -> bool:
    """Best-effort check so labels never navigate away from the live picker tab."""
    try:
        pid = int(_read_text_file(_PICKER_PID_FILE) or "0")
        if pid <= 0:
            return False
        PROCESS_SYNCHRONIZE = 0x00100000
        WAIT_TIMEOUT = 0x00000102
        k32 = ctypes.windll.kernel32
        h = k32.OpenProcess(PROCESS_SYNCHRONIZE, False, pid)
        if not h:
            return False
        try:
            return int(k32.WaitForSingleObject(h, 0)) == WAIT_TIMEOUT
        finally:
            k32.CloseHandle(h)
    except Exception:
        return False


def _write_json_atomic(path: Path, data: dict) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(path)
    except Exception:
        pass


def _read_json(path: Path) -> dict:
    try:
        obj = json.loads(path.read_text(encoding="utf-8"))
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def _read_text_file(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8-sig").strip()
    except Exception:
        return ""


def _append_jsonl(path: Path, obj: dict) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":")) + "\n")
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except Exception:
                pass
    except Exception:
        pass


def _label_device_id() -> str:
    value = _read_text_file(_LABEL_DEVICE_FILE)
    if value:
        return value
    value = (os.environ.get("COMPUTERNAME") or "PC").strip() + "-" + uuid.uuid4().hex[:10]
    try:
        _LABEL_DEVICE_FILE.write_text(value, encoding="utf-8")
    except Exception:
        pass
    return value


def _clean_label_state(obj: dict | None) -> dict:
    obj = obj or {}
    labels0 = obj.get("labels") if isinstance(obj.get("labels"), dict) else {}
    times0 = obj.get("times") if isinstance(obj.get("times"), dict) else {}
    revs0 = obj.get("revisions") if isinstance(obj.get("revisions"), dict) else {}
    labels: dict[str, str] = {}
    times: dict[str, float] = {}
    revisions: dict[str, int] = {}
    keys = set(labels0) | set(times0) | set(revs0)
    for raw_key in keys:
        key = str(raw_key or "").strip().upper()[:80]
        if not key:
            continue
        raw_value = labels0.get(raw_key, labels0.get(key, ""))
        value = str(raw_value or "").strip().upper()[:40]
        try:
            ts = max(0.0, float(times0.get(raw_key, times0.get(key, 0.0)) or 0.0))
        except Exception:
            ts = 0.0
        try:
            rev = max(0, int(revs0.get(raw_key, revs0.get(key, 0)) or 0))
        except Exception:
            rev = 0
        if value:
            labels[key] = value
        times[key] = ts
        revisions[key] = rev
    try:
        server_rev = max(0, int(obj.get("server_rev", 0) or 0))
    except Exception:
        server_rev = 0
    return {"labels": labels, "times": times, "revisions": revisions, "server_rev": server_rev}


def _merge_label_states(a: dict | None, b: dict | None) -> dict:
    """Compatibility merge for local/page or legacy-server snapshots.

    Protocol-2 remote snapshots use server revisions in LabelSyncManager.merge_remote().
    This helper keeps the old timestamp merge for legacy data while carrying revisions.
    """
    aa = _clean_label_state(a)
    bb = _clean_label_state(b)
    out_labels: dict[str, str] = {}
    out_times: dict[str, float] = {}
    out_revs: dict[str, int] = {}
    keys = set(aa["times"]) | set(bb["times"]) | set(aa["labels"]) | set(bb["labels"])
    for key in keys:
        ta = float(aa["times"].get(key, 0.0) or 0.0)
        tb = float(bb["times"].get(key, 0.0) or 0.0)
        if tb > ta:
            chosen = bb["labels"].get(key, "")
            ts = tb
            rev = max(int(aa["revisions"].get(key, 0) or 0), int(bb["revisions"].get(key, 0) or 0))
        else:
            chosen = aa["labels"].get(key, "")
            ts = ta
            rev = max(int(aa["revisions"].get(key, 0) or 0), int(bb["revisions"].get(key, 0) or 0))
        out_times[key] = ts
        out_revs[key] = rev
        if chosen:
            out_labels[key] = chosen
    return {
        "labels": out_labels,
        "times": out_times,
        "revisions": out_revs,
        "server_rev": max(int(aa.get("server_rev", 0) or 0), int(bb.get("server_rev", 0) or 0)),
    }


def _discover_label_sync_url_from_manifest() -> str:
    """Discover the shared label endpoint without any per-computer setup."""
    feeds = []
    configured = _read_text_file(_LABEL_UPDATE_FEED_FILE)
    if configured:
        feeds.append(configured)
    if _LABEL_OFFICIAL_UPDATE_FEED not in feeds:
        feeds.append(_LABEL_OFFICIAL_UPDATE_FEED)
    for feed in feeds:
        if not str(feed).lower().startswith(("https://", "http://")):
            continue
        try:
            r = requests.get(str(feed), timeout=2.5, headers={"Accept": "application/json"})
            if not (200 <= r.status_code < 300):
                continue
            data = r.json() if r.content else {}
            if not isinstance(data, dict):
                continue
            candidates = [
                data.get("label_sync_url"),
                (data.get("labels") or {}).get("sync_url") if isinstance(data.get("labels"), dict) else None,
                (data.get("label_sync") or {}).get("url") if isinstance(data.get("label_sync"), dict) else None,
            ]
            for value in candidates:
                value = str(value or "").strip()
                if value.lower().startswith("https://"):
                    try:
                        _LABEL_SYNC_URL_FILE.write_text(value, encoding="utf-8")
                    except Exception:
                        pass
                    return value
        except Exception:
            continue
    return ""


class LabelSyncManager:
    """No-loss local label journal plus independent cross-device synchronization.

    Every local edit is first persisted outside the Adeon program folder, then queued
    for the remote label service. The queue survives reboots and updates. Protocol-2
    servers assign per-order revisions, preserve an append-only server history, and
    reject stale offline overwrites instead of silently destroying a newer label.
    A private ntfy topic carries only a generic "changed" ping so other laptops can
    pull the persistent label server immediately without constant 200 ms web polling.
    """
    def __init__(self) -> None:
        self.device = _label_device_id()
        self.lock = threading.RLock()
        self.state = self._load_state_with_recovery()
        self.outbox = self._load_outbox()
        self.url = (
            _read_text_file(_LABEL_SYNC_URL_FILE)
            or _read_text_file(_BUILTIN_LABEL_SYNC_URL_FILE)
            or _discover_label_sync_url_from_manifest()
        )
        self.secret = _read_text_file(_LABEL_SYNC_SECRET_FILE) or _read_text_file(_BUILTIN_LABEL_SYNC_SECRET_FILE)
        self.last_remote_poll = 0.0
        self.last_remote_push = 0.0
        self.last_remote_error = 0.0
        self.last_backup_at = 0.0
        self.remote_hint = threading.Event()
        self._notify_stop = threading.Event()
        self._notify_thread = None
        if self.configured():
            self._start_notify_listener()

    def configured(self) -> bool:
        return bool(self.url.lower().startswith(("https://", "http://")))

    def snapshot(self) -> dict:
        with self.lock:
            return {
                "labels": dict(self.state.get("labels") or {}),
                "times": dict(self.state.get("times") or {}),
                "revisions": dict(self.state.get("revisions") or {}),
                "server_rev": int(self.state.get("server_rev", 0) or 0),
            }

    def _load_state_with_recovery(self) -> dict:
        direct = _read_json(_LABEL_LOCAL_FILE)
        if direct:
            return _clean_label_state(direct)
        # If the main snapshot was damaged or missing, recover the newest valid backup.
        try:
            _LABEL_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
            backups = sorted(_LABEL_BACKUP_DIR.glob("Labels *.json"), key=lambda p: p.stat().st_mtime, reverse=True)
            for backup in backups:
                obj = _read_json(backup)
                if obj:
                    recovered = _clean_label_state(obj)
                    _write_json_atomic(_LABEL_LOCAL_FILE, recovered)
                    log(f"LABEL RECOVERY: restored local snapshot from {backup.name}.")
                    return recovered
        except Exception:
            pass
        # Last resort: replay the local append-only journal. This preserves edits even
        # when both the active snapshot and a backup were interrupted during a crash.
        rebuilt = {"labels": {}, "times": {}, "revisions": {}, "server_rev": 0}
        try:
            if _LABEL_HISTORY_FILE.exists():
                for line in _LABEL_HISTORY_FILE.read_text(encoding="utf-8", errors="ignore").splitlines():
                    try:
                        ev = json.loads(line)
                    except Exception:
                        continue
                    if not isinstance(ev, dict):
                        continue
                    key = str(ev.get("order") or "").strip().upper()[:80]
                    if not key:
                        continue
                    value = str(ev.get("value") or "").strip().upper()[:40]
                    try:
                        ts = float(ev.get("client_time") or ev.get("time") or 0.0)
                    except Exception:
                        ts = 0.0
                    # Replay in durable journal order, not wall-clock order. Device
                    # clocks can differ, while append order reflects what Adeon actually
                    # accepted/applied. Thus a later remote conflict resolution correctly
                    # supersedes an older offline local proposal during disaster recovery.
                    rebuilt["times"][key] = ts
                    try:
                        rebuilt["revisions"][key] = max(int(rebuilt["revisions"].get(key, 0) or 0), int(ev.get("revision", 0) or 0))
                    except Exception:
                        pass
                    if value:
                        rebuilt["labels"][key] = value
                    else:
                        rebuilt["labels"].pop(key, None)
                if rebuilt["times"]:
                    _write_json_atomic(_LABEL_LOCAL_FILE, rebuilt)
                    log("LABEL RECOVERY: rebuilt local labels from append-only history.")
        except Exception:
            pass
        return _clean_label_state(rebuilt)

    def _load_outbox(self) -> list[dict]:
        obj = _read_json(_LABEL_OUTBOX_FILE)
        rows = obj.get("events") if isinstance(obj.get("events"), list) else []
        out = []
        for ev in rows:
            if not isinstance(ev, dict):
                continue
            key = str(ev.get("order") or "").strip().upper()[:80]
            if key:
                ev = dict(ev)
                ev["order"] = key
                out.append(ev)
        return out

    def _save_outbox(self) -> None:
        with self.lock:
            payload = {"events": list(self.outbox), "saved_at": time.time(), "device": self.device}
        _write_json_atomic(_LABEL_OUTBOX_FILE, payload)

    def _backup_if_due(self, force: bool = False) -> None:
        now = time.time()
        if not force and now - self.last_backup_at < _LABEL_BACKUP_MIN_INTERVAL:
            return
        self.last_backup_at = now
        try:
            _LABEL_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now().strftime("%Y%m%d %H%M%S")
            dest = _LABEL_BACKUP_DIR / f"Labels {stamp}.json"
            _write_json_atomic(dest, self.snapshot())
            backups = sorted(_LABEL_BACKUP_DIR.glob("Labels *.json"), key=lambda p: p.stat().st_mtime, reverse=True)
            for old in backups[_LABEL_BACKUP_KEEP:]:
                try:
                    old.unlink()
                except Exception:
                    pass
        except Exception:
            pass

    def _save(self) -> None:
        payload = self.snapshot()
        payload.update({"saved_at": time.time(), "device": self.device})
        _write_json_atomic(_LABEL_LOCAL_FILE, payload)
        self._backup_if_due(False)

    def _queue_local_event(self, key: str, value: str, client_time: float, base_rev: int) -> None:
        event = {
            "event_id": f"{self.device}-{uuid.uuid4().hex}",
            "device": self.device,
            "order": key,
            "value": value,
            "client_time": float(client_time or time.time()),
            "base_rev": int(base_rev or 0),
            "queued_at": time.time(),
        }
        with self.lock:
            # Coalesce rapid keystrokes for one order. The append-only local history
            # still records each observed value, while the network queue carries only
            # the newest unsent value for that order.
            self.outbox = [e for e in self.outbox if str(e.get("order") or "") != key]
            self.outbox.append(event)
        _append_jsonl(_LABEL_HISTORY_FILE, {**event, "kind": "local_edit"})
        self._save_outbox()

    def merge_page(self, page_state: dict | None) -> bool:
        page = _clean_label_state(page_state)
        changed = False
        queued = []
        with self.lock:
            keys = set(page["times"]) | set(page["labels"]) | set(self.state.get("times") or {}) | set(self.state.get("labels") or {})
            for key in keys:
                old_ts = float((self.state.get("times") or {}).get(key, 0.0) or 0.0)
                new_ts = float(page["times"].get(key, 0.0) or 0.0)
                if new_ts <= old_ts + 1e-7:
                    continue
                old_value = str((self.state.get("labels") or {}).get(key, "") or "")
                new_value = str(page["labels"].get(key, "") or "")
                self.state.setdefault("times", {})[key] = new_ts
                if new_value:
                    self.state.setdefault("labels", {})[key] = new_value
                else:
                    self.state.setdefault("labels", {}).pop(key, None)
                base_rev = int(self.state.setdefault("revisions", {}).get(key, 0) or 0)
                if new_value != old_value:
                    changed = True
                    queued.append((key, new_value, new_ts, base_rev))
        if changed:
            self._save()
            for key, value, ts, base_rev in queued:
                self._queue_local_event(key, value, ts, base_rev)
        return changed

    def merge_remote(self, remote_state: dict | None) -> bool:
        remote = _clean_label_state(remote_state)
        changed = False
        with self.lock:
            local_revs = self.state.setdefault("revisions", {})
            local_times = self.state.setdefault("times", {})
            local_labels = self.state.setdefault("labels", {})
            protocol2 = bool(remote.get("revisions")) or int(remote.get("server_rev", 0) or 0) > 0
            keys = set(remote["times"]) | set(remote["labels"]) | set(remote["revisions"])
            for key in keys:
                rr = int(remote["revisions"].get(key, 0) or 0)
                lr = int(local_revs.get(key, 0) or 0)
                rt = float(remote["times"].get(key, 0.0) or 0.0)
                lt = float(local_times.get(key, 0.0) or 0.0)
                should_take = (rr > lr) if protocol2 else (rt > lt)
                if not should_take:
                    continue
                value = str(remote["labels"].get(key, "") or "")
                before = str(local_labels.get(key, "") or "")
                if value:
                    local_labels[key] = value
                else:
                    local_labels.pop(key, None)
                local_times[key] = rt
                local_revs[key] = rr
                changed = changed or (before != value or rr != lr or abs(rt-lt) > 1e-7)
                _append_jsonl(_LABEL_HISTORY_FILE, {
                    "kind": "remote_apply", "order": key, "value": value,
                    "client_time": rt, "revision": rr, "time": time.time(),
                })
            self.state["server_rev"] = max(int(self.state.get("server_rev", 0) or 0), int(remote.get("server_rev", 0) or 0))
        if changed:
            self._save()
        return changed

    def _notification_topic(self) -> str:
        if not self.configured() or not self.secret:
            return ""
        digest = hashlib.sha256((self.url + "|" + self.secret).encode("utf-8", errors="ignore")).hexdigest()[:40]
        return "adeon-label-" + digest

    def _start_notify_listener(self) -> None:
        topic = self._notification_topic()
        if not topic or (self._notify_thread and self._notify_thread.is_alive()):
            return
        def run() -> None:
            backoff = 2.0
            while not self._notify_stop.is_set():
                try:
                    with requests.get(f"{_LABEL_NOTIFY_BASE}/{topic}/sse", stream=True, timeout=(5.0, 70.0), headers={"Accept": "text/event-stream"}) as r:
                        if not (200 <= r.status_code < 300):
                            raise RuntimeError(f"HTTP {r.status_code}")
                        backoff = 2.0
                        for raw in r.iter_lines(decode_unicode=True):
                            if self._notify_stop.is_set():
                                return
                            line = str(raw or "").strip()
                            if not line.startswith("data:"):
                                continue
                            try:
                                data = json.loads(line[5:].strip())
                            except Exception:
                                data = {}
                            if isinstance(data, dict) and str(data.get("event") or "") == "message":
                                # The notification carries no label text. It merely wakes
                                # the client so the persistent private label server is read.
                                self.remote_hint.set()
                except Exception as e:
                    if time.time() - self.last_remote_error > 30.0:
                        self.last_remote_error = time.time()
                        log(f"LABEL LIVE SYNC notifier unavailable; fallback polling remains active: {e}")
                    self._notify_stop.wait(backoff)
                    backoff = min(30.0, backoff * 1.6)
        self._notify_thread = threading.Thread(target=run, name="Adeon-Label-LiveSync", daemon=True)
        self._notify_thread.start()

    def _publish_change_ping(self) -> None:
        topic = self._notification_topic()
        if not topic:
            return
        def send() -> None:
            try:
                requests.post(
                    f"{_LABEL_NOTIFY_BASE}/{topic}",
                    data=b"changed",
                    headers={"Title": "Adeon label update", "Priority": "min", "Tags": "label"},
                    timeout=3.0,
                )
            except Exception:
                pass
        threading.Thread(target=send, name="Adeon-Label-Ping", daemon=True).start()

    def poll_remote(self, force: bool = False) -> bool:
        if not self.configured():
            return False
        now = time.time()
        hinted = self.remote_hint.is_set()
        if not force and not hinted and now - self.last_remote_poll < _LABEL_REMOTE_FALLBACK_POLL:
            return False
        self.remote_hint.clear()
        self.last_remote_poll = now
        headers = {"Accept": "application/json", "X-Adeon-Device": self.device}
        if self.secret:
            headers["X-Adeon-Secret"] = self.secret
        try:
            params = {"adeon_secret": self.secret, "action": "pull", "since": int(self.state.get("server_rev", 0) or 0)}
            sep = "&" if "?" in self.url else "?"
            url = self.url + sep + urllib.parse.urlencode(params)
            r = requests.get(url, headers=headers, timeout=4.0)
            if not (200 <= r.status_code < 300):
                raise RuntimeError(f"HTTP {r.status_code}")
            data = r.json() if r.content else {}
            if isinstance(data, dict) and data.get("ok") is False:
                raise RuntimeError(str(data.get("error") or "label sync server rejected request"))
            remote_state = data.get("state") if isinstance(data, dict) and isinstance(data.get("state"), dict) else data
            return self.merge_remote(remote_state if isinstance(remote_state, dict) else {})
        except Exception as e:
            if now - self.last_remote_error > 30.0:
                self.last_remote_error = now
                log(f"LABEL SYNC read unavailable: {e}")
            return False

    def push_remote(self, force: bool = False) -> bool:
        if not self.configured():
            return False
        with self.lock:
            events = [dict(e) for e in self.outbox]
        if not events:
            return False
        now = time.time()
        if not force and now - self.last_remote_push < 0.20:
            return False
        self.last_remote_push = now
        headers = {"Content-Type": "application/json", "Accept": "application/json", "X-Adeon-Device": self.device}
        if self.secret:
            headers["X-Adeon-Secret"] = self.secret
        body = {
            "protocol": 2,
            "device": self.device,
            "events": events,
            "state": self.snapshot(),  # legacy server fallback
            "secret": self.secret,
        }
        try:
            r = requests.post(self.url, json=body, headers=headers, timeout=5.0)
            if not (200 <= r.status_code < 300):
                raise RuntimeError(f"HTTP {r.status_code}")
            try:
                data = r.json() if r.content else {}
            except Exception:
                data = {}
            if isinstance(data, dict) and data.get("ok") is False:
                raise RuntimeError(str(data.get("error") or "label sync server rejected request"))

            protocol2 = isinstance(data, dict) and int(data.get("protocol", 0) or 0) >= 2
            if protocol2:
                accepted = {str(x) for x in (data.get("accepted") or [])}
                conflicts = data.get("conflicts") if isinstance(data.get("conflicts"), list) else []
                conflict_ids = {str(c.get("event_id") or "") for c in conflicts if isinstance(c, dict)}
                done = accepted | conflict_ids
                if done:
                    with self.lock:
                        self.outbox = [e for e in self.outbox if str(e.get("event_id") or "") not in done]
                    self._save_outbox()
                for conflict in conflicts:
                    if isinstance(conflict, dict):
                        _append_jsonl(_LABEL_CONFLICT_FILE, {**conflict, "saved_at": time.time(), "device": self.device})
                remote_state = data.get("state") if isinstance(data.get("state"), dict) else {}
                self.merge_remote(remote_state)
            else:
                # Old server compatibility: it accepted the current merged snapshot.
                with self.lock:
                    self.outbox = []
                self._save_outbox()
                remote_state = data.get("state") if isinstance(data, dict) and isinstance(data.get("state"), dict) else {}
                if remote_state:
                    self.merge_remote(remote_state)
            self._publish_change_ping()
            return True
        except Exception as e:
            if now - self.last_remote_error > 30.0:
                self.last_remote_error = now
                log(f"LABEL SYNC write unavailable; edit remains safely queued locally: {e}")
            return False

    def close(self) -> None:
        self._notify_stop.set()
        self._backup_if_due(True)

def save_reservation_state(data: dict) -> None:
    _write_json_atomic(_RESERVATION_STATE_FILE, data or {})


def load_reservation_state() -> dict:
    try:
        if not _RESERVATION_STATE_FILE.exists():
            return {}
        data = json.loads(_RESERVATION_STATE_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def clear_reservation_state() -> None:
    try:
        _RESERVATION_STATE_FILE.unlink(missing_ok=True)
    except Exception:
        pass


def app_stop_requested() -> bool:
    if not _APP_WORKER_MODE:
        return False
    try:
        return _APP_STOP_FILE.exists()
    except Exception:
        return False

def stop_requested_now() -> bool:
    """Fast fail-closed check used immediately before any physical action."""
    return bool(_stop or app_stop_requested())


def start_app_stop_watchdog() -> threading.Thread | None:
    """Watch the app stop flag at 25 ms so Alt+S cannot be missed by a busy loop."""
    if not _APP_WORKER_MODE:
        return None

    def worker() -> None:
        global _stop, _stop_reason
        while not _stop:
            if app_stop_requested():
                if not str(_stop_reason or "").strip() or _stop_reason == "normal shutdown":
                    _stop_reason = "Adeon app / Alt+S stop requested"
                _stop = True
                try:
                    set_status_ticket(bot="STOPPED", page="OFF", job="-", f5="OFF", mouse="OFF")
                except Exception:
                    pass
                log("APP STOP WATCHDOG: stop flag detected. No new F5/click/mouse action may start.")
                break
            time.sleep(0.025)

    t = threading.Thread(target=worker, name="AdeonAppStopWatchdog", daemon=True)
    t.start()
    return t


_log_lock = threading.Lock()
_issue_lock = threading.Lock()
_issues: list[dict] = []
_issue_last: dict[str, float] = {}
_stats: dict[str, int] = {
    "dom_reads": 0, "brain_read_errors": 0, "reconnects": 0,
    "row_clicks": 0, "reserve_clicks": 0, "click_refusals": 0,
    "f5": 0, "reservations_confirmed": 0, "alerts_sent": 0,
    "alert_failures": 0, "loop_errors": 0, "left_find_orders": 0,
    "trusted_native_clicks": 0, "untrusted_clicks": 0, "manual_accepts": 0,
    "manual_rejects": 0, "reject_clicks": 0, "midnight_auto_rejects": 0,
    "soft_pauses": 0, "soft_resumes": 0, "logout_pauses": 0, "logout_stops": 0,
    "alerts_cancelled": 0, "idle_pause_cycles": 0,
    "nav_clicks": 0, "my_orders_visits": 0, "reservation_status_checks": 0,
    "panel_inspection_scrolls": 0, "panel_files_toggles": 0,
    "reservation_state_restores": 0,
}
_last_state: dict[str, object] = {}
_report_written = False
_stop_reason = "normal shutdown"


def record_stat(name: str, amount: int = 1) -> None:
    _stats[name] = int(_stats.get(name, 0)) + amount


def write_last_error(message: str) -> None:
    try:
        _APP_LAST_ERROR_FILE.write_text(str(message or "Unknown Adeon worker error"), encoding="utf-8")
    except Exception:
        pass


def log(msg: str) -> None:
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{stamp}] {msg}"
    # The installed worker is windowless, but direct/debug runs can inherit a
    # legacy Windows console encoding such as cp1252. Never let an emoji or
    # non-ASCII DOM character crash the automation merely because print()
    # cannot encode it. The UTF-8 log files below remain authoritative.
    try:
        if getattr(sys, "stdout", None) is not None:
            try:
                print(line, flush=True)
            except UnicodeEncodeError:
                enc = getattr(sys.stdout, "encoding", None) or "ascii"
                safe = line.encode(enc, errors="replace").decode(enc, errors="replace")
                print(safe, flush=True)
    except Exception:
        pass
    try:
        with _log_lock:
            with _SESSION_LOG.open("a", encoding="utf-8") as fh:
                fh.write(line + "\n")
            with _APP_ACTIVITY_LOG.open("a", encoding="utf-8") as fh:
                fh.write(line + "\n")
    except Exception:
        pass


def note_issue(code: str, message: str, severity: str = "WARN", details: str = "", throttle: float = 5.0) -> None:
    now = time.time()
    with _issue_lock:
        last = _issue_last.get(code, 0.0)
        if throttle and last and now - last < throttle:
            return
        _issue_last[code] = now
        _issues.append({
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "severity": severity, "code": code, "message": message,
            "details": str(details)[:1000],
        })
    log(f"{severity} [{code}] {message}" + (f" | {str(details)[:300]}" if details else ""))


def capture_diagnostic(label: str, min_interval: float = 8.0) -> str:
    """Save a full-screen diagnostic image without interrupting the bot."""
    global _last_diag_shot
    now = time.time()
    if _last_diag_shot and now - _last_diag_shot < min_interval:
        return ""
    _last_diag_shot = now
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(label))[:60] or "diagnostic"
    path = _REPORT_DIR / f"Adeon {SESSION_ID}_{datetime.now().strftime('%H%M%S')}_{safe}.png"
    try:
        pyautogui.screenshot(str(path))
        log(f"Diagnostic screenshot saved: {path}")
        return str(path)
    except Exception as e:
        log(f"Diagnostic screenshot failed: {e}")
        return ""


def update_last_state(snap: dict | None = None, **extra) -> None:
    if snap:
        _last_state.update({
            "url": str(snap.get("url") or "")[:300],
            "page_title": str(snap.get("pageTitle") or "")[:200],
            "rows_seen": len(snap.get("rows") or []),
            "panel_open": bool(snap.get("panelOpen")),
            "reserve_visible": bool(snap.get("reserve")),
            "accept_visible": bool(snap.get("accept")),
            "reject_visible": bool(snap.get("reject")),
            "reserve_disabled": bool(snap.get("reserveDisabled")),
            "accepted_gone": bool(snap.get("acceptedGone")),
            "panel_text_excerpt": str(snap.get("panelText") or "")[:500].replace("\\n", " "),
            "last_good_dom": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        })
    _last_state.update(extra)


def write_shutdown_report(reason: str | None = None) -> str:
    global _report_written
    if _report_written:
        return str(_REPORT_VISIBLE if _REPORT_VISIBLE.exists() else _REPORT_LOCAL)
    _report_written = True
    ended = time.time()
    duration = max(0.0, ended - SESSION_STARTED_AT)
    early_exit = duration < 5.0 and int(_stats.get("dom_reads", 0)) == 0
    status = "REVIEW NEEDED" if (early_exit or any(str(i.get("severity", "")).upper() in ("WARN", "ERROR") for i in _issues)) else "NO ACTIONABLE ANOMALIES RECORDED"
    lines = [
        "LR WRITERS BOT SESSION REPORT", "=" * 30,
        f"Session: {SESSION_ID}",
        f"Started: {datetime.fromtimestamp(SESSION_STARTED_AT).strftime('%Y-%m-%d %H:%M:%S')}",
        f"Ended: {datetime.fromtimestamp(ended).strftime('%Y-%m-%d %H:%M:%S')}",
        f"Duration: {duration / 60:.1f} minutes",
        f"Stop reason: {reason or _stop_reason}", f"Status: {status}", "",
        "CONFIGURATION", f"Minimum preferred earnings: ${MIN_PAY:.2f} (A+ earns when present, otherwise You\'ll earn)",
        f"Fast refresh: {RELOAD_FAST[0]:.1f}-{RELOAD_FAST[1]:.1f}s x {RELOAD_FAST_N}",
        f"Slow refresh: {RELOAD_SLOW[0]:.1f}-{RELOAD_SLOW[1]:.1f}s x {RELOAD_SLOW_N}",
        f"Absolute minimum between any two F5 presses: {F5_HARD_MIN_GAP:.1f}s",
        f"Scheduled F5 range while searching: {min(RELOAD_FAST[0], RELOAD_SLOW[0]):.1f}-{max(RELOAD_FAST[1], RELOAD_SLOW[1]):.1f}s",
        f"Actual minimum spacing between F5 presses: {F5_HARD_MIN_GAP:.1f}s",
        "Reserved F5: held completely until the reservation ends",
        "Allowed physical clicks: order row, Reserve, exact Yes, I\'m here keep-alive confirmation, and DOM-verified inert background idle clicks",
        "Same order row: one successful physical click maximum per session",
        "Accept click: forbidden by code; trusted manual Accept is only observed",
        f"Idle mouse rhythm: active 5 min, then rests randomly {IDLE_REST[0]/60:.0f}-{IDLE_REST[1]/60:.0f} min; job clicks/F5 continue",
        f"Midnight rule: {MIDNIGHT_RULE_START_HOUR:02d}:00-{MIDNIGHT_RULE_END_HOUR:02d}:00 local; if remaining time is under {MIDNIGHT_REJECT_UNDER_MINUTES/60:.0f}h, show Reject cues only after {MIDNIGHT_REJECT_AFTER/60:.0f} min reserved; never auto-Reject",
        "Control: Alt+S toggles the active bot session START/STOP; there is no pause mode",
        "Logout safety: active session stops immediately; no automatic navigation/login/F5/mouse action occurs while stopped",
        "Alerts: full Reserved report, 1-minute reminder, then Critical Alert from 4:00 reserved; 15s cadence until 5:30, then 10s, 7.5s, and 5s escalation until reservation ends", "", "COUNTERS",
    ]
    for key in sorted(_stats): lines.append(f"{key}: {_stats[key]}")
    lines += ["", "LAST KNOWN STATE"]
    if _last_state:
        for key in sorted(_last_state): lines.append(f"{key}: {_last_state[key]}")
    else:
        lines.append("No valid DOM snapshot was recorded.")
    lines += ["", f"ANOMALIES / NOTES ({len(_issues)})"]
    if _issues:
        for i, item in enumerate(_issues, 1):
            lines.append(f"{i}. [{item['time']}] {item['severity']} {item['code']} - {item['message']}")
            if item.get("details"): lines.append(f"   Details: {item['details']}")
    else:
        lines.append("None recorded.")

    if early_exit:
        lines += [
            "",
            "EARLY EXIT DIAGNOSTIC",
            "The worker ended before it completed a single DOM read.",
            "This report is intentionally marked REVIEW NEEDED even if no exception was recorded.",
        ]

    # Make the one report fully self-contained. Users should never need to hunt
    # for a separate .log file just to diagnose a failure.
    try:
        session_text = _SESSION_LOG.read_text(encoding="utf-8", errors="replace").strip()
    except Exception as e:
        session_text = f"(session log could not be read: {e})"
    if not session_text:
        session_text = "(no session log lines were recorded)"

    try:
        activity_lines = _APP_ACTIVITY_LOG.read_text(encoding="utf-8", errors="replace").splitlines()
        activity_tail = "\n".join(activity_lines[-120:]).strip()
    except Exception as e:
        activity_tail = f"(activity log could not be read: {e})"
    if not activity_tail:
        activity_tail = "(no activity log lines were recorded)"

    lines += [
        "", "FULL SESSION LOG (EMBEDDED)", session_text,
        "", "ACTIVITY LOG TAIL (LAST 120 LINES)", activity_tail,
        "", "REPORT / LOG FILE LOCATIONS",
        f"Visible report folder (same folder as Adeon setup): {_VISIBLE_REPORT_DIR}",
        f"Visible report: {_REPORT_VISIBLE}",
        f"Session log: {_SESSION_LOG}",
        f"Activity log: {_APP_ACTIVITY_LOG}",
        "",
        "This report already contains the diagnostic log needed for review.",
    ]
    text = "\n".join(lines) + "\n"
    paths=[]
    try:
        _REPORT_LOCAL.write_text(text, encoding="utf-8"); paths.append(_REPORT_LOCAL)
    except Exception:
        pass
    try:
        _VISIBLE_REPORT_DIR.mkdir(parents=True, exist_ok=True)
        _REPORT_VISIBLE.write_text(text, encoding="utf-8"); paths.append(_REPORT_VISIBLE)
    except Exception as e:
        try:
            with _SESSION_LOG.open("a", encoding="utf-8") as fh:
                fh.write(f"Report copy to setup folder failed: {e}\n")
        except Exception:
            pass
    result=str(paths[-1] if paths else _REPORT_LOCAL)
    try:
        if getattr(sys, "stdout", None) is not None:
            print(f"\nSession report saved: {result}", flush=True)
            print(f"Full session log: {_SESSION_LOG}", flush=True)
    except Exception:
        pass
    return result


def request_stop(reason: str = "") -> None:
    """Stop the active session without overwriting a more specific stop reason."""
    global _stop, _stop_reason
    wanted = str(reason or "").strip()
    if wanted:
        _stop_reason = wanted
    elif not str(_stop_reason or "").strip() or _stop_reason == "normal shutdown":
        _stop_reason = "Ctrl+C / console exit requested"
    _stop = True
    _controller_exit.set()


def hard_stop_logout(reason: str = "LR Writers logout detected") -> None:
    """Terminate this bot session immediately when LR Writers is logged out.

    No automatic navigation/login attempt is made. The active worker ends and the
    controller remains inert at STOPPED so the user can log in manually and press
    Alt+S to start a fresh session.
    """
    global _stop, _stop_reason, _paused, _resume_requested, _resume_source
    if _stop:
        return
    with _pause_lock:
        _paused = False
        _resume_requested = False
        _resume_source = ""
    _stop_reason = reason or "LR Writers logout detected — hard stop"
    _stop = True
    record_stat("logout_stops")
    set_status_ticket(bot="STOPPED", page="LOGGED OUT", job="-", f5="OFF", mouse="OFF")
    log(f"LOGOUT HARD STOP: {_stop_reason}. No automatic login/navigation will be attempted. Log back in manually, then press Alt+S to start a fresh session.")


def soft_pause(reason: str, *, logout: bool = False) -> None:
    """Manual pause only: pause browser input without exiting so Ctrl+A or Alt+A can resume later."""
    global _paused, _pause_reason, _resume_requested
    with _pause_lock:
        if _paused:
            if reason:
                _pause_reason = reason
            return
        _paused = True
        _pause_reason = reason or "manual hotkey pause"
        _resume_requested = False
    record_stat("soft_pauses")
    if logout:
        record_stat("logout_pauses")
    set_status_ticket(bot="PAUSED", page="LOGGED OUT" if logout else "ONLINE", f5="PAUSED", mouse="PAUSED")
    log(f"SOFT PAUSE: {_pause_reason}. No F5, mouse movement, clicks, or new alerts will be started until Ctrl+A or Alt+A resumes on Find Orders.")


def request_pause_toggle(source: str = "Ctrl+A") -> None:
    """Manual hotkey pause/resume. Logout never uses this path; logout hard-stops."""
    global _resume_requested, _resume_source
    if _stop:
        return
    source = str(source or "hotkey")
    with _pause_lock:
        paused = bool(_paused)
        if paused:
            if _resume_requested:
                return
            _resume_requested = True
            _resume_source = source
    if paused:
        log(f"{source} detected while paused. Resume requested; bot will continue only if the controlled tab is back on Find Orders and not logged out.")
    else:
        soft_pause(f"{source} manual pause")


def request_ctrl_a_toggle() -> None:
    request_pause_toggle("Ctrl+A")


# Only a real Adeon app-worker session should generate a session report.
# Launching Adeon Bot.py directly merely redirects to Adeon.exe and must not
# create a misleading zero-action "normal shutdown" report.
if _APP_WORKER_MODE:
    atexit.register(write_shutdown_report)


# ---------------- Windows DPI + Chrome window ----------------
user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32

EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)


class RECT(ctypes.Structure):
    _fields_ = [
        ("left", ctypes.c_long),
        ("top", ctypes.c_long),
        ("right", ctypes.c_long),
        ("bottom", ctypes.c_long),
    ]


class POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


class MSG(ctypes.Structure):
    _fields_ = [
        ("hwnd", wintypes.HWND),
        ("message", wintypes.UINT),
        ("wParam", wintypes.WPARAM),
        ("lParam", wintypes.LPARAM),
        ("time", wintypes.DWORD),
        ("pt", POINT),
        ("lPrivate", wintypes.DWORD),
    ]


# Explicit signatures avoid handle truncation/argument ambiguity on 64-bit Windows.
try:
    user32.WindowFromPoint.argtypes = [POINT]
    user32.WindowFromPoint.restype = wintypes.HWND
    user32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
    user32.GetAncestor.restype = wintypes.HWND
    user32.SetWindowPos.argtypes = [
        wintypes.HWND, wintypes.HWND,
        ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.UINT,
    ]
    user32.SetWindowPos.restype = wintypes.BOOL
    user32.BringWindowToTop.argtypes = [wintypes.HWND]
    user32.BringWindowToTop.restype = wintypes.BOOL
    user32.SetForegroundWindow.argtypes = [wintypes.HWND]
    user32.SetForegroundWindow.restype = wintypes.BOOL
except Exception:
    pass


def dpi_aware() -> None:
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            user32.SetProcessDPIAware()
        except Exception:
            pass


def _cls(hwnd) -> str:
    buf = ctypes.create_unicode_buffer(256)
    user32.GetClassNameW(hwnd, buf, 256)
    return buf.value


def _title(hwnd) -> str:
    n = user32.GetWindowTextLengthW(hwnd)
    buf = ctypes.create_unicode_buffer(n + 1)
    user32.GetWindowTextW(hwnd, buf, n + 1)
    return buf.value


def _visible(hwnd) -> bool:
    return bool(user32.IsWindowVisible(hwnd))


def chrome_debug_pid(port: int | None = None) -> int:
    """Return the Windows PID that owns Adeon's current local Chrome DevTools port."""
    target_port = int(port or _debug_port or 0)
    if target_port <= 0:
        return 0
    needle = f":{target_port}"
    try:
        out = subprocess.run(
            ["netstat", "-ano", "-p", "tcp"],
            capture_output=True, text=True, timeout=3, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
        ).stdout
        for line in out.splitlines():
            up = line.upper()
            if needle not in line or "LISTENING" not in up:
                continue
            parts = line.split()
            if parts and parts[-1].isdigit():
                return int(parts[-1])
    except Exception:
        pass
    return 0


def _window_pid(hwnd: int) -> int:
    try:
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        return int(pid.value)
    except Exception:
        return 0


def find_chrome_main(preferred_title: str = "") -> int:
    """Return the Chrome window owned by Adeon's connected DevTools browser whenever possible."""
    exact_pid: list[int] = []
    likely_pid: list[int] = []
    any_pid: list[int] = []
    exact: list[int] = []
    likely: list[int] = []
    want = (preferred_title or "").strip().lower()
    target_pid = int(_debug_chrome_pid or 0)

    def cb(hwnd, _):
        if not _visible(hwnd) or "Chrome_WidgetWin_1" not in _cls(hwnd):
            return True
        h = int(hwnd)
        title = _title(hwnd).lower()
        same_pid = bool(target_pid and _window_pid(h) == target_pid)
        is_exact = bool(want and want in title)
        is_likely = any(k in title for k in (
            "lrwriters", "lr writers", "find orders", "findorders",
            "myaccount", "livingston", "irlwriters"
        ))
        if same_pid:
            any_pid.append(h)
            if is_exact:
                exact_pid.append(h)
            if is_likely:
                likely_pid.append(h)
        if is_exact:
            exact.append(h)
        if is_likely:
            likely.append(h)
        return True

    user32.EnumWindows(EnumWindowsProc(cb), 0)
    # A PID match is strongest. Title is only the fallback when PID discovery fails.
    return (exact_pid or likely_pid or any_pid or exact or likely or [0])[0]


def find_render(parent: int) -> int:
    found: list[int] = []

    def cb(hwnd, _):
        if _cls(hwnd) == "Chrome_RenderWidgetHostHWND" and _visible(hwnd):
            found.append(int(hwnd))
        return True

    if parent:
        user32.EnumChildWindows(parent, EnumWindowsProc(cb), 0)
    best, area = 0, 0
    for h in found:
        r = RECT()
        user32.GetClientRect(h, ctypes.byref(r))
        a = max(0, r.right - r.left) * max(0, r.bottom - r.top)
        if a > area:
            best, area = h, a
    return best


def render_origin(hwnd: int) -> tuple[int, int]:
    pt = POINT(0, 0)
    user32.ClientToScreen(hwnd, ctypes.byref(pt))
    return int(pt.x), int(pt.y)


def focus_hwnd(hwnd: int) -> None:
    """Bring Chrome forward without changing its size/state or synthesizing Alt keys."""
    if not hwnd:
        return
    attached = []
    try:
        fg = int(user32.GetForegroundWindow() or 0)
        fg_tid = int(user32.GetWindowThreadProcessId(fg, None) or 0)
        target_tid = int(user32.GetWindowThreadProcessId(hwnd, None) or 0)
        my_tid = int(kernel32.GetCurrentThreadId())
        for tid in {fg_tid, target_tid}:
            if tid and tid != my_tid:
                try:
                    if user32.AttachThreadInput(my_tid, tid, True):
                        attached.append(tid)
                except Exception:
                    pass

        # IMPORTANT: SW_RESTORE (9) was restoring a maximized browser immediately
        # before a click. That changed the viewport after the DOM coordinates had
        # already been read and caused the mouse to tap the wrong place.
        if bool(user32.IsIconic(hwnd)):
            user32.ShowWindow(hwnd, 9)  # restore only when genuinely minimized
        else:
            user32.ShowWindow(hwnd, 5)  # SW_SHOW; preserve current size/state

        user32.BringWindowToTop(hwnd)
        user32.SetForegroundWindow(hwnd)
    except Exception:
        try:
            if bool(user32.IsIconic(hwnd)):
                user32.ShowWindow(hwnd, 9)
            else:
                user32.ShowWindow(hwnd, 5)
            user32.BringWindowToTop(hwnd)
            user32.SetForegroundWindow(hwnd)
        except Exception:
            pass
    finally:
        try:
            my_tid = int(kernel32.GetCurrentThreadId())
            for tid in attached:
                user32.AttachThreadInput(my_tid, tid, False)
        except Exception:
            pass


def _root_window_at(x: int, y: int) -> int:
    """Return the top-level window that would receive a physical click at x,y."""
    try:
        pt = POINT(int(x), int(y))
        hit = int(user32.WindowFromPoint(pt) or 0)
        if not hit:
            return 0
        return int(user32.GetAncestor(hit, GA_ROOT) or hit)
    except Exception:
        return 0


def _prepare_chrome_for_physical_click(main: int, x: int, y: int, label: str) -> bool:
    """Temporarily put Chrome above topmost terminals and verify click ownership."""
    if not main:
        return False
    try:
        if bool(user32.IsIconic(main)):
            user32.ShowWindow(main, 9)
        else:
            user32.ShowWindow(main, 5)
        user32.SetWindowPos(
            main, HWND_TOPMOST, 0, 0, 0, 0,
            SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW,
        )
        focus_hwnd(main)
        time.sleep(0.055)
        root = _root_window_at(x, y)
        if root != int(main):
            occ_title = _title(root) if root else "unknown"
            occ_cls = _cls(root) if root else "unknown"
            shot = capture_diagnostic("click_occluded", min_interval=3.0)
            note_issue(
                "CLICK_OCCLUDED",
                "Physical click was blocked because another window still covered the target",
                "ERROR",
                f"label={label} point=({x},{y}) expected_hwnd={main} actual_hwnd={root} "
                f"actual_class={occ_cls} actual_title={occ_title!r} screenshot={shot}",
                throttle=3.0,
            )
            return False
        return True
    except Exception as e:
        note_issue(
            "CLICK_WINDOW_PREP_FAILED",
            "Could not safely expose Chrome for the physical click",
            "ERROR",
            str(e),
            throttle=3.0,
        )
        return False


def _release_chrome_topmost(main: int) -> None:
    if not main:
        return
    try:
        user32.SetWindowPos(
            main, HWND_NOTOPMOST, 0, 0, 0, 0,
            SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW,
        )
    except Exception:
        pass

def install_ctrl_c() -> None:
    global _ctrl_handler_ref
    try:
        signal.signal(signal.SIGINT, request_stop)
    except Exception:
        pass
    if sys.platform == "win32":
        try:
            signal.signal(signal.SIGBREAK, request_stop)
        except Exception:
            pass
        Handler = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_uint)

        def _handler(ctrl):
            request_stop()
            return True

        _ctrl_handler_ref = Handler(_handler)
        kernel32.SetConsoleCtrlHandler(_ctrl_handler_ref, True)


def request_alt_s_toggle() -> None:
    """Alt+S is the only normal bot control: START when stopped, STOP when active."""
    global _stop, _stop_reason, _controller_active
    with _controller_lock:
        active = bool(_controller_active and _controller_worker and _controller_worker.is_alive())
        if active:
            _stop_reason = "Alt+S stop requested"
            _stop = True
            # Show the requested red STOPPED state immediately. The worker then
            # finishes its cleanup/report without performing another web action.
            set_status_ticket(bot="STOPPED", page="OFF", job="-", f5="OFF", mouse="OFF")
            log("ALT+S: STOP requested. Bot web activity is stopping now.")
        else:
            _controller_start_requested.set()
            log("ALT+S: START requested.")


def start_alt_s_monitor() -> threading.Thread:
    """Reserve Alt+S globally so the same key combination toggles START/STOP."""
    HOTKEY_ID = 0x4C54  # LT
    MOD_ALT = 0x0001
    MOD_NOREPEAT = 0x4000
    VK_S = 0x53
    WM_HOTKEY = 0x0312

    def worker() -> None:
        registered = False
        try:
            registered = bool(user32.RegisterHotKey(None, HOTKEY_ID, MOD_ALT | MOD_NOREPEAT, VK_S))
            if not registered:
                log("ERROR: Could not reserve Alt+S globally. Another program may already own that hotkey.")
                return
            msg = MSG()
            while not _controller_exit.is_set():
                result = int(user32.GetMessageW(ctypes.byref(msg), None, 0, 0))
                if result <= 0:
                    break
                if int(msg.message) == WM_HOTKEY and int(msg.wParam) == HOTKEY_ID:
                    request_alt_s_toggle()
        except Exception as e:
            log(f"ERROR: Global Alt+S monitor failed: {e}")
        finally:
            if registered:
                try:
                    user32.UnregisterHotKey(None, HOTKEY_ID)
                except Exception:
                    pass

    t = threading.Thread(target=worker, name="LR-AltS-StartStop", daemon=True)
    t.start()
    return t


# ---------------- brain (DOM) ----------------
SCAN_JS = r"""
() => {
  // Passive click audit only. It never blocks, changes, or creates a click.
  // It lets the log prove whether Chrome received a native/trusted click.
  if (!window.__lrBotClickAuditInstalled) {
    window.__lrBotClickAuditInstalled = true;
    window.__lrBotLastClick = null;
    try {
      const saved = sessionStorage.getItem("__lrBotLastClick");
      if (saved) window.__lrBotLastClick = JSON.parse(saved);
    } catch (_) {}
    document.addEventListener("click", (ev) => {
      try {
        const path = (typeof ev.composedPath === "function") ? ev.composedPath() : [ev.target];
        const clickable = path.find((e) => e && e.nodeType === 1 && e.matches &&
          e.matches('button, a, [role="button"], input[type="button"]'));
        const el = clickable || ev.target;
        const text = String((el && (el.innerText || el.value)) || "").replace(/\s+/g, " ").trim();
        window.__lrBotLastClick = {
          ts: Date.now(),
          trusted: !!ev.isTrusted,
          text: text.slice(0, 120),
          tag: String((el && el.tagName) || ""),
          clientX: Number(ev.clientX || 0),
          clientY: Number(ev.clientY || 0),
          screenX: Number(ev.screenX || 0),
          screenY: Number(ev.screenY || 0)
        };
        try { sessionStorage.setItem("__lrBotLastClick", JSON.stringify(window.__lrBotLastClick)); } catch (_) {}
      } catch (_) {}
    }, true);
  }

  const vp = (el) => {
    if (!el) return null;
    const r = el.getBoundingClientRect();
    if (r.width < 6 || r.height < 6) return null;
    if (r.bottom < 0 || r.top > (window.innerHeight || 0)) return null;
    return {
      vx: r.left + r.width / 2,
      vy: r.top + r.height / 2,
      w: r.width,
      h: r.height,
      top: r.top,
      left: r.left
    };
  };
  const chromeLeft = Math.max(0, (window.outerWidth - window.innerWidth) / 2);
  const chromeTop = Math.max(0, window.outerHeight - window.innerHeight);
  const screenOf = (p) => {
    if (!p) return null;
    return {
      ...p,
      sx: Math.round(window.screenX + chromeLeft + p.left + p.w / 2),
      sy: Math.round(window.screenY + chromeTop + p.top + p.h / 2)
    };
  };
  const exactBtns = (label) => {
    const want = String(label).toLowerCase();
    return [...document.querySelectorAll('button, a, [role="button"], input[type="button"]')].filter((el) => {
      const t = (el.innerText || el.value || "").replace(/\s+/g, " ").trim().toLowerCase();
      return t === want || t === want + " order";
    });
  };
  const rightmost = (els) => {
    const live = els.filter((el) => {
      const r = el.getBoundingClientRect();
      return r.width >= 8 && r.height >= 10 && r.bottom > 20;
    });
    if (!live.length) return null;
    live.sort((a, b) => b.getBoundingClientRect().x - a.getBoundingClientRect().x);
    return live[0];
  };
  const navPos = (label) => {
    const want = String(label).toLowerCase();
    const el = [...document.querySelectorAll("a, button, span")].find((e) => {
      const t = (e.innerText || "").replace(/\s+/g, " ").trim().toLowerCase();
      return t === want;
    });
    return vp(el);
  };
  const moneyValue = (text) => {
    const m = String(text || "").match(/\$\s*([0-9]+(?:\.[0-9]{1,2})?)/);
    return m ? parseFloat(m[1]) : 0;
  };
  const normText = (value) => String(value || '').replace(/\s+/g, ' ').trim().toLowerCase();
  const headerCenterX = (labelText) => {
    const want = normText(labelText);
    const cacheKey = want.includes('a+') ? '__adeonAPlusHeaderX' : '__adeonYouEarnHeaderX';
    const cached = Number(window[cacheKey] || 0);
    if (cached > 0) return cached;
    const candidates = [...document.querySelectorAll('[role="columnheader"], th, .table-row span, .table-row div, .table-header span, .table-header div')];
    const el = candidates.find((node) => normText(node.innerText || node.textContent || '') === want);
    if (!el) return 0;
    const r = el.getBoundingClientRect();
    if (!r || r.width <= 0) return 0;
    const x = r.left + r.width / 2;
    window[cacheKey] = x;
    return x;
  };
  const parseAPlusPay = (row, text) => {
    // Read A+ earns independently first. The final eligibility value prefers A+
    // when LR shows it and falls back to You'll earn only when A+ is absent.
    // First use an explicit semantic label when LR exposes one.
    const labelled = [...row.querySelectorAll('[aria-label], [title], [data-label], [data-title], [headers]')];
    for (const el of labelled) {
      const label = [
        el.getAttribute('aria-label') || '',
        el.getAttribute('title') || '',
        el.getAttribute('data-label') || '',
        el.getAttribute('data-title') || '',
        el.getAttribute('headers') || ''
      ].join(' ').replace(/\s+/g, ' ').trim().toLowerCase();
      if (label.includes('a+ earns') || label.includes('a + earns') || label.includes('a+ level earns') || label.includes('a + level earns')) {
        const v = moneyValue(el.innerText || el.textContent || '');
        if (v > 0) return { value: v, source: 'labelled A+ cell' };
      }
    }

    // Next map money cells to the visible column headers by screen position.
    // This avoids assuming that row.innerText always preserves the table order.
    const aPlusX = headerCenterX('a+ earns') || headerCenterX('a+ level earns');
    const youEarnX = headerCenterX("you'll earn");
    if (aPlusX > 0) {
      const moneyEls = [...row.querySelectorAll('*')].filter((el) => {
        const t = String(el.innerText || el.textContent || '').trim();
        if (!/\$\s*[0-9]/.test(t)) return false;
        // Prefer the deepest visible element containing the amount, not a wrapper
        // that repeats the whole row's text.
        const childHasMoney = [...el.children].some((ch) => /\$\s*[0-9]/.test(String(ch.innerText || ch.textContent || '')));
        if (childHasMoney) return false;
        const r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 0;
      });
      let best = null;
      for (const el of moneyEls) {
        const r = el.getBoundingClientRect();
        const cx = r.left + r.width / 2;
        const dxA = Math.abs(cx - aPlusX);
        const dxY = youEarnX > 0 ? Math.abs(cx - youEarnX) : Number.POSITIVE_INFINITY;
        if (youEarnX > 0 && dxA >= dxY) continue; // never choose the You'll earn column
        const v = moneyValue(el.innerText || el.textContent || '');
        if (!(v > 0)) continue;
        if (!best || dxA < best.dx) best = { value: v, dx: dxA };
      }
      if (best) return { value: best.value, source: 'A+ header position' };
    }

    // Last fallback: only treat the second amount as A+ when the A+ column
    // itself is present. If the A+ column is absent, the caller must use
    // You'll earn instead, even if some unrelated second dollar amount exists.
    const vals = [];
    const re = /\$\s*([0-9]+(?:\.[0-9]{1,2})?)/g;
    let m;
    while ((m = re.exec(text || ''))) vals.push(parseFloat(m[1]));
    if (aPlusX > 0 && vals.length >= 2) return { value: vals[1], source: 'second row amount with A+ column present' };

    // Return 0 here when A+ cannot be identified. The caller will then use the
    // independently parsed You'll earn value as the fallback.
    return { value: 0, source: 'A+ not identified' };
  };
  const parseYouEarnPay = (row, text) => {
    const labelled = [...row.querySelectorAll('[aria-label], [title], [data-label], [data-title], [headers]')];
    for (const el of labelled) {
      const label = [
        el.getAttribute('aria-label') || '', el.getAttribute('title') || '',
        el.getAttribute('data-label') || '', el.getAttribute('data-title') || '',
        el.getAttribute('headers') || ''
      ].join(' ').replace(/\s+/g, ' ').trim().toLowerCase();
      if (label.includes("you'll earn") || label.includes('you will earn')) {
        const v = moneyValue(el.innerText || el.textContent || '');
        if (v > 0) return { value: v, source: "labelled You'll earn cell" };
      }
    }
    const x = headerCenterX("you'll earn");
    if (x > 0) {
      const moneyEls = [...row.querySelectorAll('*')].filter((el) => {
        const t = String(el.innerText || el.textContent || '').trim();
        if (!/\$\s*[0-9]/.test(t)) return false;
        const childHasMoney = [...el.children].some((ch) => /\$\s*[0-9]/.test(String(ch.innerText || ch.textContent || '')));
        if (childHasMoney) return false;
        const r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 0;
      });
      let best = null;
      for (const el of moneyEls) {
        const r = el.getBoundingClientRect();
        const dx = Math.abs((r.left + r.width / 2) - x);
        const v = moneyValue(el.innerText || el.textContent || '');
        if (!(v > 0)) continue;
        if (!best || dx < best.dx) best = { value:v, dx };
      }
      if (best) return { value:best.value, source:"You'll earn header position" };
    }
    const vals = [];
    const re = /\$\s*([0-9]+(?:\.[0-9]{1,2})?)/g;
    let m;
    while ((m = re.exec(text || ''))) vals.push(parseFloat(m[1]));
    if (vals.length >= 1) return { value:vals[0], source:"first row amount fallback" };
    return { value:0, source:"You'll earn not identified" };
  };
  const rows = [];
  document.querySelectorAll(".table-row.row.vertical, .table-row.row").forEach((row) => {
    const text = (row.innerText || "").replace(/\s+/g, " ").trim();
    const rawText = (row.textContent || "").replace(/\s+/g, " ").trim();
    const metaText = [...row.querySelectorAll("[title], [aria-label], time")].map((el) => {
      return [el.getAttribute("title") || "", el.getAttribute("aria-label") || "", el.getAttribute("datetime") || "", el.textContent || ""].join(" ");
    }).join(" ").replace(/\s+/g, " ").trim();
    const deadlineText = [text, rawText, metaText].filter(Boolean).join(" | ").slice(0, 900);
    const low = text.toLowerCase();
    // Tutoring rows can expose their type through an icon/title/ARIA/data attribute
    // instead of visible innerText. Build a structured scan so they are excluded
    // before the physical mouse is ever allowed to click the row.
    const tutorMeta = [
      rawText,
      metaText,
      String((row.querySelector('a[href]') || {}).href || ""),
      String(row.className || ""),
      row.getAttribute("title") || "",
      row.getAttribute("aria-label") || "",
      row.getAttribute("data-type") || "",
      row.getAttribute("data-order-type") || "",
      ...[...row.querySelectorAll('[title],[aria-label],[alt],[data-type],[data-order-type]')].map((el) => [
        el.getAttribute("title") || "",
        el.getAttribute("aria-label") || "",
        el.getAttribute("alt") || "",
        el.getAttribute("data-type") || "",
        el.getAttribute("data-order-type") || ""
      ].join(" "))
    ].join(" ").replace(/\s+/g, " ").toLowerCase();
    const isTutorRow = low.includes("tutoring order") ||
      /(^|[^a-z])tutor(ing)?([^a-z]|$)/.test(low) ||
      tutorMeta.includes("tutoring order") ||
      /(^|[^a-z])tutor(ing)?([^a-z]|$)/.test(tutorMeta);
    if (!text) return;
    if (low.includes("order number") && low.includes("you'll earn")) return;
    if (low.startsWith("order number")) return;
    const link = row.querySelector('a[href*="/order/"]');
    const href = link ? String(link.href || "") : "";
    const id = (href.match(/\/order\/([^/?#]+)/i) || [])[1] || "";
    const orderNo = (text.match(/\b[A-Z]{1,6}\d{6,}-\d+\b/i) || [])[0] || "";
    const p = vp(row);
    if (!p || p.top < 70) return;
    const clickP = {
      ...p,
      vx: p.left + Math.min(Math.max(p.w * 0.28, 80), 240),
      vy: p.top + p.h * 0.55
    };
    const sp = screenOf(clickP);
    const aPlusInfo = parseAPlusPay(row, text);
    const youEarnInfo = parseYouEarnPay(row, text);
    const payInfo = Number(aPlusInfo.value || 0) > 0
      ? { value:Number(aPlusInfo.value || 0), source:String(aPlusInfo.source || 'A+ earns'), kind:'A+ earns' }
      : { value:Number(youEarnInfo.value || 0), source:String(youEarnInfo.source || "You'll earn fallback"), kind:"You'll earn" };
    rows.push({
      id,
      orderNo,
      text: text.slice(0, 180),
      deadlineText,
      pay: Number(payInfo.value || 0),
      paySource: String(payInfo.source || ''),
      payKind: String(payInfo.kind || ''),
      aPlusEarn: Number(aPlusInfo.value || 0),
      aPlusEarnSource: String(aPlusInfo.source || ''),
      youEarn: Number(youEarnInfo.value || 0),
      youEarnSource: String(youEarnInfo.source || ''),
      tutor: isTutorRow,
      vx: sp.vx,
      vy: sp.vy,
      // Keep the original row rectangle as well as the chosen click point.
      // The physical-mouse safety layer needs these fields to prove that
      // the mapped click still lies inside this exact row.
      left: p.left,
      top: p.top,
      w: p.w,
      h: p.h,
      sx: sp.sx,
      sy: sp.sy
    });
  });
  const reserveBtn = rightmost(exactBtns("reserve"));
  const acceptBtn = rightmost(exactBtns("accept"));
  const rejectBtn = rightmost(exactBtns("reject"));
  // Exact keep-alive popup requested by the user. This target exists only when
  // the visible page says "Are you still there?" AND the exact confirmation
  // button says "Yes, I'm here". It is independent from order Accept.
  const stillHerePageText = String(document.body ? document.body.innerText : "").replace(/\s+/g, " ").trim();
  const stillHerePopupVisible = /\bare you still there\b/i.test(stillHerePageText);
  const stillHereCandidates = [...document.querySelectorAll('button, a, [role="button"], input[type="button"]')].filter((el) => {
    const t = String(el.innerText || el.value || el.textContent || "")
      .replace(/[\u2018\u2019]/g, "'").replace(/\s+/g, " ").trim().toLowerCase();
    const r = el.getBoundingClientRect();
    const disabled = !!(el.disabled || el.getAttribute("disabled") != null || el.getAttribute("aria-disabled") === "true");
    return !disabled && r.width >= 8 && r.height >= 10 && r.bottom > 20 && (t === "yes, i'm here" || t === "yes i'm here");
  });
  const stillHereBtn = stillHerePopupVisible ? rightmost(stillHereCandidates) : null;
  const reserveDisabled = !!(
    reserveBtn && (reserveBtn.disabled || reserveBtn.getAttribute("disabled") != null)
  );
  const root = reserveBtn || acceptBtn || rejectBtn;

  // Pick the RICHEST order-detail ancestor, not merely the closest element whose
  // class happens to contain the word "order". The old selector could sometimes
  // land on the tiny Reserve/Accept button strip, producing panelText such as
  // "ReserveAccept" and losing the task title/summary/description.
  let panel = null;
  if (root) {
    const candidates = [];
    const addPanelCandidate = (el) => {
      if (!el || el === document.body || el === document.documentElement) return;
      if (!candidates.includes(el)) candidates.push(el);
    };
    for (const sel of [
      '.order-tab-container', '.order-tab', '.drawer', '.modal',
      '.order-detail-body', 'aside', '[role="dialog"]'
    ]) {
      try { addPanelCandidate(root.closest(sel)); } catch (e) {}
    }
    let anc = root.parentElement;
    for (let i = 0; anc && i < 10; i++, anc = anc.parentElement) addPanelCandidate(anc);

    const panelScore = (el) => {
      try {
        const inner = String(el.innerText || '');
        const deep = String(el.textContent || '');
        const text = inner.length >= 40 ? inner : deep;
        const low = text.toLowerCase();
        let score = Math.min(Math.max(inner.length, deep.length), 30000);
        try {
          if (el.matches('.order-tab-container, .order-tab, .drawer, .modal, .order-detail-body, [role=\"dialog\"]')) score += 35000;
          else if (el.matches('aside')) score += 15000;
        } catch (e) {}
        if (text.length > 18000) score -= Math.min(18000, text.length - 18000);
        if (/\b[A-Z]{1,6}\d{6,}-\d+\b/i.test(text)) score += 7000;
        if (low.includes('task summary')) score += 18000;
        if (low.includes('full order description')) score += 18000;
        if (low.includes('final ddl')) score += 9000;
        if (low.includes('order info')) score += 3500;
        if (low.includes('formatting style')) score += 2000;
        if (low.includes('sources')) score += 1500;
        if (low.includes('reserve')) score += 500;
        if (text.replace(/\s+/g,'').toLowerCase() === 'reserveaccept' || text.length < 60) score -= 25000;
        return score;
      } catch (e) { return -100000; }
    };
    candidates.sort((a,b) => panelScore(b) - panelScore(a));
    panel = candidates.length ? candidates[0] : root.parentElement;
  }

  const panelInnerText = panel ? String(panel.innerText || '') : '';
  const panelDeepText = panel ? String(panel.textContent || '') : '';
  // innerText preserves the same human-readable line structure the old
  // Tampermonkey parser consumed. textContent is returned separately as a fallback
  // for content mounted in the drawer but not currently visible in its viewport.
  const panelText = panelInnerText || panelDeepText;

  // Reserved-panel inspection helpers. These expose only geometry/state; Python
  // performs the visible wheel/click actions and revalidates before each action.
  let panelScroll = null;
  let filesToggle = null;
  if (panel) {
    const candidates = [panel, ...panel.querySelectorAll("div, section, aside")];
    // LR's order drawer does not always declare overflow:auto even though the
    // element is actually scrollable. Choose by real scroll geometry first,
    // then use CSS overflow only as a bonus. This makes the visible wheel move
    // the actual order-content container instead of a non-scrolling wrapper.
    const scrollables = candidates.map((el) => {
      try {
        const r = el.getBoundingClientRect();
        const cs = getComputedStyle(el);
        const delta = Number(el.scrollHeight || 0) - Number(el.clientHeight || 0);
        const overflowY = String(cs.overflowY || "");
        const scrollbarWidth = Math.max(0, Number(el.offsetWidth || 0) - Number(el.clientWidth || 0));
        // Fail closed. If LR is not painting a real vertical scrollbar, Adeon must
        // not move the mouse at all during the reserved-minute inspection.
        if (!(r.width > 120 && r.height > 100 && r.bottom > 70 && r.top < window.innerHeight &&
              delta > 20 && /(auto|scroll)/i.test(overflowY) && scrollbarWidth >= 6)) return null;
        return { el, score: 5000 + scrollbarWidth * 200 + delta * 4 + Math.min(r.height, 900), scrollbarWidth, overflowY };
      } catch (e) { return null; }
    }).filter(Boolean);
    scrollables.sort((a,b) => b.score - a.score);
    const scrollInfo = scrollables.length ? scrollables[0] : null;
    if (scrollInfo) {
      const scrollEl = scrollInfo.el;
      try {
        const r = scrollEl.getBoundingClientRect();
        if (r.width > 80 && r.height > 80) {
          panelScroll = {
            vx: Math.max(r.left + 20, r.right - Math.max(3, scrollInfo.scrollbarWidth / 2)),
            vy: Math.max(r.top + 30, Math.min(r.bottom - 30, r.top + r.height * 0.52)),
            left:r.left, top:r.top, w:r.width, h:r.height,
            scrollTop:Number(scrollEl.scrollTop || 0),
            scrollHeight:Number(scrollEl.scrollHeight || 0),
            clientHeight:Number(scrollEl.clientHeight || 0),
            scrollbarWidth:Number(scrollInfo.scrollbarWidth || 0),
            overflowY:String(scrollInfo.overflowY || "")
          };
        }
      } catch (e) {}
    }

    const toggleCandidates = [...panel.querySelectorAll('button, [role="button"], [aria-expanded]')].filter((el) => {
      try {
        if (el.closest('a[href]')) return false;
        const r = el.getBoundingClientRect();
        if (r.width < 20 || r.height < 12 || r.bottom < 70 || r.top > window.innerHeight) return false;
        const t = (el.innerText || el.textContent || '').replace(/\s+/g,' ').trim().toLowerCase();
        return t === 'files' || t === 'order files' || t === 'additional materials' ||
               t.startsWith('order files ') || t.startsWith('files ');
      } catch (e) { return false; }
    });
    if (toggleCandidates.length) {
      const el = toggleCandidates[0];
      const p = vp(el);
      if (p) {
        filesToggle = screenOf({ ...p, text:(el.innerText || el.textContent || '').replace(/\s+/g,' ').trim().slice(0,80), expanded:el.getAttribute('aria-expanded') });
      }
    }
  }

  const bodyText = String(document.body ? document.body.innerText : "");
  const url = location.href;

  // Rich detail fallback for the reservation notification.  The LR drawer can
  // visually contain Task summary / Full order description even when the button
  // strip is the closest ancestor of Reserve.  Keep a text window around those
  // human-readable labels, using both innerText and textContent, so Python can
  // parse the exact same words the older Tampermonkey script saw.
  const bodyDeepText = panel ? String(document.body ? document.body.textContent || '' : '') : '';
  const detailWindow = (source) => {
    source = String(source || '');
    if (!source) return '';
    const low = source.toLowerCase();
    const anchors = ['task summary', 'full order description', 'final ddl', 'order info']
      .map((x) => low.indexOf(x)).filter((x) => x >= 0);
    if (!anchors.length) return '';
    const a = Math.min(...anchors);
    return source.slice(Math.max(0, a - 6000), Math.min(source.length, a + 24000));
  };
  const detailAnchorText = detailWindow(bodyText);
  const detailDeepAnchorText = detailWindow(bodyDeepText);

  // Detect the right-side order drawer even on My Orders pages where there is no
  // exact Reserve/Accept/Reject button for the older panel detector to anchor to.
  // Local label editors must disappear while this drawer is open so they never
  // float above LR Writers' own order details panel.
  const detectSideOrderPanel = () => {
    try {
      const clues = ['order info', 'task summary', 'full order description', 'final ddl', 'more order details', 'upload final'];
      const seen = new Set();
      const nodes = [];
      const add = (el) => {
        if (!el || el === document.body || el === document.documentElement || seen.has(el)) return;
        seen.add(el);
        nodes.push(el);
      };

      // The drawer always occupies the right edge. Sampling the actual painted
      // elements there is more reliable than depending on one LR Writers class name.
      const x = Math.max(1, window.innerWidth - 8);
      for (const frac of [0.20, 0.38, 0.56, 0.74]) {
        const y = Math.max(1, Math.min(window.innerHeight - 2, window.innerHeight * frac));
        const stack = document.elementsFromPoint ? document.elementsFromPoint(x, y) : [];
        for (const start of stack) {
          let cur = start;
          for (let i=0; cur && i<10; i++, cur=cur.parentElement) add(cur);
        }
      }

      const selectors = [
        '.order-tab-container', '.order-tab', '.drawer', '[class*=\"drawer\"]',
        '[class*=\"order-detail\"]', '[class*=\"order-tab\"]', 'aside', '[role=\"dialog\"]'
      ].join(',');
      document.querySelectorAll(selectors).forEach(add);

      for (const el of nodes) {
        const r = el.getBoundingClientRect();
        if (!(r.width >= 250 && r.width <= window.innerWidth * 0.62)) continue;
        if (!(r.height >= Math.min(300, window.innerHeight * 0.42))) continue;
        if (!(r.right >= window.innerWidth - 24 && r.left >= window.innerWidth * 0.34)) continue;
        const cs = getComputedStyle(el);
        if (!cs || cs.display === 'none' || cs.visibility === 'hidden' || Number(cs.opacity || 1) <= 0.02) continue;
        const text = String(el.innerText || el.textContent || '').replace(/\s+/g, ' ').toLowerCase();
        let hits = 0;
        for (const clue of clues) if (text.includes(clue)) hits++;
        if (hits >= 2) return true;
      }
    } catch (_) {}
    return false;
  };
  const sideOrderPanelOpen = !!panel || detectSideOrderPanel();

  // LABEL: My Orders annotations. Nothing is submitted into LR Writers forms.
  // The browser keeps a fast local copy; the Adeon labels worker mirrors it to a
  // persistent data file and, when configured, the independent label-sync server.
  // Rows are discovered by visible order number rather than one fragile CSS class.
  const myOrdersHeaders = /\byour price\b/i.test(bodyText) && /\bpayout date\b/i.test(bodyText);
  const onMyOrders = /\/myorders(?:[\/#?]|$)/i.test(url) || myOrdersHeaders;
  const ADEON_ORDER_RE = /\b[A-Z]{1,6}\d{6,}-\d+\b/i;

  const findMyOrderRows = () => {
    const found = new Map();
    const add = (el) => {
      if (!el || !el.getBoundingClientRect) return;
      const r = el.getBoundingClientRect();
      if (!r || r.width < 420 || r.height < 18 || r.height > 110) return;
      const txt = String(el.innerText || el.textContent || '').replace(/\s+/g,' ').trim();
      const m = txt.match(ADEON_ORDER_RE);
      if (!m) return;
      const key = String(m[0]).toUpperCase();
      const prev = found.get(key);
      // Prefer the smallest row-like container that still spans the table width.
      if (!prev || r.height < prev.getBoundingClientRect().height) found.set(key, el);
    };

    // Normal LR table structures first.
    document.querySelectorAll('.table-row.row.vertical, .table-row.row, [role="row"], tr, [class*="table-row"]').forEach(add);
    document.querySelectorAll('a[href*="/order/"]').forEach((a) => {
      let cur = a;
      for (let i=0; cur && i<8; i++, cur=cur.parentElement) {
        const r = cur && cur.getBoundingClientRect ? cur.getBoundingClientRect() : null;
        if (r && r.width >= 420 && r.height >= 18 && r.height <= 110) { add(cur); break; }
      }
    });

    // My Orders has used more than one row class over time. If the direct selectors
    // found nothing (or missed a row), locate the visible order-number text itself and
    // walk upward to the first table-width ancestor. This is local DOM reading only.
    try {
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      let node;
      let guard = 0;
      while ((node = walker.nextNode()) && guard++ < 12000) {
        const raw = String(node.nodeValue || '').trim();
        if (!ADEON_ORDER_RE.test(raw)) continue;
        let cur = node.parentElement;
        for (let i=0; cur && cur !== document.body && i<10; i++, cur=cur.parentElement) {
          const r = cur.getBoundingClientRect();
          if (r.width >= 420 && r.height >= 18 && r.height <= 110) { add(cur); break; }
        }
      }
    } catch (_) {}
    return found;
  };

  const ensureAdeonLabels = () => {
    let layer = document.getElementById('__adeonLabelLayer');
    if (!onMyOrders) {
      if (layer) layer.remove();
      return 0;
    }
    if (!layer) {
      layer = document.createElement('div');
      layer.id = '__adeonLabelLayer';
      layer.style.cssText = 'position:fixed;inset:0;z-index:2147483000;pointer-events:none;font-family:Arial,sans-serif;';
      document.documentElement.appendChild(layer);
    }

    let store = {};
    let storeTimes = {};
    try { store = JSON.parse(localStorage.getItem('__adeonMyOrderLabelsV1') || '{}') || {}; } catch (_) { store = {}; }
    try { storeTimes = JSON.parse(localStorage.getItem('__adeonMyOrderLabelTimesV1') || '{}') || {}; } catch (_) { storeTimes = {}; }
    const live = new Set();
    const rowsByOrder = findMyOrderRows();
    const finalPaperX = Number(headerCenterX('final paper') || 0);

    const greenDotRight = (row) => {
      try {
        const rr = row.getBoundingClientRect();
        let best = 0;
        const nodes = [row, ...row.querySelectorAll('svg,span,i,div,path,circle')];
        const isGreen = (value) => {
          const m = String(value || '').match(/rgba?\((\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i);
          if (!m) return false;
          const r=Number(m[1]), g=Number(m[2]), b=Number(m[3]);
          return g >= 95 && g > r * 1.18 && g > b * 1.08;
        };
        for (const el of nodes) {
          if (!el || !el.getBoundingClientRect) continue;
          const r = el.getBoundingClientRect();
          if (r.width < 6 || r.height < 6 || r.width > 28 || r.height > 28) continue;
          if (r.top < rr.top - 2 || r.bottom > rr.bottom + 2) continue;
          if (r.left < Math.max(rr.left + rr.width * 0.72, finalPaperX - 30)) continue;
          const cs = getComputedStyle(el);
          const attrs = [
            cs.color, cs.backgroundColor, cs.borderColor, cs.fill, cs.stroke, cs.boxShadow,
            el.getAttribute && el.getAttribute('fill'), el.getAttribute && el.getAttribute('stroke')
          ];
          const semantic = String((el.className && (el.className.baseVal || el.className)) || '') + ' ' +
                           String(el.getAttribute && (el.getAttribute('aria-label') || el.getAttribute('title') || ''));
          const looksLikeSuccess = /(?:success|check|complete|completed|final)/i.test(semantic);
          if (!attrs.some(isGreen) && !looksLikeSuccess) continue;
          best = Math.max(best, r.right);
        }
        return best;
      } catch (_) { return 0; }
    };

    for (const [key, row] of rowsByOrder.entries()) {
      live.add(key);
      const rr = row.getBoundingClientRect();
      const id = '__adeonLabel_' + key.replace(/[^A-Z0-9]/g,'_');
      let item = document.getElementById(id);
      if (!item) {
        item = document.createElement('div');
        item.id = id;
        item.dataset.order = key;
        item.title = 'ADEON LOCAL LABEL • ' + key;
        item.style.cssText = 'position:fixed;display:flex;align-items:center;height:22px;pointer-events:auto;white-space:nowrap;overflow:hidden;';

        const inp = document.createElement('input');
        inp.type = 'text';
        inp.autocomplete = 'off';
        inp.spellcheck = false;
        inp.maxLength = 40;
        inp.placeholder = '';
        inp.setAttribute('aria-label', 'Local label for ' + key);
        inp.style.cssText = 'height:20px;width:56px;min-width:0;max-width:56px;border:1px solid #cbd5e1;border-radius:3px;outline:none;background:rgba(255,255,255,.98);padding:1px 3px;color:#111827;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0;box-sizing:border-box;overflow:hidden;';
        inp.value = String(store[key] || '').toUpperCase();

        inp.addEventListener('focus', () => { inp.style.borderColor = '#64748b'; });
        inp.addEventListener('blur', () => { inp.style.borderColor = '#cbd5e1'; });
        inp.addEventListener('input', () => {
          const start = inp.selectionStart;
          const upper = String(inp.value || '').toUpperCase();
          if (inp.value !== upper) inp.value = upper;
          try {
            const m = JSON.parse(localStorage.getItem('__adeonMyOrderLabelsV1') || '{}') || {};
            const t = JSON.parse(localStorage.getItem('__adeonMyOrderLabelTimesV1') || '{}') || {};
            if (upper) m[key] = upper; else delete m[key];
            t[key] = Date.now() / 1000;
            localStorage.setItem('__adeonMyOrderLabelsV1', JSON.stringify(m));
            localStorage.setItem('__adeonMyOrderLabelTimesV1', JSON.stringify(t));
            store = m;
            storeTimes = t;
          } catch (_) {}
          try { if (start != null) inp.setSelectionRange(start, start); } catch (_) {}
        });
        item.appendChild(inp);
        layer.appendChild(item);
      }

      // Keep the editor inside the visible LR Writers row. It never grows with text.
      // When the Final-paper green status dot is present, start strictly after
      // its painted right edge so the typing bar never covers the dot.
      const rightEdge = Math.min(window.innerWidth - 5, rr.right - 5);
      const dotRight = greenDotRight(row);
      // If the exact green indicator was found, the input starts 6px after its
      // painted right edge. The fallback is deliberately farther right than the
      // Final-paper column center so even an SVG check whose fill is inherited
      // from a parent cannot be covered.
      let left = dotRight > 0 ? dotRight + 6 : (finalPaperX > 0 ? finalPaperX + 20 : rightEdge - 56);
      if (left < rr.left + 4) left = rr.left + 4;
      let width = Math.min(56, Math.floor(rightEdge - left));
      if (dotRight <= 0 && width < 26) {
        // Only the no-dot fallback is allowed to slide left for a usable box.
        // When a real green dot was found, NEVER move the box back over it.
        width = Math.min(56, Math.max(26, Math.floor(rr.width * 0.045)));
        left = Math.max(rr.left + 4, rightEdge - width);
      }
      if (dotRight > 0) {
        left = Math.max(left, dotRight + 6);
        width = Math.max(0, Math.min(56, Math.floor(rightEdge - left)));
      }
      item.style.left = Math.round(left) + 'px';
      item.style.width = Math.max(1, Math.round(width)) + 'px';
      item.style.top = Math.round(rr.top + rr.height / 2 - 10) + 'px';
      item.style.display = (!sideOrderPanelOpen && rr.bottom > 65 && rr.top < window.innerHeight && rr.height > 10 && width >= 10) ? 'flex' : 'none';

      // Clean up the old illustration dot if a pre-1.0.19 label node survived in-page.
      [...item.children].forEach((child) => { if (child.tagName !== 'INPUT') child.remove(); });
      const inp = item.querySelector('input');
      if (inp) {
        inp.style.width = Math.max(1, Math.round(width)) + 'px';
        inp.style.maxWidth = Math.max(1, Math.round(width)) + 'px';
        if (document.activeElement !== inp) {
          const saved = String(store[key] || '').toUpperCase();
          if (inp.value !== saved) inp.value = saved;
        }
      }
    }

    [...layer.children].forEach((item) => {
      if (!live.has(String(item.dataset.order || '').toUpperCase())) item.remove();
    });
    try { window.__adeonLabelExport = { labels:store, times:storeTimes }; } catch (_) {}
    return live.size;
  };
  const labelCount = ensureAdeonLabels();
  let labelStore = {labels:{}, times:{}};
  try { labelStore = window.__adeonLabelExport || labelStore; } catch (_) {}
  let urlId = "";
  const mAll = url.match(/\/findorders\/all\/([^/?#]+)/i);
  const mOrd = url.match(/\/order\/([^/?#]+)/i);
  if (mAll && mAll[1] && mAll[1].toLowerCase() !== "all") urlId = mAll[1];
  else if (mOrd) urlId = mOrd[1];
  const acceptedGone = /upload final file|already accepted|you accepted|successfully accepted/i.test(
    bodyText + " " + panelText
  );
  const hasPasswordInput = !!document.querySelector('input[type="password"]');
  const loginUrl = /\/(?:login|log-in|signin|sign-in|auth)(?:[\/?#]|$)/i.test(url);
  const loginWords = /\b(?:log\s*in|sign\s*in)\b/i.test(bodyText);
  const loggedOut = !!(loginUrl || (hasPasswordInput && loginWords));

  // Safe idle points. These are deliberately NOT arbitrary page points.
  // Sample across the visible webpage and keep only coordinates whose
  // DOM target is non-interactive, outside order rows, and outside the
  // currently open order panel.
  const idleMovePoints = [];
  const idleClickPoints = [];
  const interactiveSel = [
    "a", "button", "input", "textarea", "select", "option",
    "[role='button']", "[role='link']", "[onclick]", "[contenteditable='true']",
    ".table-row.row", ".table-row.row.vertical"
  ].join(",");
  const pointSafe = (x, y) => {
    const el = document.elementFromPoint(x, y);
    if (!el) return null;
    if (el.closest && el.closest(interactiveSel)) return null;
    if (panel && panel.contains(el)) return null;
    const cs = getComputedStyle(el);
    if (!cs || cs.pointerEvents === "none" || cs.visibility === "hidden") return null;
    return el;
  };
  const clickTagOK = (el) => {
    if (!el) return false;
    const tag = String(el.tagName || "").toLowerCase();
    if (!["body", "main", "section", "div", "article"].includes(tag)) return false;
    const cs = getComputedStyle(el);
    if (cs && (cs.cursor === "pointer" || cs.cursor === "text")) return false;
    return true;
  };
  const xs = [0.10, 0.24, 0.38, 0.52, 0.66, 0.80, 0.92];
  const ys = [0.16, 0.28, 0.40, 0.52, 0.64, 0.76, 0.88];
  for (const xf of xs) {
    for (const yf of ys) {
      const x = Math.round(window.innerWidth * xf);
      const y = Math.round(window.innerHeight * yf);
      if (y < 120) continue;
      const el = pointSafe(x, y);
      if (!el) continue;
      idleMovePoints.push({vx:x, vy:y, tag:String(el.tagName || ""), cls:String(el.className || "").slice(0,80)});
      if (clickTagOK(el)) {
        idleClickPoints.push({vx:x, vy:y, tag:String(el.tagName || ""), cls:String(el.className || "").slice(0,80)});
      }
    }
  }

  return {
    url,
    urlId,
    pageTitle: document.title || "",
    innerW: window.innerWidth,
    innerH: window.innerHeight,
    rows,
    reserve: reserveDisabled ? null : screenOf(vp(reserveBtn)),
    accept: screenOf(vp(acceptBtn)),
    reject: screenOf(vp(rejectBtn)),
    stillHere: screenOf(vp(stillHereBtn)),
    reserveDisabled,
    panelOpen: !!(reserveBtn || acceptBtn || rejectBtn),
    panelText: panelText.slice(0, 30000),
    panelDeepText: panelDeepText.slice(0, 30000),
    panelScroll,
    filesToggle,
    acceptedGone,
    loggedOut,
    bodyText: bodyText.slice(0, 30000),
    bodyTextExcerpt: bodyText.slice(0, 1000),
    detailAnchorText: detailAnchorText.slice(0, 30000),
    detailDeepAnchorText: detailDeepAnchorText.slice(0, 30000),
    onMyOrders,
    labelCount,
    labelStore,
    sideOrderPanelOpen,
    lastClick: window.__lrBotLastClick || null,
    navFind: navPos("find orders"),
    navMy: navPos("my orders"),
    navInbox: navPos("inbox"),
    navProgress: navPos("my progress"),
    onFind: /\/findorders\//i.test(url),
    onInbox: /\/inbox(?:[\/#?]|$)/i.test(url) || /\binbox\b/i.test(document.title || ""),
    onProgress: /\/(?:myprogress|progress)(?:[\/#?]|$)/i.test(url) || /\bmy progress\b/i.test(document.title || ""),
    idleMovePoints,
    idleClickPoints
  };
}
"""


def chrome_user_data_dirs() -> list[Path]:
    """Likely DevTools user-data roots, with Adeon's managed Chrome first."""
    local = Path(os.environ.get("LOCALAPPDATA", ""))
    candidates = [
        _ADEON_CHROME_DATA,
        local / "Google" / "Chrome" / "User Data",
        local / "Google" / "Chrome Beta" / "User Data",
        local / "Google" / "Chrome Dev" / "User Data",
        local / "Google" / "Chrome SxS" / "User Data",
    ]
    out: list[Path] = []
    seen: set[str] = set()
    for item in candidates:
        key = os.path.normcase(os.path.abspath(str(item)))
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    return out


def _endpoint_http_live(port: int) -> bool:
    if int(port or 0) <= 0:
        return False
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{int(port)}/json/version", timeout=1.5) as r:
            return 200 <= int(getattr(r, "status", 200)) < 500
    except Exception:
        return False


def discover_chrome_debug_endpoint() -> tuple[str, int, str]:
    """Find a live local Chrome DevTools endpoint without navigating the browser."""
    global _debug_port, _debug_endpoint, _debug_user_data_dir

    for user_dir in chrome_user_data_dirs():
        active = user_dir / "DevToolsActivePort"
        try:
            if not active.is_file():
                continue
            lines = [x.strip() for x in active.read_text(encoding="utf-8", errors="ignore").splitlines() if x.strip()]
            if len(lines) < 2:
                continue
            port = int(lines[0])
            path = lines[1]
            if not (1 <= port <= 65535) or not path.startswith("/"):
                continue
            if not _endpoint_http_live(port):
                continue
            endpoint = f"ws://127.0.0.1:{port}{path}"
            _debug_port = port
            _debug_endpoint = endpoint
            _debug_user_data_dir = str(user_dir)
            return endpoint, port, str(user_dir)
        except Exception:
            continue

    # Compatibility fallback for a manually configured Chrome.
    if _endpoint_http_live(9222):
        try:
            with urllib.request.urlopen("http://127.0.0.1:9222/json/version", timeout=1.5) as r:
                info = json.loads(r.read().decode("utf-8", "ignore") or "{}")
            endpoint = str(info.get("webSocketDebuggerUrl") or "http://127.0.0.1:9222")
        except Exception:
            endpoint = "http://127.0.0.1:9222"
        _debug_port = 9222
        _debug_endpoint = endpoint
        _debug_user_data_dir = "manual-9222"
        return endpoint, 9222, "manual-9222"

    _debug_port = 0
    _debug_endpoint = ""
    _debug_user_data_dir = ""
    return "", 0, ""


def _legacy_chrome_port_live() -> bool:
    endpoint, port, _ = discover_chrome_debug_endpoint()
    return bool(endpoint and port)


def find_chrome_exe() -> str:
    for path in (
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
    ):
        if os.path.isfile(path):
            return path
    return ""


def _chrome_browser_commandline() -> str:
    """Best-effort command line for Chrome's browser process (not renderer children)."""
    try:
        ps = (
            "$p=Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'chrome.exe' -and "
            "$_.CommandLine -and $_.CommandLine -notmatch '--type=' } | Select-Object -First 1; "
            "if($p){[Console]::Write($p.CommandLine)}"
        )
        cp = subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, timeout=4,
            creationflags=0x08000000,
        )
        return (cp.stdout or "").strip()
    except Exception:
        return ""


def _extract_switch(commandline: str, name: str) -> str:
    text = str(commandline or "")
    # Supports --name=value, --name="value with spaces", and --name value.
    patterns = [
        rf'--{re.escape(name)}=(?:"([^"]+)"|([^\s]+))',
        rf'--{re.escape(name)}\s+(?:"([^"]+)"|([^\s]+))',
    ]
    for pattern in patterns:
        m = re.search(pattern, text, re.I)
        if m:
            return next((g for g in m.groups() if g), "")
    return ""


def _active_chrome_root_and_profile() -> tuple[Path | None, str]:
    """Return the user-data root/profile of the Chrome browser process that is open now."""
    cmd = _chrome_browser_commandline()
    user_arg = _extract_switch(cmd, "user-data-dir")
    profile_arg = _extract_switch(cmd, "profile-directory")
    local = Path(os.environ.get("LOCALAPPDATA", ""))
    root = Path(os.path.expandvars(user_arg)).expanduser() if user_arg else (local / "Google" / "Chrome" / "User Data")
    if not root.exists():
        return None, profile_arg.strip() or "Default"
    profile = profile_arg.strip() if profile_arg else ""
    if not profile:
        try:
            state = json.loads((root / "Local State").read_text(encoding="utf-8", errors="ignore"))
            profile = str(((state.get("profile") or {}).get("last_used")) or "Default").strip()
        except Exception:
            profile = "Default"
    if not profile or not (root / profile).exists():
        profile = "Default" if (root / "Default").exists() else (profile or "Default")
    return root, profile


def _normal_chrome_root_and_profile() -> tuple[Path | None, str]:
    """Locate the Chrome profile the user was using before Adeon restarts Chrome."""
    cmd = _chrome_browser_commandline()
    user_arg = _extract_switch(cmd, "user-data-dir")
    profile_arg = _extract_switch(cmd, "profile-directory")

    candidates: list[Path] = []
    if user_arg:
        candidates.append(Path(os.path.expandvars(user_arg)).expanduser())
    local = Path(os.environ.get("LOCALAPPDATA", ""))
    candidates.extend([
        local / "Google" / "Chrome" / "User Data",
        local / "Google" / "Chrome Beta" / "User Data",
        local / "Google" / "Chrome Dev" / "User Data",
        local / "Google" / "Chrome SxS" / "User Data",
    ])

    root = next((x for x in candidates if x.exists() and x.resolve() != _ADEON_CHROME_DATA.resolve()), None)
    if root is None:
        return None, "Default"

    profile = profile_arg.strip() if profile_arg else ""
    if not profile:
        try:
            state = json.loads((root / "Local State").read_text(encoding="utf-8", errors="ignore"))
            profile = str(((state.get("profile") or {}).get("last_used")) or "Default").strip()
        except Exception:
            profile = "Default"
    if not profile or not (root / profile).exists():
        profile = "Default" if (root / "Default").exists() else profile
    return root, profile or "Default"


def _chrome_running() -> bool:
    try:
        cp = subprocess.run(
            ["tasklist", "/FI", "IMAGENAME eq chrome.exe", "/FO", "CSV", "/NH"],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, timeout=3,
            creationflags=0x08000000,
        )
        out = (cp.stdout or "").lower()
        return "chrome.exe" in out
    except Exception:
        return False


def _close_chrome_windows_gracefully() -> None:
    """Ask visible Chrome windows to close so session/cookies are flushed before cloning."""
    try:
        WM_CLOSE = 0x0010
        EnumProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)

        def callback(hwnd, _lparam):
            try:
                cls = ctypes.create_unicode_buffer(256)
                user32.GetClassNameW(hwnd, cls, len(cls))
                if cls.value == "Chrome_WidgetWin_1" and user32.IsWindowVisible(hwnd):
                    user32.PostMessageW(hwnd, WM_CLOSE, 0, 0)
            except Exception:
                pass
            return True

        user32.EnumWindows(EnumProc(callback), 0)
    except Exception as e:
        log(f"Could not send Chrome a graceful close request: {e}")


def _wait_chrome_closed(timeout: float) -> bool:
    deadline = time.time() + max(0.5, timeout)
    while time.time() < deadline:
        if not _chrome_running():
            return True
        time.sleep(0.35)
    return not _chrome_running()


def _copy_profile_tree(source_root: Path, profile_name: str) -> bool:
    """Fast one-time bootstrap of login/session data into Adeon's CDP profile.

    The older build copied almost the whole Chrome profile and could spend minutes
    on cache, extensions, history, and other data Adeon does not need.  For the
    LR Writers hand-off we only copy the pieces that can carry the current profile
    identity, cookies/site storage and session state.  The user's original Chrome
    profile is never modified.
    """
    source_profile = source_root / profile_name
    if not source_profile.exists():
        log(f"Chrome profile bootstrap source is missing: {source_profile}")
        return False

    try:
        if _ADEON_CHROME_MARKER.exists() and (_ADEON_CHROME_DATA / profile_name).exists():
            log(f"Adeon Chrome profile already prepared ({profile_name}); preserving its current login/session.")
            return True
    except Exception:
        pass

    try:
        set_status_ticket(bot="STARTING", page="PREPARING CHROME", job="-", f5="OFF", mouse="OFF")
        started = time.time()
        log(f"Preparing fast Adeon Chrome profile from {source_profile}")
        _ADEON_CHROME_DATA.mkdir(parents=True, exist_ok=True)
        target_profile = _ADEON_CHROME_DATA / profile_name
        target_profile.mkdir(parents=True, exist_ok=True)

        # Chrome's encryption/profile metadata.  On the same Windows account this
        # lets the copied Cookies database remain usable when Chrome permits it.
        local_state = source_root / "Local State"
        if local_state.exists():
            try:
                shutil.copy2(local_state, _ADEON_CHROME_DATA / "Local State")
            except Exception as e:
                log(f"Fast profile copy skipped Local State while Chrome is live: {e}")

        # Small profile files that can matter for identity/login/site behavior.
        files = (
            "Preferences", "Secure Preferences", "Cookies", "Cookies-journal",
            "Login Data", "Login Data-journal", "Login Data For Account",
            "Web Data", "Web Data-journal", "Shortcuts", "Top Sites",
        )
        for name in files:
            src = source_profile / name
            dst = target_profile / name
            try:
                if src.is_file():
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(src, dst)
            except Exception as e:
                log(f"Fast profile copy skipped {name}: {e}")

        # Site/session storage.  These are normally far smaller than a full Chrome
        # profile and are the parts most likely to matter to an already logged-in
        # LR Writers session.
        dirs = (
            "Network", "Local Storage", "Session Storage", "Sessions", "WebStorage",
        )
        ignore = shutil.ignore_patterns(
            "Cache", "Code Cache", "GPUCache", "DawnCache", "GrShaderCache", "ShaderCache",
            "Crashpad", "BrowserMetrics", "Media Cache", "LOCK", "lockfile", "Singleton*", "*.tmp"
        )
        for name in dirs:
            src = source_profile / name
            dst = target_profile / name
            try:
                if src.is_dir():
                    shutil.copytree(src, dst, dirs_exist_ok=True, ignore=ignore)
            except Exception as e:
                log(f"Fast profile copy skipped {name}: {e}")

        # Copy only LR Writers-specific IndexedDB entries when present instead of
        # cloning every site's database. This keeps first activation fast.
        idx_src = source_profile / "IndexedDB"
        idx_dst = target_profile / "IndexedDB"
        try:
            if idx_src.is_dir():
                for child in idx_src.iterdir():
                    low = child.name.lower()
                    if "lrwriters" not in low and "liv-research" not in low:
                        continue
                    if child.is_dir():
                        shutil.copytree(child, idx_dst / child.name, dirs_exist_ok=True, ignore=ignore)
                    elif child.is_file():
                        idx_dst.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(child, idx_dst / child.name)
        except Exception as e:
            log(f"Fast profile copy skipped LR Writers IndexedDB: {e}")

        _write_json_atomic(_ADEON_CHROME_MARKER, {
            "source_root": str(source_root),
            "profile": profile_name,
            "prepared_at": time.time(),
            "mode": "fast-login-session-copy-v3-localappdata",
        })
        elapsed = time.time() - started
        log(f"Adeon Chrome profile prepared successfully in {elapsed:.1f}s: {target_profile}")
        return True
    except Exception as e:
        write_last_error("Adeon could not prepare the Chrome profile. See VIEW ACTIVITY LOG.")
        log(f"Chrome profile bootstrap failed: {e}")
        note_issue("CHROME_PROFILE_COPY", "Could not prepare Chrome profile for DevTools restart", "ERROR", str(e), throttle=0)
        return False


def _sync_latest_tabs_into_adeon(source_root: Path | None, source_profile_name: str, target_profile_name: str) -> None:
    """Copy only Chrome's just-flushed tab/session files into Adeon's managed profile.

    This is used when Adeon must restart a normal Chrome window for DevTools. It
    preserves the user's currently open work without replacing the rest of the
    already-prepared Adeon profile.
    """
    if source_root is None:
        return
    try:
        if source_root.resolve() == _ADEON_CHROME_DATA.resolve():
            return
    except Exception:
        pass
    source_profile = source_root / (source_profile_name or "Default")
    target_profile = _ADEON_CHROME_DATA / (target_profile_name or "Default")
    if not source_profile.exists() or not target_profile.exists():
        return
    try:
        src_sessions = source_profile / "Sessions"
        dst_sessions = target_profile / "Sessions"
        if src_sessions.is_dir():
            shutil.rmtree(dst_sessions, ignore_errors=True)
            shutil.copytree(src_sessions, dst_sessions, dirs_exist_ok=True)
        # Older Chrome builds/profile layouts can still expose these legacy files.
        for name in ("Current Session", "Current Tabs", "Last Session", "Last Tabs"):
            src = source_profile / name
            dst = target_profile / name
            if src.is_file():
                shutil.copy2(src, dst)
        log(f"Chrome tab/session state copied into Adeon profile from {source_profile}.")
    except Exception as e:
        log(f"Chrome tab/session sync skipped: {e}")


def _prepared_profile_name(default: str = "Default") -> str:
    try:
        data = json.loads(_ADEON_CHROME_MARKER.read_text(encoding="utf-8"))
        name = str(data.get("profile") or "").strip()
        if name and (_ADEON_CHROME_DATA / name).exists():
            return name
    except Exception:
        pass
    return default or "Default"


def _bridge_http_json(method: str, path: str, payload: dict | None = None, timeout: float = 0.8) -> dict:
    try:
        data = None
        headers = {"Cache-Control": "no-store"}
        if payload is not None:
            data = json.dumps(payload, separators=(",", ":")).encode("utf-8")
            headers["Content-Type"] = "application/json"
        req = urllib.request.Request(
            _BROWSER_BRIDGE_BASE + str(path),
            data=data,
            headers=headers,
            method=str(method or "GET").upper(),
        )
        with urllib.request.urlopen(req, timeout=max(0.15, float(timeout))) as r:
            raw = r.read(8 * 1024 * 1024)
        obj = json.loads(raw.decode("utf-8", "replace") or "{}")
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def _bridge_tabs(max_age: float = 1.5) -> list[dict]:
    obj = _bridge_http_json("GET", "/v1/tabs", timeout=0.45)
    now = float(obj.get("now") or time.time())
    tabs = []
    for rec in obj.get("tabs") or []:
        if not isinstance(rec, dict):
            continue
        age = now - float(rec.get("received_at") or 0.0)
        url = str(rec.get("url") or "").lower()
        if age <= max(0.25, float(max_age)) and "myaccount.lrwriters.com" in url:
            tabs.append(rec)
    return tabs


def _bridge_any_live(max_age: float = 3.0) -> bool:
    return bool(_bridge_tabs(max_age=max_age))


def _bridge_pick_record(mode: str, preferred_tab: int = 0) -> dict | None:
    """Choose an LR Writers tab from Chrome or Thorium without creating one.

    Stay with the already selected tab while it is useful, but allow a newly
    opened/activated target page to take over. This matters when Picker is armed
    on My Orders and the user later reaches Find Orders in another existing tab,
    or when Labels is waiting and My Orders is opened separately.
    """
    tabs = _bridge_tabs(max_age=1.5)
    if not tabs:
        return None

    mode = "labels" if str(mode).lower() == "labels" else "picker"

    def desired(rec: dict) -> bool:
        snap = rec.get("snap") if isinstance(rec.get("snap"), dict) else {}
        return bool(snap.get("onMyOrders")) if mode == "labels" else bool(snap.get("onFind"))

    preferred_tab = int(preferred_tab or 0)
    preferred = next((r for r in tabs if int(r.get("tabId") or 0) == preferred_tab), None) if preferred_tab else None
    if preferred is not None and desired(preferred):
        return preferred

    active_target = [r for r in tabs if bool(r.get("active")) and desired(r)]
    if active_target:
        return max(active_target, key=lambda r: float(r.get("received_at") or 0.0))

    if preferred is not None and bool(preferred.get("active")):
        return preferred

    def score(rec: dict) -> tuple:
        # A correct existing page is more useful than a wrong active LR page.
        # If there is no correct page yet, the active LR tab becomes the waiting tab.
        return (
            1 if desired(rec) else 0,
            1 if bool(rec.get("active")) else 0,
            float(rec.get("received_at") or 0.0),
        )
    return max(tabs, key=score)


def _bridge_write_command(tab_id: int, command_type: str, *, wait: bool = False, timeout: float = 0.8, **kwargs):
    tab_id = int(tab_id or 0)
    if tab_id <= 0:
        return None
    rid = uuid.uuid4().hex if wait else ""
    payload = {"tabId": tab_id, "type": str(command_type or ""), "id": rid}
    payload.update(kwargs)
    ack = _bridge_http_json("POST", "/v1/command", payload, timeout=0.45)
    if not ack.get("ok"):
        return None
    if not wait:
        return True
    deadline = time.time() + max(0.15, float(timeout))
    while time.time() < deadline and not _stop:
        obj = _bridge_http_json("GET", "/v1/result?id=" + urllib.parse.quote(rid), timeout=0.35)
        if obj.get("ready"):
            item = obj.get("item") if isinstance(obj.get("item"), dict) else {}
            envelope = item.get("value")
            if isinstance(envelope, dict) and "ok" in envelope:
                if not bool(envelope.get("ok")):
                    return None
                return envelope.get("result")
            return envelope
        time.sleep(0.025)
    return None


def _bridge_wait_for(tab_id: int, predicate, timeout: float = 8.0) -> dict | None:
    deadline = time.time() + max(0.1, float(timeout))
    tab_id = int(tab_id or 0)
    while time.time() < deadline and not _stop:
        rec = _bridge_pick_record("picker", tab_id)
        if rec and int(rec.get("tabId") or 0) == tab_id:
            snap = rec.get("snap") if isinstance(rec.get("snap"), dict) else {}
            try:
                if predicate(snap, rec):
                    return rec
            except Exception:
                pass
        time.sleep(0.05)
    return None


def chrome_port_live() -> bool:
    # Compatibility name retained for existing health checks. Current Adeon uses the
    # Chrome/Thorium extension bridge instead of a DevTools port.
    return _bridge_any_live(max_age=3.0)


def start_chrome(start_url: str = FIND_ORDERS, force_restart: bool = False) -> bool:
    """Hard safety lock: Adeon never launches/restarts Chrome or Thorium."""
    write_last_error(
        "Adeon will not open a browser. Open LR Writers in your existing Chrome or Thorium and Adeon will attach there."
    )
    note_issue(
        "CHROME_LAUNCH_BLOCKED",
        "A request to launch a browser was blocked by the existing-browser safety lock",
        "ERROR",
        throttle=0,
    )
    log("EXISTING BROWSER SAFETY: browser launch/restart request blocked.")
    return False


class Brain:
    """DOM bridge for an LR Writers tab already open in Chrome or Thorium."""
    def __init__(self) -> None:
        self._tab_id = 0
        self._window_id = 0
        self._last_record: dict = {}
        self._label_reload_pending = False
        self._labels_enabled = False
        # Hidden read-only reservation verifier only. This never opens a visible
        # Chrome window/profile and is not used for picker/labels interaction.
        self._pw = None
        self._probe_browser = None
        self._probe_context = None
        self._probe_page = None

    def _select(self) -> dict | None:
        mode = "labels" if _LABELS_ONLY_MODE else "picker"
        rec = _bridge_pick_record(mode, self._tab_id)
        if rec:
            self._tab_id = int(rec.get("tabId") or self._tab_id or 0)
            self._window_id = int(rec.get("windowId") or self._window_id or 0)
            self._last_record = rec
        return rec

    def attach(self) -> bool:
        # The app normally starts the worker only after a live LR Writers snapshot
        # exists. Keep a short defensive wait in case the page is reloading exactly
        # as the worker starts. Never launch Chrome, Thorium, a window, or a tab.
        deadline = time.time() + 15.0
        rec = None
        while time.time() < deadline and not _stop:
            rec = self._select()
            if rec:
                break
            time.sleep(0.10)
        if not rec:
            write_last_error(
                "Adeon is waiting for LR Writers in your existing Chrome or Thorium. "
                "No browser window or tab was opened."
            )
            set_status_ticket(
                bot="STOPPED", page="WAITING LR WRITERS",
                job=("LABEL" if _LABELS_ONLY_MODE else "SEARCHING"), f5="OFF", mouse="OFF"
            )
            log("EXISTING BROWSER: no live LR Writers snapshot. Browser-launch fallback is disabled.")
            return False

        snap = rec.get("snap") if isinstance(rec.get("snap"), dict) else {}
        if not _LABELS_ONLY_MODE:
            # Picker does not hijack whatever LR page the user is currently on.
            # If Find Orders is not there yet, stay armed and wait until the user
            # reaches it in this browser. A newly active Find Orders tab can take
            # over through _bridge_pick_record().
            waiting_logged = False
            while not _stop:
                rec = self._select()
                if rec:
                    snap = rec.get("snap") if isinstance(rec.get("snap"), dict) else {}
                    if bool(snap.get("onFind")):
                        break
                if not waiting_logged:
                    waiting_logged = True
                    log("PICKER: attached to existing Chrome/Thorium LR Writers session; waiting for the user to reach Find Orders. No navigation/window/tab was created.")
                set_status_ticket(bot="CONNECTING", page="WAITING FIND ORDERS", job="SEARCHING", f5="OFF", mouse="OFF")
                # Let a different newly-active target tab become the preferred tab.
                if rec is not None and not bool((rec.get("snap") or {}).get("onFind")):
                    self._tab_id = 0
                time.sleep(0.12)
            if _stop:
                return False

            # Find Orders is now present. Refresh this exact existing tab once so
            # the picker begins from a clean, current LR DOM without opening anything.
            before = float(rec.get("received_at") or 0.0)
            _bridge_write_command(self._tab_id, "reload_tab")
            rec2 = _bridge_wait_for(
                self._tab_id,
                lambda sp, rr: bool(sp.get("onFind")) and float(rr.get("received_at") or 0.0) > before + 0.05,
                timeout=10.0,
            )
            if rec2:
                self._last_record = rec2
            log("PICKER: refreshed the same existing Find Orders tab once. No Chrome/Thorium window or tab opened.")

        log(f"EXISTING BROWSER: attached to LR Writers tab {self._tab_id} in Chrome/Thorium; no browser window/profile/tab was launched.")
        return True

    def prepare_labels_tab(self, *, reload_current: bool = True) -> bool:
        rec = self._select()
        if not rec or self._tab_id <= 0:
            return False
        snap = rec.get("snap") if isinstance(rec.get("snap"), dict) else {}
        enabled = _bridge_write_command(
            self._tab_id, "set_labels_enabled", wait=True, timeout=0.9, enabled=True
        )
        self._labels_enabled = bool(enabled)
        if not self._labels_enabled:
            return False
        if bool(snap.get("onMyOrders")):
            if reload_current:
                before = float(rec.get("received_at") or 0.0)
                _bridge_write_command(self._tab_id, "reload_tab")
                _bridge_wait_for(
                    self._tab_id,
                    lambda sp, rr: bool(sp.get("onMyOrders")) and float(rr.get("received_at") or 0.0) > before + 0.05,
                    timeout=8.0,
                )
                log("LABELS: refreshed the same existing My Orders tab once. No Chrome/Thorium window/tab opened.")
            self._label_reload_pending = False
        else:
            # Do not steal the current tab. Labels remain enabled at origin level and
            # the first arrival at My Orders gets exactly one same-tab refresh.
            self._label_reload_pending = bool(reload_current)
            log("LABELS: enabled in existing Chrome/Thorium; waiting for My Orders. That same tab will refresh once when reached.")
        return True

    def apply_label_state(self, state: dict | None) -> bool:
        rec = self._select()
        if not rec or self._tab_id <= 0:
            return False
        clean = _clean_label_state(state)
        result = _bridge_write_command(
            self._tab_id, "apply_labels", wait=True, timeout=0.9, state=clean
        )
        self._labels_enabled = bool(result)
        return bool(result)

    def reconnect_cdp(self) -> bool:
        # Compatibility name only. Recovery now reconnects to the normal-Chrome
        # bridge in place and never restarts Chrome.
        rec = self._select()
        if rec:
            log("NORMAL CHROME: browser bridge recovered in place; Chrome was not restarted.")
            return True
        return False

    def _chrome_cookies(self) -> list[dict]:
        rec = self._select()
        if not rec or self._tab_id <= 0:
            return []
        value = _bridge_write_command(self._tab_id, "get_cookies", wait=True, timeout=1.4)
        return value if isinstance(value, list) else []


    def _ensure_probe_page(self) -> bool:
        # Current Adeon never launches a second/headless browser process.
        return False

    def _close_probe(self) -> None:
        self._probe_page = None
        self._probe_context = None
        self._probe_browser = None
        self._pw = None

    def fresh_reservation_probe(self, public_id: str, internal_id: str = "") -> dict:
        """Fresh same-session check through the extension, with no second Chrome.

        The browser integration performs credentialed background fetches from the
        already-running normal Chrome profile. It never launches headless Chrome,
        opens a tab, or changes the visible page.
        """
        public_id = str(public_id or "").strip().upper()
        internal_id = str(internal_id or "").strip()
        if not public_id:
            return {"status": "unknown", "reason": "no public order id"}
        rec = self._select()
        if not rec or self._tab_id <= 0:
            return {"status": "unknown", "reason": "browser integration unavailable"}

        def fetch_text(url: str) -> dict:
            value = _bridge_write_command(
                self._tab_id, "fetch_text", wait=True, timeout=3.2,
                url=str(url or ""), max_chars=350000
            )
            return value if isinstance(value, dict) else {}

        try:
            if internal_id:
                exact = fetch_text(f"https://myaccount.lrwriters.com/order/{internal_id}")
                text = str(exact.get("text") or "")
                low = re.sub(r"\s+", " ", text).lower()
                final_url = str(exact.get("url") or "").lower()
                if exact.get("ok") and text:
                    if "login" in final_url and "myaccount.lrwriters.com" in final_url:
                        return {"status": "unknown", "reason": "session redirected to login"}
                    if any(x in low for x in (
                        "upload final files", "upload final", "already accepted",
                        "successfully accepted", "order has been accepted",
                    )):
                        return {"status": "ended", "source": "normal-Chrome background fetch exact order"}
                    # Treat an explicit visible Reject/Cancel reservation control as
                    # evidence the exact order is still held. We intentionally avoid
                    # interpreting generic bundled JavaScript strings.
                    bodyish = re.sub(r"<script\b[^>]*>.*?</script>", " ", text, flags=re.I | re.S)
                    bodyish = re.sub(r"<style\b[^>]*>.*?</style>", " ", bodyish, flags=re.I | re.S)
                    bodyish = re.sub(r"<[^>]+>", " ", bodyish)
                    bodyish = re.sub(r"\s+", " ", bodyish).lower()
                    if public_id.lower() in bodyish and re.search(r"\breject(?: order)?\b", bodyish):
                        return {"status": "held", "source": "normal-Chrome background fetch exact order"}

            listing = fetch_text(FIND_ORDERS)
            text = str(listing.get("text") or "")
            if listing.get("ok") and text:
                bodyish = re.sub(r"<script\b[^>]*>.*?</script>", " ", text, flags=re.I | re.S)
                bodyish = re.sub(r"<style\b[^>]*>.*?</style>", " ", bodyish, flags=re.I | re.S)
                bodyish = re.sub(r"<[^>]+>", " ", bodyish)
                bodyish = re.sub(r"\s+", " ", bodyish)
                low = bodyish.lower()
                pid = public_id.lower()
                if pid in low:
                    around_i = low.find(pid)
                    around = low[max(0, around_i - 300): around_i + 900]
                    if "reserved" in around:
                        return {"status": "held", "source": "normal-Chrome background fetch Find Orders"}
                    # The row exists but no longer shows reserved. This is strong
                    # enough to end the stale local reservation.
                    return {"status": "ended", "source": "normal-Chrome background fetch row no longer reserved"}
                # Absence is kept as a softer signal and still requires the existing
                # two-check rule in the caller before clearing the reservation.
                return {"status": "absent", "source": "normal-Chrome background fetch order absent"}
            return {"status": "unknown", "reason": "background fetch unavailable"}
        except Exception as e:
            note_issue("REMOTE_RESERVATION_PROBE_FAILED", "Fresh reservation verifier failed", "WARN", str(e), throttle=30.0)
            return {"status": "unknown", "reason": str(e)[:160]}

    def maximize(self) -> None:
        # Keep the user's normal Chrome size/state. Only restore it if it is minimized.
        try:
            rec = self._select() or {}
            snap = rec.get("snap") if isinstance(rec.get("snap"), dict) else {}
            title = str(snap.get("pageTitle") or rec.get("title") or "")
            main = find_chrome_main(title)
            if main and bool(user32.IsIconic(main)):
                user32.ShowWindow(main, 9)
        except Exception:
            pass

    def reconnect(self) -> None:
        self._select()

    def read(self) -> dict:
        rec = self._select()
        if not rec:
            record_stat("brain_read_errors")
            return {}
        snap = dict(rec.get("snap") or {})
        snap.setdefault("url", str(rec.get("url") or ""))
        snap.setdefault("pageTitle", str(rec.get("title") or ""))
        snap["bridgeTabId"] = int(rec.get("tabId") or 0)
        snap["bridgeWindowId"] = int(rec.get("windowId") or 0)
        snap["bridgeReceivedAt"] = float(rec.get("received_at") or 0.0)
        record_stat("dom_reads")

        if _LABELS_ONLY_MODE and bool(snap.get("onMyOrders")) and self._label_reload_pending:
            self._label_reload_pending = False
            _bridge_write_command(self._tab_id, "reload_tab")
            log("LABELS: My Orders reached; queued the one requested same-tab reload.")
        return snap

    def stay_on_find_orders(self) -> None:
        return

    def activate(self) -> str:
        rec = self._select()
        if not rec or self._tab_id <= 0:
            return ""
        _bridge_write_command(self._tab_id, "focus")
        title = str((rec.get("snap") or {}).get("pageTitle") or rec.get("title") or "")
        try:
            main = find_chrome_main(title)
            if main:
                focus_hwnd(main)
        except Exception:
            pass
        return title

    def validate_click(self, pos: dict | None, kind: str) -> bool:
        if not pos:
            return False
        rec = self._select()
        if not rec or self._tab_id <= 0:
            return False
        result = _bridge_write_command(
            self._tab_id, "validate_click", wait=True, timeout=0.75,
            pos=pos, kind=str(kind or "")
        )
        return bool(result)

    def remove_labels(self) -> None:
        if not _LABELS_ONLY_MODE:
            return
        rec = self._select()
        if rec and self._tab_id > 0:
            _bridge_write_command(self._tab_id, "remove_labels", wait=False)
        self._labels_enabled = False

    def close(self) -> None:
        try:
            self.remove_labels()
        except Exception:
            pass
        self._close_probe()


# ---------------- motor ----------------
_enum_keep = []


def chrome_handles(preferred_title: str = "") -> tuple[int, int]:
    try:
        main = find_chrome_main(preferred_title)
        rend = find_render(main) if main else 0
        return main, rend
    except Exception:
        return 0, 0


def _screen_rect(hwnd: int) -> tuple[int, int, int, int] | None:
    """Return a window rectangle in physical screen pixels."""
    if not hwnd:
        return None
    try:
        r = RECT()
        if not user32.GetWindowRect(hwnd, ctypes.byref(r)):
            return None
        left, top, right, bottom = int(r.left), int(r.top), int(r.right), int(r.bottom)
        if right <= left or bottom <= top:
            return None
        return left, top, right, bottom
    except Exception:
        return None


def _viewport_mapping(
    inner_w: float, inner_h: float, preferred_title: str = ""
) -> dict | None:
    """
    Map Chrome CSS viewport pixels to physical Windows screen pixels.

    DOM getBoundingClientRect() returns CSS pixels. Windows mouse APIs use
    physical screen pixels. Browser zoom, Windows DPI scaling, and a resized
    window mean those units are not always 1:1.
    """
    try:
        iw, ih = float(inner_w or 0), float(inner_h or 0)
        if iw < 100 or ih < 100:
            return None
        main, rend = chrome_handles(preferred_title)
        if not main or not rend:
            return None
        rr = _screen_rect(rend)
        mr = _screen_rect(main)
        if not rr or not mr:
            return None

        left, top, right, bottom = rr
        rw, rh = float(right - left), float(bottom - top)
        scale_x, scale_y = rw / iw, rh / ih

        # Broad valid range so unusual DPI/zoom settings still work, while
        # rejecting a clearly wrong render widget.
        if not (0.35 <= scale_x <= 3.5 and 0.35 <= scale_y <= 3.5):
            note_issue(
                "BAD_VIEWPORT_SCALE",
                "Physical/CSS viewport scale is not plausible, so mouse mapping was refused",
                "ERROR",
                f"css={iw:.0f}x{ih:.0f} render={rw:.0f}x{rh:.0f} scale={scale_x:.3f},{scale_y:.3f}",
                throttle=5.0,
            )
            return None

        # X and Y can differ slightly because of scrollbars, but a large
        # mismatch usually means we selected the wrong renderer.
        mismatch = abs(scale_x - scale_y) / max(scale_x, scale_y)
        if mismatch > 0.18:
            note_issue(
                "VIEWPORT_SCALE_MISMATCH",
                "Horizontal and vertical viewport scales disagree too much; click mapping was refused",
                "ERROR",
                f"scale_x={scale_x:.3f} scale_y={scale_y:.3f} render={rr} main={mr}",
                throttle=5.0,
            )
            return None

        return {
            "main": int(main),
            "render": int(rend),
            "left": left,
            "top": top,
            "right": right,
            "bottom": bottom,
            "scale_x": scale_x,
            "scale_y": scale_y,
            "inner_w": iw,
            "inner_h": ih,
            "render_rect": rr,
            "main_rect": mr,
        }
    except Exception as e:
        note_issue(
            "VIEWPORT_MAPPING_ERROR",
            "Could not calculate CSS-to-screen mouse mapping",
            "ERROR",
            str(e),
            throttle=5.0,
        )
        return None


def viewport_to_screen(
    vx: float,
    vy: float,
    preferred_title: str = "",
    inner_w: float = 0,
    inner_h: float = 0,
) -> tuple[int, int] | None:
    """Convert a DOM viewport point to a real Windows mouse coordinate."""
    m = _viewport_mapping(inner_w, inner_h, preferred_title)
    if not m:
        return None
    try:
        x = int(round(m["left"] + float(vx) * m["scale_x"]))
        y = int(round(m["top"] + float(vy) * m["scale_y"]))
        # A valid DOM point must map inside the actual renderer.
        if not (m["left"] <= x < m["right"] and m["top"] <= y < m["bottom"]):
            note_issue(
                "MAPPED_POINT_OUTSIDE_RENDER",
                "DOM point mapped outside Chrome's visible page area, so the click was refused",
                "ERROR",
                f"dom=({vx:.1f},{vy:.1f}) screen=({x},{y}) render={m['render_rect']}",
                throttle=3.0,
            )
            return None
        return x, y
    except Exception:
        return None


def _mapped_dom_rect(
    el: dict | None, snap: dict, preferred_title: str = ""
) -> tuple[int, int, int, int] | None:
    """Map a DOM element rectangle to physical screen pixels."""
    if not el:
        return None
    try:
        m = _viewport_mapping(
            float(snap.get("innerW") or 0),
            float(snap.get("innerH") or 0),
            preferred_title,
        )
        if not m:
            return None
        left = float(el.get("left"))
        top = float(el.get("top"))
        width = float(el.get("w") or 0)
        height = float(el.get("h") or 0)
        if width <= 0 or height <= 0:
            return None
        x1 = int(round(m["left"] + left * m["scale_x"]))
        y1 = int(round(m["top"] + top * m["scale_y"]))
        x2 = int(round(m["left"] + (left + width) * m["scale_x"]))
        y2 = int(round(m["top"] + (top + height) * m["scale_y"]))
        return x1, y1, x2, y2
    except Exception:
        return None


def forbidden(x: int, y: int, kind: str, inner_w: float, inner_h: float) -> bool:
    w, h = pyautogui.size()
    if x < 2 or y < 2 or x > w - 2 or y > h - 2:
        return True
    if kind in ("reserve", "midnight_reject"):
        return y < 180
    if kind in ("row", "idle", "files_toggle"):
        return y < 100
    if kind in ("nav_my", "nav_find", "nav_inbox", "nav_progress", "still_here"):
        return y < 35
    return True


def _near_dom_button(
    x: int,
    y: int,
    btn: dict | None,
    snap: dict,
    preferred_title: str,
    margin: int = 12,
) -> bool:
    rect = _mapped_dom_rect(btn, snap, preferred_title)
    if not rect:
        return False
    x1, y1, x2, y2 = rect
    return (x1 - margin) <= x <= (x2 + margin) and (y1 - margin) <= y <= (y2 + margin)



def motor_click(pos: dict | None, label: str, kind: str, snap: dict, brain: Brain) -> bool:
    """Physically click only freshly verified LR Writers action or navigation targets."""
    global _last_click
    if stop_requested_now():
        return False
    if kind not in ("row", "reserve", "midnight_reject", "nav_my", "nav_find", "nav_inbox", "nav_progress", "files_toggle", "still_here"):
        record_stat("click_refusals")
        note_issue(
            "BLOCKED_CLICK_TYPE",
            "Blocked a forbidden click type",
            "ERROR",
            f"label={label} kind={kind}",
            throttle=0,
        )
        return False
    if not pos:
        record_stat("click_refusals")
        note_issue("NO_CLICK_COORDS", "Target had no usable coordinates", "WARN", label)
        return False

    # Bringing Chrome forward must never resize it. Then take a NEW DOM snapshot
    # so the physical mapping uses the viewport that exists at click time.
    title = brain.activate() or str(snap.get("pageTitle") or "")
    fresh = brain.read()
    if stop_requested_now():
        return False
    if not fresh:
        record_stat("click_refusals")
        note_issue("CLICK_FRESH_READ_FAILED", "Could not refresh DOM state immediately before click", "WARN", label)
        return False

    current = None
    if kind == "reserve":
        current = fresh.get("reserve")
    elif kind == "midnight_reject":
        current = fresh.get("reject")
    elif kind == "nav_my":
        current = fresh.get("navMy")
    elif kind == "nav_find":
        current = fresh.get("navFind")
    elif kind == "nav_inbox":
        current = fresh.get("navInbox")
    elif kind == "nav_progress":
        current = fresh.get("navProgress")
    elif kind == "files_toggle":
        current = fresh.get("filesToggle")
    elif kind == "still_here":
        current = fresh.get("stillHere")
    else:
        want_order = str(pos.get("orderNo") or "").strip().upper()
        want_id = str(pos.get("id") or "")
        want_text = str(pos.get("text") or "")
        for row in fresh.get("rows") or []:
            row_order = str(row.get("orderNo") or "").strip().upper()
            rid = str(row.get("id") or "")
            text = str(row.get("text") or "")
            if want_order and row_order == want_order:
                current = row
                break
            if want_id and rid == want_id:
                current = row
                break
            if not want_order and not want_id and want_text and text[:50] == want_text[:50]:
                current = row
                break

    if not current:
        record_stat("click_refusals")
        note_issue("STALE_TARGET", "Target disappeared or moved before click, so the click was blocked", "WARN", label)
        return False

    pos = current
    snap = fresh
    title = str(snap.get("pageTitle") or title)

    if not brain.validate_click(pos, kind):
        record_stat("click_refusals")
        note_issue("STALE_TARGET", "Fresh target did not validate in the DOM, so the click was blocked", "WARN", label)
        return False

    try:
        vx, vy = float(pos.get("vx")), float(pos.get("vy"))
    except Exception:
        record_stat("click_refusals")
        note_issue("NO_VIEWPORT_POINT", "Fresh target had no usable DOM center point", "WARN", label)
        return False

    inner_w = float(snap.get("innerW") or 0)
    inner_h = float(snap.get("innerH") or 0)
    mapped = viewport_to_screen(vx, vy, title, inner_w, inner_h)
    if not mapped:
        record_stat("click_refusals")
        note_issue("NO_SAFE_CLICK_POINT", "Could not map the DOM target to a physical screen point", "ERROR", label)
        return False

    x, y = mapped
    if forbidden(x, y, kind, inner_w, inner_h):
        record_stat("click_refusals")
        note_issue("FORBIDDEN_CLICK_POINT", "Mapped point failed the screen safety bounds", "ERROR", f"{label} ({x},{y})")
        return False

    target_rect = _mapped_dom_rect(pos, snap, title)
    if not target_rect:
        record_stat("click_refusals")
        note_issue("TARGET_RECT_MAPPING_FAILED", "Could not map the target rectangle to the screen", "ERROR", label)
        return False
    tx1, ty1, tx2, ty2 = target_rect
    if not (tx1 <= x <= tx2 and ty1 <= y <= ty2):
        record_stat("click_refusals")
        note_issue(
            "TARGET_CENTER_OUTSIDE_RECT",
            "Calculated click point was not inside the target's physical rectangle",
            "ERROR",
            f"label={label} point=({x},{y}) rect={target_rect}",
            throttle=0,
        )
        return False

    # Accept is never a physical target. Reject is allowed only for the explicit
    # midnight-rule action; all row/Reserve clicks are still kept away from it.
    near_accept = _near_dom_button(x, y, snap.get("accept"), snap, title)
    near_reject = _near_dom_button(x, y, snap.get("reject"), snap, title)
    if near_accept or (near_reject and kind != "midnight_reject"):
        record_stat("click_refusals")
        note_issue(
            "NEAR_ACCEPT_REJECT",
            "Click blocked because the mapped point overlaps a forbidden Accept/Reject target",
            "ERROR",
            f"{label} ({x},{y})",
            throttle=0,
        )
        return False

    mapping = _viewport_mapping(inner_w, inner_h, title)
    if not mapping:
        record_stat("click_refusals")
        return False
    main = int(mapping["main"])
    main_rect = mapping["main_rect"]
    ml, mt, mr, mb = main_rect
    if not (ml <= x < mr and mt <= y < mb):
        record_stat("click_refusals")
        note_issue(
            "MAPPED_POINT_OUTSIDE_CHROME",
            "Mapped target point was outside the normal Chrome window; click was refused",
            "ERROR",
            f"label={label} point=({x},{y}) main_rect={main_rect}",
            throttle=0,
        )
        return False

    # Log the real conversion. This is useful when browser zoom/DPI is involved.
    note_issue(
        "VIEWPORT_SCALE_APPLIED",
        "DOM coordinates were converted to real Windows pixels using the live viewport scale",
        "INFO",
        f"label={label} scale={mapping['scale_x']:.3f},{mapping['scale_y']:.3f} "
        f"dom=({vx:.1f},{vy:.1f}) screen=({x},{y})",
        throttle=60.0,
    )

    if stop_requested_now():
        return False

    with _click_lock:
        prepared = False
        try:
            prepared = _prepare_chrome_for_physical_click(main, x, y, label)
            if not prepared or stop_requested_now():
                record_stat("click_refusals")
                return False

            # Revalidate the same DOM point after Chrome has been exposed.
            if not brain.validate_click(pos, kind):
                record_stat("click_refusals")
                note_issue(
                    "LAST_SECOND_TARGET_CHANGE",
                    "Target changed immediately before click, so the click was blocked",
                    "WARN",
                    label,
                )
                return False

            before = pyautogui.position()
            move_seconds = random.uniform(0.035, 0.075)
            log(
                f"PHYSICAL MOUSE {label}: move ({int(before.x)},{int(before.y)}) -> "
                f"({x},{y}) in {move_seconds:.3f}s, then real mouse down/up"
            )
            pyautogui.moveTo(x, y, duration=move_seconds)
            if stop_requested_now():
                return False

            root = _root_window_at(x, y)
            if root != int(main):
                record_stat("click_refusals")
                shot = capture_diagnostic("target_became_occluded", min_interval=3.0)
                note_issue(
                    "TARGET_BECAME_OCCLUDED",
                    "Another window covered the verified target while the mouse was moving; click was cancelled",
                    "ERROR",
                    f"label={label} expected_hwnd={main} actual_hwnd={root} screenshot={shot}",
                    throttle=3.0,
                )
                return False

            if not brain.validate_click(pos, kind):
                record_stat("click_refusals")
                note_issue(
                    "TARGET_CHANGED_DURING_MOUSE_MOVE",
                    "Target changed while the mouse was moving, so the click was blocked",
                    "WARN",
                    label,
                )
                return False

            if stop_requested_now():
                return False
            pyautogui.mouseDown()
            try:
                time.sleep(0.045)
            finally:
                pyautogui.mouseUp()
            _last_click = time.time()
        finally:
            if prepared:
                time.sleep(0.025)
            _release_chrome_topmost(main)

    if kind == "reserve":
        record_stat("reserve_clicks")
    elif kind == "midnight_reject":
        record_stat("reject_clicks")
    elif kind in ("nav_my", "nav_find"):
        record_stat("nav_clicks")
    elif kind == "files_toggle":
        record_stat("panel_files_toggles")
    elif kind == "still_here":
        record_stat("still_here_clicks")
    else:
        record_stat("row_clicks")
    log(f"CLICK {label} (scaled-hwnd) at ({x}, {y})")

    # For action buttons, immediately read Chrome's passive click audit so the
    # log proves whether the browser received the OS-level mouse event as trusted.
    if kind in ("reserve", "midnight_reject"):
        expected = "Reserve" if kind == "reserve" else "Reject"
        context = "bot physical Reserve" if kind == "reserve" else "bot midnight-rule Reject"
        time.sleep(0.06)
        audit_snap = brain.read()
        audit = consume_click_audit(audit_snap, context=context, expected_label=expected)
        if not audit:
            code = "RESERVE_CLICK_AUDIT_MISSING" if kind == "reserve" else "REJECT_CLICK_AUDIT_MISSING"
            note_issue(
                code,
                f"{expected} mouse-down/up was sent but Chrome's click audit did not capture a new click event",
                "WARN",
                f"screen=({x},{y})",
                throttle=0,
            )
    return True


def drag_reserved_panel_scrollbar_cycle(snap: dict, brain: Brain, pass_number: int) -> bool:
    """Drag the reserved drawer's real scrollbar down/up once, or do absolutely nothing.

    Fail-closed rule: unless a visible, scrollable native scrollbar is positively
    present and mappable, this function does not focus Chrome and does not move,
    press, click, or drag the mouse at all.
    """
    global _last_click
    if _paused or stop_requested_now():
        return False
    prepared = False
    main = 0
    try:
        # Read first without activating Chrome. Missing/hidden scrollbar = no action.
        fresh = brain.read() or {}
        pos = fresh.get("panelScroll") or {}
        if not pos or not fresh.get("panelOpen"):
            log(f"RESERVED PANEL SCROLLBAR PASS {pass_number}: no verified visible scrollbar; no mouse action was performed.")
            return False

        top = float(pos.get("top") or 0)
        left = float(pos.get("left") or 0)
        width = float(pos.get("w") or 0)
        height = float(pos.get("h") or 0)
        scroll_top = float(pos.get("scrollTop") or 0)
        scroll_height = float(pos.get("scrollHeight") or 0)
        client_height = float(pos.get("clientHeight") or 0)
        scrollbar_width = float(pos.get("scrollbarWidth") or 0)
        overflow_y = str(pos.get("overflowY") or "").lower()
        maximum = max(0.0, scroll_height - client_height)
        if (width < 100 or height < 100 or maximum < 20 or scroll_height <= 0 or
                client_height <= 0 or scrollbar_width < 6 or overflow_y not in ("auto", "scroll")):
            log(f"RESERVED PANEL SCROLLBAR PASS {pass_number}: scrollbar verification failed; no mouse action was performed.")
            return False

        track_top = top + 4.0
        track_height = max(30.0, height - 8.0)
        thumb_height = max(24.0, min(track_height, track_height * (client_height / scroll_height)))
        travel = max(1.0, track_height - thumb_height)
        ratio = max(0.0, min(1.0, scroll_top / maximum))
        start_vx = left + width - max(3.0, scrollbar_width / 2.0)
        start_vy = track_top + ratio * travel + thumb_height / 2.0
        bottom_vy = track_top + travel + thumb_height / 2.0

        title = str(fresh.get("pageTitle") or "")
        mapped_start = viewport_to_screen(start_vx, start_vy, title, float(fresh.get("innerW") or 0), float(fresh.get("innerH") or 0))
        mapped_bottom = viewport_to_screen(start_vx, bottom_vy, title, float(fresh.get("innerW") or 0), float(fresh.get("innerH") or 0))
        if not mapped_start or not mapped_bottom:
            log(f"RESERVED PANEL SCROLLBAR PASS {pass_number}: scrollbar could not be mapped; no mouse action was performed.")
            return False

        # Only now is mouse/focus activity allowed.
        brain.activate()
        main, _ = chrome_handles(title)
        if not main:
            return False
        sx, sy = mapped_start
        bx, by = mapped_bottom
        if not _prepare_chrome_for_physical_click(main, sx, sy, f"reserved scrollbar pass {pass_number}"):
            return False
        prepared = True

        with _click_lock:
            if stop_requested_now():
                return False
            focus_hwnd(main)
            pyautogui.moveTo(sx, sy, duration=0.05)
            if stop_requested_now():
                return False
            pyautogui.dragTo(bx, by, duration=RESERVED_SCROLLBAR_DRAG_SECONDS, button="left")
            _last_click = time.time()
        time.sleep(0.12)

        down_snap = brain.read() or {}
        down_pos = down_snap.get("panelScroll") or {}
        down_top = float(down_pos.get("scrollTop") or scroll_top)
        if down_top <= scroll_top + 2 and scroll_top < maximum - 2:
            # No fallback movement. A failed drag ends this pass immediately.
            log(f"RESERVED PANEL SCROLLBAR PASS {pass_number}: downward drag was not confirmed; no fallback mouse action will be attempted.")
            return False

        live_top = float(down_pos.get("top") or top)
        live_left = float(down_pos.get("left") or left)
        live_width = float(down_pos.get("w") or width)
        live_height = float(down_pos.get("h") or height)
        live_scroll_height = float(down_pos.get("scrollHeight") or scroll_height)
        live_client_height = float(down_pos.get("clientHeight") or client_height)
        live_scrollbar_width = float(down_pos.get("scrollbarWidth") or scrollbar_width)
        if live_scrollbar_width < 6:
            log(f"RESERVED PANEL SCROLLBAR PASS {pass_number}: scrollbar disappeared after downward drag; no further mouse action was attempted.")
            return False
        live_max = max(1.0, live_scroll_height - live_client_height)
        live_track_top = live_top + 4.0
        live_track_height = max(30.0, live_height - 8.0)
        live_thumb_height = max(24.0, min(live_track_height, live_track_height * (live_client_height / live_scroll_height)))
        live_travel = max(1.0, live_track_height - live_thumb_height)
        live_ratio = max(0.0, min(1.0, down_top / live_max))
        live_vx = live_left + live_width - max(3.0, live_scrollbar_width / 2.0)
        live_vy = live_track_top + live_ratio * live_travel + live_thumb_height / 2.0
        top_vy = live_track_top + live_thumb_height / 2.0

        mapped_live = viewport_to_screen(live_vx, live_vy, str(down_snap.get("pageTitle") or title), float(down_snap.get("innerW") or fresh.get("innerW") or 0), float(down_snap.get("innerH") or fresh.get("innerH") or 0))
        mapped_top = viewport_to_screen(live_vx, top_vy, str(down_snap.get("pageTitle") or title), float(down_snap.get("innerW") or fresh.get("innerW") or 0), float(down_snap.get("innerH") or fresh.get("innerH") or 0))
        if not mapped_live or not mapped_top:
            return False
        lx, ly = mapped_live
        tx, ty = mapped_top

        with _click_lock:
            if stop_requested_now():
                return False
            focus_hwnd(main)
            pyautogui.moveTo(lx, ly, duration=0.05)
            if stop_requested_now():
                return False
            pyautogui.dragTo(tx, ty, duration=RESERVED_SCROLLBAR_DRAG_SECONDS, button="left")
            _last_click = time.time()
        time.sleep(0.12)

        up_snap = brain.read() or {}
        up_pos = up_snap.get("panelScroll") or {}
        up_top = float(up_pos.get("scrollTop") or down_top)
        if up_top >= down_top - 2 and down_top > 2:
            log(f"RESERVED PANEL SCROLLBAR PASS {pass_number}: upward return was not confirmed; no fallback mouse action will be attempted.")
            return False

        record_stat("panel_inspection_scrolls")
        log(f"RESERVED PANEL SCROLLBAR PASS {pass_number}: physical thumb dragged down then up, scrollTop={scroll_top:.0f}->{down_top:.0f}->{up_top:.0f}.")
        return True
    except Exception as e:
        log(f"RESERVED PANEL SCROLLBAR PASS {pass_number}: skipped after verification/error ({e}); no fallback mouse action.")
        return False
    finally:
        if prepared and main:
            _release_chrome_topmost(main)


def send_f5(brain: Brain) -> None:
    if _paused or stop_requested_now():
        return
    # Just before any keyboard refresh, check whether LR Writers has logged out.
    # Logout is a hard stop: never navigate, retry login, or press F5 afterward.
    try:
        pre = brain.read() or {}
        if bool(pre.get("loggedOut")):
            hard_stop_logout("LR Writers logout/login page detected before F5")
            return
    except Exception:
        pass
    with _click_lock:
        title = brain.activate()
        main, _ = chrome_handles(title)
        if not main:
            note_issue("F5_WINDOW_MISSING", "Refresh was skipped because controlled Chrome could not be found", "WARN", throttle=5.0)
            return
        try:
            user32.SetWindowPos(
                main, HWND_TOPMOST, 0, 0, 0, 0,
                SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW,
            )
            focus_hwnd(main)
            time.sleep(0.04)
            if stop_requested_now():
                return
            if int(user32.GetForegroundWindow() or 0) != int(main):
                note_issue("F5_NOT_FOREGROUND", "Refresh was skipped because Chrome could not get keyboard focus", "WARN", throttle=5.0)
                return
            pyautogui.press("f5")
        finally:
            _release_chrome_topmost(main)
    record_stat("f5")
    log("F5")

def _idle_point_to_screen(snap: dict, point: dict) -> tuple[int, int] | None:
    """Map one DOM-vetted idle point to the real Chrome render surface."""
    try:
        return viewport_to_screen(
            float(point.get("vx")),
            float(point.get("vy")),
            str(snap.get("pageTitle") or ""),
            float(snap.get("innerW") or 0),
            float(snap.get("innerH") or 0),
        )
    except Exception:
        return None


def idle_mouse(snap: dict, allow_click: bool = False) -> bool:
    """Move through a random DOM-vetted non-interactive point.

    If allow_click=True, make one physical click only on a point that the
    live page classified as inert background. Never background-click while
    an order panel is open.
    """
    global _last_idle_dir

    if _paused or stop_requested_now():
        return False
    if snap.get("panelOpen") or snap.get("reserve") or snap.get("accept") or snap.get("reject"):
        return False

    points = list(snap.get("idleClickPoints") or []) if allow_click else list(snap.get("idleMovePoints") or [])
    if not points:
        return False

    random.shuffle(points)
    chosen = None
    for pt in points:
        mapped = _idle_point_to_screen(snap, pt)
        if not mapped:
            continue
        x, y = mapped
        if forbidden(x, y, "idle", float(snap.get("innerW") or 0), float(snap.get("innerH") or 0)):
            continue
        key = f"{x},{y}"
        if key == _last_idle_dir and len(points) > 1:
            continue
        chosen = (pt, x, y, key)
        break

    if not chosen:
        return False

    pt, x, y, key = chosen
    duration = random.uniform(0.35, 1.20)
    if stop_requested_now():
        return False
    pyautogui.moveTo(x, y, duration=duration)
    if stop_requested_now():
        return False
    log(
        f"IDLE MOUSE: moved across webpage to safe DOM point ({x},{y}) "
        f"in {duration:.2f}s tag={pt.get('tag') or '?'}"
    )
    _last_idle_dir = key

    if not allow_click:
        return True

    main, _ = chrome_handles()
    if not main:
        return False
    point_obj = POINT(x, y)
    actual = int(user32.WindowFromPoint(point_obj) or 0)
    GA_ROOT = 2
    root_actual = int(user32.GetAncestor(actual, GA_ROOT) or actual) if actual else 0
    root_main = int(user32.GetAncestor(main, GA_ROOT) or main)
    if root_actual != root_main:
        note_issue(
            "IDLE_CLICK_OCCLUDED",
            "Safe idle click skipped because Chrome did not own the physical point",
            "INFO",
            f"point=({x},{y}) actual={root_actual} expected={root_main}",
            throttle=30.0,
        )
        return False

    if stop_requested_now():
        return False
    pyautogui.mouseDown()
    time.sleep(random.uniform(0.035, 0.070))
    pyautogui.mouseUp()
    record_stat("idle_background_clicks")
    log(
        f"IDLE SAFE CLICK: physical mouse clicked verified inert webpage background "
        f"at ({x},{y}) tag={pt.get('tag') or '?'}"
    )
    return True




def _try_scheduled_navigation_scroll(brain: Brain, snap: dict, label: str, direction: str) -> bool:
    """Try one small physical mouse-wheel scroll on a scheduled detour page.

    This is fail-closed: if Chrome, a safe webpage point, or coordinate mapping cannot
    be verified, Adeon does nothing. It never clicks while performing this scroll.
    """
    if _stop or _paused or not snap or snap.get("loggedOut") or snap.get("panelOpen"):
        return False
    try:
        points = list(snap.get("idleMovePoints") or [])
        if not points:
            log(f"SCHEDULED NAV {label}: no verified safe page point for scrolling; scroll skipped.")
            return False
        # Prefer a point near the center of the visible webpage so the wheel applies
        # to the page rather than a sidebar or browser chrome.
        iw = float(snap.get("innerW") or 0)
        ih = float(snap.get("innerH") or 0)
        points.sort(key=lambda p: abs(float(p.get("vx") or 0) - iw * 0.52) + abs(float(p.get("vy") or 0) - ih * 0.55))
        pt = points[0]
        mapped = viewport_to_screen(float(pt.get("vx") or 0), float(pt.get("vy") or 0), str(snap.get("pageTitle") or ""), iw, ih)
        mapping = _viewport_mapping(iw, ih, str(snap.get("pageTitle") or ""))
        if not mapped or not mapping:
            log(f"SCHEDULED NAV {label}: page-to-screen mapping unavailable; scroll skipped.")
            return False
        x, y = mapped
        main = int(mapping.get("main") or 0)
        if not _prepare_chrome_for_physical_click(main, x, y, f"{label} scheduled scroll"):
            log(f"SCHEDULED NAV {label}: Chrome could not be safely exposed; scroll skipped.")
            return False
        try:
            pyautogui.moveTo(x, y, duration=random.uniform(0.05, 0.10))
            # pyautogui positive = up, negative = down. Keep movement modest.
            clicks = -4 if str(direction).lower() == "down" else 4
            pyautogui.scroll(clicks)
            log(f"SCHEDULED NAV {label}: physical mouse-wheel scroll {direction} attempted.")
            return True
        finally:
            _release_chrome_topmost(main)
    except Exception as e:
        log(f"SCHEDULED NAV {label}: scroll skipped after verification/error ({e}).")
        return False


def perform_scheduled_navigation_visit(brain: Brain, snap: dict, destination: str) -> bool:
    """Physically visit one LR navigation page, remain there for two minutes, then return.

    Sequence is controlled by the caller. No visit runs while a panel/reservation is
    active. During the two-minute dwell Adeon makes two small verified scroll attempts
    and otherwise leaves the page alone.
    """
    if _stop or _paused or not snap or snap.get("loggedOut"):
        return False
    if snap.get("panelOpen") or snap.get("reserve") or snap.get("accept") or snap.get("reject"):
        return False

    config = {
        "my_orders": ("My Orders", "navMy", "nav_my", "onMyOrders"),
        "inbox": ("Inbox", "navInbox", "nav_inbox", "onInbox"),
        "my_progress": ("My Progress", "navProgress", "nav_progress", "onProgress"),
    }
    if destination not in config:
        return False
    label, snap_key, kind, state_key = config[destination]
    target = snap.get(snap_key)
    if not target:
        note_issue("SCHEDULED_NAV_MISSING", f"{label} navigation target was not visible; scheduled visit skipped", "INFO", throttle=60.0)
        return False

    set_status_ticket(job=f"{label.upper()} CHECK", f5="WAIT", mouse="VISIT")
    log(f"SCHEDULED NAV: physically clicking {label}.")
    if not motor_click(target, label, kind, snap, brain):
        return False

    deadline = time.time() + 12.0
    dest_snap = {}
    while time.time() < deadline and not _stop and not _paused:
        time.sleep(0.15)
        dest_snap = brain.read() or {}
        if dest_snap.get("loggedOut"):
            hard_stop_logout(f"LR Writers logout/login page detected during {label} visit")
            return False
        if dest_snap.get(state_key) or (dest_snap and not bool(dest_snap.get("onFind"))):
            break
    if not dest_snap or bool(dest_snap.get("onFind")):
        note_issue("SCHEDULED_NAV_FAILED", f"{label} did not become active after the physical navigation click", "WARN", str(dest_snap.get("url") or ""), throttle=30.0)
        return False

    # Stay on the destination for the requested two minutes. No clicks are made
    # during this dwell. At 30s and 90s, try a small page scroll. If safe scrolling
    # cannot be verified, simply stay on the page and do nothing until the dwell ends.
    dwell_started = time.time()
    scroll_index = 0
    set_status_ticket(job=f"{label.upper()} 2 MIN", f5="WAIT", mouse="SCROLL")
    while not _stop and not _paused:
        elapsed = time.time() - dwell_started
        if elapsed >= SCHEDULED_NAV_DWELL:
            break
        time.sleep(0.20)
        dest_snap = brain.read() or dest_snap
        if dest_snap.get("loggedOut"):
            hard_stop_logout(f"LR Writers logout/login page detected during {label} dwell")
            return False
        # If the scheduled page unexpectedly disappeared, end the dwell cleanly
        # instead of trying mouse actions on an unknown page.
        if not dest_snap.get(state_key):
            log(f"SCHEDULED NAV: {label} is no longer the active page; ending dwell without extra mouse actions.")
            break
        if scroll_index < len(SCHEDULED_NAV_SCROLL_AT) and elapsed >= SCHEDULED_NAV_SCROLL_AT[scroll_index]:
            direction = "down" if scroll_index == 0 else "up"
            _try_scheduled_navigation_scroll(brain, dest_snap, label, direction)
            scroll_index += 1

    dest_snap = brain.read() or dest_snap
    nav_find = dest_snap.get("navFind")
    if not nav_find:
        note_issue("FIND_ORDERS_NAV_MISSING", f"Find Orders navigation target was not visible while returning from {label}", "WARN", str(dest_snap.get("url") or ""), throttle=30.0)
        return False
    log(f"SCHEDULED NAV: physically clicking Find Orders to return from {label}.")
    if not motor_click(nav_find, "Find Orders", "nav_find", dest_snap, brain):
        return False

    deadline = time.time() + 12.0
    while time.time() < deadline and not _stop and not _paused:
        time.sleep(0.15)
        back = brain.read() or {}
        if back.get("loggedOut"):
            hard_stop_logout(f"LR Writers logout/login page detected while returning from {label}")
            return False
        if back.get("onFind"):
            record_stat("my_orders_visits")
            log(f"SCHEDULED NAV COMPLETE: {label} -> Find Orders. 100 ms new-row scanning resumes.")
            return True
    note_issue("FIND_ORDERS_RETURN_FAILED", f"Scheduled {label} visit could not confirm return to Find Orders", "WARN", throttle=30.0)
    return False


def recover_to_find_orders(brain: Brain, snap: dict, reason: str = "") -> bool:
    """Physically return the active LR Writers tab to Find Orders when safe.

    This is picker-only recovery. It never runs for Labels-only mode, while logged
    out, on a network-error page, while an order panel/reservation is active, or
    when the Find Orders navigation target cannot be verified. The click uses the
    same native mouse path and DOM validation as every other allowed Adeon click.
    """
    if _LABELS_ONLY_MODE or _stop or _paused or not snap:
        return False
    if snap.get("loggedOut") or is_network_error_snapshot(snap):
        return False
    if bool(snap.get("onFind")):
        return True
    if snap.get("panelOpen") or snap.get("reserve") or snap.get("accept") or snap.get("reject"):
        return False
    nav_find = snap.get("navFind")
    if not nav_find:
        note_issue(
            "FIND_ORDERS_RECOVERY_TARGET_MISSING",
            "Adeon is off Find Orders but the verified Find Orders navigation target is not visible yet",
            "WARN",
            str(snap.get("url") or reason or ""),
            throttle=20.0,
        )
        return False
    why = str(reason or snap.get("url") or "another LR page")[:180]
    log(f"FIND ORDERS RECOVERY: physically returning from {why} to Find Orders.")
    set_status_ticket(bot="CONNECTED", page="RETURNING FIND ORDERS", job="SEARCHING", f5="OFF", mouse="NAV")
    if not motor_click(nav_find, "Find Orders", "nav_find", snap, brain):
        return False
    deadline = time.time() + 10.0
    while time.time() < deadline and not _stop and not _paused:
        time.sleep(0.12)
        back = brain.read() or {}
        if back.get("loggedOut"):
            hard_stop_logout("LR Writers logout/login page detected while returning to Find Orders")
            return False
        if bool(back.get("onFind")):
            log("FIND ORDERS RECOVERY COMPLETE: picker is back on Find Orders and scanning continues.")
            return True
    note_issue(
        "FIND_ORDERS_RECOVERY_FAILED",
        "Adeon clicked Find Orders but could not confirm the page returned; it will keep retrying while safe",
        "WARN",
        why,
        throttle=20.0,
    )
    return False


def is_network_error_snapshot(snap: dict | None) -> bool:
    """True only for browser/network error pages, never for an LR login/logout page."""
    if not snap:
        return False
    url = str(snap.get("url") or "").strip().lower()
    title = str(snap.get("pageTitle") or "").strip().lower()
    text = str(snap.get("bodyText") or snap.get("panelText") or "").strip().lower()
    if url.startswith("chrome-error://") or url.startswith("chrome://network-error"):
        return True
    if any(x in title for x in ("site can't be reached", "no internet", "offline", "network error")):
        return True
    if any(x in text for x in ("this site can’t be reached", "this site can't be reached", "no internet", "err_internet_disconnected", "err_network_changed")):
        return True
    return False


# ---------------- alerts ----------------
def send_gmail(title: str, message: str) -> bool:
    if not GMAIL_WEBAPP_URL:
        return False
    try:
        r = requests.post(
            GMAIL_WEBAPP_URL,
            json={"secret": GMAIL_WEBAPP_SECRET, "to": GMAIL_TO, "subject": title, "body": message},
            timeout=15,
        )
        ok = 200 <= r.status_code < 300
        log("Gmail: " + str(r.status_code))
        if not ok:
            note_issue("GMAIL_HTTP_ERROR", "Gmail alert returned a non-success status", "WARN", str(r.status_code), throttle=30)
        return ok
    except Exception as e:
        note_issue("GMAIL_FAILED", "Gmail alert delivery failed", "WARN", str(e), throttle=30)
        return False



def cancel_alert_keys(keys: list[str]) -> None:
    """Cancel queued reminder keys for a reservation that was accepted/rejected/cleared."""
    clean = [k for k in keys if k]
    if not clean:
        return
    with _alert_lock:
        before = len(_alert_cancelled)
        _alert_cancelled.update(clean)
        added = len(_alert_cancelled) - before
    if added:
        record_stat("alerts_cancelled", added)

def _alert_is_cancelled(key: str) -> bool:
    with _alert_lock:
        return key in _alert_cancelled

def _deliver_alert_worker(title: str, message: str, key: str) -> None:
    """Deliver Pushover/Gmail off the director thread so F5 never waits on network I/O."""
    push_ok = False
    mail_ok = False
    try:
        if _alert_is_cancelled(key):
            log(f"Alert cancelled before delivery: {title}")
            return
        try:
            push_message = (message or title)[:1000]
            push_data = {
                "token": PUSHOVER_APP_TOKEN, "user": PUSHOVER_USER_KEY, "title": title[:80],
                "message": push_message, "sound": "siren",
            }
            if "<b>" in push_message or "</b>" in push_message:
                push_data["html"] = "1"
            r = requests.post(
                "https://api.pushover.net/1/messages.json",
                data=push_data, timeout=15,
            )
            push_ok = 200 <= r.status_code < 300
            log("Pushover: " + title + " (" + str(r.status_code) + ")")
            if not push_ok:
                note_issue("PUSHOVER_HTTP_ERROR", "Pushover returned a non-success status", "WARN", str(r.status_code), throttle=30)
        except Exception as e:
            note_issue("PUSHOVER_FAILED", "Pushover alert delivery failed", "WARN", str(e), throttle=30)

        if _alert_is_cancelled(key):
            log(f"Alert cancelled before Gmail delivery: {title}")
            return
        mail_ok = send_gmail(title, re.sub(r"<[^>]+>", "", message or title))
        with _alert_lock:
            if push_ok or mail_ok:
                _alerted.add(key)
                record_stat("alerts_sent")
            else:
                record_stat("alert_failures")
                note_issue("ALERT_DELIVERY_FAILED", "Both alert methods failed; bot will retry later", "WARN", title, throttle=30)
    finally:
        with _alert_lock:
            _alert_inflight.discard(key)


def send_alert(title: str, message: str, key: str) -> bool:
    """Queue an alert without blocking row scanning, mouse actions, or F5."""
    if _paused or stop_requested_now():
        return False
    if not key:
        return False
    now = time.time()
    with _alert_lock:
        if key in _alert_cancelled:
            return False
        if key in _alerted:
            return True
        if key in _alert_inflight:
            return False
        last_try = _alert_last_try.get(key, 0.0)
        if last_try and now - last_try < 30.0:
            return False
        _alert_last_try[key] = now
        _alert_inflight.add(key)

    threading.Thread(
        target=_deliver_alert_worker,
        args=(title, message, key),
        name="LR-Alert-" + re.sub(r"[^A-Za-z0-9_-]+", "_", key)[:30],
        daemon=True,
    ).start()
    log(f"Alert queued in background: {title}")
    return False



_loud_bell_wavs: dict[int, bytes] = {}


def _build_loud_bell_wav(level: int = 1) -> bytes:
    """Create a progressively more insistent but safety-capped local alarm WAV.

    Adeon does not force Windows hardware volume to maximum and does not generate
    ultrasonic or intentionally painful tones. The user's speaker volume remains
    the final loudness limit.
    """
    level = max(1, min(4, int(level or 1)))
    cached = _loud_bell_wavs.get(level)
    if cached is not None:
        return cached
    try:
        import io
        import math
        import struct
        import wave

        rate = 44100
        patterns = {
            1: ((0.00, 0.72, 1.44), 2.35, 0.44),
            2: ((0.00, 0.52, 1.04, 1.56, 2.08), 2.95, 0.52),
            3: ((0.00, 0.40, 0.80, 1.20, 1.60, 2.00, 2.40), 3.25, 0.60),
            4: ((0.00, 0.32, 0.64, 0.96, 1.28, 1.60, 1.92, 2.24, 2.56, 2.88), 3.75, 0.68),
        }
        strikes, duration, amplitude = patterns[level]
        frames = bytearray()
        total = int(rate * duration)
        for i in range(total):
            t = i / rate
            sample = 0.0
            for strike in strikes:
                dt = t - strike
                if 0.0 <= dt <= 0.62:
                    env = math.exp(-5.2 * dt)
                    sample += env * (
                        0.62 * math.sin(2.0 * math.pi * 784.0 * dt)
                        + 0.28 * math.sin(2.0 * math.pi * 1046.5 * dt)
                        + 0.14 * math.sin(2.0 * math.pi * 1318.5 * dt)
                    )
            sample = max(-0.72, min(0.72, sample * amplitude))
            frames += struct.pack('<h', int(sample * 32767))
        buf = io.BytesIO()
        with wave.open(buf, 'wb') as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(rate)
            wf.writeframes(bytes(frames))
        _loud_bell_wavs[level] = buf.getvalue()
    except Exception:
        _loud_bell_wavs[level] = b''
    return _loud_bell_wavs[level]


def _loud_bell_worker(key: str, level: int = 1) -> None:
    """Play one levelled local alarm without blocking the 100 ms picker loop."""
    level = max(1, min(4, int(level or 1)))
    try:
        if _alert_is_cancelled(key):
            return
        import winsound
        wav = _build_loud_bell_wav(level)
        if wav:
            winsound.PlaySound(wav, winsound.SND_MEMORY)
            return
        fallback = {
            1: ((784, 260), (1047, 300), (784, 360)),
            2: ((784, 260), (1047, 300), (1175, 300), (784, 380)),
            3: ((784, 230), (1047, 250), (1175, 260), (1047, 280), (784, 380)),
            4: ((784, 210), (1047, 220), (1175, 230), (1319, 240), (1047, 260), (784, 360)),
        }[level]
        for freq, ms in fallback:
            if _alert_is_cancelled(key):
                return
            winsound.Beep(freq, ms)
            time.sleep(0.05)
    except Exception as e:
        note_issue("LOUD_BELL_FAILED", "Laptop reservation bell could not play", "WARN", str(e), throttle=30)


def play_loud_reservation_bell(key: str, level: int = 1) -> None:
    if _stop or _paused or not key or _alert_is_cancelled(key):
        return
    level = max(1, min(4, int(level or 1)))
    threading.Thread(
        target=_loud_bell_worker,
        args=(key, level),
        name=f"Adeon-Reserve-Bell-L{level}",
        daemon=True,
    ).start()


def _critical_group_key(key: str) -> str:
    return str(key or '').split(':critical-', 1)[0]


def _cancel_pushover_receipt(receipt: str) -> bool:
    receipt = str(receipt or '').strip()
    if not receipt:
        return True
    try:
        r = requests.post(
            f"https://api.pushover.net/1/receipts/{receipt}/cancel.json",
            data={"token": PUSHOVER_APP_TOKEN},
            timeout=10,
        )
        ok = 200 <= r.status_code < 300
        log(f"Pushover emergency receipt cancel ({r.status_code})")
        return ok
    except Exception as e:
        note_issue("PUSHOVER_CRITICAL_CANCEL_FAILED", "Could not cancel the previous Pushover emergency retry", "WARN", str(e), throttle=30)
        return False


def cancel_critical_reservation_push(group_key: str) -> None:
    """Cancel the currently active Pushover emergency receipt for this reservation."""
    group = str(group_key or '').strip()
    if not group:
        return
    with _critical_receipt_lock:
        receipt = _critical_receipts.pop(group, '')
    if not receipt:
        return
    threading.Thread(
        target=_cancel_pushover_receipt,
        args=(receipt,),
        name="Adeon-Cancel-Critical",
        daemon=True,
    ).start()


def _deliver_critical_reservation_alert_worker(title: str, message: str, key: str) -> None:
    """Send one true Pushover emergency/critical alert for one escalation slot.

    Pushover emergency retry itself cannot be configured below 30 seconds. Adeon
    cancels the prior slot receipt before creating the next scheduled slot. The API
    cannot raise the phone's hardware volume, so frequency and siren urgency escalate.
    """
    push_ok = False
    group = _critical_group_key(key)
    try:
        if _alert_is_cancelled(key):
            log(f"Critical reservation alert cancelled before delivery: {title}")
            return

        # Cancel the previous emergency receipt before creating this 15-second slot.
        with _critical_receipt_lock:
            old_receipt = _critical_receipts.pop(group, '')
        if old_receipt:
            _cancel_pushover_receipt(old_receipt)
        if _alert_is_cancelled(key):
            return

        try:
            push_data = {
                "token": PUSHOVER_APP_TOKEN,
                "user": PUSHOVER_USER_KEY,
                "title": title[:80],
                "message": (message or title)[:1000],
                "priority": "2",
                "retry": "30",
                "expire": "35",
                "sound": "siren",
            }
            r = requests.post("https://api.pushover.net/1/messages.json", data=push_data, timeout=15)
            push_ok = 200 <= r.status_code < 300
            receipt = ''
            if push_ok:
                try:
                    receipt = str((r.json() or {}).get('receipt') or '').strip()
                except Exception:
                    receipt = ''
            log("Pushover CRITICAL emergency: " + title + " (" + str(r.status_code) + ")")
            if not push_ok:
                note_issue("PUSHOVER_CRITICAL_HTTP_ERROR", "Critical Pushover alert returned a non-success status", "WARN", str(r.status_code), throttle=30)
            elif receipt:
                if _alert_is_cancelled(key):
                    # Reservation ended while the HTTP request was in flight.
                    _cancel_pushover_receipt(receipt)
                else:
                    with _critical_receipt_lock:
                        _critical_receipts[group] = receipt
        except Exception as e:
            note_issue("PUSHOVER_CRITICAL_FAILED", "Critical Pushover alert delivery failed", "WARN", str(e), throttle=30)

        with _alert_lock:
            if push_ok:
                _alerted.add(key)
                record_stat("alerts_sent")
            else:
                record_stat("alert_failures")
    finally:
        with _alert_lock:
            _alert_inflight.discard(key)


def send_critical_reservation_alert(title: str, message: str, key: str) -> bool:
    """Queue one true Pushover emergency/critical reservation alert."""
    if _paused or stop_requested_now() or not key:
        return False
    now = time.time()
    with _alert_lock:
        if key in _alert_cancelled:
            return False
        if key in _alerted:
            return True
        if key in _alert_inflight:
            return False
        last_try = _alert_last_try.get(key, 0.0)
        if last_try and now - last_try < 5.0:
            return False
        _alert_last_try[key] = now
        _alert_inflight.add(key)
    threading.Thread(
        target=_deliver_critical_reservation_alert_worker,
        args=(title, message, key),
        name="LR-Critical-" + re.sub(r"[^A-Za-z0-9_-]+", "_", key)[:30],
        daemon=True,
    ).start()
    log(f"Critical reservation alert queued: {title}")
    return False



def in_midnight_rule_window(dt: datetime | None = None) -> bool:
    """Use the PC's local clock. The rule is active from midnight until 08:00."""
    dt = dt or datetime.now()
    h = dt.hour + dt.minute / 60.0 + dt.second / 3600.0
    start = float(MIDNIGHT_RULE_START_HOUR)
    end = float(MIDNIGHT_RULE_END_HOUR)
    if start <= end:
        return start <= h < end
    return h >= start or h < end


def parse_remaining_minutes(text: str) -> float | None:
    """Parse only explicit relative-deadline wording; ignore generic '60 minutes - 300 words'."""
    t = re.sub(r"\s+", " ", str(text or "").lower().replace("’", "'")).strip()
    if not t:
        return None

    # Normalize natural singular phrases used by the site.
    t = re.sub(r"\ban hour\b", "1 hour", t)
    t = re.sub(r"\ba hour\b", "1 hour", t)
    t = re.sub(r"\ba day\b", "1 day", t)
    t = re.sub(r"\ban? minute\b", "1 minute", t)

    # Only consider text close to a relative-deadline cue. This avoids treating
    # assignment-production hints such as '60 minutes - 300 words' as deadlines.
    candidates: list[str] = []
    cue_patterns = [
        r"(?:in\s+)?[^|.;]{0,80}?\bfrom now\b",
        r"(?:in\s+)?[^|.;]{0,80}?\b(?:left|remaining)\b",
        r"\b(?:deadline|final ddl|ddl)\b[^|.;]{0,100}",
        r"\bin\s+\d+(?:\.\d+)?\s*(?:days?|d|hours?|hrs?|hr|h|minutes?|mins?|min|m)\b",
    ]
    for pat in cue_patterns:
        for m in re.finditer(pat, t, re.I):
            candidates.append(m.group(0))

    if not candidates:
        return None

    best: float | None = None
    for seg in candidates:
        days = hours = minutes = 0.0
        found = False
        for val, unit in re.findall(r"(\d+(?:\.\d+)?)\s*(days?|d|hours?|hrs?|hr|h|minutes?|mins?|min|m)\b", seg, re.I):
            found = True
            n = float(val)
            u = unit.lower()
            if u.startswith("d"):
                days += n
            elif u.startswith("h"):
                hours += n
            else:
                minutes += n
        if found:
            total = days * 1440.0 + hours * 60.0 + minutes
            if total >= 0 and (best is None or total < best):
                best = total
    return best


def deadline_source_for_row(row: dict | None) -> str:
    if not row:
        return ""
    return " ".join(str(row.get(k) or "") for k in ("deadlineText", "text"))


def _one_line(text: str) -> str:
    return re.sub(r"\s+", " ", str(text or "")).strip()


def _extract_named_section(raw: str, heading_pattern: str, stop_headings: tuple[str, ...]) -> str:
    m = re.search(heading_pattern, raw or "", re.I)
    if not m:
        return ""
    tail = (raw or "")[m.end():]
    cut = len(tail)
    low = tail.lower()
    for stop in stop_headings:
        i = low.find(stop.lower())
        if i >= 0:
            cut = min(cut, i)
    return tail[:cut].strip()


def _old_style_money(raw: str) -> str:
    """Match the original Tampermonkey notification price extraction."""
    lines = [_one_line(x) for x in str(raw or "").splitlines()[:60] if _one_line(x)]
    best = None
    best_score = -10**9
    for i, line in enumerate(lines):
        if "$" not in line or re.search(r"\(\s*\$\s*\d", line):
            continue
        m = re.search(r"\$\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)", line)
        if not m:
            continue
        try:
            value = float(m.group(1).replace(",", ""))
        except Exception:
            continue
        has_decimals = bool(re.search(r"\$\s*\d+\.\d{2}\b", line))
        score = (1000 if has_decimals else 0) - i
        if score > best_score:
            best_score = score
            best = value
    return "" if best is None else f"${best:.2f}"


def _preferred_earnings_money(*texts: str) -> str:
    """Use A+ earns when it is actually shown, otherwise use You'll earn.

    This intentionally does not infer A+ from an unrelated second dollar value.
    A+ wins only when its own label is present. If no A+ label/value is found,
    You'll earn is used. The generic legacy money parser is only a last fallback
    when neither labelled field exists in the supplied drawer text.
    """
    merged = "\n".join(str(x or "") for x in texts if str(x or "").strip())
    if not merged:
        return ""

    def labelled_value(labels: tuple[str, ...]) -> str:
        # Handle both "Label  $12.34" and "$12.34  Label" layouts, with a small
        # allowance for intervening table whitespace/text.
        label_re = "(?:" + "|".join(labels) + ")"
        pats = (
            rf"{label_re}[^$\n]{{0,80}}\$\s*([0-9][0-9,]*(?:\.[0-9]{{1,2}})?)",
            rf"\$\s*([0-9][0-9,]*(?:\.[0-9]{{1,2}})?)[^\n]{{0,80}}{label_re}",
        )
        for pat in pats:
            m = re.search(pat, merged, re.I)
            if not m:
                continue
            try:
                return f"${float(m.group(1).replace(',', '')):.2f}"
            except Exception:
                continue
        return ""

    a_plus = labelled_value((r"A\s*\+\s*(?:level\s*)?earns",))
    if a_plus:
        return a_plus
    you_earn = labelled_value((r"you\s*(?:'|’)?ll\s+earn", r"you\s+will\s+earn"))
    if you_earn:
        return you_earn
    return _old_style_money(merged)


def _old_style_size(raw: str) -> str:
    for pat, unit in (
        (r"\b(\d+)\s*pages?\b", "pages"),
        (r"\b(\d+)\s*slides?\b", "slides"),
        (r"\b(\d{2,6})\s*words?\b", "words"),
    ):
        m = re.search(pat, raw or "", re.I)
        if m:
            return f"{m.group(1)} {unit}"
    return ""


def _old_style_title(raw: str, task_no: str, hint: str = "") -> str:
    """Extract the human task title from the same panel text the old script used.

    Prefer the portion immediately after the task number and before Task summary.
    This avoids button-strip strings such as ReserveAccept and list/header text.
    """
    text = str(raw or "")
    stop_words = (
        "final ddl", "order info", "operator messages", "more order details",
        "order files", "upload final", "task summary", "full order description",
        "reserved time left", "reserved:", "reserveaccept", "reserve accept",
        "acceptreject", "accept reject", "reserve reject", "find orders",
        "my orders", "inbox", "my progress", "finances", "issue resolution", "help",
        "formatting style", "sources", "country of origin", "order files",
    )
    bad_exact = {
        "reserve", "accept", "reject", "order info", "operator messages",
        "more order details", "task summary", "full order description",
        "show on-line orders", "show reserved", "all deadlines", "all subjects", "all task types",
    }
    cuts = (
        r"\b\d+\s*words?\b", r"\b\d+\s*pages?\b", r"\b\d+\s*slides?\b",
        r"\b(?:days?|hours?)\s*from\s*now\b", r"\breserved\b",
    )

    # Work in the detail area before Task summary.  If the order number occurs
    # multiple times (row + drawer), the last occurrence before Task summary is
    # normally the open drawer copy, which is the one we want.
    pre = re.split(r"Task\s*summary\s*:?", text, maxsplit=1, flags=re.I)[0]
    if task_no:
        idx = pre.upper().rfind(task_no.upper())
        if idx >= 0:
            pre = pre[idx + len(task_no):]
    lines = [_one_line(x) for x in pre.splitlines() if _one_line(x)]

    def clean_candidate(line: str) -> str:
        candidate = _one_line(line)
        if task_no:
            candidate = re.sub(re.escape(task_no), "", candidate, flags=re.I).strip()
        low0 = candidate.lower().strip(" :-")
        compact = re.sub(r"\s+", "", low0)
        if not candidate or low0 in bad_exact:
            return ""
        if any(w in low0 for w in stop_words):
            return ""
        if compact in {"reserveaccept", "acceptreject", "reservereject", "reserveacceptreject"}:
            return ""
        if re.fullmatch(r"\$?\d+(?:\.\d+)?(?:\s*/?\s*(?:hour|hours|hrs|h|day|days|minutes|mins))?", low0):
            return ""
        if re.match(r"^(?:final ddl|deadline|reserved time left|you'?ll earn|a\+ level earns|size|type of work|subject)\b", low0):
            return ""
        if "$" in candidate and len(candidate) < 80:
            # Price/metadata lines are not titles.
            return ""
        dollar_idx = candidate.find("$")
        if dollar_idx > 0:
            candidate = candidate[:dollar_idx].strip()
        for pat in cuts:
            m = re.search(pat, candidate, re.I)
            if m and m.start() > 0:
                candidate = candidate[:m.start()].strip()
        candidate = _one_line(candidate).strip(" -:|")
        if len(candidate) < 4:
            return ""
        return candidate[:180]

    for line in lines:
        c = clean_candidate(line)
        if c:
            return c

    # Original-script style Topic fallback.
    m = re.search(r"\bTopic\s*:\s*([^\n]+)", text, re.I)
    if m:
        topic = _one_line(m.group(1))
        topic = re.sub(r"ATTACHED.*$", "", topic, flags=re.I).strip()
        if topic:
            return topic[:180]

    # Last fallback: row/hint text, but never button-strip garbage.
    for line in str(hint or "").splitlines():
        c = clean_candidate(line)
        if c:
            return c
    return task_no or "unknown"

def _old_style_deadline(raw: str, fallback_text: str = "") -> tuple[str, str]:
    """Return (display, Final DDL text), deliberately ignoring Reserved time left."""
    text = str(raw or "")
    ddl = ""
    m = re.search(r"Final\s*DDL\s*:\s*([^\n]+)", text, re.I)
    if m:
        ddl = _one_line(m.group(1))
    # Same order as the older Tampermonkey parser.
    m = re.search(r"(\d+(?:\.\d+)?)\s*hours?\s*from\s*now", text, re.I)
    if m:
        return (f"{float(m.group(1)):g}hrs", ddl)
    m = re.search(r"(\d+(?:\.\d+)?)\s*(?:minutes?|mins?)\s*from\s*now", text, re.I)
    if m:
        hrs = float(m.group(1)) / 60.0
        return (f"{hrs:.1f}".rstrip("0").rstrip(".") + "hrs", ddl)
    m = re.search(r"(\d+(?:\.\d+)?)\s*days?\s*from\s*now", text, re.I)
    if m:
        return (f"{float(m.group(1))*24:g}hrs", ddl)
    if re.search(r"\ba\s*day\s*from\s*now\b", text, re.I):
        return ("24hrs", ddl)
    if re.search(r"\ban?\s*hour\s*from\s*now\b", text, re.I):
        return ("1hrs", ddl)
    if re.search(r"\ba\s*minute\s*from\s*now\b", text, re.I):
        return ("0hrs", ddl)
    # Row text commonly includes '/ 9h' or '/ 48h'. Use it only as a deadline
    # fallback and never consume 'Reserved time left: 6:59'.
    fallback = _one_line(fallback_text)
    mh = re.search(r"(?:/|\b)(\d+(?:\.\d+)?)\s*h(?:rs?)?\b", fallback, re.I)
    if mh:
        return (f"{float(mh.group(1)):g}hrs", ddl)
    return (ddl or "unknown", ddl)


def _detail_snapshot_score(snap: dict | None) -> int:
    raw = str((snap or {}).get("panelText") or (snap or {}).get("panelDeepText") or "")
    if not raw:
        return -100000
    low = raw.lower()
    score = min(len(raw), 20000)
    if "task summary" in low:
        score += 12000
    if "full order description" in low:
        score += 12000
    if "final ddl" in low:
        score += 4000
    if "reserved time left" in low:
        score -= 9000
    return score


def _detail_body_segment(body: str, rid: str = "") -> str:
    """Choose the part of page text most likely to belong to the currently open order."""
    body = str(body or "")
    if not body:
        return ""
    positions = []
    rid_u = str(rid or "").strip().upper()
    body_u = body.upper()
    if rid_u:
        pos = body_u.find(rid_u)
        while pos >= 0:
            positions.append(pos)
            pos = body_u.find(rid_u, pos + 1)
    for m in _ORDER_NO_RE.finditer(body):
        positions.append(m.start())
    positions = sorted(set(positions))
    if not positions:
        for label in ("Task summary", "Full order description", "Final DDL"):
            pos = body.lower().find(label.lower())
            if pos >= 0:
                positions.append(pos)
    if not positions:
        return body[:16000]
    best = ""
    best_score = -10**9
    for pos in positions:
        seg = body[max(0, pos - 1200): min(len(body), pos + 18000)]
        score = _detail_snapshot_score({"panelText": seg})
        if rid_u and rid_u in seg.upper():
            score += 5000
        if score > best_score:
            best_score = score
            best = seg
    return best


def _best_detail_raw(snap: dict | None, rid: str = "") -> tuple[str, str]:
    """Return the richest pre-Reserve detail text available from the open drawer.

    In addition to the selected panel ancestor, use a body-text window anchored on
    Task summary / Full order description.  This is important because LR sometimes
    renders the action buttons in a sibling strip while the readable detail text is
    elsewhere in the same drawer.
    """
    snap = snap or {}
    panel = str(snap.get("panelText") or "")
    deep = str(snap.get("panelDeepText") or "")
    anchor = str(snap.get("detailAnchorText") or "")
    deep_anchor = str(snap.get("detailDeepAnchorText") or "")
    body = _detail_body_segment(str(snap.get("bodyText") or ""), rid)
    candidates = [x for x in (panel, deep, anchor, deep_anchor, body) if x.strip()]
    primary = max(candidates, key=lambda x: _detail_snapshot_score({"panelText": x}), default=panel)
    broad_parts = []
    for x in (primary, panel, deep, anchor, deep_anchor, body):
        x = str(x or "").strip()
        if x and x not in broad_parts:
            broad_parts.append(x)
    return primary, "\n".join(broad_parts)

def _meaningful_title(value: str) -> bool:
    t = _one_line(value).lower().replace(" ", "")
    if not t or t in {"reserve", "accept", "reject", "reserveaccept", "acceptreject", "reservereject"}:
        return False
    return len(t) >= 4


def capture_reservation_details(snap: dict | None, rid: str, hint: str = "", deadline_hint: str = "") -> dict:
    """Mirror the older Tampermonkey full-notification extraction as closely as possible.

    This parser is intentionally state-agnostic: it can consume the live panel both
    before and AFTER Reserve.  Adeon 1.0.18 deliberately feeds it the freshly
    reserved panel first, because that is the state the user confirmed contains the
    clearest complete order information.
    """
    snap = snap or {}
    raw, broad = _best_detail_raw(snap, rid)
    combined = raw + "\n" + broad + "\n" + str(hint or "")
    order_match = _ORDER_NO_RE.search(combined)
    task_no = order_match.group(0).upper() if order_match else str(rid or "").strip().upper()

    # Mirror the old Tampermonkey field order, but if the selected drawer text is
    # incomplete use the same page's deeper DOM text for the missing field only.
    price = _preferred_earnings_money(raw, broad)
    size = _old_style_size(raw) or _old_style_size(broad)

    # Keep the exact list-row values as a fallback. Use the same preferred earnings
    # rule everywhere: A+ earns when that value is present, otherwise You'll earn.
    row_match = None
    for row in snap.get("rows") or []:
        rno = str(row.get("orderNo") or "").strip().upper()
        rtext = str(row.get("text") or "").upper()
        if (task_no and (rno == task_no or task_no in rtext)) or (rid and rno == str(rid).strip().upper()):
            row_match = row
            break
    if row_match:
        try:
            preferred_pay = float(row_match.get("pay") or 0)
        except Exception:
            preferred_pay = 0.0
        if preferred_pay > 0:
            price = f"${preferred_pay:.2f}"
    title = _old_style_title(raw, task_no, "")
    if not _meaningful_title(title):
        title = _old_style_title(str(snap.get("panelDeepText") or ""), task_no, "")
    if not _meaningful_title(title):
        title = _old_style_title(str(hint or ""), task_no, "")
    if not _meaningful_title(title):
        title = task_no or "unknown"
    if size and size.lower() not in title.lower():
        title = f"{title} ({size})"

    deadline_display, ddl = _old_style_deadline(raw, deadline_hint or hint)
    if deadline_display == "unknown":
        deadline_display2, ddl2 = _old_style_deadline(broad, deadline_hint or hint)
        deadline_display = deadline_display2
        ddl = ddl or ddl2

    task_summary = _extract_named_section(
        raw, r"Task\s*summary\s*:?",
        ("Full order description", "Order files", "Upload final files", "Order Info", "Operator messages", "More order details"),
    ) or _extract_named_section(
        broad, r"Task\s*summary\s*:?",
        ("Full order description", "Order files", "Upload final files", "Order Info", "Operator messages", "More order details"),
    )
    full_desc = _extract_named_section(
        raw, r"Full\s*order\s*description\s*:?",
        ("Order files", "Upload final files", "Order Info", "Operator messages", "More order details"),
    ) or _extract_named_section(
        broad, r"Full\s*order\s*description\s*:?",
        ("Order files", "Upload final files", "Order Info", "Operator messages", "More order details"),
    )
    internal_id = str((row_match or {}).get("id") or "").strip()
    return {
        "taskNo": task_no or "unknown",
        "price": price,
        "title": title or "unknown",
        "deadline": deadline_display,
        "ddlText": ddl,
        "taskSummary": task_summary,
        "fullDesc": full_desc,
        "internalId": internal_id,
    }


def _reservation_detail_score(details: dict | None) -> int:
    d = details or {}
    score = 0
    task = str(d.get("taskNo") or "").strip()
    price = str(d.get("price") or "").strip()
    deadline = str(d.get("deadline") or d.get("ddlText") or "").strip()
    title = str(d.get("title") or "").strip()
    summary = str(d.get("taskSummary") or "").strip()
    full_desc = str(d.get("fullDesc") or "").strip()
    if _ORDER_NO_RE.fullmatch(task): score += 20
    if price: score += 10
    if deadline and deadline.lower() != "unknown": score += 15
    if _meaningful_title(title) and title.upper() != task.upper(): score += 20
    if summary: score += 30 + min(len(summary), 2000) // 200
    if full_desc: score += 35 + min(len(full_desc), 4000) // 250
    return score


def _reservation_details_complete(details: dict | None) -> bool:
    d = details or {}
    task = str(d.get("taskNo") or "").strip()
    title = str(d.get("title") or "").strip()
    deadline = str(d.get("deadline") or d.get("ddlText") or "").strip()
    return bool(
        _ORDER_NO_RE.fullmatch(task)
        and str(d.get("price") or "").strip()
        and deadline and deadline.lower() != "unknown"
        and _meaningful_title(title) and title.upper() != task.upper()
        and str(d.get("taskSummary") or "").strip()
        and str(d.get("fullDesc") or "").strip()
    )


def _merge_missing_reservation_details(primary: dict, fallback: dict) -> dict:
    """Fill only truly missing post-Reserve fields; never overwrite live reserved text."""
    out = dict(primary or {})
    fb = fallback or {}
    for key in ("taskNo", "price", "ddlText", "taskSummary", "fullDesc", "internalId"):
        if not str(out.get(key) or "").strip() and str(fb.get(key) or "").strip():
            out[key] = fb.get(key)
    if str(out.get("deadline") or "").strip().lower() in ("", "unknown"):
        if str(fb.get("deadline") or fb.get("ddlText") or "").strip():
            out["deadline"] = fb.get("deadline") or fb.get("ddlText")
    title = str(out.get("title") or "").strip()
    if not _meaningful_title(title) or title.upper() == str(out.get("taskNo") or "").strip().upper():
        fb_title = str(fb.get("title") or "").strip()
        if _meaningful_title(fb_title):
            out["title"] = fb_title
    return out


def build_reserved_pushover_message(details: dict) -> str:
    """Same field order/spacing as the older Tampermonkey full Accepted message, with Reserved wording."""
    import html as _html
    now = datetime.now().strftime("%H:%M")
    esc = lambda x: _html.escape(str(x or ""), quote=True)
    task_no = str(details.get("taskNo") or "unknown")
    price = str(details.get("price") or "")
    deadline = str(details.get("deadline") or details.get("ddlText") or "unknown")
    title = str(details.get("title") or "unknown")
    task_with_price = f"{esc(task_no)}</b> <b>{esc(price)}" if price else esc(task_no)
    header = (
        f"LR job reserved at <b>{esc(now)}</b>\n\n"
        f"With task number <b>{task_with_price}</b>\n\n"
        f"With final deadline <b>{esc(deadline)}</b>\n\n"
        f"Task title {esc(title)}\n\n"
    )
    body = ""
    summary = str(details.get("taskSummary") or "").strip()
    full_desc = str(details.get("fullDesc") or "").strip()
    if summary:
        body += "Task summary\n" + summary + "\n\n"
    if full_desc:
        body += "Full order description\n" + full_desc
    if not body.strip():
        body = "Order details were captured before Reserve, but no summary/description text was exposed by the page."
    max_body = max(0, 980 - len(header))
    safe_body = body if len(body) <= max_body else body[:max(0, max_body - 4)] + "\n..."
    msg = header + safe_body
    return msg if len(msg) <= 1024 else msg[:1020] + "\n..."

def is_tutoring_order_text(text: str) -> bool:
    """Fail closed on any panel/body text that identifies a tutoring order."""
    t = (text or "").lower()
    return bool("tutoring order" in t or re.search(r"(^|[^a-z])tutor(ing)?([^a-z]|$)", t))


def has_do_not_accept(text: str) -> bool:
    t = (text or "").lower().replace("’", "'").replace("‘", "'")
    return any(
        p in t
        for p in (
            "do not accept",
            "don't accept",
            "dont accept",
            "do not reserve",
            "don't reserve",
            "dont reserve",
            "do not take this order",
            "don't take this order",
            "dont take this order",
            "you will be fined",
            "you'll be fined",
        )
    )


_ORDER_NO_RE = re.compile(r"\b[A-Z]{1,6}\d{6,}-\d+\b", re.I)
_last_click_audit_ts = 0


def row_key(row: dict | None) -> str:
    """Stable public order identity when possible, otherwise the internal row id."""
    if not row:
        return ""
    order_no = str(row.get("orderNo") or "").strip()
    if order_no:
        return order_no.upper()
    text = str(row.get("text") or "")
    m = _ORDER_NO_RE.search(text)
    if m:
        return m.group(0).upper()
    rid = str(row.get("id") or "").strip()
    if rid:
        return rid
    return text[:80]


def consume_click_audit(snap: dict | None, context: str = "", expected_label: str = "") -> dict | None:
    """Consume the newest browser click audit event once and log isTrusted."""
    global _last_click_audit_ts
    click = (snap or {}).get("lastClick") or {}
    try:
        ts = int(click.get("ts") or 0)
    except Exception:
        ts = 0
    if not ts or ts <= _last_click_audit_ts:
        return None
    age_ms = int(time.time() * 1000) - ts
    if age_ms > 10000:
        _last_click_audit_ts = ts
        return None
    _last_click_audit_ts = ts
    trusted = bool(click.get("trusted"))
    text = str(click.get("text") or "").strip()
    if trusted:
        record_stat("trusted_native_clicks")
    else:
        record_stat("untrusted_clicks")
    log(
        f"DOM CLICK AUDIT | context={context or 'page'} target={text!r} "
        f"isTrusted={trusted} client=({int(click.get('clientX') or 0)},{int(click.get('clientY') or 0)})"
    )
    if expected_label and expected_label.lower() not in text.lower():
        note_issue(
            "CLICK_AUDIT_TARGET_MISMATCH",
            "Chrome received the physical click on a different labelled target than expected",
            "ERROR",
            f"expected={expected_label!r} actual={text!r} trusted={trusted}",
            throttle=0,
        )
    if expected_label and not trusted:
        note_issue(
            "CLICK_NOT_TRUSTED",
            "Chrome reported that the expected click was not a trusted native user-input event",
            "ERROR",
            f"expected={expected_label!r} actual={text!r}",
            throttle=0,
        )
    return click


def job_id(row: dict | None, snap: dict) -> str:
    # The open page/panel is more authoritative than some other eligible row.
    uid = str(snap.get("urlId") or "")
    if uid and uid.lower() not in ("all", "findorders"):
        return uid
    key = row_key(row)
    if key:
        return key
    return ""


def job_still_held(snap: dict, rid: str, hint: str) -> bool:
    """Strong reservation proof only. A row merely existing is never proof that it is still reserved."""
    if not snap or snap.get("acceptedGone"):
        return False
    rid_norm = str(rid or "").strip().upper()
    uid = str(snap.get("urlId") or "").strip().upper()
    url = str(snap.get("url") or "").upper()
    panel = str(snap.get("panelText") or "").upper()
    rows = snap.get("rows") or []
    keys = [row_key(r).upper() for r in rows]
    texts = [str(r.get("text") or "").upper() for r in rows]

    identity_matches = bool(rid_norm and (uid == rid_norm or rid_norm in url or rid_norm in panel))
    row_matches = bool(rid_norm and rid_norm in keys)
    hint_token = str(hint or "").strip().upper()[:24]
    hint_matches = bool(hint_token and any(hint_token in t for t in texts))

    # A verified Reject button tied to THIS order is the positive proof that the
    # reservation is still alive. A normal list row by itself is never enough.
    if snap.get("reject") and (identity_matches or row_matches or hint_matches):
        return True

    # Accepted state or the same order returning to Reserve are definite end states.
    if snap.get("reserve") and identity_matches and not snap.get("reject"):
        return False

    return False


def reservation_definitely_ended(snap: dict, rid: str) -> bool:
    """Return True only for a strong, same-order accepted/rejected/end-state signal."""
    if not snap:
        return False
    if snap.get("acceptedGone"):
        return True
    rid_norm = str(rid or "").strip().upper()
    if not rid_norm:
        return False
    uid = str(snap.get("urlId") or "").strip().upper()
    url = str(snap.get("url") or "").upper()
    panel = str(snap.get("panelText") or "").upper()
    identity_matches = bool(uid == rid_norm or rid_norm in url or rid_norm in panel)
    # Manual Reject normally returns this exact order to a Reserve state.
    return bool(identity_matches and snap.get("reserve") and not snap.get("reject"))


def pick_row(rows, reserved_id: str, tapped: dict[str, float], opened_once: set[str], priority_keys: set[str] | None = None, new_only: bool = False):
    now = time.time()
    best = None
    reserved_norm = str(reserved_id or "").strip().upper()
    done_norm = {str(x).strip().upper() for x in _done}
    opened_norm = {str(x).strip().upper() for x in opened_once}
    priority_norm = {str(x).strip().upper() for x in (priority_keys or set()) if str(x).strip()}
    for r in rows or []:
        key = row_key(r)
        key_norm = key.strip().upper()
        if not key:
            continue
        if new_only and key_norm not in priority_norm:
            continue
        if r.get("tutor"):
            continue
        # If the list row itself already exposes a DO NOT ACCEPT / fine warning,
        # do not even open it, much less Reserve it. The panel is checked again
        # immediately before every Reserve click as a second hard gate.
        if has_do_not_accept(str(r.get("text") or "")):
            _done.add(key_norm)
            log(f"DO NOT ACCEPT warning visible in row {key}; skipping without Reserve.")
            continue
        pay = float(r.get("pay") or 0)
        pay_source = str(r.get("paySource") or "unknown")
        pay_kind = str(r.get("payKind") or "preferred earnings")
        audit_key = f"{key_norm}|{pay:.2f}|{pay_kind}|{pay_source}"
        if audit_key not in _pay_audit_seen:
            _pay_audit_seen.add(audit_key)
            decision = "ELIGIBLE" if pay >= MIN_PAY else "SKIP UNDER/UNKNOWN $6 EARNINGS LIMIT"
            log(f"PAY CHECK | {key} | {pay_kind}=${pay:.2f} | source={pay_source} | {decision}")
        if pay < MIN_PAY:
            continue
        if key_norm in done_norm:
            continue
        if reserved_norm and key_norm == reserved_norm:
            continue
        # Once a physical row click has been sent successfully for this exact
        # order during this session, never click that same row again. F5 does
        # all future refreshing. A different/new order can still be opened.
        if key_norm in opened_norm:
            continue
        last = tapped.get(key)
        if last and now - last < ROW_RETRY_SEC:
            continue
        if best is None or pay > float(best.get("pay") or 0):
            best = r
    return best


def next_reload(i: int, last: float | None = None) -> float:
    # A fresh random 3-5 second search delay each time. The real-F5 hard floor
    # independently guarantees that no physical refresh can happen sooner than 3s.
    lo, hi = RELOAD_FAST if i % (RELOAD_FAST_N + RELOAD_SLOW_N) < RELOAD_FAST_N else RELOAD_SLOW
    return random.uniform(lo, hi)


def critical_alert_profile(waited: float) -> tuple[int, float, float, int] | None:
    """Return (slot, due_at, next_cadence, level) for the latest critical slot.

    Schedule: 4:00-5:30 every 15s, 5:30-6:00 every 10s,
    6:00-6:30 every 7.5s, then every 5s until reservation end.
    """
    waited = max(0.0, float(waited or 0.0))
    if waited < RESERVE_CRITICAL_START:
        return None

    stage1_count = int(round((RESERVE_CRITICAL_ESCALATE - RESERVE_CRITICAL_START) / RESERVE_CRITICAL_CADENCE_1))
    stage2_count = int(round((RESERVE_CRITICAL_STAGE3 - RESERVE_CRITICAL_ESCALATE) / RESERVE_CRITICAL_CADENCE_2))
    stage3_count = int(round((RESERVE_CRITICAL_STAGE4 - RESERVE_CRITICAL_STAGE3) / RESERVE_CRITICAL_CADENCE_3))

    if waited < RESERVE_CRITICAL_ESCALATE:
        local = int((waited - RESERVE_CRITICAL_START) // RESERVE_CRITICAL_CADENCE_1)
        due_at = RESERVE_CRITICAL_START + local * RESERVE_CRITICAL_CADENCE_1
        return local, due_at, RESERVE_CRITICAL_CADENCE_1, 1
    if waited < RESERVE_CRITICAL_STAGE3:
        local = int((waited - RESERVE_CRITICAL_ESCALATE) // RESERVE_CRITICAL_CADENCE_2)
        due_at = RESERVE_CRITICAL_ESCALATE + local * RESERVE_CRITICAL_CADENCE_2
        return stage1_count + local, due_at, RESERVE_CRITICAL_CADENCE_2, 2
    if waited < RESERVE_CRITICAL_STAGE4:
        local = int((waited - RESERVE_CRITICAL_STAGE3) // RESERVE_CRITICAL_CADENCE_3)
        due_at = RESERVE_CRITICAL_STAGE3 + local * RESERVE_CRITICAL_CADENCE_3
        return stage1_count + stage2_count + local, due_at, RESERVE_CRITICAL_CADENCE_3, 3

    local = int((waited - RESERVE_CRITICAL_STAGE4) // RESERVE_CRITICAL_CADENCE_4)
    due_at = RESERVE_CRITICAL_STAGE4 + local * RESERVE_CRITICAL_CADENCE_4
    return stage1_count + stage2_count + stage3_count + local, due_at, RESERVE_CRITICAL_CADENCE_4, 4


# ---------------- health checks ----------------
def startup_self_check(brain: Brain) -> bool:
    ok = True
    if not chrome_port_live():
        note_issue(
            "SELF_CHECK_PORT",
            "Startup check failed because the normal-Chrome browser integration is not live",
            "ERROR",
            throttle=0,
        )
        ok = False

    snap = brain.read()
    if not snap:
        note_issue(
            "SELF_CHECK_DOM",
            "Startup check could not read the LR Writers page",
            "ERROR",
            throttle=0,
        )
        return False

    if bool(snap.get("loggedOut")):
        hard_stop_logout("LR Writers was already logged out when the bot started")
        return False

    url = str(snap.get("url") or "")
    if "findorders" not in url.lower() and not bool(snap.get("onMyOrders")):
        note_issue(
            "SELF_CHECK_PAGE",
            "Startup is not on Find Orders or My Orders; bot will not navigate automatically",
            "WARN",
            url,
            throttle=0,
        )
        return False

    title = str(snap.get("pageTitle") or "")
    main, rend = chrome_handles(title)
    if not main or not rend:
        note_issue(
            "SELF_CHECK_WINDOW",
            "Could not identify the normal Chrome window and its page renderer",
            "ERROR",
            title,
            throttle=0,
        )
        ok = False

    inner_w = float(snap.get("innerW") or 0)
    inner_h = float(snap.get("innerH") or 0)
    if inner_w < 500 or inner_h < 300:
        note_issue(
            "SELF_CHECK_VIEWPORT",
            "Chrome viewport looks unexpectedly small",
            "ERROR",
            f"{snap.get('innerW')}x{snap.get('innerH')}",
            throttle=0,
        )
        ok = False

    mapping = _viewport_mapping(inner_w, inner_h, title) if ok else None
    if not mapping:
        note_issue(
            "SELF_CHECK_MAPPING",
            "Could not establish a reliable DOM-to-physical mouse mapping",
            "ERROR",
            throttle=0,
        )
        ok = False
    else:
        log(
            "Viewport mapping ready: "
            f"CSS {inner_w:.0f}x{inner_h:.0f} -> render "
            f"{mapping['right']-mapping['left']}x{mapping['bottom']-mapping['top']} "
            f"scale {mapping['scale_x']:.3f},{mapping['scale_y']:.3f}"
        )

        # Probe one currently visible actionable element. This catches exactly
        # the old failure where a DOM point mapped outside the actual browser.
        probe = snap.get("reserve")
        probe_name = "Reserve"
        if not probe:
            rows = snap.get("rows") or []
            probe = rows[0] if rows else None
            probe_name = "ROW"

        if probe and probe.get("vx") is not None and probe.get("vy") is not None:
            p = viewport_to_screen(
                float(probe["vx"]),
                float(probe["vy"]),
                title,
                inner_w,
                inner_h,
            )
            rect = _mapped_dom_rect(probe, snap, title)
            if not p or not rect:
                note_issue(
                    "SELF_CHECK_PROBE_MAPPING",
                    "Visible target could not be mapped to the physical browser",
                    "ERROR",
                    probe_name,
                    throttle=0,
                )
                ok = False
            else:
                x, y = p
                x1, y1, x2, y2 = rect
                if not (x1 <= x <= x2 and y1 <= y <= y2):
                    note_issue(
                        "SELF_CHECK_PROBE_OUTSIDE",
                        "Mapped target center was outside its physical target rectangle",
                        "ERROR",
                        f"{probe_name} point={p} rect={rect}",
                        throttle=0,
                    )
                    ok = False

    update_last_state(snap, startup_check="passed" if ok else "failed")
    if ok:
        mode_name = "My Orders / LABEL" if bool(snap.get("onMyOrders")) else "Find Orders"
        log(
            "Startup self-check PASSED. Normal Chrome, " + mode_name + ", "
            "live viewport scale, and physical mouse mapping are ready."
        )
    return ok


# ---------------- director ----------------
def run_bot_session() -> None:
    global _stop_reason
    mode_name = "LABELS" if _LABELS_ONLY_MODE else "PICKER"
    set_status_ticket(bot="STARTING", page="CONNECTING", job=("LABEL" if _LABELS_ONLY_MODE else "SEARCHING"), f5="WAIT", mouse="WAIT", mode=mode_name)
    if _LABELS_ONLY_MODE:
        log("Adeon label-only session starting. Picker clicks, F5, and idle mouse activity are disabled.")
    else:
        log("Adeon session starting. Physical clicks: order row, Reserve, and exact still-there confirmation. Accept and automatic Reject are forbidden.")
    log(f"Live page scan target: every {DOM_SCAN_INTERVAL*1000:.0f} ms while active; F5 is scheduled 3-5 seconds while searching with a hard 3-second minimum between real presses, and is held completely during an active reservation. Temporary network loss never terminates the worker.")
    log(f"Midnight rule: {MIDNIGHT_RULE_START_HOUR:02d}:00-{MIDNIGHT_RULE_END_HOUR:02d}:00 local, under {MIDNIGHT_REJECT_UNDER_MINUTES/60:.0f}h -> Reject cue after {MIDNIGHT_REJECT_AFTER/60:.0f} min reserved; no automatic Reject.")
    brain = Brain()
    label_sync = LabelSyncManager() if _LABELS_ONLY_MODE else None
    try:
        if not brain.attach():
            _stop_reason = "startup failed: normal-Chrome browser integration unavailable"
            if not _APP_LAST_ERROR_FILE.exists():
                write_last_error("Adeon could not prepare/connect to Chrome. See VIEW ACTIVITY LOG.")
            note_issue("STARTUP_ABORT", "Adeon stopped because it could not prepare or attach safely to Chrome", "ERROR", throttle=0)
            return
        if _LABELS_ONLY_MODE:
            # Labels use only an already-open LR Writers tab. ON LABELS refreshes or
            # navigates that same tab to My Orders. It never creates Chrome or a new tab.
            brain.prepare_labels_tab(reload_current=True)
            if label_sync:
                # Pull canonical server state first, then flush any edits that were
                # safely queued while this laptop was offline. A protocol-2 server
                # rejects stale offline overwrites but preserves them in history.
                label_sync.poll_remote(force=True)
                label_sync.push_remote(force=True)
                label_sync.poll_remote(force=True)
                brain.apply_label_state(label_sync.snapshot())
        if not startup_self_check(brain):
            _stop_reason = "startup self-check failed"
            write_last_error("Adeon connected to Chrome, but its startup safety check failed. See VIEW ACTIVITY LOG.")
            note_issue("STARTUP_ABORT", "Bot stopped because startup self-check did not pass", "ERROR", throttle=0)
            return

        last_reload=time.time(); cycle=0; next_in=next_reload(0)
        label_mode_active=False
        last_find_recovery_try=0.0
        last_f5_press_at=0.0; burst_guard_until=0.0
        last_idle=time.time(); next_idle=random.uniform(*IDLE_MOVE)
        last_idle_click=time.time(); next_idle_click=random.uniform(*IDLE_CLICK)
        idle_active_started=time.time(); idle_pause_until=0.0
        last_reserve_try=0.0; last_row_key=None
        tapped: dict[str,float]={}; opened_once:set[str]=set(); refresh_pause_until=0.0; force_refresh=False; active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""; hold_missing_since=0.0; post_accept_ready=False; last_accepted_id=""
        seen_row_keys:set[str]=set(); new_row_keys:set[str]=set(); row_baseline_captured=False
        blank_since=0.0; busy_since=0.0; last_health_log=time.time(); last_port_check=0.0
        reserved=False; reserved_at=0.0; reserved_id=""; reserved_hint=""; reserved_flags:set[str]=set()
        reservation_serial=0; reservation_alert_prefix=""; reserved_remaining_minutes:float|None=None; reserved_midnight_window=False; reserved_midnight_reject=False; last_midnight_reject_try=0.0
        reserved_details:dict={}; last_reservation_status_check=0.0; reservation_missing_checks=0; remote_absent_checks=0; pre_reserve_cache:dict[str,dict]={}
        late_reminder_slot=-1; late_reservation_alert_keys:set[str]=set()
        # One initial Reserved report per order per worker session. This is separate
        # from reminder keys so a trusted manual Accept can never cause the same
        # order to emit a second initial Reserved message if the old drawer lingers.
        reserved_notice_order_ids:set[str]=set()
        reserved_waiting_keys:set[str]=set()
        inspection_scrollbar_passes=0
        last_still_here_click=0.0
        # Safe navigation cycle requested by the user. New rows remain first priority.
        # When the random timer fires and the picker is otherwise idle, Adeon cycles:
        # My Orders -> Inbox -> My Progress -> repeat, returning to Find Orders each time.
        scheduled_nav_index = 0
        next_scheduled_nav_visit = time.time() + random.uniform(*SCHEDULED_NAV_VISIT)

        def refresh_status_ticket(page_state: str = "ONLINE") -> None:
            now_ticket = time.time()
            if _paused:
                with _pause_lock:
                    reason = str(_pause_reason or "PAUSED")
                page_label = "LOGGED OUT" if "logout" in reason.lower() or "login" in reason.lower() else page_state
                job_label = (f"RESERVED {reserved_id[:16]}" if reserved and reserved_id else "SEARCHING")
                set_status_ticket(bot="PAUSED", page=page_label, job=job_label, f5="PAUSED", mouse="PAUSED")
                return
            job_label = (f"RESERVED {reserved_id[:16]}" if reserved and reserved_id else "SEARCHING")
            scheduled_left = next_in - (now_ticket - last_reload)
            burst_left = burst_guard_until - now_ticket
            f5_left = max(0.0, scheduled_left, burst_left)
            f5_label = "HOLD RESERVED" if reserved else f"{int(round(f5_left))}s NORMAL"
            if idle_pause_until and now_ticket < idle_pause_until:
                mins = max(1, int((idle_pause_until - now_ticket + 59.0) // 60.0))
                mouse_label = f"REST {mins}m"
            else:
                active_left = max(0.0, IDLE_ACTIVE_FOR - (now_ticket - idle_active_started))
                mins = max(1, int((active_left + 59.0) // 60.0))
                mouse_label = f"ACTIVE {mins}m"
            set_status_ticket(bot="CONNECTED", page=page_state, job=job_label, f5=f5_label, mouse=mouse_label)

        refresh_status_ticket("ONLINE")

        def maybe_f5() -> None:
            nonlocal last_reload, cycle, next_in, force_refresh, last_f5_press_at, burst_guard_until
            if _stop or _paused:
                return
            # Once Reserve is confirmed, do not refresh at all. Keep the live DOM
            # scanner/watchdog active and resume F5 only after Accept/Reject/timeout.
            if reserved:
                force_refresh = False
                return

            now_f5 = time.time()

            # Hard floor only: every actual F5 must be at least 3 seconds after
            # the previous actual F5, including queued/forced refreshes.
            if last_f5_press_at and now_f5 - last_f5_press_at < F5_HARD_MIN_GAP:
                return

            def note_f5_press(sent_at: float) -> None:
                nonlocal last_f5_press_at, burst_guard_until
                if last_f5_press_at:
                    actual_gap = sent_at - last_f5_press_at
                    burst_guard_until = 0.0
                last_f5_press_at = sent_at

            if force_refresh:
                # Newly detected orders outrank even a queued/forced F5.
                if now_f5 < refresh_pause_until:
                    return
                force_refresh = False
                send_f5(brain)
                sent_at = time.time()
                note_f5_press(sent_at)
                last_reload = sent_at
                cycle += 1
                next_in = random.uniform(*RESERVED_RELOAD) if reserved else next_reload(cycle, next_in)
                next_in = max(F5_HARD_MIN_GAP, next_in)
                mode = "reserved" if reserved else "normal"
                log(f"Queued forced F5 sent. Next scheduled F5 in {next_in:.1f}s ({mode} refresh mode)")
                return

            if now_f5 < refresh_pause_until or now_f5-_last_click < 1.20 or now_f5-last_reload < max(F5_HARD_MIN_GAP, next_in):
                return
            send_f5(brain)
            sent_at = time.time()
            note_f5_press(sent_at)
            last_reload=sent_at
            cycle+=1
            next_in = random.uniform(*RESERVED_RELOAD) if reserved else next_reload(cycle,next_in)
            next_in = max(F5_HARD_MIN_GAP, next_in)
            mode = "reserved" if reserved else "normal"
            log(f"Next F5 in {next_in:.1f}s ({mode} refresh mode)")

        def clear_reserved(why: str) -> None:
            nonlocal reserved,reserved_at,reserved_id,reserved_hint,reserved_flags,hold_missing_since
            nonlocal reservation_alert_prefix,reserved_remaining_minutes,reserved_midnight_window,reserved_midnight_reject,last_midnight_reject_try
            nonlocal last_reload,next_in,cycle,reserved_details,last_reservation_status_check,reservation_missing_checks,remote_absent_checks
            nonlocal late_reminder_slot,late_reservation_alert_keys
            nonlocal active_opened_id,active_opened_hint,active_opened_deadline_text
            nonlocal force_refresh,refresh_pause_until,reserved_waiting_keys
            nonlocal inspection_scrollbar_passes
            old_prefix = reservation_alert_prefix
            log(why)
            if reserved_id:
                _done.add(str(reserved_id).strip().upper())
                opened_once.add(str(reserved_id).strip().upper())
            if old_prefix:
                cancel_alert_keys([old_prefix+":still1", old_prefix+":still5", old_prefix+":reserved"] + list(late_reservation_alert_keys))
                cancel_critical_reservation_push(old_prefix)
            clear_reservation_state()
            reserved=False; reserved_at=0.0; reserved_id=""; reserved_hint=""; reserved_flags=set(); hold_missing_since=0.0
            reservation_alert_prefix=""; reserved_remaining_minutes=None; reserved_midnight_window=False; reserved_midnight_reject=False; last_midnight_reject_try=0.0
            reserved_details={}; last_reservation_status_check=0.0; reservation_missing_checks=0; remote_absent_checks=0; reserved_waiting_keys=set()
            late_reminder_slot=-1; late_reservation_alert_keys=set()
            inspection_scrollbar_passes=0
            # A reservation that ended must never leave the dashboard attached to
            # the old order. The next live DOM scan decides what is actually open.
            active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""
            # Return to search immediately when the reservation ends. The queued F5
            # still obeys the global 3-second minimum between real F5 presses.
            refresh_pause_until = 0.0
            force_refresh = True
            last_reload = time.time()
            next_in = next_reload(cycle, None)
            log("SEARCH MODE: reservation ended; new-order scanning is active again and a safe F5 is queued.")
            update_last_state(reserved=False,reserved_id="",reserved_remaining_minutes="",midnight_reject_pending=False,next_refresh_seconds=round(next_in,1))

        def remember_pre_reserve_snapshot(snap0: dict | None, rid_hint: str = "") -> None:
            snap0 = snap0 or {}
            raw0 = str(snap0.get("panelText") or "")
            if not raw0:
                return
            keys = set()
            if rid_hint:
                keys.add(str(rid_hint).strip().upper())
            m0 = _ORDER_NO_RE.search(raw0)
            if m0:
                keys.add(m0.group(0).upper())
            uid0 = str(snap0.get("urlId") or "").strip().upper()
            if uid0 and uid0 not in ("ALL", "FINDORDERS"):
                keys.add(uid0)
            for rr in snap0.get("rows") or []:
                rno = str(rr.get("orderNo") or "").strip().upper()
                if rno and (not keys or rno in keys or rno in raw0.upper()):
                    keys.add(rno)
                    iid = str(rr.get("id") or "").strip().upper()
                    if iid:
                        keys.add(iid)
            for key in keys:
                if key:
                    old_snap = pre_reserve_cache.get(key)
                    if old_snap is None or _detail_snapshot_score(snap0) >= _detail_snapshot_score(old_snap):
                        pre_reserve_cache[key] = dict(snap0)

        def gather_pre_reserve_details(expected_id: str, initial: dict | None, seconds: float = 1.25) -> dict:
            """Take several fresh DOM reads before Reserve and keep the richest exact-order drawer.

            This is intentionally DOM reading only: no F5 and no action click. It gives
            React/LR a short moment to finish mounting the same title, deadline, Task
            summary and Full order description that the older Tampermonkey script read.
            """
            nonlocal refresh_pause_until
            expected = str(expected_id or "").strip().upper()
            best = dict(initial or {})
            remember_pre_reserve_snapshot(best, expected)
            deadline = time.time() + max(0.2, seconds)
            refresh_pause_until = max(refresh_pause_until, deadline + 0.20)
            while time.time() < deadline and not _stop and not _paused:
                cur = brain.read() or {}
                if cur:
                    uid = str(cur.get("urlId") or "").strip().upper()
                    ptxt = (str(cur.get("panelText") or "") + "\n" + str(cur.get("panelDeepText") or "")).upper()
                    id_ok = (not expected) or uid == expected or expected in ptxt or f"/{expected}" in str(cur.get("url") or "").upper()
                    if id_ok:
                        remember_pre_reserve_snapshot(cur, expected)
                        if _detail_snapshot_score(cur) > _detail_snapshot_score(best):
                            best = dict(cur)
                        low = (str(best.get("panelText") or "") + " " + str(best.get("panelDeepText") or "")).lower()
                        if "task summary" in low and "full order description" in low and "final ddl" in low:
                            break
                time.sleep(0.10)
            return best

        def gather_post_reserve_details(expected_id: str, initial: dict | None, deadline_text: str = "", seconds: float = 3.2) -> tuple[dict, dict]:
            """Read the freshly RESERVED drawer repeatedly before any Pushover is sent.

            The reserved state is authoritative for notification extraction.  We read
            innerText, textContent and the anchored body text on every 100ms DOM pass,
            exactly like the warning scanner reads DO NOT ACCEPT.  No F5 occurs here.
            We stop early only when task number, price, deadline, title, Task summary
            and Full order description are all present.
            """
            nonlocal refresh_pause_until
            expected = str(expected_id or "").strip().upper()
            best_snap = dict(initial or {})
            best_details = capture_reservation_details(best_snap, expected, expected, deadline_text)
            best_score = _reservation_detail_score(best_details)
            end = time.time() + max(0.6, seconds)
            refresh_pause_until = max(refresh_pause_until, end + 0.25)
            while time.time() < end and not _stop and not _paused:
                cur = brain.read() or {}
                if cur:
                    panel_words = "\n".join([
                        str(cur.get("panelText") or ""),
                        str(cur.get("panelDeepText") or ""),
                        str(cur.get("detailAnchorText") or ""),
                        str(cur.get("detailDeepAnchorText") or ""),
                        str(cur.get("bodyText") or ""),
                    ])
                    uid = str(cur.get("urlId") or "").strip().upper()
                    id_ok = (
                        bool(cur.get("reject"))
                        or not expected
                        or uid == expected
                        or expected in panel_words.upper()
                        or f"/{expected}" in str(cur.get("url") or "").upper()
                    )
                    if id_ok:
                        details = capture_reservation_details(cur, expected, panel_words, deadline_text)
                        score = _reservation_detail_score(details)
                        if score > best_score:
                            best_score = score
                            best_snap = dict(cur)
                            best_details = details
                        if _reservation_details_complete(details):
                            best_snap = dict(cur)
                            best_details = details
                            log(
                                "POST-RESERVE DETAILS COMPLETE | "
                                f"task={details.get('taskNo')} price={details.get('price')} "
                                f"deadline={details.get('deadline')} title={details.get('title')} "
                                f"summary_chars={len(str(details.get('taskSummary') or ''))} "
                                f"full_desc_chars={len(str(details.get('fullDesc') or ''))}"
                            )
                            return best_snap, best_details
                time.sleep(DOM_SCAN_INTERVAL)

            # The live reserved drawer remains primary.  Only if LR genuinely omitted
            # a field from that drawer do we fill that one missing field from the rich
            # snapshot captured for the same order immediately before Reserve.
            pre_candidates = []
            for ck, cached in list(pre_reserve_cache.items()):
                if ck == expected or expected in str((cached or {}).get("panelText") or "").upper():
                    pre_candidates.append(cached)
            if pre_candidates:
                pre_best = max(pre_candidates, key=_detail_snapshot_score)
                pre_details = capture_reservation_details(pre_best, expected, expected, deadline_text)
                merged = _merge_missing_reservation_details(best_details, pre_details)
                if merged != best_details:
                    log("POST-RESERVE DETAIL FALLBACK | live reserved drawer was missing one or more fields; filled only missing fields from the same order's pre-Reserve snapshot.")
                best_details = merged
            return best_snap, best_details

        def mark_reserved(rid: str, hint: str, reserve_snap: dict|None=None, deadline_text: str="") -> None:
            nonlocal reserved,reserved_at,reserved_id,reserved_hint,reserved_flags,hold_missing_since
            nonlocal reservation_serial,reservation_alert_prefix,reserved_remaining_minutes,reserved_midnight_window,reserved_midnight_reject,last_midnight_reject_try
            nonlocal last_reload,next_in,reserved_details,last_reservation_status_check,reservation_missing_checks,remote_absent_checks
            nonlocal late_reminder_slot,late_reservation_alert_keys
            nonlocal inspection_scrollbar_passes,force_refresh
            reserved=True; reserved_at=time.time(); reserved_id=(rid or hint or "job").strip().upper(); reserved_hint=hint or reserved_id; reserved_flags=set(); hold_missing_since=0.0
            last_reservation_status_check=0.0; reservation_missing_checks=0; remote_absent_checks=0
            late_reminder_slot=-1; late_reservation_alert_keys=set()
            inspection_scrollbar_passes=0
            # Reservation hold: no F5 is allowed until this reservation ends.
            # The 100ms DOM scanner and 10-second reservation watchdog remain live.
            force_refresh = False
            last_reload = reserved_at
            next_in = 999999.0
            log("RESERVED F5 HOLD: refresh is disabled until this order is accepted, rejected, or no longer reserved.")
            reservation_serial += 1
            reservation_alert_prefix = f"{reserved_id}:{int(reserved_at)}:{reservation_serial}"
            last_midnight_reject_try=0.0
            source = " ".join([deadline_text or "", str((reserve_snap or {}).get("panelText") or ""), reserved_hint])
            reserved_remaining_minutes = parse_remaining_minutes(source)
            reserved_midnight_window = in_midnight_rule_window()
            reserved_midnight_reject = bool(
                reserved_midnight_window
                and reserved_remaining_minutes is not None
                and reserved_remaining_minutes < MIDNIGHT_REJECT_UNDER_MINUTES
            )
            # IMPORTANT: read the page AFTER Reserve has changed the order into its
            # reserved state.  Do not send Pushover until the live reserved drawer has
            # been re-read repeatedly and its old-script fields have been extracted.
            # This uses the same DOM text surfaces that warning detection uses.
            best_detail_snap, reserved_details = gather_post_reserve_details(
                reserved_id, reserve_snap or {}, deadline_text, seconds=3.2
            )
            log(
                "RESERVATION DETAILS CAPTURED FROM RESERVED PANEL | "
                f"task={reserved_details.get('taskNo') or 'unknown'} | "
                f"price={reserved_details.get('price') or 'missing'} | "
                f"deadline={reserved_details.get('deadline') or 'unknown'} | "
                f"title={reserved_details.get('title') or 'missing'} | "
                f"summary_chars={len(str(reserved_details.get('taskSummary') or ''))} | "
                f"full_desc_chars={len(str(reserved_details.get('fullDesc') or ''))}"
            )
            if not str(reserved_details.get("taskSummary") or "").strip() or not str(reserved_details.get("fullDesc") or "").strip():
                note_issue(
                    "RESERVATION_DETAIL_INCOMPLETE",
                    "Reserved panel did not expose every old-style notification section after repeated DOM reads",
                    "WARN",
                    f"task={reserved_details.get('taskNo') or reserved_id} title={reserved_details.get('title') or ''}",
                    throttle=0,
                )
            public_task_no = str(reserved_details.get("taskNo") or "").strip().upper()
            if _ORDER_NO_RE.fullmatch(public_task_no) and public_task_no != reserved_id:
                old_reserved_id = reserved_id
                reserved_id = public_task_no
                reservation_alert_prefix = f"{reserved_id}:{int(reserved_at)}:{reservation_serial}"
                log(f"RESERVATION ID NORMALIZED: {old_reserved_id} -> public task number {reserved_id}.")
            opened_once.add(reserved_id)
            record_stat("reservations_confirmed")
            update_last_state(
                reserved=True,reserved_id=reserved_id,reserved_hint=reserved_hint[:180],opened_once_count=len(opened_once),
                reserved_remaining_minutes=(round(reserved_remaining_minutes,1) if reserved_remaining_minutes is not None else "unknown"),
                midnight_window_at_reserve=reserved_midnight_window,midnight_reject_pending=reserved_midnight_reject,
            )
            if reserved_midnight_reject:
                log(f"MIDNIGHT RULE ADVISORY ARMED: {reserved_id} has about {reserved_remaining_minutes:.1f} min remaining; Reject cues will be shown, but Adeon will NOT click Reject. Normal reservation alerts continue.")
                # Local laptop cue, separate from Pushover: red decision ticket + two-tone bell.
                show_action_popup("REJECT IN 1 MINUTE", "reject", duration=3.0, bell=True)
            elif reserved_midnight_window and reserved_remaining_minutes is None:
                note_issue("MIDNIGHT_DEADLINE_UNKNOWN","Midnight window is active but remaining deadline could not be parsed; the short-deadline Reject advisory is not armed","WARN",reserved_hint,throttle=0)
                show_action_popup("ACCEPT", "accept")
            else:
                # The bot never clicks Accept. This is only the same small green
                # decision cue used by the older script to tell the user what to do.
                show_action_popup("ACCEPT", "accept")
            # Reservation Pushovers: full report now, one short reminder at 1 minute, then from 4:00 an escalating emergency Critical Alert + laptop alarm until the reservation ends.
            full_message = build_reserved_pushover_message(reserved_details)
            notice_id = str(reserved_id or "").strip().upper()
            if notice_id and notice_id in reserved_notice_order_ids:
                log(f"DUPLICATE RESERVED NOTICE SUPPRESSED: {notice_id} already sent its initial Reserved report in this worker session.")
            else:
                if notice_id:
                    # Mark before queuing so even a fast stale-DOM loop cannot queue it twice.
                    reserved_notice_order_ids.add(notice_id)
                send_alert("Reserved", full_message, reservation_alert_prefix+":reserved")
            save_reservation_state({
                "reserved_id": reserved_id, "reserved_hint": reserved_hint, "reserved_at": reserved_at,
                "reservation_alert_prefix": reservation_alert_prefix, "reminder_sent": False,
                "late_reminder_slot": -1,
                "alert_schedule_version": 3,
                "reserve_notice_started": True, "details": reserved_details,
                "remaining_minutes": reserved_remaining_minutes, "midnight_window": reserved_midnight_window,
                "midnight_reject": reserved_midnight_reject,
            })

        def panel_identity(snap: dict, fallback_id: str="", fallback_hint: str="") -> tuple[str,str]:
            uid=str(snap.get("urlId") or ""); rid=uid.upper() if uid and uid.lower() not in ("all","findorders") else (fallback_id or active_opened_id)
            hint=fallback_hint or active_opened_hint
            if not hint: hint=str(snap.get("panelText") or "").replace("\n"," ").strip()[:180]
            return rid or hint or "job", hint or rid or "job"

        def wait_reject(seconds: float=3.6) -> dict:
            nonlocal refresh_pause_until
            deadline=time.time()+seconds; refresh_pause_until=max(refresh_pause_until,deadline+0.75); last={}
            while time.time()<deadline and not _stop and not _paused:
                last=brain.read()
                if last: update_last_state(last,reserved=reserved,reserved_id=reserved_id)
                if last.get("reject") or last.get("acceptedGone"): return last
                time.sleep(0.16)
            return last

        def wait_for_panel_identity(expected_id: str, seconds: float=2.4) -> tuple[dict, bool]:
            """After a new row click, never act on the old panel. Return only when URL/panel identity matches the clicked order."""
            nonlocal refresh_pause_until
            expected = str(expected_id or "").strip().upper()
            deadline = time.time() + seconds
            # F5 must not interrupt the row -> matching panel -> Reserve handoff.
            refresh_pause_until = max(refresh_pause_until, deadline + 0.25)
            last = {}
            while time.time() < deadline and not _stop and not _paused:
                last = brain.read() or {}
                if not last:
                    time.sleep(0.06)
                    continue
                uid = str(last.get("urlId") or "").strip().upper()
                url = str(last.get("url") or "").upper()
                panel_text = str(last.get("panelText") or "").upper()
                url_matches = bool(expected and (uid == expected or f"/{expected}" in url))
                public_order = bool(_ORDER_NO_RE.fullmatch(expected))
                # For normal public order numbers, require BOTH the URL identity and the
                # visible panel text to contain the new order number. This prevents the
                # previous panel's Reserve button from being mistaken for the new one.
                identity_matches = bool(url_matches and ((expected in panel_text) if public_order else True))
                if identity_matches:
                    return last, True
                time.sleep(0.06)
            return last, False

        # Recover a reservation across app STOP/START. Before restoring any lock,
        # verify the live page. If the user accepted/rejected while the bot was off,
        # discard the stale state immediately and continue searching.
        persisted = load_reservation_state()
        if persisted:
            persisted_id = str(persisted.get("reserved_id") or "").strip().upper()
            persisted_hint = str(persisted.get("reserved_hint") or persisted_id)
            first_snap = brain.read() or {}
            still_held = job_still_held(first_snap, persisted_id, persisted_hint)
            if not still_held:
                time.sleep(0.7)
                second_snap = brain.read() or {}
                still_held = job_still_held(second_snap, persisted_id, persisted_hint)
            if still_held and persisted_id:
                reserved = True
                reserved_id = persisted_id
                reserved_hint = persisted_hint
                try:
                    reserved_at = float(persisted.get("reserved_at") or time.time())
                except Exception:
                    reserved_at = time.time()
                reservation_alert_prefix = str(persisted.get("reservation_alert_prefix") or f"{reserved_id}:{int(reserved_at)}:restored")
                reserved_details = persisted.get("details") if isinstance(persisted.get("details"), dict) else {}
                try:
                    v = persisted.get("remaining_minutes")
                    reserved_remaining_minutes = None if v is None else float(v)
                except Exception:
                    reserved_remaining_minutes = None
                reserved_midnight_window = bool(persisted.get("midnight_window"))
                reserved_midnight_reject = bool(persisted.get("midnight_reject"))
                if bool(persisted.get("reminder_sent")):
                    reserved_flags.add("1")
                try:
                    if int(persisted.get("alert_schedule_version", 0) or 0) == 3:
                        late_reminder_slot = int(persisted.get("late_reminder_slot", -1))
                    else:
                        # Older builds used different start times/cadences.
                        late_reminder_slot = -1
                except Exception:
                    late_reminder_slot = -1
                late_reservation_alert_keys = set()
                opened_once.add(reserved_id)
                last_reload = time.time()
                next_in = random.uniform(*RESERVED_RELOAD)
                last_reservation_status_check = 0.0
                reservation_missing_checks = 0
                restored_waited = max(0.0, time.time() - reserved_at)
                inspection_scrollbar_passes = sum(1 for t in RESERVED_SCROLLBAR_PASS_AT if restored_waited >= t)
                record_stat("reservation_state_restores")
                log(f"RESERVATION RESTORED: {reserved_id} is still reserved. Original timer retained; status will be checked every 10 seconds.")
                update_last_state(reserved=True, reserved_id=reserved_id, restored_reservation=True)
            else:
                if persisted_id:
                    _done.add(persisted_id)
                    opened_once.add(persisted_id)
                clear_reservation_state()
                log(f"RESERVATION RECONCILED ON START: {persisted_id or 'previous order'} is no longer reserved. Stale timer cleared; searching resumes.")

        while not _stop:
            try:
                scan_cycle_started = time.perf_counter()
                if app_stop_requested():
                    try:
                        _APP_STOP_FILE.unlink(missing_ok=True)
                    except Exception:
                        pass
                    request_stop("Adeon app deactivate requested")
                    break
                # Legacy pause code is kept only for direct-script compatibility; the installed app uses START/STOP only.
                # mouse movement/clicks, or new alert scheduling occurs. A resume request
                # is validated once against the live tab before any automation restarts.
                if _paused:
                    if _resume_requested:
                        with _pause_lock:
                            globals()["_resume_requested"] = False
                            resume_source = str(globals().get("_resume_source") or "hotkey")
                            globals()["_resume_source"] = ""
                        resume_snap = brain.read() or {}
                        resume_url = str(resume_snap.get("url") or "")
                        if resume_snap and not bool(resume_snap.get("loggedOut")) and "findorders" in resume_url.lower():
                            # Re-run the full mapping/window safety check after a logout or long pause.
                            # The paused flag stays set during the check, so no mouse/F5 action can leak through.
                            resume_ok = startup_self_check(brain)
                            if resume_ok:
                                with _pause_lock:
                                    globals()["_paused"] = False
                                    globals()["_pause_reason"] = ""
                                record_stat("soft_resumes")
                                last_reload=time.time(); next_in=next_reload(cycle,next_in); force_refresh=False
                                idle_active_started=time.time(); idle_pause_until=0.0
                                last_idle=time.time(); last_idle_click=time.time()
                                log(f"{resume_source} RESUME CONFIRMED: Find Orders is open, logged in, and the safety mapping passed. Bot activity is continuing now.")
                            else:
                                log(f"{resume_source} RESUME REFUSED: Find Orders was visible but the startup safety check failed. Bot remains paused.")
                        else:
                            if bool(resume_snap.get("loggedOut")):
                                hard_stop_logout(f"LR Writers logout/login page detected during {resume_source} resume check")
                                break
                            reason = f"not on Find Orders ({resume_url or 'unknown page'})"
                            log(f"{resume_source} RESUME REFUSED: {reason}. Bot remains paused until Find Orders is open and you press Ctrl+A or Alt+A again.")
                    refresh_status_ticket("ONLINE")
                    time.sleep(0.12)
                    continue

                if _LABELS_ONLY_MODE:
                    set_status_ticket(bot="CONNECTED", page="LABELS WAIT", job="LABEL", f5="OFF", mouse="OFF", mode="LABELS")
                    # The ON LABELS button remains available even while active. A
                    # second press requests an in-place refresh/re-injection.
                    if _LABEL_REFRESH_FILE.exists():
                        try:
                            _LABEL_REFRESH_FILE.unlink(missing_ok=True)
                        except Exception:
                            pass
                        brain.prepare_labels_tab(reload_current=True)
                        if label_sync:
                            label_sync.poll_remote(force=True)
                            label_sync.push_remote(force=True)
                            label_sync.poll_remote(force=True)
                            brain.apply_label_state(label_sync.snapshot())
                        log("LABELS ON repair: current LR Writers tab refreshed in place; label state re-applied.")
                else:
                    # Scan-first rule: read the newest DOM before any F5 decision.
                    refresh_status_ticket("ONLINE")
                if _paused or stop_requested_now():
                    continue
                snap=brain.read(); now=time.time()
                if not snap:
                    if not blank_since: blank_since=now
                    elif now-blank_since>=3.0: note_issue("DOM_BLIND","No usable DOM snapshot for at least 3 seconds; worker remains alive","WARN",f"blind_for={now-blank_since:.1f}s", throttle=30.0)
                    if blank_since and now-blank_since>=10.0:
                        record_stat("reconnects"); brain.reconnect()
                        set_status_ticket(bot="CONNECTED", page="WAITING NETWORK", job=("RESERVED " + str(reserved_id or "")) if reserved else "SEARCHING", f5="WAITING", mouse="OFF")
                    time.sleep(0.2); continue
                blank_since=0.0
                if bool(snap.get("loggedOut")):
                    update_last_state(snap,reserved=reserved,reserved_id=reserved_id,logged_out=True,soft_paused=False)
                    hard_stop_logout("LR Writers logout/login page detected")
                    break

                # Exact LR keep-alive exception requested by the user. In picker mode,
                # if the visible popup says "Are you still there?", physically click
                # only its exact "Yes, I'm here" button. Accept remains forbidden.
                if (not _LABELS_ONLY_MODE) and snap.get("stillHere"):
                    if now - last_still_here_click >= 1.0:
                        if motor_click(snap.get("stillHere"), "Yes, I'm here", "still_here", snap, brain):
                            last_still_here_click = time.time()
                            log("STILL-THERE POPUP: clicked the exact Yes, I'm here confirmation button.")
                            time.sleep(0.12)
                            continue

                if _LABELS_ONLY_MODE:
                    url = str(snap.get("url") or "")
                    count = int(snap.get("labelCount") or 0)
                    local_changed = False
                    remote_changed = False
                    if label_sync:
                        local_changed = label_sync.merge_page(snap.get("labelStore") if isinstance(snap.get("labelStore"), dict) else {})
                        remote_changed = label_sync.poll_remote(force=False)
                        if remote_changed:
                            brain.apply_label_state(label_sync.snapshot())
                        if local_changed:
                            # The local snapshot/journal/outbox are already durable
                            # before any network request happens. A successful push
                            # may return a newer canonical revision or a conflict, so
                            # always re-apply the resulting protected snapshot.
                            if label_sync.push_remote(force=False):
                                brain.apply_label_state(label_sync.snapshot())
                    if bool(snap.get("onMyOrders")):
                        set_status_ticket(bot="CONNECTED", page="MY ORDERS", job="LABEL", f5="OFF", mouse="OFF", mode="LABELS")
                        update_last_state(
                            snap, label_mode=True, label_only=True, label_count=count, reserved=False, reserved_id="",
                            label_persistent_file=str(_LABEL_LOCAL_FILE),
                            label_sync=("ONLINE" if (label_sync and label_sync.configured()) else "LOCAL"),
                        )
                    else:
                        set_status_ticket(bot="CONNECTED", page="LABELS WAIT", job="LABEL", f5="OFF", mouse="OFF", mode="LABELS")
                        update_last_state(
                            snap, label_mode=False, label_only=True, label_count=0, reserved=False, reserved_id="",
                            label_persistent_file=str(_LABEL_LOCAL_FILE),
                            label_sync=("ONLINE" if (label_sync and label_sync.configured()) else "LOCAL"),
                        )
                    time.sleep(DOM_SCAN_INTERVAL)
                    continue

                rows=snap.get("rows") or []
                current_row_keys = {row_key(r).strip().upper() for r in rows if row_key(r).strip()}
                if not row_baseline_captured:
                    seen_row_keys = set(current_row_keys)
                    row_baseline_captured = True
                    log(f"NEW-ROW BASELINE: {len(seen_row_keys)} existing row(s) ignored; only rows first appearing after activation are eligible for opening.")
                else:
                    appeared = current_row_keys - seen_row_keys
                    if appeared:
                        new_row_keys.update(appeared)
                        seen_row_keys.update(appeared)
                        log("NEW ROW DETECTED: " + ", ".join(sorted(appeared)))
                    # A row that vanished is no longer actionable. It stays in seen_row_keys
                    # so an old row returning after F5 is not mistaken for a new job.
                    new_row_keys.intersection_update(current_row_keys)

                # NEW-ORDER REFRESH LOCK. Because this runs before maybe_f5(), a newly
                # detected eligible order can freeze refresh before F5 has a chance to
                # erase it. The following row -> panel -> Reserve handoff gets 10 seconds
                # of protection; its own verification helpers extend the lock as needed.
                if not reserved and new_row_keys:
                    protected_candidate = pick_row(rows, reserved_id, tapped, opened_once, new_row_keys, True)
                    if protected_candidate is not None:
                        protect_until = time.time() + 10.0
                        if protect_until > refresh_pause_until:
                            refresh_pause_until = protect_until
                            log(
                                "NEW ORDER REFRESH LOCK: eligible new order "
                                + str(row_key(protected_candidate) or "job")
                                + "; F5 frozen while row -> panel -> Reserve handoff runs."
                            )

                if not reserved and snap.get("panelOpen") and snap.get("reserve") and not snap.get("reject"):
                    try:
                        cache_rid, _cache_hint = panel_identity(snap)
                    except Exception:
                        cache_rid = ""
                    remember_pre_reserve_snapshot(snap, cache_rid)

                # Live-open reconciliation. Never keep JOB OPEN pinned to an order
                # after its panel was closed, accepted, rejected, or replaced.
                # This runs on every DOM scan, so the dashboard follows the live page
                # instead of remembering an old task number.
                if not reserved and active_opened_id:
                    live_panel_open = bool(snap.get("panelOpen"))
                    live_id, live_hint = panel_identity(snap) if live_panel_open else ("", "")
                    live_id_norm = str(live_id or "").strip().upper()
                    active_norm = str(active_opened_id or "").strip().upper()
                    if not live_panel_open or bool(snap.get("acceptedGone")):
                        old_open = active_opened_id
                        active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""
                        log(f"OPEN STATE CLEARED: {old_open} is no longer open on the live page.")
                    elif live_id_norm and active_norm and live_id_norm != active_norm:
                        old_open = active_opened_id
                        active_opened_id = live_id_norm
                        active_opened_hint = str(live_hint or live_id_norm)
                        active_opened_deadline_text = ""
                        log(f"OPEN STATE SWITCHED: {old_open} -> {active_opened_id} from the live DOM.")

                update_last_state(snap,reserved=reserved,reserved_id=reserved_id,active_opened_id=active_opened_id,opened_once_count=len(opened_once),next_refresh_seconds=round(max(0.0,next_in-(now-last_reload)),1),idle_mouse_paused=bool(idle_pause_until and now<idle_pause_until),idle_pause_remaining_seconds=round(max(0.0,idle_pause_until-now),1) if idle_pause_until else 0.0,logged_out=False,soft_paused=False)
                refresh_status_ticket("ONLINE")

                # Observe real user clicks without creating them. If you manually
                # click Accept, stop reservation alerts immediately and lock this
                # order so it can never be row-clicked again in this session.
                audit = consume_click_audit(snap, context="page")
                if audit and bool(audit.get("trusted")):
                    audit_text = str(audit.get("text") or "").strip().lower()
                    if audit_text in ("accept", "accept order"):
                        record_stat("manual_accepts")
                        accepted_id, _accepted_hint = panel_identity(snap)
                        last_accepted_id = str(accepted_id or "").strip().upper()
                        if last_accepted_id:
                            _done.add(last_accepted_id)
                            opened_once.add(last_accepted_id)
                            reserved_notice_order_ids.add(last_accepted_id)
                            new_row_keys.discard(last_accepted_id)
                        post_accept_ready = True
                        # No post-Accept delay. Cancel any row/panel pause and make the very next loop press F5.
                        refresh_pause_until = 0.0
                        force_refresh = True
                        if reserved:
                            log("Trusted manual Accept click detected. Reservation alerts stopped; old row stays locked. Immediate F5 queued; next NEW row may replace the still-open old panel.")
                            clear_reserved("You manually accepted the reserved order. No more alerts for it.")
                        else:
                            old_open = active_opened_id
                            active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""
                            log(f"Trusted manual Accept click detected. OPEN state cleared for {old_open or 'current order'}; immediate F5 queued and searching resumes.")
                        continue
                    if audit_text in ("reject", "reject order") and reserved:
                        record_stat("manual_rejects")
                        refresh_pause_until = 0.0
                        force_refresh = True
                        clear_reserved("Trusted manual Reject click detected. Reservation reminders were cancelled immediately; this order stays locked and will not be reserved again this session.")
                        continue

                if now-last_port_check>=15.0:
                    last_port_check=now
                    if not chrome_port_live():
                        note_issue("DEBUG_PORT_LOST","Normal-Chrome browser integration stopped responding; reconnecting in place without restarting Chrome","ERROR")
                        if brain.reconnect_cdp():
                            record_stat("reconnects")
                            blank_since = 0.0
                            refresh_status_ticket("ONLINE")
                            log("STABILITY RECOVERY: normal-Chrome browser integration recovered in place; Chrome was not closed or reopened.")
                if snap.get("reserve") and snap.get("reject"): note_issue("AMBIGUOUS_RESERVE_REJECT","Reserve and Reject are visible at the same time","WARN",str(snap.get("url") or ""))
                if rows:
                    missing_ids=sum(1 for r in rows if not r.get("id"))
                    if missing_ids==len(rows): note_issue("ROW_IDS_MISSING","All visible order rows are missing IDs; site HTML may have changed","WARN",f"rows={len(rows)}")
                    zero_pay=sum(1 for r in rows if float(r.get("pay") or 0)<=0 and "$" in str(r.get("text") or ""))
                    if zero_pay: note_issue("PAY_PARSE_FAILED","A visible row contains a dollar amount but pay parsed as zero","WARN",f"rows={zero_pay}")
                if now-last_health_log>=60.0:
                    last_health_log=now; log(f"HEALTH OK | rows={len(rows)} reserved={reserved} issues={len(_issues)} reads={_stats.get('dom_reads',0)}")

                row_list_key="|".join(str(r.get("id") or r.get("text") or "")[:24] for r in rows)
                if row_list_key!=last_row_key:
                    last_row_key=row_list_key
                    if rows: log("Rows: "+" | ".join(f"${float(r.get('pay') or 0):.2f} {str(r.get('text') or '')[:34]}" for r in rows[:6]))
                    else: log("Rows: none")

                url=str(snap.get("url") or "")
                if "findorders" not in url.lower():
                    # Temporary network loss must NEVER terminate the picker. Chrome/Thorium
                    # can replace the LR page with a browser error page while offline. Keep
                    # the worker/reservation state alive and use the normal search-mode F5
                    # recovery. A live reservation still keeps the absolute F5 hold.
                    if is_network_error_snapshot(snap):
                        record_stat("left_find_orders")
                        update_last_state(snap, reserved=reserved, reserved_id=reserved_id, network_wait=True)
                        set_status_ticket(bot="CONNECTED", page="WAITING NETWORK", job=("RESERVED " + str(reserved_id or "")) if reserved else "SEARCHING", f5="WAITING", mouse="OFF")
                        note_issue("NETWORK_WAIT", "Network/browser error page detected; Adeon stays alive and will recover automatically", "INFO", url[:250], throttle=30.0)
                        if (not reserved) and now-last_reload >= max(F5_HARD_MIN_GAP, next_in):
                            send_f5(brain)
                            last_reload=time.time()
                            next_in=random.uniform(NETWORK_RETRY_MIN, NETWORK_RETRY_MAX)
                            log(f"NETWORK RECOVERY: F5 sent; next retry in {next_in:.1f}s if still offline.")
                        elif reserved and now-last_reload >= max(F5_HARD_MIN_GAP, next_in):
                            note_issue("NETWORK_RESERVED_F5_HOLD", "Network error seen while reserved; F5 remains disabled until the reservation ends", "INFO", reserved_id, throttle=30.0)
                        time.sleep(DOM_SCAN_INTERVAL)
                        continue

                    # GLOBAL PICKER PAGE RECOVERY. Any normal LR Writers detour must
                    # come back to Find Orders and continue scanning. Never navigate
                    # while an order panel or reservation is active; as soon as that
                    # protected work ends, the next loop returns safely.
                    record_stat("left_find_orders")
                    protected_page = bool(reserved or snap.get("panelOpen") or snap.get("reserve") or snap.get("accept") or snap.get("reject"))
                    if protected_page:
                        set_status_ticket(bot="CONNECTED", page="OFF FIND ORDERS", job=("RESERVED " + str(reserved_id or "")) if reserved else "ORDER OPEN", f5="OFF", mouse="OFF")
                        update_last_state(snap, reserved=reserved, reserved_id=reserved_id, find_orders_recovery_wait=True)
                        note_issue("FIND_ORDERS_RECOVERY_HELD", "Adeon is off Find Orders but protected order/reservation work is active; return is held until that work ends", "INFO", url[:250], throttle=30.0)
                        time.sleep(DOM_SCAN_INTERVAL)
                        continue

                    if now - last_find_recovery_try >= 1.5:
                        last_find_recovery_try = now
                        reason = "My Orders" if bool(snap.get("onMyOrders")) else (url or "another LR Writers page")
                        if recover_to_find_orders(brain, snap, reason):
                            label_mode_active=False
                            last_reload=time.time()
                            next_in=next_reload(cycle, None)
                            update_last_state(label_mode=False, label_count=0, find_orders_recovered=True)
                            time.sleep(DOM_SCAN_INTERVAL)
                            continue
                    set_status_ticket(bot="CONNECTED", page="RETURNING FIND ORDERS", job="SEARCHING", f5="OFF", mouse="WAIT")
                    update_last_state(snap, reserved=False, reserved_id="", find_orders_recovery_wait=True)
                    time.sleep(DOM_SCAN_INTERVAL)
                    continue

                if label_mode_active:
                    label_mode_active=False
                    last_reload=time.time()
                    next_in=next_reload(cycle, None)
                    log("LABEL MODE ENDED: Find Orders is back. Picker searching/F5 schedule resumed automatically.")
                    update_last_state(snap, label_mode=False, label_count=0)

                # Scheduled navigation cycle. NEW ROWS are always the priority. A
                # due detour runs only when Find Orders is idle with no open order panel,
                # then remains there for two minutes before returning to Find Orders. Rows that
                # appeared during the detour are detected as new as soon as the page returns.
                if (not reserved and now >= next_scheduled_nav_visit and bool(snap.get("onFind"))
                        and not bool(snap.get("panelOpen")) and not new_row_keys):
                    destination = SCHEDULED_NAV_SEQUENCE[scheduled_nav_index % len(SCHEDULED_NAV_SEQUENCE)]
                    if perform_scheduled_navigation_visit(brain, snap, destination):
                        scheduled_nav_index = (scheduled_nav_index + 1) % len(SCHEDULED_NAV_SEQUENCE)
                        last_reload = time.time()
                        next_in = next_reload(cycle, None)
                        snap = brain.read() or snap
                    next_scheduled_nav_visit = time.time() + random.uniform(*SCHEDULED_NAV_VISIT)

                if reserved:
                    waited=time.time()-reserved_at

                    # RESERVED-PANEL SCROLLBAR MOTION. There is no F5 while held.
                    # During the first minute Adeon touches only the visible scrollbar.
                    # It performs exactly two quick physical down-and-up thumb drags and
                    # does not use the mouse wheel or open any Files/accordion control.
                    if inspection_scrollbar_passes < len(RESERVED_SCROLLBAR_PASS_AT):
                        due_at = RESERVED_SCROLLBAR_PASS_AT[inspection_scrollbar_passes]
                        if waited >= due_at and waited < RESERVE_REMINDER_AFTER:
                            pass_number = inspection_scrollbar_passes + 1
                            drag_reserved_panel_scrollbar_cycle(snap, brain, pass_number)
                            inspection_scrollbar_passes += 1
                            snap = brain.read() or snap

                    # HARD RESERVATION HOLD: rows are still scanned every 100 ms, but
                    # while one order is genuinely reserved Adeon must not click/open
                    # any other job. New jobs simply wait in the list until the current
                    # reservation ends through manual Accept/Reject, auto-Reject, expiry,
                    # or the 10-second reservation watchdog.
                    waiting_now=set()
                    current_norm=str(reserved_id or "").strip().upper()
                    done_now={str(x).strip().upper() for x in _done}
                    for wr in rows:
                        wk=row_key(wr).strip().upper()
                        if not wk or wk == current_norm or wk in done_now:
                            continue
                        if wr.get("tutor") or has_do_not_accept(str(wr.get("text") or "")):
                            continue
                        try:
                            if float(wr.get("pay") or 0) < MIN_PAY:
                                continue
                        except Exception:
                            continue
                        waiting_now.add(wk)
                    if waiting_now != reserved_waiting_keys:
                        reserved_waiting_keys = waiting_now
                        if reserved_waiting_keys:
                            log(f"RESERVED HOLD: {len(reserved_waiting_keys)} other eligible job(s) visible; none will be clicked until {reserved_id} is accepted/rejected or otherwise leaves reserved state.")
                        else:
                            log("RESERVED HOLD: no other eligible jobs are currently waiting.")

                    # Independent reservation watchdog. Every 10 seconds, verify that
                    # THIS exact order is still reserved. Two consecutive misses are
                    # required to survive a brief F5/DOM transition, then stale state
                    # is cleared and normal searching resumes automatically.
                    if now-last_reservation_status_check >= RESERVATION_STATUS_CHECK:
                        last_reservation_status_check = now
                        record_stat("reservation_status_checks")
                        # A phone Accept/Reject does not necessarily mutate the laptop's
                        # already-open reserved DOM. Use a fresh hidden authenticated read
                        # every 10 seconds so remote actions end reminders without touching
                        # or refreshing the user's visible order panel.
                        remote_probe = brain.fresh_reservation_probe(reserved_id, str(reserved_details.get("internalId") or ""))
                        remote_status = str(remote_probe.get("status") or "unknown")
                        if remote_status == "ended":
                            refresh_pause_until = 0.0
                            force_refresh = True
                            clear_reserved(f"Fresh 10-second server check confirmed {reserved_id} is no longer reserved ({remote_probe.get('source') or 'remote state'}). All reminders cancelled; searching resumes.")
                            continue
                        if remote_status == "absent":
                            remote_absent_checks += 1
                            log(f"REMOTE RESERVATION CHECK: {reserved_id} absent from fresh Find Orders ({remote_absent_checks}/2).")
                            if remote_absent_checks >= 2:
                                refresh_pause_until = 0.0
                                force_refresh = True
                                clear_reserved(f"Two fresh server checks confirmed {reserved_id} is absent from reserved orders. Remote Accept/Reject/expiry recognized; reminders cancelled.")
                                continue
                        elif remote_status == "held":
                            remote_absent_checks = 0
                            reservation_missing_checks = 0
                            hold_missing_since = 0.0
                            log(f"REMOTE RESERVATION CHECK: {reserved_id} still reserved ({remote_probe.get('source') or 'fresh read'}).")
                        held_now = job_still_held(snap,reserved_id,reserved_hint)
                        if reservation_definitely_ended(snap, reserved_id):
                            if snap.get("acceptedGone"):
                                last_accepted_id = str(reserved_id or "").strip().upper()
                                post_accept_ready = True
                            refresh_pause_until = 0.0
                            force_refresh = True
                            clear_reserved("10-second reservation check found a definite accepted/rejected end state. Stale reservation state cleared; searching resumes.")
                            continue
                        if held_now:
                            reservation_missing_checks = 0
                            hold_missing_since = 0.0
                        else:
                            reservation_missing_checks += 1
                            log(f"RESERVATION CHECK: {reserved_id} not confirmed reserved ({reservation_missing_checks}/2).")
                            if reservation_missing_checks >= 2:
                                old_id = reserved_id
                                refresh_pause_until = 0.0
                                force_refresh = True
                                clear_reserved(f"10-second reservation checks confirmed {old_id} is no longer reserved (accepted/rejected/expired). Stale timer cleared; searching resumes.")
                                continue

                    # If the deadline was not readable at the instant of reservation, try again
                    # from the live reserved panel/row while the midnight window snapshot is active.
                    if reserved_midnight_window and reserved_remaining_minutes is None:
                        live_source = str(snap.get("panelText") or "")
                        for rr in rows:
                            if row_key(rr).strip().upper() == str(reserved_id).strip().upper():
                                live_source += " " + deadline_source_for_row(rr)
                                break
                        maybe_minutes = parse_remaining_minutes(live_source)
                        if maybe_minutes is not None:
                            reserved_remaining_minutes = maybe_minutes
                            reserved_midnight_reject = maybe_minutes < MIDNIGHT_REJECT_UNDER_MINUTES
                            st = load_reservation_state()
                            if st:
                                st["remaining_minutes"] = maybe_minutes
                                st["midnight_reject"] = reserved_midnight_reject
                                save_reservation_state(st)
                            update_last_state(reserved_remaining_minutes=round(maybe_minutes,1),midnight_reject_pending=reserved_midnight_reject)
                            if reserved_midnight_reject:
                                log(f"MIDNIGHT RULE ADVISORY ARMED LATE: {reserved_id} has about {maybe_minutes:.1f} min remaining; a Reject cue is due at the 1-minute reservation mark, but Adeon will NOT click Reject.")

                    # Midnight short-deadline rule is ADVISORY ONLY. Keep the same
                    # local Reject cue, but never physically click Reject. The order
                    # remains reserved and follows the normal Pushover + Critical Alert
                    # sequence exactly like every other reservation.
                    if reserved_midnight_reject and waited >= MIDNIGHT_REJECT_AFTER and "midnight_reject_cue" not in reserved_flags:
                        reserved_flags.add("midnight_reject_cue")
                        log(f"MIDNIGHT RULE ADVISORY: 1 minute reached for {reserved_id}; showing the Reject cue only. Adeon will NOT click Reject.")
                        show_action_popup("REJECT", "reject", duration=2.2, bell=False)
                        update_last_state(midnight_reject_pending=True, midnight_reject_advisory_only=True)

                    # Reservation notifications:
                    # 1) full report at Reserve (sent in mark_reserved)
                    # 2) one short "still reserved" at 1 minute
                    # 3) from exactly 4:00 onward, Critical Alert stays active until the
                    #    reservation ends. It starts every 15 seconds and escalates from
                    #    5:30 to 10s, then 7.5s, then 5s. Each slot gets two fresh strong
                    #    checks first; clear_reserved() cancels all queued/live reminders.
                    if waited >= RESERVE_REMINDER_AFTER and "1" not in reserved_flags and reservation_alert_prefix:
                        reminder_key = reservation_alert_prefix+":still1"
                        if reminder_key in _alerted:
                            reserved_flags.add("1")
                            st = load_reservation_state()
                            if st:
                                st["reminder_sent"] = True
                                save_reservation_state(st)
                        else:
                            confirm1 = job_still_held(snap,reserved_id,reserved_hint)
                            confirm_snap = {}
                            if confirm1:
                                time.sleep(DOM_SCAN_INTERVAL)
                                confirm_snap = brain.read() or {}
                            confirm2 = bool(confirm_snap and job_still_held(confirm_snap,reserved_id,reserved_hint))
                            if confirm1 and confirm2 and reserved and reservation_alert_prefix:
                                send_alert("still reserved",f"still reserved {reserved_id}",reminder_key)
                            elif reservation_definitely_ended(confirm_snap or snap, reserved_id):
                                refresh_pause_until = 0.0
                                force_refresh = True
                                clear_reserved("1-minute reminder check found the order already accepted/rejected. Reminder cancelled; searching resumes.")
                                continue

                    # CRITICAL RESERVATION ALERT LOOP. Begins exactly at 4:00 and
                    # continues until the reservation ends. Frequency escalates from
                    # 5:30 onward: 15s -> 10s -> 7.5s -> 5s. Each slot gets two fresh
                    # same-order checks before either Pushover or the laptop alarm fires.
                    critical = critical_alert_profile(waited)
                    if critical and reservation_alert_prefix:
                        current_late_slot, due_at, next_cadence, alert_level = critical
                        if current_late_slot > late_reminder_slot:
                            late_key = reservation_alert_prefix + f":critical-{current_late_slot}"
                            confirm1 = job_still_held(snap,reserved_id,reserved_hint)
                            confirm_snap = {}
                            if confirm1:
                                time.sleep(DOM_SCAN_INTERVAL)
                                confirm_snap = brain.read() or {}
                            confirm2 = bool(confirm_snap and job_still_held(confirm_snap,reserved_id,reserved_hint))
                            if confirm1 and confirm2 and reserved and reservation_alert_prefix:
                                late_reminder_slot = current_late_slot
                                late_reservation_alert_keys.add(late_key)
                                mins = waited / 60.0
                                send_critical_reservation_alert(
                                    f"CRITICAL ALERT L{alert_level} - RESERVATION STILL ACTIVE",
                                    f"{reserved_id} is still reserved after {mins:.1f} minutes. Accept or reject it now. Critical alerts will continue until the reservation ends.",
                                    late_key,
                                )
                                play_loud_reservation_bell(late_key, alert_level)
                                st = load_reservation_state()
                                if st:
                                    st["late_reminder_slot"] = late_reminder_slot
                                    st["alert_schedule_version"] = 3
                                    st["critical_level"] = alert_level
                                    save_reservation_state(st)
                                log(
                                    f"CRITICAL RESERVATION ALERT L{alert_level}: Pushover emergency + "
                                    f"levelled laptop alarm at {waited:.1f}s; next cadence {next_cadence:g}s while still reserved."
                                )
                            elif reservation_definitely_ended(confirm_snap or snap, reserved_id):
                                refresh_pause_until = 0.0
                                force_refresh = True
                                clear_reserved("Critical alert check found the order already accepted/rejected/timed out. All remaining alerts cancelled; searching resumes.")
                                continue

                # Never select/click another row while the current reservation is alive.
                # The rows are still being scanned above so a waiting job is noticed, but
                # it cannot be opened until clear_reserved() returns the bot to SEARCHING.
                extra=None if reserved else pick_row(rows,reserved_id,tapped,opened_once,new_row_keys,True); panel=snap.get("panelText") or ""
                # After a trusted/manual Accept, LR Writers may leave the accepted order panel open.
                # If a different NEW eligible row exists, ignore only that stale old panel and click the new row once.
                post_accept_new_row = bool((not reserved) and post_accept_ready and extra and row_key(extra).strip().upper() != last_accepted_id)
                if reserved:
                    # Reservation logic above owns the session. During the first minute
                    # the ONLY automated mouse action is the two verified scrollbar-thumb
                    # down/up cycles above. No idle move, idle click, wheel, accordion,
                    # row click, or F5 path is allowed to fall through from here.
                    busy_since=0.0
                    refresh_status_ticket("ONLINE")
                    scan_elapsed = time.perf_counter() - scan_cycle_started
                    if scan_elapsed < DOM_SCAN_INTERVAL:
                        time.sleep(DOM_SCAN_INTERVAL - scan_elapsed)
                    continue
                elif post_accept_new_row:
                    busy_since=0.0
                    log(f"POST-ACCEPT NEW ROW: old panel may still be open, but new order {row_key(extra)} is available; opening it immediately with the physical mouse.")
                elif has_do_not_accept(panel):
                    rid,_=panel_identity(snap); log("DO NOT ACCEPT. Skipping this exact open order. Never clicking Accept.")
                    if rid:
                        rid_norm=str(rid).strip().upper(); _done.add(rid_norm); opened_once.add(rid_norm)
                    active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""; extra=pick_row(rows,reserved_id,tapped,opened_once,new_row_keys,True); busy_since=0.0
                elif snap.get("reject"):
                    busy_since=0.0
                    if not reserved:
                        rid,hint=panel_identity(snap); log("Reject is showing. Reserved. Never clicking Accept."); mark_reserved(rid,hint,snap,active_opened_deadline_text)
                elif snap.get("reserve"):
                    busy_since=0.0; pos=snap["reserve"]; rid,hint=panel_identity(snap)
                    if time.time()-last_reserve_try>=RESERVE_RETRY_SEC:
                        last_reserve_try=time.time()
                        preview = viewport_to_screen(
                            float(pos.get("vx") or 0),
                            float(pos.get("vy") or 0),
                            str(snap.get("pageTitle") or ""),
                            float(snap.get("innerW") or 0),
                            float(snap.get("innerH") or 0),
                        )
                        log(
                            f"Reserve visible at DOM ({int(pos.get('vx') or 0)}, {int(pos.get('vy') or 0)}) "
                            f"mapped {preview} — attempting"
                        )
                        # HARD PRE-RESERVE WARNING GATE: re-read the live panel at the
                        # last possible moment. A DO NOT ACCEPT / fine warning means
                        # Reserve is forbidden, even if it appeared after the prior scan.
                        pre_reserve = gather_pre_reserve_details(rid, brain.read() or snap, 1.25)
                        if has_do_not_accept(pre_reserve.get("panelText") or ""):
                            log(f"DO NOT ACCEPT appeared immediately before Reserve for {rid}; Reserve cancelled and order locked out.")
                            rid_norm=str(rid or "").strip().upper()
                            if rid_norm:
                                _done.add(rid_norm); opened_once.add(rid_norm)
                            active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""
                            continue
                        if pre_reserve.get("reserve"):
                            pos = pre_reserve["reserve"]
                            snap = pre_reserve
                        if motor_click(pos,"Reserve","reserve",snap,brain):
                            check=wait_reject(3.6)
                            if check.get("reject"):
                                rid2,hint2=panel_identity(check,rid,hint); log("Reject appeared. Reserved confirmed. Never clicking Accept."); mark_reserved(rid2,hint2,check,active_opened_deadline_text)
                            elif check.get("acceptedGone"): note_issue("RESERVE_STATE_UNEXPECTED","Page moved to accepted state while waiting for Reserve confirmation","WARN",rid,throttle=0)
                            else:
                                shot = capture_diagnostic("reserve_unconfirmed", min_interval=6.0)
                                note_issue(
                                    "RESERVE_UNCONFIRMED",
                                    "Reserve was clicked but Reject confirmation was not seen within 3.6 seconds",
                                    "WARN",
                                    f"{rid} screenshot={shot}",
                                    throttle=0,
                                )
                    continue
                elif snap.get("accept") or (snap.get("panelOpen") and snap.get("reserveDisabled")):
                    # An unreserved unresolved/stale panel must never pin Adeon to that
                    # order. Keep the row scanner alive; if another eligible job exists
                    # it may be opened, otherwise normal F5 searching continues.
                    if not busy_since:
                        busy_since=now
                    elif now-busy_since>=2.0:
                        note_issue("UNRESERVED_PANEL_IGNORED","Unreserved panel stayed unresolved; Adeon is continuing to search instead of staying fixed to it","INFO",str(snap.get("url") or ""),throttle=10.0)
                        if active_opened_id:
                            old_open=active_opened_id
                            active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""
                            log(f"SEARCH MODE: stopped displaying OPEN {old_open}; no active reservation exists, so row scanning continues.")
                else: busy_since=0.0

                if extra:
                    rid=row_key(extra); new_row_keys.discard(str(rid).strip().upper()); log("Opening NEW row once "+str(extra.get("text") or "")[:50]); tapped[rid]=time.time()
                    active_opened_id=rid; active_opened_hint=str(extra.get("text") or rid); active_opened_deadline_text=deadline_source_for_row(extra); refresh_pause_until=max(refresh_pause_until,time.time()+2.5)
                    if motor_click(extra,"ROW","row",snap,brain):
                        opened_once.add(str(rid).strip().upper())
                        log(f"ROW ONE-CLICK LOCK: {rid} will not be clicked again this session. F5 will refresh it; another new order can be opened only while no order is actively reserved.")
                        update_last_state(active_opened_id=active_opened_id,opened_once_count=len(opened_once))
                        # Critical stale-panel protection: do not inspect/click Reserve until the URL/panel identity
                        # proves that the newly clicked row has actually replaced any previously open panel.
                        opened, identity_ok = wait_for_panel_identity(rid, 2.4)
                        if not identity_ok:
                            note_issue(
                                "NEW_ROW_PANEL_IDENTITY_NOT_READY",
                                "New row was clicked, but the open panel never proved it belonged to that order; Reserve was not touched",
                                "WARN",
                                f"expected={rid} current_url={str((opened or {}).get('url') or '')}",
                                throttle=0,
                            )
                            snap=opened or snap; rows=snap.get("rows") or rows
                        else:
                            if post_accept_ready:
                                post_accept_ready=False
                                log(f"POST-ACCEPT PANEL SWITCH CONFIRMED: {rid}. Old accepted panel has been replaced by the new order.")
                            snap=opened or snap; rows=snap.get("rows") or rows; update_last_state(snap,active_opened_id=active_opened_id)
                        if identity_ok and is_tutoring_order_text(snap.get("panelText") or ""):
                            log(f"TUTORING ORDER HARD BLOCK after panel identity for {rid}; never reserving it.")
                            _done.add(str(rid).strip().upper()); opened_once.add(str(rid).strip().upper()); active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""
                        elif identity_ok and has_do_not_accept(snap.get("panelText") or ""):
                            log("DO NOT ACCEPT after open. Skipping this exact order."); _done.add(str(rid).strip().upper()); opened_once.add(str(rid).strip().upper()); active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""
                        elif identity_ok and snap.get("reject"):
                            if not reserved: log("Reject after open. Reserved."); mark_reserved(rid,str(extra.get("text") or rid),snap,deadline_source_for_row(extra))
                        elif identity_ok and snap.get("reserve"):
                            # HARD PRE-RESERVE WARNING GATE again after row-open identity proof.
                            pre_reserve = gather_pre_reserve_details(rid, brain.read() or snap, 1.25)
                            if is_tutoring_order_text(pre_reserve.get("panelText") or ""):
                                log(f"TUTORING ORDER detected immediately before Reserve for {rid}; skipping without Reserve.")
                                _done.add(str(rid).strip().upper()); opened_once.add(str(rid).strip().upper())
                                active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""
                                continue
                            if has_do_not_accept(pre_reserve.get("panelText") or ""):
                                log(f"DO NOT ACCEPT appeared immediately before Reserve for {rid}; skipping without Reserve.")
                                _done.add(str(rid).strip().upper()); opened_once.add(str(rid).strip().upper())
                                active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""
                                continue
                            if pre_reserve.get("reserve"):
                                snap = pre_reserve
                            pos=snap["reserve"]; log("Reserve appeared after row open — clicking"); last_reserve_try=time.time()
                            if motor_click(pos,"Reserve","reserve",snap,brain):
                                check=wait_reject(3.6)
                                if check.get("reject"):
                                    rid2,hint2=panel_identity(check,rid,str(extra.get("text") or rid)); log("Reject appeared. Reserved confirmed."); mark_reserved(rid2,hint2,check,active_opened_deadline_text)
                                elif check.get("acceptedGone"): note_issue("RESERVE_STATE_UNEXPECTED","Page moved to accepted state while waiting for Reserve confirmation","WARN",rid,throttle=0)
                                else:
                                    shot = capture_diagnostic("reserve_unconfirmed_after_open", min_interval=6.0)
                                    note_issue(
                                        "RESERVE_UNCONFIRMED",
                                        "Reserve clicked after opening row but confirmation was not seen",
                                        "WARN",
                                        f"{rid} screenshot={shot}",
                                        throttle=0,
                                    )
                        elif identity_ok:
                            note_issue("ROW_PANEL_NOT_READY","New row panel identity matched, but Reserve/Reject did not appear during initial wait","INFO",rid)

                # Idle-only mouse rhythm: roam/click normally for five minutes, then
                # stop ALL idle mouse activity for a random 3-20 minutes. Job row,
                # Reserve/Reject safety actions and F5 are NOT paused by this rest.
                idle_now = time.time()
                if idle_pause_until:
                    if idle_now >= idle_pause_until:
                        idle_pause_until = 0.0
                        idle_active_started = idle_now
                        last_idle = idle_now
                        last_idle_click = idle_now
                        next_idle = random.uniform(*IDLE_MOVE)
                        next_idle_click = random.uniform(*IDLE_CLICK)
                        log("IDLE MOUSE RESUMED after random rest; new 1-minute active window started.")
                elif idle_now - idle_active_started >= IDLE_ACTIVE_FOR:
                    rest_for = random.uniform(*IDLE_REST)
                    idle_pause_until = idle_now + rest_for
                    record_stat("idle_pause_cycles")
                    log(f"IDLE MOUSE PAUSED for {rest_for/60:.1f} minutes after 5 active minutes. F5 and real job clicks continue.")
                else:
                    if idle_now-last_idle>=next_idle:
                        idle_mouse(snap, allow_click=False)
                        last_idle=idle_now
                        next_idle=random.uniform(*IDLE_MOVE)

                    if idle_now-last_idle_click>=next_idle_click:
                        idle_mouse(snap, allow_click=True)
                        last_idle_click=idle_now
                        next_idle_click=random.uniform(*IDLE_CLICK)

                refresh_status_ticket("ONLINE")
                maybe_f5()
                # Target one live DOM/row scan every 100 ms during ordinary
                # operation. Action/reload transitions may briefly take longer, but
                # we never intentionally sleep past the 100 ms scan cadence here.
                scan_elapsed = time.perf_counter() - scan_cycle_started
                if scan_elapsed < DOM_SCAN_INTERVAL:
                    time.sleep(DOM_SCAN_INTERVAL - scan_elapsed)
            except KeyboardInterrupt:
                request_stop(); break
            except Exception:
                record_stat("loop_errors"); note_issue("LOOP_ERROR","Unexpected main-loop error; bot continued","ERROR",traceback.format_exc(),throttle=0); time.sleep(0.6)

        if _stop_reason=="normal shutdown": _stop_reason="stop flag requested"
        final_page = "LOGGED OUT" if "logout" in str(_stop_reason).lower() or "login" in str(_stop_reason).lower() else "OFF"
        set_status_ticket(bot="STOPPED", page=final_page, f5="OFF", mouse="OFF")
        log("Stopped.")
    finally:
        final_page = "LOGGED OUT" if "logout" in str(_stop_reason).lower() or "login" in str(_stop_reason).lower() else "OFF"
        set_status_ticket(bot="STOPPED", page=final_page, f5="OFF", mouse="OFF")
        try:
            if label_sync:
                label_sync.close()
        except Exception:
            pass
        try: brain.close()
        except Exception as e: note_issue("BRAIN_CLOSE_ERROR","Error while closing browser connection","WARN",str(e),throttle=0)
        write_shutdown_report(_stop_reason)


def reset_session_state() -> None:
    """Reset per-run state so every Alt+S START is a clean new bot session/report."""
    global SESSION_STARTED_AT, SESSION_ID, _SESSION_LOG, _REPORT_LOCAL, _REPORT_VISIBLE
    global _report_written, _stop_reason, _stop, _paused, _pause_reason, _resume_requested, _resume_source
    global _last_click, _last_idle_dir, _last_diag_shot, _debug_chrome_pid, _debug_port, _debug_endpoint, _debug_user_data_dir

    SESSION_STARTED_AT = time.time()
    SESSION_ID = datetime.now().strftime("%Y%m%d_%H%M%S")
    _SESSION_LOG = _REPORT_DIR / f"Adeon Session {SESSION_ID}.log"
    _REPORT_LOCAL = _REPORT_DIR / f"Adeon Report {SESSION_ID}.txt"
    _REPORT_VISIBLE = _VISIBLE_REPORT_DIR / f"Adeon Report {SESSION_ID}.txt"
    _report_written = False
    _stop_reason = "normal shutdown"
    _stop = False
    _paused = False
    _pause_reason = ""
    _resume_requested = False
    _resume_source = ""
    _last_click = 0.0
    _last_idle_dir = ""
    _last_diag_shot = 0.0
    _debug_chrome_pid = 0
    _debug_port = 0
    _debug_endpoint = ""
    _debug_user_data_dir = ""
    _done.clear()
    with _alert_lock:
        _alerted.clear()
        _alert_last_try.clear()
        _alert_inflight.clear()
        _alert_cancelled.clear()
    with _issue_lock:
        _issues.clear()
        _issue_last.clear()
    _last_state.clear()
    for key in list(_stats):
        _stats[key] = 0


def _session_thread_entry() -> None:
    global _controller_active
    try:
        run_bot_session()
    finally:
        with _controller_lock:
            _controller_active = False
        set_status_ticket(bot="STOPPED", page="OFF", job="-", f5="OFF", mouse="OFF")


def main() -> None:
    """Adeon Bot is worker-only. The visible controller is Adeon.exe / Adeon App.pyw.

    This deliberately removes the old source-controller mode that could leave a
    black Python/CMD window open. If this .py file is accidentally launched by
    itself, it simply asks Windows to open the Adeon app and exits.
    """
    global _stop
    dpi_aware()
    if _APP_WORKER_MODE:
        try:
            _APP_STOP_FILE.unlink(missing_ok=True)
            _APP_LAST_ERROR_FILE.unlink(missing_ok=True)
        except Exception:
            pass
        # Reset first so every lifecycle line belongs to the same report/log.
        reset_session_state()
        start_app_stop_watchdog()
        log("WORKER | Activate received; starting fresh Adeon worker.")
        log(f"WORKER | PID={os.getpid()} mode=app-worker base={_BASE_DIR}")
        # The visible Adeon app owns the persistent bottom-left dashboard so it
        # remains visible even after this worker is DEACTIVATED.
        set_status_ticket(bot="STARTING", page="CONNECTING", job=("LABEL" if _LABELS_ONLY_MODE else "SEARCHING"), f5="WAIT", mouse="WAIT", mode=("LABELS" if _LABELS_ONLY_MODE else "PICKER"))
        run_bot_session()
        return

    # Never run the legacy Alt+S/source-controller loop from the editable script.
    # Starting the source directly should result in the real Adeon app, not a terminal.
    try:
        base = _BASE_DIR
        exe = base / "Adeon.exe"
        app = base / "Adeon App.pyw"
        if exe.exists():
            subprocess.Popen(
                [str(exe)], cwd=str(base),
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
        elif app.exists():
            pyw = Path(sys.executable).with_name("pythonw.exe")
            runner = str(pyw if pyw.exists() else sys.executable)
            subprocess.Popen(
                [runner, str(app)], cwd=str(base),
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass
    return


if __name__ == "__main__":
    main()
