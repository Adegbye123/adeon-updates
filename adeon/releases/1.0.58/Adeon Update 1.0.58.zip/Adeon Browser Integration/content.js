(() => {
  "use strict";
  if (window.__adeonBridgeContentInstalled) return;
  window.__adeonBridgeContentInstalled = true;
  window.__adeonLabelsEnabled = (localStorage.getItem("__adeonLabelsEnabledV1") === "1");
  const pendingResults = {};
  let bridgeSeq = 0;

  function adeonScan() {

  // Passive click audit only. It never blocks, changes, or creates a click.
  // It lets the log prove whether Chrome received a native/trusted click.
  if (!window.__lrBotClickAuditInstalled) {
    window.__lrBotClickAuditInstalled = true;
    window.__lrBotLastClick = null;
    try {
      const saved = sessionStorage.getItem("__lrBotLastClick");
      if (saved) window.__lrBotLastClick = JSON.parse(saved);
    } catch (_) {}
    document.addEventListener("click", (ev) => {
      try {
        const path = (typeof ev.composedPath === "function") ? ev.composedPath() : [ev.target];
        const clickable = path.find((e) => e && e.nodeType === 1 && e.matches &&
          e.matches('button, a, [role="button"], input[type="button"]'));
        const el = clickable || ev.target;
        const text = String((el && (el.innerText || el.value)) || "").replace(/\s+/g, " ").trim();
        window.__lrBotLastClick = {
          ts: Date.now(),
          trusted: !!ev.isTrusted,
          text: text.slice(0, 120),
          tag: String((el && el.tagName) || ""),
          clientX: Number(ev.clientX || 0),
          clientY: Number(ev.clientY || 0),
          screenX: Number(ev.screenX || 0),
          screenY: Number(ev.screenY || 0)
        };
        try { sessionStorage.setItem("__lrBotLastClick", JSON.stringify(window.__lrBotLastClick)); } catch (_) {}
      } catch (_) {}
    }, true);
  }

  const vp = (el) => {
    if (!el) return null;
    const r = el.getBoundingClientRect();
    if (r.width < 6 || r.height < 6) return null;
    if (r.bottom < 0 || r.top > (window.innerHeight || 0)) return null;
    return {
      vx: r.left + r.width / 2,
      vy: r.top + r.height / 2,
      w: r.width,
      h: r.height,
      top: r.top,
      left: r.left
    };
  };
  const chromeLeft = Math.max(0, (window.outerWidth - window.innerWidth) / 2);
  const chromeTop = Math.max(0, window.outerHeight - window.innerHeight);
  const screenOf = (p) => {
    if (!p) return null;
    return {
      ...p,
      sx: Math.round(window.screenX + chromeLeft + p.left + p.w / 2),
      sy: Math.round(window.screenY + chromeTop + p.top + p.h / 2)
    };
  };
  const exactBtns = (label) => {
    const want = String(label).toLowerCase();
    return [...document.querySelectorAll('button, a, [role="button"], input[type="button"]')].filter((el) => {
      const t = (el.innerText || el.value || "").replace(/\s+/g, " ").trim().toLowerCase();
      return t === want || t === want + " order";
    });
  };
  const rightmost = (els) => {
    const live = els.filter((el) => {
      const r = el.getBoundingClientRect();
      return r.width >= 8 && r.height >= 10 && r.bottom > 20;
    });
    if (!live.length) return null;
    live.sort((a, b) => b.getBoundingClientRect().x - a.getBoundingClientRect().x);
    return live[0];
  };
  const navPos = (label) => {
    const want = String(label).toLowerCase();
    const el = [...document.querySelectorAll("a, button, span")].find((e) => {
      const t = (e.innerText || "").replace(/\s+/g, " ").trim().toLowerCase();
      return t === want;
    });
    return vp(el);
  };
  const moneyValue = (text) => {
    const m = String(text || "").match(/\$\s*([0-9]+(?:\.[0-9]{1,2})?)/);
    return m ? parseFloat(m[1]) : 0;
  };
  const normText = (value) => String(value || '').replace(/\s+/g, ' ').trim().toLowerCase();
  const headerCenterX = (labelText) => {
    const want = normText(labelText);
    const cacheKey = want.includes('a+') ? '__adeonAPlusHeaderX' : '__adeonYouEarnHeaderX';
    const cached = Number(window[cacheKey] || 0);
    if (cached > 0) return cached;
    const candidates = [...document.querySelectorAll('[role="columnheader"], th, .table-row span, .table-row div, .table-header span, .table-header div')];
    const el = candidates.find((node) => normText(node.innerText || node.textContent || '') === want);
    if (!el) return 0;
    const r = el.getBoundingClientRect();
    if (!r || r.width <= 0) return 0;
    const x = r.left + r.width / 2;
    window[cacheKey] = x;
    return x;
  };
  const parseAPlusPay = (row, text) => {
    // Read A+ earns independently first. The final eligibility value prefers A+
    // when LR shows it and falls back to You'll earn only when A+ is absent.
    // First use an explicit semantic label when LR exposes one.
    const labelled = [...row.querySelectorAll('[aria-label], [title], [data-label], [data-title], [headers]')];
    for (const el of labelled) {
      const label = [
        el.getAttribute('aria-label') || '',
        el.getAttribute('title') || '',
        el.getAttribute('data-label') || '',
        el.getAttribute('data-title') || '',
        el.getAttribute('headers') || ''
      ].join(' ').replace(/\s+/g, ' ').trim().toLowerCase();
      if (label.includes('a+ earns') || label.includes('a + earns') || label.includes('a+ level earns') || label.includes('a + level earns')) {
        const v = moneyValue(el.innerText || el.textContent || '');
        if (v > 0) return { value: v, source: 'labelled A+ cell' };
      }
    }

    // Next map money cells to the visible column headers by screen position.
    // This avoids assuming that row.innerText always preserves the table order.
    const aPlusX = headerCenterX('a+ earns') || headerCenterX('a+ level earns');
    const youEarnX = headerCenterX("you'll earn");
    if (aPlusX > 0) {
      const moneyEls = [...row.querySelectorAll('*')].filter((el) => {
        const t = String(el.innerText || el.textContent || '').trim();
        if (!/\$\s*[0-9]/.test(t)) return false;
        // Prefer the deepest visible element containing the amount, not a wrapper
        // that repeats the whole row's text.
        const childHasMoney = [...el.children].some((ch) => /\$\s*[0-9]/.test(String(ch.innerText || ch.textContent || '')));
        if (childHasMoney) return false;
        const r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 0;
      });
      let best = null;
      for (const el of moneyEls) {
        const r = el.getBoundingClientRect();
        const cx = r.left + r.width / 2;
        const dxA = Math.abs(cx - aPlusX);
        const dxY = youEarnX > 0 ? Math.abs(cx - youEarnX) : Number.POSITIVE_INFINITY;
        if (youEarnX > 0 && dxA >= dxY) continue; // never choose the You'll earn column
        const v = moneyValue(el.innerText || el.textContent || '');
        if (!(v > 0)) continue;
        if (!best || dxA < best.dx) best = { value: v, dx: dxA };
      }
      if (best) return { value: best.value, source: 'A+ header position' };
    }

    // Last fallback: only treat the second amount as A+ when the A+ column
    // itself is present. If the A+ column is absent, the caller must use
    // You'll earn instead, even if some unrelated second dollar amount exists.
    const vals = [];
    const re = /\$\s*([0-9]+(?:\.[0-9]{1,2})?)/g;
    let m;
    while ((m = re.exec(text || ''))) vals.push(parseFloat(m[1]));
    if (aPlusX > 0 && vals.length >= 2) return { value: vals[1], source: 'second row amount with A+ column present' };

    // Return 0 here when A+ cannot be identified. The caller will then use the
    // independently parsed You'll earn value as the fallback.
    return { value: 0, source: 'A+ not identified' };
  };
  const parseYouEarnPay = (row, text) => {
    const labelled = [...row.querySelectorAll('[aria-label], [title], [data-label], [data-title], [headers]')];
    for (const el of labelled) {
      const label = [
        el.getAttribute('aria-label') || '', el.getAttribute('title') || '',
        el.getAttribute('data-label') || '', el.getAttribute('data-title') || '',
        el.getAttribute('headers') || ''
      ].join(' ').replace(/\s+/g, ' ').trim().toLowerCase();
      if (label.includes("you'll earn") || label.includes('you will earn')) {
        const v = moneyValue(el.innerText || el.textContent || '');
        if (v > 0) return { value: v, source: "labelled You'll earn cell" };
      }
    }
    const x = headerCenterX("you'll earn");
    if (x > 0) {
      const moneyEls = [...row.querySelectorAll('*')].filter((el) => {
        const t = String(el.innerText || el.textContent || '').trim();
        if (!/\$\s*[0-9]/.test(t)) return false;
        const childHasMoney = [...el.children].some((ch) => /\$\s*[0-9]/.test(String(ch.innerText || ch.textContent || '')));
        if (childHasMoney) return false;
        const r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 0;
      });
      let best = null;
      for (const el of moneyEls) {
        const r = el.getBoundingClientRect();
        const dx = Math.abs((r.left + r.width / 2) - x);
        const v = moneyValue(el.innerText || el.textContent || '');
        if (!(v > 0)) continue;
        if (!best || dx < best.dx) best = { value:v, dx };
      }
      if (best) return { value:best.value, source:"You'll earn header position" };
    }
    const vals = [];
    const re = /\$\s*([0-9]+(?:\.[0-9]{1,2})?)/g;
    let m;
    while ((m = re.exec(text || ''))) vals.push(parseFloat(m[1]));
    if (vals.length >= 1) return { value:vals[0], source:"first row amount fallback" };
    return { value:0, source:"You'll earn not identified" };
  };
  const rows = [];
  document.querySelectorAll(".table-row.row.vertical, .table-row.row").forEach((row) => {
    const text = (row.innerText || "").replace(/\s+/g, " ").trim();
    const rawText = (row.textContent || "").replace(/\s+/g, " ").trim();
    const metaText = [...row.querySelectorAll("[title], [aria-label], time")].map((el) => {
      return [el.getAttribute("title") || "", el.getAttribute("aria-label") || "", el.getAttribute("datetime") || "", el.textContent || ""].join(" ");
    }).join(" ").replace(/\s+/g, " ").trim();
    const deadlineText = [text, rawText, metaText].filter(Boolean).join(" | ").slice(0, 900);
    const low = text.toLowerCase();
    // Tutoring rows can expose their type through an icon/title/ARIA/data attribute
    // instead of visible innerText. Build a structured scan so they are excluded
    // before the physical mouse is ever allowed to click the row.
    const tutorMeta = [
      rawText,
      metaText,
      String((row.querySelector('a[href]') || {}).href || ""),
      String(row.className || ""),
      row.getAttribute("title") || "",
      row.getAttribute("aria-label") || "",
      row.getAttribute("data-type") || "",
      row.getAttribute("data-order-type") || "",
      ...[...row.querySelectorAll('[title],[aria-label],[alt],[data-type],[data-order-type]')].map((el) => [
        el.getAttribute("title") || "",
        el.getAttribute("aria-label") || "",
        el.getAttribute("alt") || "",
        el.getAttribute("data-type") || "",
        el.getAttribute("data-order-type") || ""
      ].join(" "))
    ].join(" ").replace(/\s+/g, " ").toLowerCase();
    const isTutorRow = low.includes("tutoring order") ||
      /(^|[^a-z])tutor(ing)?([^a-z]|$)/.test(low) ||
      tutorMeta.includes("tutoring order") ||
      /(^|[^a-z])tutor(ing)?([^a-z]|$)/.test(tutorMeta);
    if (!text) return;
    if (low.includes("order number") && low.includes("you'll earn")) return;
    if (low.startsWith("order number")) return;
    const link = row.querySelector('a[href*="/order/"]');
    const href = link ? String(link.href || "") : "";
    const id = (href.match(/\/order\/([^/?#]+)/i) || [])[1] || "";
    const orderNo = (text.match(/\b[A-Z]{1,6}\d{6,}-\d+\b/i) || [])[0] || "";
    const p = vp(row);
    if (!p || p.top < 70) return;
    const clickP = {
      ...p,
      vx: p.left + Math.min(Math.max(p.w * 0.28, 80), 240),
      vy: p.top + p.h * 0.55
    };
    const sp = screenOf(clickP);
    const aPlusInfo = parseAPlusPay(row, text);
    const youEarnInfo = parseYouEarnPay(row, text);
    const payInfo = Number(aPlusInfo.value || 0) > 0
      ? { value:Number(aPlusInfo.value || 0), source:String(aPlusInfo.source || 'A+ earns'), kind:'A+ earns' }
      : { value:Number(youEarnInfo.value || 0), source:String(youEarnInfo.source || "You'll earn fallback"), kind:"You'll earn" };
    rows.push({
      id,
      orderNo,
      text: text.slice(0, 180),
      deadlineText,
      pay: Number(payInfo.value || 0),
      paySource: String(payInfo.source || ''),
      payKind: String(payInfo.kind || ''),
      aPlusEarn: Number(aPlusInfo.value || 0),
      aPlusEarnSource: String(aPlusInfo.source || ''),
      youEarn: Number(youEarnInfo.value || 0),
      youEarnSource: String(youEarnInfo.source || ''),
      tutor: isTutorRow,
      vx: sp.vx,
      vy: sp.vy,
      // Keep the original row rectangle as well as the chosen click point.
      // The physical-mouse safety layer needs these fields to prove that
      // the mapped click still lies inside this exact row.
      left: p.left,
      top: p.top,
      w: p.w,
      h: p.h,
      sx: sp.sx,
      sy: sp.sy
    });
  });
  const reserveBtn = rightmost(exactBtns("reserve"));
  const acceptBtn = rightmost(exactBtns("accept"));
  const rejectBtn = rightmost(exactBtns("reject"));
  // Exact keep-alive popup requested by the user. This target exists only when
  // the visible page says "Are you still there?" AND the exact confirmation
  // button says "Yes, I'm here". It is independent from order Accept.
  const stillHerePageText = String(document.body ? document.body.innerText : "").replace(/\s+/g, " ").trim();
  const stillHerePopupVisible = /\bare you still there\b/i.test(stillHerePageText);
  const stillHereCandidates = [...document.querySelectorAll('button, a, [role="button"], input[type="button"]')].filter((el) => {
    const t = String(el.innerText || el.value || el.textContent || "")
      .replace(/[\u2018\u2019]/g, "'").replace(/\s+/g, " ").trim().toLowerCase();
    const r = el.getBoundingClientRect();
    const disabled = !!(el.disabled || el.getAttribute("disabled") != null || el.getAttribute("aria-disabled") === "true");
    return !disabled && r.width >= 8 && r.height >= 10 && r.bottom > 20 && (t === "yes, i'm here" || t === "yes i'm here");
  });
  const stillHereBtn = stillHerePopupVisible ? rightmost(stillHereCandidates) : null;
  const reserveDisabled = !!(
    reserveBtn && (reserveBtn.disabled || reserveBtn.getAttribute("disabled") != null)
  );
  const root = reserveBtn || acceptBtn || rejectBtn;

  // Pick the RICHEST order-detail ancestor, not merely the closest element whose
  // class happens to contain the word "order". The old selector could sometimes
  // land on the tiny Reserve/Accept button strip, producing panelText such as
  // "ReserveAccept" and losing the task title/summary/description.
  let panel = null;
  if (root) {
    const candidates = [];
    const addPanelCandidate = (el) => {
      if (!el || el === document.body || el === document.documentElement) return;
      if (!candidates.includes(el)) candidates.push(el);
    };
    for (const sel of [
      '.order-tab-container', '.order-tab', '.drawer', '.modal',
      '.order-detail-body', 'aside', '[role="dialog"]'
    ]) {
      try { addPanelCandidate(root.closest(sel)); } catch (e) {}
    }
    let anc = root.parentElement;
    for (let i = 0; anc && i < 10; i++, anc = anc.parentElement) addPanelCandidate(anc);

    const panelScore = (el) => {
      try {
        const inner = String(el.innerText || '');
        const deep = String(el.textContent || '');
        const text = inner.length >= 40 ? inner : deep;
        const low = text.toLowerCase();
        let score = Math.min(Math.max(inner.length, deep.length), 30000);
        try {
          if (el.matches('.order-tab-container, .order-tab, .drawer, .modal, .order-detail-body, [role=\"dialog\"]')) score += 35000;
          else if (el.matches('aside')) score += 15000;
        } catch (e) {}
        if (text.length > 18000) score -= Math.min(18000, text.length - 18000);
        if (/\b[A-Z]{1,6}\d{6,}-\d+\b/i.test(text)) score += 7000;
        if (low.includes('task summary')) score += 18000;
        if (low.includes('full order description')) score += 18000;
        if (low.includes('final ddl')) score += 9000;
        if (low.includes('order info')) score += 3500;
        if (low.includes('formatting style')) score += 2000;
        if (low.includes('sources')) score += 1500;
        if (low.includes('reserve')) score += 500;
        if (text.replace(/\s+/g,'').toLowerCase() === 'reserveaccept' || text.length < 60) score -= 25000;
        return score;
      } catch (e) { return -100000; }
    };
    candidates.sort((a,b) => panelScore(b) - panelScore(a));
    panel = candidates.length ? candidates[0] : root.parentElement;
  }

  const panelInnerText = panel ? String(panel.innerText || '') : '';
  const panelDeepText = panel ? String(panel.textContent || '') : '';
  // innerText preserves the same human-readable line structure the old
  // Tampermonkey parser consumed. textContent is returned separately as a fallback
  // for content mounted in the drawer but not currently visible in its viewport.
  const panelText = panelInnerText || panelDeepText;

  // Reserved-panel inspection helpers. These expose only geometry/state; Python
  // performs the visible wheel/click actions and revalidates before each action.
  let panelScroll = null;
  let filesToggle = null;
  if (panel) {
    const candidates = [panel, ...panel.querySelectorAll("div, section, aside")];
    // LR's order drawer does not always declare overflow:auto even though the
    // element is actually scrollable. Choose by real scroll geometry first,
    // then use CSS overflow only as a bonus. This makes the visible wheel move
    // the actual order-content container instead of a non-scrolling wrapper.
    const scrollables = candidates.map((el) => {
      try {
        const r = el.getBoundingClientRect();
        const cs = getComputedStyle(el);
        const delta = Number(el.scrollHeight || 0) - Number(el.clientHeight || 0);
        const overflowY = String(cs.overflowY || "");
        const scrollbarWidth = Math.max(0, Number(el.offsetWidth || 0) - Number(el.clientWidth || 0));
        // Fail closed. If LR is not painting a real vertical scrollbar, Adeon must
        // not move the mouse at all during the reserved-minute inspection.
        if (!(r.width > 120 && r.height > 100 && r.bottom > 70 && r.top < window.innerHeight &&
              delta > 20 && /(auto|scroll)/i.test(overflowY) && scrollbarWidth >= 6)) return null;
        return { el, score: 5000 + scrollbarWidth * 200 + delta * 4 + Math.min(r.height, 900), scrollbarWidth, overflowY };
      } catch (e) { return null; }
    }).filter(Boolean);
    scrollables.sort((a,b) => b.score - a.score);
    const scrollInfo = scrollables.length ? scrollables[0] : null;
    if (scrollInfo) {
      const scrollEl = scrollInfo.el;
      try {
        const r = scrollEl.getBoundingClientRect();
        if (r.width > 80 && r.height > 80) {
          panelScroll = {
            vx: Math.max(r.left + 20, r.right - Math.max(3, scrollInfo.scrollbarWidth / 2)),
            vy: Math.max(r.top + 30, Math.min(r.bottom - 30, r.top + r.height * 0.52)),
            left:r.left, top:r.top, w:r.width, h:r.height,
            scrollTop:Number(scrollEl.scrollTop || 0),
            scrollHeight:Number(scrollEl.scrollHeight || 0),
            clientHeight:Number(scrollEl.clientHeight || 0),
            scrollbarWidth:Number(scrollInfo.scrollbarWidth || 0),
            overflowY:String(scrollInfo.overflowY || "")
          };
        }
      } catch (e) {}
    }

    const toggleCandidates = [...panel.querySelectorAll('button, [role="button"], [aria-expanded]')].filter((el) => {
      try {
        if (el.closest('a[href]')) return false;
        const r = el.getBoundingClientRect();
        if (r.width < 20 || r.height < 12 || r.bottom < 70 || r.top > window.innerHeight) return false;
        const t = (el.innerText || el.textContent || '').replace(/\s+/g,' ').trim().toLowerCase();
        return t === 'files' || t === 'order files' || t === 'additional materials' ||
               t.startsWith('order files ') || t.startsWith('files ');
      } catch (e) { return false; }
    });
    if (toggleCandidates.length) {
      const el = toggleCandidates[0];
      const p = vp(el);
      if (p) {
        filesToggle = screenOf({ ...p, text:(el.innerText || el.textContent || '').replace(/\s+/g,' ').trim().slice(0,80), expanded:el.getAttribute('aria-expanded') });
      }
    }
  }

  const bodyText = String(document.body ? document.body.innerText : "");
  const url = location.href;

  // Rich detail fallback for the reservation notification.  The LR drawer can
  // visually contain Task summary / Full order description even when the button
  // strip is the closest ancestor of Reserve.  Keep a text window around those
  // human-readable labels, using both innerText and textContent, so Python can
  // parse the exact same words the older Tampermonkey script saw.
  const bodyDeepText = panel ? String(document.body ? document.body.textContent || '' : '') : '';
  const detailWindow = (source) => {
    source = String(source || '');
    if (!source) return '';
    const low = source.toLowerCase();
    const anchors = ['task summary', 'full order description', 'final ddl', 'order info']
      .map((x) => low.indexOf(x)).filter((x) => x >= 0);
    if (!anchors.length) return '';
    const a = Math.min(...anchors);
    return source.slice(Math.max(0, a - 6000), Math.min(source.length, a + 24000));
  };
  const detailAnchorText = detailWindow(bodyText);
  const detailDeepAnchorText = detailWindow(bodyDeepText);

  // Detect the right-side order drawer even on My Orders pages where there is no
  // exact Reserve/Accept/Reject button for the older panel detector to anchor to.
  // Local label editors must disappear while this drawer is open so they never
  // float above LR Writers' own order details panel.
  const detectSideOrderPanel = () => {
    try {
      const clues = ['order info', 'task summary', 'full order description', 'final ddl', 'more order details', 'upload final'];
      const seen = new Set();
      const nodes = [];
      const add = (el) => {
        if (!el || el === document.body || el === document.documentElement || seen.has(el)) return;
        seen.add(el);
        nodes.push(el);
      };

      // The drawer always occupies the right edge. Sampling the actual painted
      // elements there is more reliable than depending on one LR Writers class name.
      const x = Math.max(1, window.innerWidth - 8);
      for (const frac of [0.20, 0.38, 0.56, 0.74]) {
        const y = Math.max(1, Math.min(window.innerHeight - 2, window.innerHeight * frac));
        const stack = document.elementsFromPoint ? document.elementsFromPoint(x, y) : [];
        for (const start of stack) {
          let cur = start;
          for (let i=0; cur && i<10; i++, cur=cur.parentElement) add(cur);
        }
      }

      const selectors = [
        '.order-tab-container', '.order-tab', '.drawer', '[class*=\"drawer\"]',
        '[class*=\"order-detail\"]', '[class*=\"order-tab\"]', 'aside', '[role=\"dialog\"]'
      ].join(',');
      document.querySelectorAll(selectors).forEach(add);

      for (const el of nodes) {
        const r = el.getBoundingClientRect();
        if (!(r.width >= 250 && r.width <= window.innerWidth * 0.62)) continue;
        if (!(r.height >= Math.min(300, window.innerHeight * 0.42))) continue;
        if (!(r.right >= window.innerWidth - 24 && r.left >= window.innerWidth * 0.34)) continue;
        const cs = getComputedStyle(el);
        if (!cs || cs.display === 'none' || cs.visibility === 'hidden' || Number(cs.opacity || 1) <= 0.02) continue;
        const text = String(el.innerText || el.textContent || '').replace(/\s+/g, ' ').toLowerCase();
        let hits = 0;
        for (const clue of clues) if (text.includes(clue)) hits++;
        if (hits >= 2) return true;
      }
    } catch (_) {}
    return false;
  };
  const sideOrderPanelOpen = !!panel || detectSideOrderPanel();

  // LABEL: My Orders annotations. Nothing is submitted into LR Writers forms.
  // The browser keeps a fast local copy; the Adeon labels worker mirrors it to a
  // persistent data file and, when configured, the independent label-sync server.
  // Rows are discovered by visible order number rather than one fragile CSS class.
  const myOrdersHeaders = /\byour price\b/i.test(bodyText) && /\bpayout date\b/i.test(bodyText);
  const onMyOrders = /\/myorders(?:[\/#?]|$)/i.test(url) || myOrdersHeaders;
  const ADEON_ORDER_RE = /\b[A-Z]{1,6}\d{6,}-\d+\b/i;

  const findMyOrderRows = () => {
    const found = new Map();
    const add = (el) => {
      if (!el || !el.getBoundingClientRect) return;
      const r = el.getBoundingClientRect();
      if (!r || r.width < 420 || r.height < 18 || r.height > 110) return;
      const txt = String(el.innerText || el.textContent || '').replace(/\s+/g,' ').trim();
      const m = txt.match(ADEON_ORDER_RE);
      if (!m) return;
      const key = String(m[0]).toUpperCase();
      const prev = found.get(key);
      // Prefer the smallest row-like container that still spans the table width.
      if (!prev || r.height < prev.getBoundingClientRect().height) found.set(key, el);
    };

    // Normal LR table structures first.
    document.querySelectorAll('.table-row.row.vertical, .table-row.row, [role="row"], tr, [class*="table-row"]').forEach(add);
    document.querySelectorAll('a[href*="/order/"]').forEach((a) => {
      let cur = a;
      for (let i=0; cur && i<8; i++, cur=cur.parentElement) {
        const r = cur && cur.getBoundingClientRect ? cur.getBoundingClientRect() : null;
        if (r && r.width >= 420 && r.height >= 18 && r.height <= 110) { add(cur); break; }
      }
    });

    // My Orders has used more than one row class over time. If the direct selectors
    // found nothing (or missed a row), locate the visible order-number text itself and
    // walk upward to the first table-width ancestor. This is local DOM reading only.
    try {
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      let node;
      let guard = 0;
      while ((node = walker.nextNode()) && guard++ < 12000) {
        const raw = String(node.nodeValue || '').trim();
        if (!ADEON_ORDER_RE.test(raw)) continue;
        let cur = node.parentElement;
        for (let i=0; cur && cur !== document.body && i<10; i++, cur=cur.parentElement) {
          const r = cur.getBoundingClientRect();
          if (r.width >= 420 && r.height >= 18 && r.height <= 110) { add(cur); break; }
        }
      }
    } catch (_) {}
    return found;
  };

  const ensureAdeonLabels = () => {
    let layer = document.getElementById('__adeonLabelLayer');
    if (!onMyOrders || !window.__adeonLabelsEnabled) {
      if (layer) layer.remove();
      return 0;
    }
    if (!layer) {
      layer = document.createElement('div');
      layer.id = '__adeonLabelLayer';
      layer.style.cssText = 'position:fixed;inset:0;z-index:2147483000;pointer-events:none;font-family:Arial,sans-serif;';
      document.documentElement.appendChild(layer);
    }

    let store = {};
    let storeTimes = {};
    try { store = JSON.parse(localStorage.getItem('__adeonMyOrderLabelsV1') || '{}') || {}; } catch (_) { store = {}; }
    try { storeTimes = JSON.parse(localStorage.getItem('__adeonMyOrderLabelTimesV1') || '{}') || {}; } catch (_) { storeTimes = {}; }
    const live = new Set();
    const rowsByOrder = findMyOrderRows();
    const finalPaperX = Number(headerCenterX('final paper') || 0);

    const greenDotRight = (row) => {
      try {
        const rr = row.getBoundingClientRect();
        let best = 0;
        const nodes = [row, ...row.querySelectorAll('svg,span,i,div,path,circle')];
        const isGreen = (value) => {
          const m = String(value || '').match(/rgba?\((\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i);
          if (!m) return false;
          const r=Number(m[1]), g=Number(m[2]), b=Number(m[3]);
          return g >= 95 && g > r * 1.18 && g > b * 1.08;
        };
        for (const el of nodes) {
          if (!el || !el.getBoundingClientRect) continue;
          const r = el.getBoundingClientRect();
          if (r.width < 6 || r.height < 6 || r.width > 28 || r.height > 28) continue;
          if (r.top < rr.top - 2 || r.bottom > rr.bottom + 2) continue;
          if (r.left < Math.max(rr.left + rr.width * 0.72, finalPaperX - 30)) continue;
          const cs = getComputedStyle(el);
          const attrs = [
            cs.color, cs.backgroundColor, cs.borderColor, cs.fill, cs.stroke, cs.boxShadow,
            el.getAttribute && el.getAttribute('fill'), el.getAttribute && el.getAttribute('stroke')
          ];
          const semantic = String((el.className && (el.className.baseVal || el.className)) || '') + ' ' +
                           String(el.getAttribute && (el.getAttribute('aria-label') || el.getAttribute('title') || ''));
          const looksLikeSuccess = /(?:success|check|complete|completed|final)/i.test(semantic);
          if (!attrs.some(isGreen) && !looksLikeSuccess) continue;
          best = Math.max(best, r.right);
        }
        return best;
      } catch (_) { return 0; }
    };

    for (const [key, row] of rowsByOrder.entries()) {
      live.add(key);
      const rr = row.getBoundingClientRect();
      const id = '__adeonLabel_' + key.replace(/[^A-Z0-9]/g,'_');
      let item = document.getElementById(id);
      if (!item) {
        item = document.createElement('div');
        item.id = id;
        item.dataset.order = key;
        item.title = 'ADEON LOCAL LABEL • ' + key;
        item.style.cssText = 'position:fixed;display:flex;align-items:center;height:22px;pointer-events:auto;white-space:nowrap;overflow:hidden;';

        const inp = document.createElement('input');
        inp.type = 'text';
        inp.autocomplete = 'off';
        inp.spellcheck = false;
        inp.maxLength = 40;
        inp.placeholder = '';
        inp.setAttribute('aria-label', 'Local label for ' + key);
        inp.style.cssText = 'height:20px;width:56px;min-width:0;max-width:56px;border:1px solid #cbd5e1;border-radius:3px;outline:none;background:rgba(255,255,255,.98);padding:1px 3px;color:#111827;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0;box-sizing:border-box;overflow:hidden;';
        inp.value = String(store[key] || '').toUpperCase();

        inp.addEventListener('focus', () => { inp.style.borderColor = '#64748b'; });
        inp.addEventListener('blur', () => { inp.style.borderColor = '#cbd5e1'; });
        inp.addEventListener('input', () => {
          const start = inp.selectionStart;
          const upper = String(inp.value || '').toUpperCase();
          if (inp.value !== upper) inp.value = upper;
          try {
            const m = JSON.parse(localStorage.getItem('__adeonMyOrderLabelsV1') || '{}') || {};
            const t = JSON.parse(localStorage.getItem('__adeonMyOrderLabelTimesV1') || '{}') || {};
            if (upper) m[key] = upper; else delete m[key];
            t[key] = Date.now() / 1000;
            localStorage.setItem('__adeonMyOrderLabelsV1', JSON.stringify(m));
            localStorage.setItem('__adeonMyOrderLabelTimesV1', JSON.stringify(t));
            store = m;
            storeTimes = t;
          } catch (_) {}
          try { if (start != null) inp.setSelectionRange(start, start); } catch (_) {}
        });
        item.appendChild(inp);
        layer.appendChild(item);
      }

      // Keep the editor inside the visible LR Writers row. It never grows with text.
      // When the Final-paper green status dot is present, start strictly after
      // its painted right edge so the typing bar never covers the dot.
      const rightEdge = Math.min(window.innerWidth - 5, rr.right - 5);
      const dotRight = greenDotRight(row);
      // If the exact green indicator was found, the input starts 6px after its
      // painted right edge. The fallback is deliberately farther right than the
      // Final-paper column center so even an SVG check whose fill is inherited
      // from a parent cannot be covered.
      let left = dotRight > 0 ? dotRight + 6 : (finalPaperX > 0 ? finalPaperX + 20 : rightEdge - 56);
      if (left < rr.left + 4) left = rr.left + 4;
      let width = Math.min(56, Math.floor(rightEdge - left));
      if (dotRight <= 0 && width < 26) {
        // Only the no-dot fallback is allowed to slide left for a usable box.
        // When a real green dot was found, NEVER move the box back over it.
        width = Math.min(56, Math.max(26, Math.floor(rr.width * 0.045)));
        left = Math.max(rr.left + 4, rightEdge - width);
      }
      if (dotRight > 0) {
        left = Math.max(left, dotRight + 6);
        width = Math.max(0, Math.min(56, Math.floor(rightEdge - left)));
      }
      item.style.left = Math.round(left) + 'px';
      item.style.width = Math.max(1, Math.round(width)) + 'px';
      item.style.top = Math.round(rr.top + rr.height / 2 - 10) + 'px';
      item.style.display = (!sideOrderPanelOpen && rr.bottom > 65 && rr.top < window.innerHeight && rr.height > 10 && width >= 10) ? 'flex' : 'none';

      // Clean up the old illustration dot if a pre-1.0.19 label node survived in-page.
      [...item.children].forEach((child) => { if (child.tagName !== 'INPUT') child.remove(); });
      const inp = item.querySelector('input');
      if (inp) {
        inp.style.width = Math.max(1, Math.round(width)) + 'px';
        inp.style.maxWidth = Math.max(1, Math.round(width)) + 'px';
        if (document.activeElement !== inp) {
          const saved = String(store[key] || '').toUpperCase();
          if (inp.value !== saved) inp.value = saved;
        }
      }
    }

    [...layer.children].forEach((item) => {
      if (!live.has(String(item.dataset.order || '').toUpperCase())) item.remove();
    });
    try { window.__adeonLabelExport = { labels:store, times:storeTimes }; } catch (_) {}
    return live.size;
  };
  const labelCount = ensureAdeonLabels();
  let labelStore = {labels:{}, times:{}};
  try { labelStore = window.__adeonLabelExport || labelStore; } catch (_) {}
  let urlId = "";
  const mAll = url.match(/\/findorders\/all\/([^/?#]+)/i);
  const mOrd = url.match(/\/order\/([^/?#]+)/i);
  if (mAll && mAll[1] && mAll[1].toLowerCase() !== "all") urlId = mAll[1];
  else if (mOrd) urlId = mOrd[1];
  const acceptedGone = /upload final file|already accepted|you accepted|successfully accepted/i.test(
    bodyText + " " + panelText
  );
  const hasPasswordInput = !!document.querySelector('input[type="password"]');
  const loginUrl = /\/(?:login|log-in|signin|sign-in|auth)(?:[\/?#]|$)/i.test(url);
  const loginWords = /\b(?:log\s*in|sign\s*in)\b/i.test(bodyText);
  const loggedOut = !!(loginUrl || (hasPasswordInput && loginWords));

  // Safe idle points. These are deliberately NOT arbitrary page points.
  // Sample across the visible webpage and keep only coordinates whose
  // DOM target is non-interactive, outside order rows, and outside the
  // currently open order panel.
  const idleMovePoints = [];
  const idleClickPoints = [];
  const interactiveSel = [
    "a", "button", "input", "textarea", "select", "option",
    "[role='button']", "[role='link']", "[onclick]", "[contenteditable='true']",
    ".table-row.row", ".table-row.row.vertical"
  ].join(",");
  const pointSafe = (x, y) => {
    const el = document.elementFromPoint(x, y);
    if (!el) return null;
    if (el.closest && el.closest(interactiveSel)) return null;
    if (panel && panel.contains(el)) return null;
    const cs = getComputedStyle(el);
    if (!cs || cs.pointerEvents === "none" || cs.visibility === "hidden") return null;
    return el;
  };
  const clickTagOK = (el) => {
    if (!el) return false;
    const tag = String(el.tagName || "").toLowerCase();
    if (!["body", "main", "section", "div", "article"].includes(tag)) return false;
    const cs = getComputedStyle(el);
    if (cs && (cs.cursor === "pointer" || cs.cursor === "text")) return false;
    return true;
  };
  const xs = [0.10, 0.24, 0.38, 0.52, 0.66, 0.80, 0.92];
  const ys = [0.16, 0.28, 0.40, 0.52, 0.64, 0.76, 0.88];
  for (const xf of xs) {
    for (const yf of ys) {
      const x = Math.round(window.innerWidth * xf);
      const y = Math.round(window.innerHeight * yf);
      if (y < 120) continue;
      const el = pointSafe(x, y);
      if (!el) continue;
      idleMovePoints.push({vx:x, vy:y, tag:String(el.tagName || ""), cls:String(el.className || "").slice(0,80)});
      if (clickTagOK(el)) {
        idleClickPoints.push({vx:x, vy:y, tag:String(el.tagName || ""), cls:String(el.className || "").slice(0,80)});
      }
    }
  }

  return {
    url,
    urlId,
    pageTitle: document.title || "",
    innerW: window.innerWidth,
    innerH: window.innerHeight,
    rows,
    reserve: reserveDisabled ? null : screenOf(vp(reserveBtn)),
    accept: screenOf(vp(acceptBtn)),
    reject: screenOf(vp(rejectBtn)),
    stillHere: screenOf(vp(stillHereBtn)),
    reserveDisabled,
    panelOpen: !!(reserveBtn || acceptBtn || rejectBtn),
    panelText: panelText.slice(0, 30000),
    panelDeepText: panelDeepText.slice(0, 30000),
    panelScroll,
    filesToggle,
    acceptedGone,
    loggedOut,
    bodyText: bodyText.slice(0, 30000),
    bodyTextExcerpt: bodyText.slice(0, 1000),
    detailAnchorText: detailAnchorText.slice(0, 30000),
    detailDeepAnchorText: detailDeepAnchorText.slice(0, 30000),
    onMyOrders,
    labelCount,
    labelStore,
    sideOrderPanelOpen,
    lastClick: window.__lrBotLastClick || null,
    navFind: navPos("find orders"),
    navMy: navPos("my orders"),
    navInbox: navPos("inbox"),
    navProgress: navPos("my progress"),
    onFind: /\/findorders\//i.test(url),
    onInbox: /\/inbox(?:[\/#?]|$)/i.test(url) || /\binbox\b/i.test(document.title || ""),
    onProgress: /\/(?:myprogress|progress)(?:[\/#?]|$)/i.test(url) || /\bmy progress\b/i.test(document.title || ""),
    idleMovePoints,
    idleClickPoints
  };

  }

  function normalizeText(v) {
    return String(v || "").replace(/[‘’]/g, "'").replace(/\s+/g, " ").trim().toLowerCase();
  }

  function validateClick(pos, kind) {
    if (!pos) return false;
    const x = Number(pos.vx), y = Number(pos.vy);
    if (!Number.isFinite(x) || !Number.isFinite(y)) return false;
    const el = document.elementFromPoint(x, y);
    if (!el) return false;
    const expectedId = String(pos.id || "");
    const expectedText = String(pos.text || "").slice(0, 80);
    if (kind === "reserve" || kind === "midnight_reject") {
      const b = el.closest('button, a, [role="button"], input[type="button"]');
      if (!b) return false;
      const t = normalizeText(b.innerText || b.value || "");
      const disabled = !!(b.disabled || b.getAttribute("disabled") != null || b.getAttribute("aria-disabled") === "true");
      const want = kind === "reserve" ? "reserve" : "reject";
      return !disabled && (t === want || t === want + " order");
    }
    if (kind === "row") {
      const row = el.closest(".table-row.row.vertical, .table-row.row, [role='row'], tr");
      if (!row) return false;
      const link = row.querySelector('a[href*="/order/"]');
      const href = link ? String(link.href || "") : "";
      if (expectedId) return href.includes("/order/" + expectedId);
      if (expectedText) {
        const actual = String(row.innerText || "").replace(/\s+/g, " ").trim();
        return actual.includes(expectedText.slice(0, 40));
      }
      return false;
    }
    if (kind === "still_here") {
      const b = el.closest('button, a, [role="button"], input[type="button"]');
      if (!b) return false;
      const t = normalizeText(b.innerText || b.value || b.textContent || "");
      const disabled = !!(b.disabled || b.getAttribute("disabled") != null || b.getAttribute("aria-disabled") === "true");
      const pageText = String(document.body ? document.body.innerText : "").replace(/\s+/g, " ");
      return !disabled && /\bare you still there\b/i.test(pageText) && (t === "yes, i'm here" || t === "yes i'm here");
    }
    if (kind === "files_toggle") {
      const b = el.closest('button, [role="button"], [aria-expanded]');
      if (!b || b.closest("a[href]")) return false;
      const t = normalizeText(b.innerText || b.textContent || "");
      return t === "files" || t === "order files" || t === "additional materials" ||
             t.startsWith("order files ") || t.startsWith("files ");
    }
    if (["nav_my","nav_find","nav_inbox","nav_progress"].includes(kind)) {
      const want = kind === "nav_my" ? "my orders" :
                   kind === "nav_find" ? "find orders" :
                   kind === "nav_inbox" ? "inbox" : "my progress";
      let cur = el;
      for (let i=0; i<5 && cur; i++, cur=cur.parentElement) {
        const t = normalizeText(cur.innerText || cur.textContent || "");
        if (t === want) return true;
        const role = (cur.getAttribute && cur.getAttribute("role")) || "";
        if ((cur.tagName === "A" || cur.tagName === "BUTTON" || role === "button") && t.includes(want)) return true;
      }
      return false;
    }
    return false;
  }

  function applyLabels(state) {
    try {
      const s = state || {};
      localStorage.setItem("__adeonMyOrderLabelsV1", JSON.stringify(s.labels || {}));
      localStorage.setItem("__adeonMyOrderLabelTimesV1", JSON.stringify(s.times || {}));
      window.__adeonLabelExport = {labels:s.labels || {}, times:s.times || {}};
      window.__adeonLabelsEnabled = true;
      try { localStorage.setItem("__adeonLabelsEnabledV1", "1"); } catch (_) {}
      return true;
    } catch (_) { return false; }
  }

  function executeCommand(cmd) {
    if (!cmd || !cmd.type) return;
    const id = String(cmd.id || "");
    let result = null;
    let ok = true;
    try {
      switch (cmd.type) {
        case "set_labels_enabled":
          window.__adeonLabelsEnabled = !!cmd.enabled;
          try { localStorage.setItem("__adeonLabelsEnabledV1", window.__adeonLabelsEnabled ? "1" : "0"); } catch (_) {}
          if (!window.__adeonLabelsEnabled) {
            const layer = document.getElementById("__adeonLabelLayer");
            if (layer) layer.remove();
          }
          result = window.__adeonLabelsEnabled;
          break;
        case "apply_labels":
          result = applyLabels(cmd.state || {});
          break;
        case "remove_labels":
          window.__adeonLabelsEnabled = false;
          try { localStorage.setItem("__adeonLabelsEnabledV1", "0"); } catch (_) {}
          {
            const layer = document.getElementById("__adeonLabelLayer");
            if (layer) layer.remove();
          }
          result = true;
          break;
        case "validate_click":
          result = validateClick(cmd.pos || null, String(cmd.kind || ""));
          break;
        case "reload":
          result = true;
          setTimeout(() => location.reload(), 20);
          break;
        default:
          ok = false;
          result = "unknown-command";
      }
    } catch (e) {
      ok = false;
      result = String(e && e.message || e || "error");
    }
    if (id) pendingResults[id] = {ok, result};
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message) return;
    if (message.type === "adeonPing") {
      if (sendResponse) sendResponse({ok:true, url: location.href});
      return false;
    }
    if (message.type !== "adeonCommands") return;
    const list = Array.isArray(message.commands) ? message.commands : [];
    for (const cmd of list) executeCommand(cmd);
    if (sendResponse) sendResponse({ok:true});
    return false;
  });

  function tick() {
    let snap = {};
    try { snap = adeonScan() || {}; } catch (e) {
      snap = {url: location.href, pageTitle: document.title, bridgeScanError: String(e && e.message || e)};
    }
    const results = {};
    for (const [k,v] of Object.entries(pendingResults)) {
      results[k] = v;
      delete pendingResults[k];
    }
    chrome.runtime.sendMessage({
      type: "adeonSnapshot",
      seq: ++bridgeSeq,
      url: location.href,
      title: document.title,
      snap,
      results
    }, () => void chrome.runtime.lastError);
  }

  tick();
  setInterval(tick, 100);
})();
