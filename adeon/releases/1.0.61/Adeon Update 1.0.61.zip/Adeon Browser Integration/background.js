'use strict';

const BRIDGE_URL = 'http://127.0.0.1:17329/v1/snapshot';
const failureCounts = new Map();
const backgroundResults = new Map();

const LR_MATCH = 'https://myaccount.lrwriters.com/*';
let bootstrapRunning = false;

function isLrUrl(url) {
  return String(url || '').startsWith('https://myaccount.lrwriters.com/');
}

function pingContent(tabId) {
  return new Promise((resolve) => {
    try {
      chrome.tabs.sendMessage(tabId, {type: 'adeonPing'}, (reply) => {
        const err = chrome.runtime.lastError;
        resolve(!err && !!(reply && reply.ok));
      });
    } catch (_) { resolve(false); }
  });
}

async function ensureContentScript(tabId) {
  tabId = Number(tabId || 0);
  if (!tabId) return false;
  if (await pingContent(tabId)) return true;
  try {
    await chrome.scripting.executeScript({target: {tabId}, files: ['content.js']});
  } catch (_) {
    return false;
  }
  await new Promise(r => setTimeout(r, 120));
  return await pingContent(tabId);
}

async function bootstrapLrTabs() {
  if (bootstrapRunning) return;
  bootstrapRunning = true;
  try {
    const tabs = await chrome.tabs.query({url: [LR_MATCH]});
    for (const tab of tabs || []) {
      if (tab && tab.id && isLrUrl(tab.url)) await ensureContentScript(tab.id);
    }
  } catch (_) {
  } finally {
    bootstrapRunning = false;
  }
}

function scheduleBootstrap(delay = 50) {
  setTimeout(() => { bootstrapLrTabs(); }, Math.max(0, Number(delay || 0)));
}

chrome.runtime.onInstalled.addListener(() => {
  try { chrome.alarms.create('adeon-bootstrap', {periodInMinutes: 0.5}); } catch (_) {}
  scheduleBootstrap(50);
});
chrome.runtime.onStartup.addListener(() => scheduleBootstrap(50));
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm && alarm.name === 'adeon-bootstrap') bootstrapLrTabs();
});
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if ((changeInfo.status === 'complete' || changeInfo.url) && isLrUrl((tab && tab.url) || changeInfo.url)) {
    ensureContentScript(tabId);
  }
});
chrome.tabs.onActivated.addListener(async ({tabId}) => {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (tab && isLrUrl(tab.url)) ensureContentScript(tabId);
  } catch (_) {}
});

// MV3 service workers in Chrome or Thorium can start after LR Writers is already open.
// Bootstrap immediately so Labels and Picker do not depend on a manual page reload.
try { chrome.alarms.create('adeon-bootstrap', {periodInMinutes: 0.5}); } catch (_) {}
scheduleBootstrap(80);

function resultBucket(tabId) {
  let bucket = backgroundResults.get(tabId);
  if (!bucket) {
    bucket = {};
    backgroundResults.set(tabId, bucket);
  }
  return bucket;
}

function storeResult(tabId, id, ok, result) {
  if (!id) return;
  resultBucket(tabId)[String(id)] = {ok: !!ok, result};
}

async function handleBackgroundCommand(cmd, sender) {
  if (!cmd || !cmd.type) return false;
  const tabId = sender.tab.id;
  const id = String(cmd.id || '');
  try {
    if (cmd.type === 'focus') {
      await chrome.windows.update(sender.tab.windowId, {focused: true});
      await chrome.tabs.update(tabId, {active: true});
      storeResult(tabId, id, true, true);
      return true;
    }
    if (cmd.type === 'reload_tab') {
      storeResult(tabId, id, true, true);
      await chrome.tabs.reload(tabId);
      return true;
    }
    if (cmd.type === 'fetch_text' && cmd.url) {
      const u = new URL(String(cmd.url));
      if (u.protocol !== 'https:' || u.hostname !== 'myaccount.lrwriters.com') {
        throw new Error('fetch_text blocked for non-LR Writers URL');
      }
      const response = await fetch(u.href, {
        method: 'GET',
        credentials: 'include',
        cache: 'no-store',
        redirect: 'follow',
        headers: {'Cache-Control': 'no-cache'}
      });
      const raw = await response.text();
      const maxChars = Math.max(1000, Math.min(Number(cmd.max_chars || 350000), 500000));
      storeResult(tabId, id, true, {
        ok: !!response.ok,
        status: Number(response.status || 0),
        url: String(response.url || u.href),
        text: String(raw || '').slice(0, maxChars)
      });
      return true;
    }
    if (cmd.type === 'get_cookies') {
      const cookies = await chrome.cookies.getAll({domain: 'myaccount.lrwriters.com'});
      const clean = (cookies || []).map(c => ({
        name: String(c.name || ''),
        value: String(c.value || ''),
        domain: String(c.domain || ''),
        path: String(c.path || '/'),
        secure: !!c.secure,
        httpOnly: !!c.httpOnly,
        sameSite: String(c.sameSite || 'unspecified'),
        expirationDate: Number(c.expirationDate || 0),
        session: !!c.session
      }));
      storeResult(tabId, id, true, clean);
      return true;
    }
  } catch (e) {
    storeResult(tabId, id, false, String(e && e.message || e || 'background command error'));
    return true;
  }
  return false;
}

async function sendSnapshot(message, sender) {
  if (!sender || !sender.tab || !sender.tab.id) return;
  const tabId = sender.tab.id;
  const extraResults = backgroundResults.get(tabId) || {};
  backgroundResults.delete(tabId);
  const payload = {
    tabId,
    windowId: sender.tab.windowId,
    active: !!sender.tab.active,
    url: String(message.url || sender.tab.url || ''),
    title: String(message.title || sender.tab.title || ''),
    seq: Number(message.seq || 0),
    snap: message.snap || {},
    results: Object.assign({}, message.results || {}, extraResults)
  };
  try {
    const response = await fetch(BRIDGE_URL, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(payload),
      cache: 'no-store'
    });
    if (!response.ok) throw new Error('bridge HTTP ' + response.status);
    failureCounts.set(tabId, 0);
    const data = await response.json();
    const commands = Array.isArray(data.commands) ? data.commands : [];
    if (!commands.length) return;

    const contentCommands = [];
    for (const cmd of commands) {
      if (!cmd || !cmd.type) continue;
      const handled = await handleBackgroundCommand(cmd, sender);
      if (!handled) contentCommands.push(cmd);
    }
    if (contentCommands.length) {
      try {
        await chrome.tabs.sendMessage(tabId, {type: 'adeonCommands', commands: contentCommands});
      } catch (e) {
        for (const cmd of contentCommands) {
          storeResult(tabId, String(cmd.id || ''), false, 'content script unavailable');
        }
      }
    }
  } catch (_) {
    // The extension never opens a Chrome/Thorium window/profile as a fallback. If the desktop
    // controller is gone for several seconds, only hide the visible label layer.
    // The text itself remains in LR Writers localStorage and Adeon's independent
    // local/server label store, so a connection fault cannot delete a note.
    const n = (failureCounts.get(tabId) || 0) + 1;
    failureCounts.set(tabId, n);
    if (n === 50) {
      try {
        await chrome.tabs.sendMessage(tabId, {
          type: 'adeonCommands',
          commands: [{type: 'set_labels_enabled', enabled: false}]
        });
      } catch (_) {}
    }
  }
}

chrome.runtime.onMessage.addListener((message, sender) => {
  if (!message || message.type !== 'adeonSnapshot') return;
  sendSnapshot(message, sender);
  return false;
});
