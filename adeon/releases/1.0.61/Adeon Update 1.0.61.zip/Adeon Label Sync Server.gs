/* Adeon Label Sync Server v2
   Independent shared label store for Adeon.

   Deploy once as a Google Apps Script Web App.
   Execute as: Me
   Who has access: Anyone

   After deployment, publish the Web App URL as `label_sync_url` in Adeon's
   normal update manifest (or place it in Built In Label Sync URL.txt before
   distributing an installer). Recipient laptops then need no manual sync setup.

   v2 safety model
   - Every accepted edit receives a monotonically increasing server revision.
   - Stale offline edits do NOT silently overwrite a newer server revision.
   - Every accepted edit and every conflict is appended to a private history Sheet.
   - The latest state is also kept in Script Properties for fast reads.
   - If the state property is ever lost, it can be rebuilt from the history Sheet.
*/

const ADEON_SHARED_SECRET = 'QqgfNUyt-WrqMbX3PGc8aIZxdPADZ7Yn0dtyxiuMywI';
const STATE_KEY = 'ADEON_LABEL_STATE_V2';
const HISTORY_SHEET_ID_KEY = 'ADEON_LABEL_HISTORY_SHEET_ID_V2';
const PROTOCOL_VERSION = 2;

function jsonOut(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function authorized(secret) {
  return String(secret || '') === ADEON_SHARED_SECRET;
}

function cleanKey(v) {
  return String(v == null ? '' : v).trim().toUpperCase().slice(0, 80);
}

function cleanValue(v) {
  return String(v == null ? '' : v).trim().toUpperCase();
}

function emptyState() {
  return {labels: {}, times: {}, revisions: {}, server_rev: 0};
}

function cleanState(input) {
  input = input && typeof input === 'object' ? input : {};
  const labelsIn = input.labels && typeof input.labels === 'object' ? input.labels : {};
  const timesIn = input.times && typeof input.times === 'object' ? input.times : {};
  const revsIn = input.revisions && typeof input.revisions === 'object' ? input.revisions : {};
  const labels = {};
  const times = {};
  const revisions = {};
  const keys = {};
  Object.keys(labelsIn).concat(Object.keys(timesIn), Object.keys(revsIn)).forEach(function(k) { keys[k] = true; });
  Object.keys(keys).forEach(function(rawKey) {
    const key = cleanKey(rawKey);
    if (!key) return;
    const value = cleanValue(Object.prototype.hasOwnProperty.call(labelsIn, rawKey) ? labelsIn[rawKey] : labelsIn[key]);
    const ts = Math.max(0, Number(Object.prototype.hasOwnProperty.call(timesIn, rawKey) ? timesIn[rawKey] : timesIn[key]) || 0);
    const rev = Math.max(0, Math.floor(Number(Object.prototype.hasOwnProperty.call(revsIn, rawKey) ? revsIn[rawKey] : revsIn[key]) || 0));
    if (value) labels[key] = value;
    times[key] = ts;
    revisions[key] = rev;
  });
  return {
    labels: labels,
    times: times,
    revisions: revisions,
    server_rev: Math.max(0, Math.floor(Number(input.server_rev) || 0))
  };
}

function getHistorySheet() {
  const props = PropertiesService.getScriptProperties();
  let id = props.getProperty(HISTORY_SHEET_ID_KEY) || '';
  let ss = null;
  if (id) {
    try { ss = SpreadsheetApp.openById(id); } catch (e) { ss = null; }
  }
  if (!ss) {
    ss = SpreadsheetApp.create('Adeon Label Sync History');
    props.setProperty(HISTORY_SHEET_ID_KEY, ss.getId());
  }
  let sh = ss.getSheetByName('Events');
  if (!sh) sh = ss.insertSheet('Events');
  if (sh.getLastRow() === 0) {
    sh.appendRow(['server_rev','server_time','status','event_id','device','order','value','client_time','base_rev','current_rev','current_value']);
    sh.setFrozenRows(1);
  }
  return sh;
}

function appendHistory(rows) {
  if (!rows || !rows.length) return;
  const sh = getHistorySheet();
  const values = rows.map(function(r) {
    return [
      Number(r.server_rev) || 0,
      Number(r.server_time) || 0,
      String(r.status || ''),
      String(r.event_id || ''),
      String(r.device || ''),
      String(r.order || ''),
      String(r.value || ''),
      Number(r.client_time) || 0,
      Number(r.base_rev) || 0,
      Number(r.current_rev) || 0,
      String(r.current_value || '')
    ];
  });
  sh.getRange(sh.getLastRow() + 1, 1, values.length, values[0].length).setValues(values);
}

function rebuildStateFromHistory() {
  const state = emptyState();
  try {
    const sh = getHistorySheet();
    const last = sh.getLastRow();
    if (last <= 1) return state;
    const rows = sh.getRange(2, 1, last - 1, 11).getValues();
    rows.forEach(function(row) {
      const rev = Math.max(0, Math.floor(Number(row[0]) || 0));
      const status = String(row[2] || '');
      const key = cleanKey(row[5]);
      if (!key) return;
      state.server_rev = Math.max(state.server_rev, rev);
      if (status !== 'accepted' && status !== 'legacy-accepted') return;
      const value = cleanValue(row[6]);
      const ts = Math.max(0, Number(row[7]) || 0);
      if (value) state.labels[key] = value; else delete state.labels[key];
      state.times[key] = ts;
      state.revisions[key] = rev;
    });
  } catch (e) {}
  return state;
}

function readState() {
  const props = PropertiesService.getScriptProperties();
  const raw = props.getProperty(STATE_KEY) || '';
  if (raw) {
    try { return cleanState(JSON.parse(raw)); } catch (e) {}
  }
  const rebuilt = rebuildStateFromHistory();
  props.setProperty(STATE_KEY, JSON.stringify(rebuilt));
  return rebuilt;
}

function saveState(state) {
  PropertiesService.getScriptProperties().setProperty(STATE_KEY, JSON.stringify(cleanState(state)));
}

function parseBody(e) {
  try { return JSON.parse(e && e.postData ? e.postData.contents : '{}'); }
  catch (err) { return {}; }
}

function doGet(e) {
  const secret = e && e.parameter ? e.parameter.adeon_secret : '';
  if (!authorized(secret)) return jsonOut({ok: false, protocol: PROTOCOL_VERSION, error: 'unauthorized'});
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const state = readState();
    return jsonOut({ok: true, protocol: PROTOCOL_VERSION, state: state, server_time: Date.now() / 1000});
  } finally {
    lock.releaseLock();
  }
}

function doPost(e) {
  const body = parseBody(e);
  const secret = body.secret || (e && e.parameter ? e.parameter.adeon_secret : '');
  if (!authorized(secret)) return jsonOut({ok: false, protocol: PROTOCOL_VERSION, error: 'unauthorized'});

  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const state = readState();
    let nextRev = Math.max(0, Number(state.server_rev) || 0);
    const accepted = [];
    const conflicts = [];
    const historyRows = [];
    const events = Array.isArray(body.events) ? body.events : [];

    if (events.length) {
      events.forEach(function(raw) {
        raw = raw && typeof raw === 'object' ? raw : {};
        const key = cleanKey(raw.order);
        if (!key) return;
        const value = cleanValue(raw.value);
        const eventId = String(raw.event_id || '').slice(0, 180);
        const device = String(raw.device || body.device || '').slice(0, 120);
        const clientTime = Math.max(0, Number(raw.client_time) || 0);
        const baseRev = Math.max(0, Math.floor(Number(raw.base_rev) || 0));
        const currentRev = Math.max(0, Math.floor(Number(state.revisions[key]) || 0));
        const currentValue = cleanValue(state.labels[key] || '');

        nextRev += 1;
        const serverTime = Date.now() / 1000;

        // Safety rule. An offline laptop that has not seen a newer revision cannot
        // silently overwrite it. Its proposed text is retained permanently in the
        // history Sheet as a conflict instead of being discarded.
        if (baseRev < currentRev) {
          const conflict = {
            event_id: eventId,
            order: key,
            proposed_value: value,
            client_time: clientTime,
            base_rev: baseRev,
            current_rev: currentRev,
            current_value: currentValue,
            server_rev: nextRev,
            server_time: serverTime
          };
          conflicts.push(conflict);
          historyRows.push({
            server_rev: nextRev, server_time: serverTime, status: 'conflict',
            event_id: eventId, device: device, order: key, value: value,
            client_time: clientTime, base_rev: baseRev,
            current_rev: currentRev, current_value: currentValue
          });
          state.server_rev = nextRev;
          return;
        }

        if (value) state.labels[key] = value; else delete state.labels[key];
        state.times[key] = clientTime || serverTime;
        state.revisions[key] = nextRev;
        state.server_rev = nextRev;
        accepted.push(eventId);
        historyRows.push({
          server_rev: nextRev, server_time: serverTime, status: 'accepted',
          event_id: eventId, device: device, order: key, value: value,
          client_time: clientTime, base_rev: baseRev,
          current_rev: currentRev, current_value: currentValue
        });
      });
    } else if (Number(body.protocol || 0) < 2) {
      // Backward compatibility for older Adeon clients that POST one merged snapshot.
      const incoming = cleanState(body.state || {});
      const keys = {};
      Object.keys(incoming.times).concat(Object.keys(incoming.labels)).forEach(function(k) { keys[k] = true; });
      Object.keys(keys).forEach(function(key) {
        const incomingTime = Number(incoming.times[key]) || 0;
        const currentTime = Number(state.times[key]) || 0;
        const incomingValue = cleanValue(incoming.labels[key] || '');
        const currentValue = cleanValue(state.labels[key] || '');
        if (incomingTime <= currentTime || incomingValue === currentValue) return;
        nextRev += 1;
        if (incomingValue) state.labels[key] = incomingValue; else delete state.labels[key];
        state.times[key] = incomingTime;
        state.revisions[key] = nextRev;
        state.server_rev = nextRev;
        historyRows.push({
          server_rev: nextRev, server_time: Date.now()/1000, status: 'legacy-accepted',
          event_id: '', device: String(body.device || ''), order: key, value: incomingValue,
          client_time: incomingTime, base_rev: 0,
          current_rev: Number(state.revisions[key]) || 0, current_value: currentValue
        });
      });
    }

    saveState(state);
    appendHistory(historyRows);
    return jsonOut({
      ok: true,
      protocol: PROTOCOL_VERSION,
      accepted: accepted,
      conflicts: conflicts,
      state: cleanState(state),
      server_time: Date.now() / 1000
    });
  } finally {
    lock.releaseLock();
  }
}
