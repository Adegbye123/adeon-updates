param(
    [string]$ImagePath = '',
    [switch]$Loop
)

$ErrorActionPreference = 'Stop'
$utf8 = New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding = $utf8

Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Storage.StorageFile, Windows.Storage, ContentType=WindowsRuntime]
$null = [Windows.Storage.FileAccessMode, Windows.Storage, ContentType=WindowsRuntime]
$null = [Windows.Storage.Streams.IRandomAccessStream, Windows.Storage.Streams, ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Foundation, ContentType=WindowsRuntime]
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType=WindowsRuntime]
$null = [Windows.Media.Ocr.OcrResult, Windows.Foundation, ContentType=WindowsRuntime]
$null = [Windows.Foundation.IAsyncOperation`1, Windows.Foundation, ContentType=WindowsRuntime]

function Wait-WinRt([object]$Operation, [Type]$ResultType) {
    $asTask = [System.WindowsRuntimeSystemExtensions].GetMethods() |
        Where-Object {
            $_.Name -eq 'AsTask' -and $_.IsGenericMethod -and
            $_.GetParameters().Count -eq 1 -and
            $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
        } | Select-Object -First 1
    if ($null -eq $asTask) { throw 'Could not locate WinRT AsTask helper.' }
    $task = $asTask.MakeGenericMethod($ResultType).Invoke($null, @($Operation))
    $task.Wait()
    return $task.Result
}

$engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
if ($null -eq $engine) { throw 'Windows OCR engine is unavailable for the current language profile.' }

function Invoke-AdeonOcr([string]$Path) {
    $stream = $null
    try {
        $resolved = (Resolve-Path -LiteralPath $Path).Path
        $file = Wait-WinRt ([Windows.Storage.StorageFile]::GetFileFromPathAsync($resolved)) ([Windows.Storage.StorageFile])
        $stream = Wait-WinRt ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
        $decoder = Wait-WinRt ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
        $bitmap = Wait-WinRt ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
        $result = Wait-WinRt ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])

        $outLines = @()
        foreach ($line in $result.Lines) {
            $outWords = @()
            $left = [double]::PositiveInfinity
            $top = [double]::PositiveInfinity
            $right = [double]::NegativeInfinity
            $bottom = [double]::NegativeInfinity
            foreach ($word in $line.Words) {
                $r = $word.BoundingRect
                $x = [double]$r.X; $y = [double]$r.Y; $w = [double]$r.Width; $h = [double]$r.Height
                if ($x -lt $left) { $left = $x }
                if ($y -lt $top) { $top = $y }
                if (($x + $w) -gt $right) { $right = $x + $w }
                if (($y + $h) -gt $bottom) { $bottom = $y + $h }
                $outWords += [ordered]@{ text = [string]$word.Text; x = $x; y = $y; w = $w; h = $h }
            }
            $bounds = $null
            if ($outWords.Count -gt 0) {
                $bounds = [ordered]@{ x = $left; y = $top; w = ($right - $left); h = ($bottom - $top) }
            }
            $outLines += [ordered]@{ text = [string]$line.Text; bounds = $bounds; words = $outWords }
        }

        return [ordered]@{
            ok = $true
            backend = 'Windows.Media.Ocr'
            language = [string]$engine.RecognizerLanguage.LanguageTag
            text = [string]$result.Text
            lines = $outLines
        }
    }
    finally {
        if ($null -ne $stream) {
            try { $stream.Dispose() } catch {}
        }
    }
}

function Write-OneResult([string]$Path) {
    try {
        $obj = Invoke-AdeonOcr $Path
        [Console]::Out.WriteLine(($obj | ConvertTo-Json -Depth 8 -Compress))
    }
    catch {
        [Console]::Out.WriteLine(([ordered]@{ ok = $false; error = [string]$_.Exception.Message } | ConvertTo-Json -Compress))
    }
    [Console]::Out.Flush()
}

if ($Loop) {
    while ($true) {
        $line = [Console]::In.ReadLine()
        if ($null -eq $line) { break }
        if ($line -eq '__QUIT__') { break }
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        Write-OneResult $line
    }
    exit 0
}

if ([string]::IsNullOrWhiteSpace($ImagePath)) {
    [ordered]@{ ok = $false; error = 'ImagePath is required unless -Loop is used.' } | ConvertTo-Json -Compress
    exit 2
}

Write-OneResult $ImagePath
