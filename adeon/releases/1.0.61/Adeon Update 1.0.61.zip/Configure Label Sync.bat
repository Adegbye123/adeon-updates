@echo off
setlocal EnableExtensions
set "DATA=%LOCALAPPDATA%\Adeon Data"
set "HERE=%~dp0"
if not exist "%DATA%" mkdir "%DATA%" >nul 2>&1
cls
echo.
echo ADEON LABEL SYNC OWNER FALLBACK
echo ----------------------
echo Paste the deployed Google Apps Script Web App URL below.
echo Ordinary 1.0.30 installs do not need this when the URL is published in the manifest or built into the package.
echo.
set /p "SYNCURL=Web App URL: "
if not defined SYNCURL (
  echo No URL entered. Nothing was changed.
  pause
  exit /b 1
)
>"%DATA%\Label Sync URL.txt" echo %SYNCURL%
if exist "%HERE%Label Sync Secret.txt" (
  copy /Y "%HERE%Label Sync Secret.txt" "%DATA%\Label Sync Secret.txt" >nul
)
echo.
echo Label sync configured.
echo Press ON LABELS in Adeon on each computer.
echo.
pause
exit /b 0
