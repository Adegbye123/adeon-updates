@echo off
setlocal EnableExtensions
set "BASE=%~dp0"
set "SCRIPT=%BASE%Register Browser Integration.ps1"
set "PAIRDIR=%BASE%Adeon Browser Integration"
if not exist "%PAIRDIR%\manifest.json" set "PAIRDIR=%LOCALAPPDATA%\Adeon Browser Integration"

if not exist "%SCRIPT%" (
    echo Adeon Browser Integration registration script is missing.
    pause
    exit /b 2
)
if not exist "%PAIRDIR%\manifest.json" (
    echo Adeon Browser Integration files are missing from:
    echo %PAIRDIR%
    echo.
    echo Re-run Install Adeon.bat first.
    pause
    exit /b 3
)

echo.
echo ============================================
echo        ADEON BROWSER INTEGRATION
echo ============================================
echo.
echo Preparing the existing Chrome/Thorium integration.
echo Adeon will NOT open, close, restart, or create a browser window, tab, or profile.
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -Install
set "RC=%ERRORLEVEL%"

echo %PAIRDIR%| clip
start "" explorer.exe "%PAIRDIR%"

echo.
echo The integration folder is open in Windows Explorer and its path is copied.
echo.
echo ONE-TIME PAIRING if Adeon says BROWSER INTEGRATION NEEDED:
echo   1. In the SAME Chrome or Thorium profile where LR Writers is open,
echo      manually go to chrome://extensions
 echo   2. Turn Developer mode ON.
echo   3. Click Load unpacked.
echo   4. Choose this folder:
echo      %PAIRDIR%
echo   5. Return to LR Writers.
echo.
echo Adeon will detect the heartbeat automatically. No new browser is created.
echo.
pause
exit /b %RC%
