param(
    [Parameter(Mandatory=$true)][Int64]$Hwnd,
    [Parameter(Mandatory=$true)][string]$ExtensionPath,
    [string]$ReturnUrl = 'https://myaccount.lrwriters.com/findorders/all'
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
Add-Type -AssemblyName System.Windows.Forms

Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class AdeonPairWin32 {
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
    [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern bool SetCursorPos(int X, int Y);
    [DllImport("user32.dll")] public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
}
"@

function Log([string]$s) { Write-Output ("AUTO_PAIR | " + $s) }
function Focus-Handle([IntPtr]$h) {
    if (-not [AdeonPairWin32]::IsWindow($h)) { throw 'Target browser window no longer exists.' }
    [AdeonPairWin32]::ShowWindow($h, 9) | Out-Null
    [AdeonPairWin32]::SetForegroundWindow($h) | Out-Null
    Start-Sleep -Milliseconds 180
}
function Set-ClipboardText([string]$s) {
    [System.Windows.Forms.Clipboard]::SetText($s)
}
function Native-Click([int]$x, [int]$y) {
    [AdeonPairWin32]::SetCursorPos($x,$y) | Out-Null
    Start-Sleep -Milliseconds 80
    [AdeonPairWin32]::mouse_event(0x0002,0,0,0,[UIntPtr]::Zero)
    Start-Sleep -Milliseconds 45
    [AdeonPairWin32]::mouse_event(0x0004,0,0,0,[UIntPtr]::Zero)
    Start-Sleep -Milliseconds 180
}
function Click-ElementCenter($el) {
    if ($null -eq $el) { return $false }
    try {
        $r = $el.Current.BoundingRectangle
        if ($r.Width -gt 4 -and $r.Height -gt 4) {
            Focus-Handle ([IntPtr]$Hwnd)
            Native-Click ([int]($r.X + ($r.Width/2))) ([int]($r.Y + ($r.Height/2)))
            return $true
        }
    } catch {}
    return $false
}
function Window-Rect([IntPtr]$h) {
    $r = New-Object AdeonPairWin32+RECT
    if ([AdeonPairWin32]::GetWindowRect($h,[ref]$r)) { return $r }
    return $null
}
function Click-Standard-DeveloperMode([IntPtr]$h) {
    $r = Window-Rect $h
    if ($null -eq $r) { return $false }
    # Chromium extensions page: Developer mode toggle is in the upper-right content header.
    $x = [int]($r.Right - 92)
    $y = [int]($r.Top + 112)
    Focus-Handle $h
    Native-Click $x $y
    return $true
}
function Click-Standard-LoadUnpacked([IntPtr]$h) {
    $r = Window-Rect $h
    if ($null -eq $r) { return $false }
    # Appears under the extensions header once Developer mode is enabled.
    $x = [int]($r.Left + 132)
    $y = [int]($r.Top + 164)
    Focus-Handle $h
    Native-Click $x $y
    return $true
}
function Navigate-In-Same-Tab([IntPtr]$h, [string]$url) {
    Focus-Handle $h
    Set-ClipboardText $url
    [System.Windows.Forms.SendKeys]::SendWait('^l')
    Start-Sleep -Milliseconds 80
    [System.Windows.Forms.SendKeys]::SendWait('^v')
    Start-Sleep -Milliseconds 50
    [System.Windows.Forms.SendKeys]::SendWait('{ENTER}')
}
function Root-For([IntPtr]$h) {
    return [System.Windows.Automation.AutomationElement]::FromHandle($h)
}
function Find-By-Names($root, [string[]]$names, [int]$waitMs = 0) {
    $deadline = [DateTime]::UtcNow.AddMilliseconds([Math]::Max(0,$waitMs))
    do {
        try {
            $all = $root.FindAll([System.Windows.Automation.TreeScope]::Descendants, [System.Windows.Automation.Condition]::TrueCondition)
            foreach ($el in $all) {
                $n = ''
                try { $n = [string]$el.Current.Name } catch {}
                if (-not $n) { continue }
                foreach ($want in $names) {
                    if ($n.Equals($want,[StringComparison]::OrdinalIgnoreCase) -or $n.IndexOf($want,[StringComparison]::OrdinalIgnoreCase) -ge 0) {
                        return $el
                    }
                }
            }
        } catch {}
        if ([DateTime]::UtcNow -ge $deadline) { break }
        Start-Sleep -Milliseconds 180
    } while ($true)
    return $null
}
function Invoke-Element($el) {
    if ($null -eq $el) { return $false }
    try {
        $p = $null
        if ($el.TryGetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern,[ref]$p)) {
            ([System.Windows.Automation.InvokePattern]$p).Invoke(); return $true
        }
    } catch {}
    try {
        $p = $null
        if ($el.TryGetCurrentPattern([System.Windows.Automation.LegacyIAccessiblePattern]::Pattern,[ref]$p)) {
            ([System.Windows.Automation.LegacyIAccessiblePattern]$p).DoDefaultAction(); return $true
        }
    } catch {}
    # Thorium may expose the control name/bounds while refusing InvokePattern.
    return (Click-ElementCenter $el)
}
function Ensure-Toggle-On($el) {
    if ($null -eq $el) { return $false }
    try {
        $p = $null
        if ($el.TryGetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern,[ref]$p)) {
            $tp = [System.Windows.Automation.TogglePattern]$p
            if ($tp.Current.ToggleState -ne [System.Windows.Automation.ToggleState]::On) { $tp.Toggle() }
            return $true
        }
    } catch {}
    # Fallback to a real visible click rather than assuming Invoke exists.
    return (Click-ElementCenter $el)
}
function Find-Folder-Dialog([int]$waitMs = 6000) {
    $deadline = [DateTime]::UtcNow.AddMilliseconds($waitMs)
    do {
        try {
            $fg = [AdeonPairWin32]::GetForegroundWindow()
            if ($fg -ne [IntPtr]::Zero -and $fg.ToInt64() -ne $Hwnd) {
                $root = Root-For $fg
                if ($root) {
                    $btn = Find-By-Names $root @('Select Folder','Select','Open') 0
                    if ($btn) { return @($fg,$root,$btn) }
                }
            }
        } catch {}
        Start-Sleep -Milliseconds 180
    } while ([DateTime]::UtcNow -lt $deadline)
    return $null
}

$browser = [IntPtr]$Hwnd
if (-not (Test-Path -LiteralPath (Join-Path $ExtensionPath 'manifest.json'))) { throw "Extension folder is incomplete: $ExtensionPath" }

Log 'using the already-open browser window; no browser/tab/window/profile will be created.'
Navigate-In-Same-Tab $browser 'chrome://extensions/'
Start-Sleep -Milliseconds 1200
$root = Root-For $browser
if (-not $root) { throw 'Could not read the existing browser accessibility tree.' }

$developer = Find-By-Names $root @('Developer mode') 5000
if ($developer) {
    if (Ensure-Toggle-On $developer) {
        Log 'Developer mode enabled using the visible control in the same browser window.'
    } else {
        throw 'Developer mode was found but could not be switched on.'
    }
    Start-Sleep -Milliseconds 900
    $root = Root-For $browser
} else {
    Log 'Developer mode was not exposed by accessibility; using guarded native click fallback on the standard Chromium extensions page.'
    if (-not (Click-Standard-DeveloperMode $browser)) { throw 'Could not activate Developer mode.' }
    Start-Sleep -Milliseconds 1000
    $root = Root-For $browser
}

$load = Find-By-Names $root @('Load unpacked') 4500
if ($load) {
    if (-not (Invoke-Element $load)) { throw 'Could not activate the visible Load unpacked control.' }
    Log 'Load unpacked activated through the visible browser control.'
} else {
    Log 'Load unpacked was not exposed by accessibility; using guarded native click fallback on the standard Chromium extensions page.'
    if (-not (Click-Standard-LoadUnpacked $browser)) { throw 'Could not activate Load unpacked.' }
}
Log 'Load unpacked activated in the same browser tab.'

$dialog = Find-Folder-Dialog 7000
if (-not $dialog) { throw 'The extension folder picker did not appear.' }
$dialogHwnd = [IntPtr]$dialog[0]
$dialogRoot = $dialog[1]
Focus-Handle $dialogHwnd
Set-ClipboardText $ExtensionPath
[System.Windows.Forms.SendKeys]::SendWait('^l')
Start-Sleep -Milliseconds 120
[System.Windows.Forms.SendKeys]::SendWait('^v')
Start-Sleep -Milliseconds 80
[System.Windows.Forms.SendKeys]::SendWait('{ENTER}')
Start-Sleep -Milliseconds 650

# Reacquire the dialog after it navigates to the extension directory.
try { $dialogRoot = Root-For $dialogHwnd } catch {}
$select = Find-By-Names $dialogRoot @('Select Folder','Select') 3500
if (-not $select) { $select = Find-By-Names $dialogRoot @('Open') 1000 }
if ($select) {
    if (-not (Invoke-Element $select)) { throw 'Could not confirm the extension folder selection.' }
} else {
    # Last folder-dialog fallback: Enter commonly confirms the current directory.
    [System.Windows.Forms.SendKeys]::SendWait('{ENTER}')
    Start-Sleep -Milliseconds 500
}
Log 'Adeon Browser Integration folder selected.'
Start-Sleep -Milliseconds 1200

# The existing LR tab was temporarily used only for browser setup. Put it back on
# Find Orders before handing control to Picker/Labels.
Navigate-In-Same-Tab $browser $ReturnUrl
Log 'same browser tab returned to LR Writers Find Orders.'
Start-Sleep -Milliseconds 1800
Log 'pairing helper completed; waiting for Browser Integration heartbeat.'
exit 0
