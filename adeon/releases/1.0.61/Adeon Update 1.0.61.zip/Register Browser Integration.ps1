param([switch]$Install, [switch]$MachineOnly)

$ErrorActionPreference = 'Stop'

$id = 'efnloiohfchcnkmiindjmlbmnmbdkifo'
$scriptDir = Split-Path -Parent $PSCommandPath
$canonicalDir = Join-Path $scriptDir 'Adeon Browser Integration'
$legacyDir = Join-Path $env:LOCALAPPDATA 'Adeon Browser Integration'
$integrationDir = if (Test-Path -LiteralPath (Join-Path $canonicalDir 'manifest.json')) { $canonicalDir } else { $legacyDir }
$manifest = Join-Path $integrationDir 'manifest.json'
$updateUrl = 'http://127.0.0.1:17329/extension/update.xml'
$installSource = 'http://127.0.0.1:17329/*'

if (-not (Test-Path -LiteralPath $manifest)) {
    throw "Adeon Browser Integration files are missing: $integrationDir"
}

function Set-ListPolicyValue {
    param(
        [Parameter(Mandatory=$true)][string]$Base,
        [Parameter(Mandatory=$true)][string]$Policy,
        [Parameter(Mandatory=$true)][string]$Value
    )
    $path = Join-Path $Base $Policy
    New-Item -Path $path -Force | Out-Null

    # Reuse an existing slot if Adeon is already present. Otherwise choose the
    # first free numeric slot so we never overwrite another browser policy.
    $props = Get-ItemProperty -Path $path -ErrorAction SilentlyContinue
    $slot = $null
    if ($props) {
        foreach ($p in $props.PSObject.Properties) {
            if ($p.Name -match '^\d+$' -and [string]$p.Value -like "$id*") {
                $slot = $p.Name
                break
            }
        }
    }
    if (-not $slot) {
        for ($i=1; $i -le 200; $i++) {
            $name = [string]$i
            $existing = (Get-ItemProperty -Path $path -Name $name -ErrorAction SilentlyContinue).$name
            if ($null -eq $existing) { $slot = $name; break }
        }
    }
    if (-not $slot) { throw "No free policy slot under $path" }
    New-ItemProperty -Path $path -Name $slot -PropertyType String -Value $Value -Force | Out-Null
}

function Prepare-ChromiumPolicyRoot {
    param([Parameter(Mandatory=$true)][string]$Root)
    Set-ListPolicyValue -Base $Root -Policy 'ExtensionInstallForcelist' -Value "$id;$updateUrl"
    Set-ListPolicyValue -Base $Root -Policy 'ExtensionInstallSources' -Value $installSource
    Set-ListPolicyValue -Base $Root -Policy 'ExtensionInstallAllowlist' -Value $id
}

# Thorium is a Chromium fork. Current Thorium builds use Chromium policy support,
# and some historical builds/templates also looked under a Thorium-branded root.
# Write user-level entries to both so setup can prepare Thorium without launching,
# closing, or restarting it.
$roots = @(
    'HKCU:\Software\Policies\Chromium',
    'HKCU:\Software\Policies\Thorium'
)
foreach ($root in $roots) {
    try {
        Prepare-ChromiumPolicyRoot -Root $root
        Write-Output "Prepared browser integration policy: $root"
    } catch {
        Write-Output "Policy preparation warning for $root : $($_.Exception.Message)"
    }
}


# Chromium-family external-extension discovery. Thorium inherits Chromium's
# Windows external registry loader, which watches this key while the browser is
# running. This gives Adeon a second, non-window-opening installation route in
# addition to enterprise policy. Chrome may ignore a non-store external update
# URL on unmanaged PCs; Thorium/Chromium can consume it when their build allows.
# Manual Load unpacked remains the guaranteed one-time fallback.
try {
    $externalKey = "HKCU:\Software\Google\Chrome\Extensions\$id"
    New-Item -Path $externalKey -Force | Out-Null
    $crxPath = Join-Path $integrationDir 'Adeon Browser Integration.crx'
    New-ItemProperty -Path $externalKey -Name 'update_url' -PropertyType String -Value $updateUrl -Force | Out-Null
    if (Test-Path -LiteralPath $crxPath) {
        New-ItemProperty -Path $externalKey -Name 'path' -PropertyType String -Value $crxPath -Force | Out-Null
        New-ItemProperty -Path $externalKey -Name 'version' -PropertyType String -Value '1.0.33' -Force | Out-Null
    }
    Write-Output "Prepared live Chromium-family external-extension registration: $externalKey"
} catch {
    Write-Output "External-extension registration warning: $($_.Exception.Message)"
}

# Machine-level policy is the most reliable Thorium/Chromium route on Windows.
# During setup only, request elevation once when Thorium is detected. Normal Adeon
# runtime repair calls never trigger UAC and stay user-level.
$isAdmin = $false
try {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    $isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
} catch {}

$thoriumPresent = $false
try { if (Get-Process -Name 'thorium' -ErrorAction SilentlyContinue) { $thoriumPresent = $true } } catch {}
foreach ($candidate in @(
    (Join-Path $env:LOCALAPPDATA 'Thorium\Application\thorium.exe'),
    (Join-Path $env:ProgramFiles 'Thorium\Application\thorium.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'Thorium\Application\thorium.exe')
)) {
    if ($candidate -and (Test-Path -LiteralPath $candidate)) { $thoriumPresent = $true }
}

if ($MachineOnly -or $isAdmin) {
    foreach ($root in @('HKLM:\Software\Policies\Chromium','HKLM:\Software\Policies\Thorium')) {
        try {
            Prepare-ChromiumPolicyRoot -Root $root
            Write-Output "Prepared machine browser integration policy: $root"
        } catch {
            Write-Output "Machine policy warning for $root : $($_.Exception.Message)"
        }
    }
    try {
        $lm = [Microsoft.Win32.Registry]::LocalMachine
        Prepare-ExternalCrxRegistration -Hive $lm -SubPath "Software\Google\Chrome\Extensions\$id"
        Prepare-ExternalCrxRegistration -Hive $lm -SubPath "Software\Wow6432Node\Google\Chrome\Extensions\$id"
        Write-Output "Prepared signed CRX external registration for Chromium-family discovery."
    } catch {}
} elseif ($Install -and $thoriumPresent) {
    try {
        $arg = '-NoLogo -NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '" -MachineOnly'
        $proc = Start-Process -FilePath 'powershell.exe' -ArgumentList $arg -Verb RunAs -Wait -PassThru -ErrorAction Stop
        Write-Output "Thorium machine registration elevation finished with code $($proc.ExitCode)."
    } catch {
        Write-Output "Thorium machine registration was not elevated: $($_.Exception.Message)"
    }
}


# Also register the already-downloaded signed CRX in the standard Chromium/Chrome
# external-extension registry locations. External discovery itself is mainly a
# startup path, but keeping these entries correct makes the next browser start
# deterministic without creating a separate Adeon profile.
function Prepare-ExternalCrxRegistration {
    param([Microsoft.Win32.RegistryKey]$Hive, [string]$SubPath)
    try {
        $crx = Join-Path $integrationDir 'Adeon Browser Integration.crx'
        if (-not (Test-Path -LiteralPath $crx)) { return }
        $key = $Hive.CreateSubKey($SubPath)
        $key.SetValue('path', $crx, [Microsoft.Win32.RegistryValueKind]::String)
        $key.SetValue('version', '1.0.33', [Microsoft.Win32.RegistryValueKind]::String)
        $key.SetValue('update_url', $updateUrl, [Microsoft.Win32.RegistryValueKind]::String)
        $key.Close()
    } catch {}
}

# Google Chrome intentionally receives no off-store force-install policy on an
# ordinary unmanaged Windows PC. Current Chrome blocks silent force-install of
# locally hosted extensions unless the browser/device is enterprise managed.
# If Adeon Browser Integration was already loaded once in Chrome, it keeps using
# the same folder and updates normally. This avoids falsely claiming Chrome was
# auto-enabled when Chrome security would reject it.

# Nudge BOTH machine and user Windows policy refresh. The prior build refreshed
# only user policy even though Thorium machine-wide entries were written under
# HKLM. Chromium/Thorium can consume dynamic policy updates without Adeon opening,
# closing, or restarting the browser.
try {
    Start-Process -FilePath 'gpupdate.exe' -ArgumentList '/force' -WindowStyle Hidden -Wait -ErrorAction SilentlyContinue | Out-Null
} catch {}
try {
    Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class AdeonPolicyBroadcast {
  [DllImport("user32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
  public static extern IntPtr SendMessageTimeout(IntPtr hWnd, uint Msg, IntPtr wParam, string lParam, uint flags, uint timeout, out IntPtr result);
}
"@ -ErrorAction SilentlyContinue
    $result=[IntPtr]::Zero
    [AdeonPolicyBroadcast]::SendMessageTimeout([IntPtr]0xffff,0x001A,[IntPtr]::Zero,'Policy',0x0002,1200,[ref]$result) | Out-Null
} catch {}

Write-Output "Adeon Browser Integration folder is ready: $integrationDir"
Write-Output 'No browser was launched, closed, restarted, or moved to another profile. Dynamic policy refresh was signaled to the already-running browser.'
Write-Output "Thorium/Chromium auto-registration and external-extension discovery were prepared. If the browser still blocks silent installation, use Adeon's one-time Load unpacked pairing button."
exit 0
