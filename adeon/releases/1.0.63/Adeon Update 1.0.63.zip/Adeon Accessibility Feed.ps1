# ADEON_ACCESS_FEED_VERSION=1.0.54
param(
    [Parameter(Mandatory=$true)][Int64]$Hwnd,
    [Parameter(Mandatory=$true)][string]$OutFile,
    [Parameter(Mandatory=$true)][string]$StopFile,
    [int]$IntervalMs = 180
)

$ErrorActionPreference = 'SilentlyContinue'
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
try { Add-Type -AssemblyName Accessibility } catch {}

Add-Type @"
using System;
using System.Text;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Accessibility;

public static class AdeonNative {
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
    [DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr hWndParent, EnumWindowsProc lpEnumFunc, IntPtr lParam);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr hWnd, StringBuilder lpClassName, int nMaxCount);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
    [DllImport("user32.dll", SetLastError=true)] public static extern IntPtr SendMessageTimeout(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam, uint fuFlags, uint uTimeout, out IntPtr lpdwResult);
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }

    public static void NudgeAccessibility(IntPtr hwnd) {
        if (hwnd == IntPtr.Zero) return;
        try {
            IntPtr result;
            // Chromium enables native accessibility on demand when assistive technology requests it.
            // WM_GETOBJECT is the standard Windows accessibility request. The custom object id 1
            // is also used by Chromium's assistive-technology detection path.
            SendMessageTimeout(hwnd, 0x003D, IntPtr.Zero, new IntPtr(1), 0x0002, 250, out result);
            SendMessageTimeout(hwnd, 0x003D, IntPtr.Zero, new IntPtr(unchecked((int)0xFFFFFFFC)), 0x0002, 250, out result); // OBJID_CLIENT
        } catch {}
    }
}

public static class AdeonMsaa {
    private const uint OBJID_CLIENT = 0xFFFFFFFC;
    private static readonly Guid IID_IAccessible = new Guid("618736E0-3C3D-11CF-810C-00AA00389B71");

    [DllImport("oleacc.dll")]
    private static extern int AccessibleObjectFromWindow(IntPtr hwnd, uint dwId, ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out object ppvObject);

    [DllImport("oleacc.dll", CharSet=CharSet.Unicode)]
    private static extern uint GetRoleText(uint lRole, StringBuilder lpszRole, uint cchRoleMax);

    public class Node {
        public string name = "";
        public string value = "";
        public string control = "";
        public string automationId = "";
        public string className = "";
        public string framework = "MSAA";
        public double left;
        public double top;
        public double width;
        public double height;
        public bool enabled = true;
        public bool focusable = false;
        public bool content = true;
        public bool controlElement = true;
    }

    public class Result {
        public List<Node> nodes = new List<Node>();
        public int visited = 0;
        public string diagnostic = "";
    }

    private class Work {
        public IAccessible acc;
        public object child;
        public int depth;
        public Work(IAccessible a, object c, int d) { acc=a; child=c; depth=d; }
    }

    private static string SafeName(IAccessible acc, object child) {
        try { return acc.get_accName(child) ?? ""; } catch { return ""; }
    }
    private static string SafeValue(IAccessible acc, object child) {
        try { return acc.get_accValue(child) ?? ""; } catch { return ""; }
    }
    private static object SafeRole(IAccessible acc, object child) {
        try { return acc.get_accRole(child); } catch { return null; }
    }
    private static object SafeState(IAccessible acc, object child) {
        try { return acc.get_accState(child); } catch { return null; }
    }
    private static string RoleName(object role) {
        try {
            int r = Convert.ToInt32(role);
            StringBuilder sb = new StringBuilder(128);
            if (GetRoleText((uint)r, sb, (uint)sb.Capacity) > 0) return sb.ToString();
            return r.ToString();
        } catch { return ""; }
    }
    private static string MapControl(string role) {
        string r = (role ?? "").ToLowerInvariant();
        if (r.Contains("push button") || r == "button") return "Button";
        if (r.Contains("link")) return "Hyperlink";
        if (r.Contains("document")) return "Document";
        if (r.Contains("text") || r.Contains("static")) return "Text";
        if (r.Contains("combo")) return "ComboBox";
        if (r.Contains("list item")) return "ListItem";
        if (r.Contains("row")) return "DataItem";
        if (r.Contains("menu item")) return "MenuItem";
        if (r.Contains("page tab")) return "TabItem";
        if (r.Contains("editable") || r.Contains("edit")) return "Edit";
        return role ?? "";
    }
    private static bool IsEnabled(object state) {
        try {
            int s = Convert.ToInt32(state);
            const int STATE_SYSTEM_UNAVAILABLE = 0x00000001;
            return (s & STATE_SYSTEM_UNAVAILABLE) == 0;
        } catch { return true; }
    }

    private static Node ReadNode(IAccessible acc, object child) {
        try {
            int x=0,y=0,w=0,h=0;
            try { acc.accLocation(out x, out y, out w, out h, child); } catch {}
            if (w < 2 || h < 2) return null;
            string name = SafeName(acc, child);
            string value = SafeValue(acc, child);
            string role = RoleName(SafeRole(acc, child));
            if (String.IsNullOrWhiteSpace(name) && String.IsNullOrWhiteSpace(value) && String.IsNullOrWhiteSpace(role)) return null;
            return new Node {
                name = name ?? "", value = value ?? "", control = MapControl(role),
                left=x, top=y, width=w, height=h, enabled=IsEnabled(SafeState(acc, child))
            };
        } catch { return null; }
    }

    private static IAccessible AsAccessible(object o) {
        try { return o as IAccessible; } catch { return null; }
    }

    public static Result Scan(IntPtr hwnd, int maxNodes, int budgetMs) {
        Result result = new Result();
        object raw = null;
        Guid iid = IID_IAccessible;
        int hr = -1;
        try { hr = AccessibleObjectFromWindow(hwnd, OBJID_CLIENT, ref iid, out raw); } catch {}
        IAccessible root = AsAccessible(raw);
        if (root == null) {
            result.diagnostic = "msaa AccessibleObjectFromWindow failed hr=" + hr;
            return result;
        }

        Stopwatch sw = Stopwatch.StartNew();
        Queue<Work> q = new Queue<Work>();
        q.Enqueue(new Work(root, 0, 0));
        HashSet<string> seen = new HashSet<string>();

        while (q.Count > 0 && result.visited < maxNodes && sw.ElapsedMilliseconds < budgetMs) {
            Work item = q.Dequeue();
            result.visited++;
            Node n = ReadNode(item.acc, item.child);
            if (n != null) {
                string key = n.left+"|"+n.top+"|"+n.width+"|"+n.height+"|"+n.name+"|"+n.value+"|"+n.control;
                if (seen.Add(key)) result.nodes.Add(n);
            }

            IAccessible container = null;
            if (item.child is int && (int)item.child != 0) {
                try { container = item.acc.get_accChild(item.child) as IAccessible; } catch {}
            } else {
                container = item.acc;
            }
            if (container == null || item.depth >= 40) continue;

            int count = 0;
            try { count = container.accChildCount; } catch { count = 0; }
            if (count <= 0) continue;
            count = Math.Min(count, Math.Min(1200, maxNodes - result.visited + 64));

            // Do not use oleacc AccessibleChildren here. Some Chromium builds expose
            // VARIANT child arrays that PowerShell/.NET marshals inconsistently and
            // that produced the runtime error "Argument types do not match". Walk
            // IAccessible children directly instead. A null accChild for an index is
            // still a valid MSAA simple-child id, so enqueue the integer id.
            for (int childId=1; childId<=count && q.Count < maxNodes; childId++) {
                object childObj = null;
                try { childObj = container.get_accChild(childId); } catch {}
                IAccessible childAcc = AsAccessible(childObj);
                if (childAcc != null) q.Enqueue(new Work(childAcc, 0, item.depth+1));
                else q.Enqueue(new Work(container, childId, item.depth+1));
            }
        }
        sw.Stop();
        result.diagnostic = "msaa visited=" + result.visited + " nodes=" + result.nodes.Count + " ms=" + sw.ElapsedMilliseconds;
        return result;
    }
}
"@ -ReferencedAssemblies @([Accessibility.IAccessible].Assembly.Location)

function Get-AdeonValue([System.Windows.Automation.AutomationElement]$El) {
    try {
        $p = $El.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern)
        if ($null -ne $p) { return [string]$p.Current.Value }
    } catch {}
    return ''
}

function Get-AdeonText([System.Windows.Automation.AutomationElement]$El) {
    try {
        $p = $El.GetCurrentPattern([System.Windows.Automation.TextPattern]::Pattern)
        if ($null -ne $p) {
            $t = [string]$p.DocumentRange.GetText(30000)
            if ($t) { return $t }
        }
    } catch {}
    return ''
}

function Get-RenderHost([IntPtr]$Parent) {
    $script:bestRender = [IntPtr]::Zero
    $script:bestArea = 0
    $cb = [AdeonNative+EnumWindowsProc]{
        param([IntPtr]$child, [IntPtr]$lp)
        try {
            $sb = New-Object System.Text.StringBuilder 256
            [void][AdeonNative]::GetClassName($child, $sb, 256)
            if ($sb.ToString() -eq 'Chrome_RenderWidgetHostHWND') {
                $r = New-Object AdeonNative+RECT
                if ([AdeonNative]::GetWindowRect($child, [ref]$r)) {
                    $area = [Math]::Max(0, $r.Right-$r.Left) * [Math]::Max(0, $r.Bottom-$r.Top)
                    if ($area -gt $script:bestArea) {
                        $script:bestArea = $area
                        $script:bestRender = $child
                    }
                }
            }
        } catch {}
        return $true
    }
    try { [void][AdeonNative]::EnumChildWindows($Parent, $cb, [IntPtr]::Zero) } catch {}
    return $script:bestRender
}

function Add-AdeonNode($El, $Nodes, [ref]$UrlRef, [ref]$DocumentTextRef) {
    try {
        $c = $El.Current
        if ($c.IsOffscreen) { return }
        $r = $c.BoundingRectangle
        if ($r.Width -lt 2 -or $r.Height -lt 2) { return }
        $name = [string]$c.Name
        $control = ''
        try { $control = [string]$c.ControlType.ProgrammaticName } catch {}
        $aid = [string]$c.AutomationId
        $cls = [string]$c.ClassName
        $framework = [string]$c.FrameworkId
        $value = ''
        if ($control -match 'Edit|Document|ComboBox') { $value = Get-AdeonValue $El }
        if (-not $UrlRef.Value -and ($value -match '^https?://(?:www\.)?myaccount\.lrwriters\.com/')) {
            $UrlRef.Value = $value
        }
        if (-not $DocumentTextRef.Value -and $control -match 'Document') {
            $DocumentTextRef.Value = Get-AdeonText $El
        }
        if (-not $name -and -not $value -and $control -notmatch 'Button|Hyperlink|MenuItem|TabItem|DataItem|ListItem|Edit|Document|Text') { return }
        $Nodes.Add([pscustomobject]@{
            name = $name
            value = $value
            control = $control
            automationId = $aid
            className = $cls
            framework = $framework
            left = [Math]::Round([double]$r.Left, 1)
            top = [Math]::Round([double]$r.Top, 1)
            width = [Math]::Round([double]$r.Width, 1)
            height = [Math]::Round([double]$r.Height, 1)
            enabled = [bool]$c.IsEnabled
            focusable = [bool]$c.IsKeyboardFocusable
            content = [bool]$c.IsContentElement
            controlElement = [bool]$c.IsControlElement
        }) | Out-Null
    } catch {}
}

function Scan-AdeonTree($Root, [int]$MaxNodes, [int]$BudgetMs, [string]$View='Control') {
    $nodes = New-Object System.Collections.Generic.List[object]
    $url = ''
    $documentText = ''
    if ($null -eq $Root) {
        return [pscustomobject]@{ nodes=$nodes; url=$url; documentText=$documentText; visited=0 }
    }

    if ($View -eq 'Raw') { $walker = [System.Windows.Automation.TreeWalker]::RawViewWalker }
    elseif ($View -eq 'Content') { $walker = [System.Windows.Automation.TreeWalker]::ContentViewWalker }
    else { $walker = [System.Windows.Automation.TreeWalker]::ControlViewWalker }

    $queue = New-Object 'System.Collections.Generic.Queue[System.Windows.Automation.AutomationElement]'
    $queue.Enqueue($Root)
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $visited = 0
    while ($queue.Count -gt 0 -and $visited -lt $MaxNodes -and $sw.ElapsedMilliseconds -lt $BudgetMs) {
        $el = $queue.Dequeue()
        $visited++
        Add-AdeonNode $el $nodes ([ref]$url) ([ref]$documentText)
        try {
            $child = $walker.GetFirstChild($el)
            $siblingGuard = 0
            while ($null -ne $child -and $siblingGuard -lt 800 -and $visited + $queue.Count -lt $MaxNodes) {
                $queue.Enqueue($child)
                $siblingGuard++
                try { $child = $walker.GetNextSibling($child) } catch { $child = $null }
            }
        } catch {}
    }
    $sw.Stop()
    return [pscustomobject]@{ nodes=$nodes; url=$url; documentText=$documentText; visited=$visited }
}

function Merge-AdeonNodes($Primary, $Extra) {
    $out = New-Object System.Collections.Generic.List[object]
    $seen = @{}
    foreach ($n in @($Primary) + @($Extra)) {
        if ($null -eq $n) { continue }
        $key = ([string]$n.left)+'|'+([string]$n.top)+'|'+([string]$n.width)+'|'+([string]$n.height)+'|'+([string]$n.name)+'|'+([string]$n.value)+'|'+([string]$n.control)
        if (-not $seen.ContainsKey($key)) {
            $seen[$key] = $true
            $out.Add($n) | Out-Null
        }
    }
    return $out
}

function Write-AdeonSnapshot($Object) {
    try {
        $json = $Object | ConvertTo-Json -Compress -Depth 6
        $tmp = $OutFile + '.tmp'
        [System.IO.File]::WriteAllText($tmp, $json, $script:utf8)
        Move-Item -LiteralPath $tmp -Destination $OutFile -Force
        return $true
    } catch { return $false }
}

$mainPtr = [IntPtr]::new($Hwnd)
$utf8 = New-Object System.Text.UTF8Encoding($false)
$script:utf8 = $utf8
$accessibilityNudged = $false

while (-not (Test-Path -LiteralPath $StopFile)) {
    $diag = ''
    try {
        $mainRoot = [System.Windows.Automation.AutomationElement]::FromHandle($mainPtr)
        if ($null -eq $mainRoot) {
            $diag = 'AutomationElement.FromHandle(main window) returned null'
            Start-Sleep -Milliseconds 250
            continue
        }

        $title = ''
        try { $title = [string]$mainRoot.Current.Name } catch {}

        $renderPtr = Get-RenderHost $mainPtr
        if (-not $accessibilityNudged) {
            try {
                [AdeonNative]::NudgeAccessibility($mainPtr)
                if ($renderPtr -ne [IntPtr]::Zero) { [AdeonNative]::NudgeAccessibility($renderPtr) }
            } catch {}
            $accessibilityNudged = $true
            Start-Sleep -Milliseconds 350
        }

        $scanRoot = $mainRoot
        $source = 'uia-main-control'
        $renderRoot = $null
        if ($renderPtr -ne [IntPtr]::Zero) {
            try {
                $renderRoot = [System.Windows.Automation.AutomationElement]::FromHandle($renderPtr)
                if ($null -ne $renderRoot) {
                    $scanRoot = $renderRoot
                    $source = 'uia-render-control'
                }
            } catch {}
        }

        $scan = Scan-AdeonTree $scanRoot 2600 1500 'Control'

        # Chromium's UIA provider is not always complete. Try the Raw view before
        # falling back to MSAA/IAccessible, which Chromium has supported for years.
        if ($scan.nodes.Count -lt 4 -and $null -ne $renderRoot) {
            $raw = Scan-AdeonTree $renderRoot 5000 2200 'Raw'
            if ($raw.nodes.Count -gt $scan.nodes.Count) {
                $scan = $raw
                $source = 'uia-render-raw'
            }
        }

        if ($scan.nodes.Count -lt 4 -and $scanRoot -ne $mainRoot) {
            $fallback = Scan-AdeonTree $mainRoot 2600 1400 'Raw'
            if ($fallback.nodes.Count -gt $scan.nodes.Count) {
                $scan = $fallback
                $source = 'uia-main-raw'
            }
        }

        # If UIA still exposes only browser chrome, query Microsoft's legacy
        # Active Accessibility interface directly. Chromium documents MSAA /
        # IAccessible as a supported Windows accessibility API.
        $msaaDiag = ''
        if ($scan.nodes.Count -lt 4 -or ([string]$scan.documentText).Length -lt 20) {
            [IntPtr]$msaaTarget = $(if ($renderPtr -ne [IntPtr]::Zero) { $renderPtr } else { $mainPtr })
            try {
                $mr = [AdeonMsaa]::Scan([IntPtr]$msaaTarget, [int]5000, [int]2500)
                $msaaDiag = [string]$mr.diagnostic
                if ($null -ne $mr -and $mr.nodes.Count -gt 0) {
                    $scan.nodes = Merge-AdeonNodes $scan.nodes $mr.nodes
                    $scan.visited = [int]$scan.visited + [int]$mr.visited
                    $source = $source + '+msaa'
                }
            } catch {
                $msaaDiag = 'msaa exception: ' + [string]$_.Exception.Message
            }
        }

        $url = [string]$scan.url
        $documentText = [string]$scan.documentText
        if (-not $url) {
            foreach ($n in $scan.nodes) {
                if (($n.value -as [string]) -match '^https?://(?:www\.)?myaccount\.lrwriters\.com/') {
                    $url = [string]$n.value
                    break
                }
            }
        }

        if (-not $documentText) {
            $texts = New-Object System.Collections.Generic.List[string]
            foreach ($n in $scan.nodes) {
                $t = [string]$(if ($n.name) { $n.name } else { $n.value })
                if ($t -and $t.Length -lt 1000) { $texts.Add($t) | Out-Null }
                if (($texts -join ' ').Length -gt 30000) { break }
            }
            $documentText = ($texts -join ' ')
        }

        $sampleParts = New-Object System.Collections.Generic.List[string]
        foreach ($n in @($scan.nodes | Select-Object -First 8)) {
            $sn = [string]$(if ($n.name) { $n.name } else { $n.value })
            if ($sn) {
                $sn = ($sn -replace '[\r\n]+',' ' -replace '\s+',' ').Trim()
                if ($sn.Length -gt 80) { $sn = $sn.Substring(0,80) }
                if ($sn) { $sampleParts.Add($sn) | Out-Null }
            }
        }
        $sampleDiag = $(if ($sampleParts.Count -gt 0) { ' sample=' + ($sampleParts -join ' | ') } else { '' })

        if ($scan.nodes.Count -lt 3 -and -not $documentText) {
            $diag = "accessibility tree is present but Chromium exposed no useful page controls ($source) $msaaDiag$sampleDiag"
        } else {
            $diag = "ok:$source visited=$($scan.visited) nodes=$($scan.nodes.Count) $msaaDiag$sampleDiag"
        }

        $obj = [ordered]@{
            ts = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() / 1000.0
            hwnd = $Hwnd
            renderHwnd = [Int64]$renderPtr
            title = $title
            url = $url
            documentText = $documentText
            nodeCount = $scan.nodes.Count
            diagnostic = $diag
            nodes = $scan.nodes
        }
        [void](Write-AdeonSnapshot $obj)
    } catch {
        $diag = 'feed exception: ' + [string]$_.Exception.Message
        $obj = [ordered]@{
            ts = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() / 1000.0
            hwnd = $Hwnd
            renderHwnd = 0
            title = ''
            url = ''
            documentText = ''
            nodeCount = 0
            diagnostic = $diag
            nodes = @()
        }
        [void](Write-AdeonSnapshot $obj)
    }
    Start-Sleep -Milliseconds ([Math]::Max(120, $IntervalMs))
}
