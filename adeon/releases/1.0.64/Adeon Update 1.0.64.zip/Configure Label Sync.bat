@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "DATA=%LOCALAPPDATA%\Adeon Data"
if not exist "%DATA%" mkdir "%DATA%" >nul 2>&1
cls
echo.
echo ADEON LABEL SYNC CONFIGURATION
echo ------------------------------
echo Enter the deployed Google Apps Script Web App URL and the SAME private
echo shared secret stored in that script's ADEON_SHARED_SECRET Script Property.
echo Neither value is written into the Adeon program folder or public updater.
echo.
set /p "SYNCURL=Web App URL (https://...): "
if not defined SYNCURL (
  echo No URL entered. Nothing was changed.
  pause
  exit /b 1
)
echo %SYNCURL% | findstr /R /I /C:"^https://" >nul
if errorlevel 1 (
  echo The sync URL must begin with https://
  pause
  exit /b 2
)
set /p "SYNCSECRET=Shared secret (24+ characters): "
if not defined SYNCSECRET (
  echo No secret entered. Nothing was changed.
  pause
  exit /b 3
)
set "SYNCURL_ENV=%SYNCURL%"
set "SYNCSECRET_ENV=%SYNCSECRET%"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command ^
  "$u=$env:SYNCURL_ENV;$s=$env:SYNCSECRET_ENV;" ^
  "if([string]::IsNullOrWhiteSpace($u)-or[string]::IsNullOrWhiteSpace($s)-or $s.Length -lt 24){exit 4};" ^
  "[IO.File]::WriteAllText((Join-Path $env:LOCALAPPDATA 'Adeon Data\Label Sync URL.txt'),$u.Trim(),[Text.UTF8Encoding]::new($false));" ^
  "[IO.File]::WriteAllText((Join-Path $env:LOCALAPPDATA 'Adeon Data\Label Sync Secret.txt'),$s.Trim(),[Text.UTF8Encoding]::new($false))"
if errorlevel 1 (
  echo Could not save the sync configuration. Secret must be at least 24 characters.
  pause
  exit /b 4
)
echo.
echo Label sync configuration saved locally.
echo Restart Labels or Adeon. The activity log must say LABEL SYNC READY.
echo.
pause
exit /b 0
