@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "DATA=%LOCALAPPDATA%\Adeon Data"
if not exist "%DATA%" mkdir "%DATA%" >nul 2>&1
cls
echo.
echo ADEON NOTIFICATION CONFIGURATION
echo --------------------------------
echo These values are stored only in your local Adeon Data folder.
echo Leave a field blank if you do not use that service.
echo.
set /p "PUUSER=Pushover user key: "
set /p "PUTOKEN=Pushover app token: "
set /p "GTO=Gmail destination address: "
set /p "GURL=Gmail Web App URL: "
set /p "GSECRET=Gmail Web App secret: "
set "PUUSER_ENV=%PUUSER%"
set "PUTOKEN_ENV=%PUTOKEN%"
set "GTO_ENV=%GTO%"
set "GURL_ENV=%GURL%"
set "GSECRET_ENV=%GSECRET%"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command ^
  "$o=[ordered]@{pushover_user_key=$env:PUUSER_ENV;pushover_app_token=$env:PUTOKEN_ENV;gmail_to=$env:GTO_ENV;gmail_webapp_url=$env:GURL_ENV;gmail_webapp_secret=$env:GSECRET_ENV};" ^
  "$json=$o|ConvertTo-Json -Depth 3;" ^
  "[IO.File]::WriteAllText((Join-Path $env:LOCALAPPDATA 'Adeon Data\Notifications.json'),$json,[Text.UTF8Encoding]::new($false))"
if errorlevel 1 (
  echo Could not save notification settings.
  pause
  exit /b 1
)
echo.
echo Notification settings saved locally.
echo Restart Adeon for them to take effect.
echo.
pause
exit /b 0
