param(
  [Parameter(Mandatory=$true)][string]$OldBot,
  [Parameter(Mandatory=$true)][string]$DataDir
)
$ErrorActionPreference='SilentlyContinue'
if(-not (Test-Path -LiteralPath $OldBot)){ exit 0 }
if(-not (Test-Path -LiteralPath $DataDir)){ New-Item -ItemType Directory -Force -Path $DataDir | Out-Null }
$dest=Join-Path $DataDir 'Notifications.json'
$current=@{}
if(Test-Path -LiteralPath $dest){
  try {
    $obj=Get-Content -Raw -LiteralPath $dest | ConvertFrom-Json
    foreach($p in $obj.PSObject.Properties){ $current[$p.Name]=[string]$p.Value }
  } catch { $current=@{} }
}
$text=Get-Content -Raw -LiteralPath $OldBot
function Get-Simple([string]$name){
  $m=[regex]::Match($text,'(?m)^'+[regex]::Escape($name)+'\s*=\s*["'']([^"'']*)["'']\s*$')
  if($m.Success){ return $m.Groups[1].Value }
  return ''
}
function Get-MultiUrl([string]$name){
  $m=[regex]::Match($text,'(?ms)^'+[regex]::Escape($name)+'\s*=\s*\((.*?)\)\s*$')
  if(-not $m.Success){ return '' }
  $parts=[regex]::Matches($m.Groups[1].Value,'["'']([^"'']*)["'']')
  $v=''
  foreach($p in $parts){ $v += $p.Groups[1].Value }
  return $v
}
$vals=[ordered]@{
  pushover_user_key=(Get-Simple 'PUSHOVER_USER_KEY')
  pushover_app_token=(Get-Simple 'PUSHOVER_APP_TOKEN')
  gmail_to=(Get-Simple 'GMAIL_TO')
  gmail_webapp_url=(Get-MultiUrl 'GMAIL_WEBAPP_URL')
  gmail_webapp_secret=(Get-Simple 'GMAIL_WEBAPP_SECRET')
}
$changed=$false
foreach($k in @($vals.Keys)){
  if([string]::IsNullOrWhiteSpace([string]$current[$k]) -and -not [string]::IsNullOrWhiteSpace([string]$vals[$k])){
    $current[$k]=[string]$vals[$k]
    $changed=$true
  }
}
if($changed -or -not (Test-Path -LiteralPath $dest)){
  $json=$current|ConvertTo-Json -Depth 3
  [IO.File]::WriteAllText($dest,$json,[Text.UTF8Encoding]::new($false))
}
exit 0
