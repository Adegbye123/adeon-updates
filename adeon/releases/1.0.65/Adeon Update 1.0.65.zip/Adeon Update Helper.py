from __future__ import annotations

import ctypes
import json
import ast
import os
import shutil
import subprocess
import sys
import tempfile
import time
import traceback
import winreg
from pathlib import Path
import tkinter as tk

CREATE_NO_WINDOW = 0x08000000
SW_SHOWNORMAL = 1

EXTENSION_ID = 'efnloiohfchcnkmiindjmlbmnmbdkifo'
EXTENSION_VERSION = '1.0.33'


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding='utf-8').strip()
    except Exception:
        return ''


def pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        k32 = ctypes.windll.kernel32
        h = k32.OpenProcess(0x00100000, False, int(pid))
        if not h:
            return False
        try:
            return int(k32.WaitForSingleObject(h, 0)) == 0x00000102
        finally:
            k32.CloseHandle(h)
    except Exception:
        return False


def python_exe(target: Path) -> Path:
    p = Path(read_text(target / 'Python Path.txt') or sys.executable)
    if p.name.lower() == 'pythonw.exe':
        candidate = p.with_name('python.exe')
        if candidate.exists():
            return candidate
    return p


def write_status(target: Path, ok: bool, version: str, message: str) -> None:
    try:
        (target / 'Adeon Update Status.json').write_text(
            json.dumps({'ok': bool(ok), 'version': version, 'message': message, 'time': time.time()}, indent=2),
            encoding='utf-8',
        )
    except Exception:
        pass


def write_support_warning(target: Path, message: str) -> None:
    """Record non-fatal support-file problems without rolling back core Adeon."""
    try:
        with (target / 'Adeon Update Support Warnings.txt').open('a', encoding='utf-8') as f:
            f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message}\n")
    except Exception:
        pass

def migrate_legacy_private_settings(target: Path) -> None:
    """Move credentials embedded by older builds into local user data before replacement."""
    old_bot = target / 'Adeon Bot.py'
    if not old_bot.is_file():
        return
    try:
        source = old_bot.read_text(encoding='utf-8', errors='ignore')
        tree = ast.parse(source)
    except Exception:
        return
    wanted = {
        'PUSHOVER_USER_KEY': 'pushover_user_key',
        'PUSHOVER_APP_TOKEN': 'pushover_app_token',
        'GMAIL_TO': 'gmail_to',
        'GMAIL_WEBAPP_URL': 'gmail_webapp_url',
        'GMAIL_WEBAPP_SECRET': 'gmail_webapp_secret',
    }
    found = {}
    for node in getattr(tree, 'body', []):
        if not isinstance(node, ast.Assign) or len(node.targets) != 1 or not isinstance(node.targets[0], ast.Name):
            continue
        name = node.targets[0].id
        if name not in wanted:
            continue
        try:
            value = ast.literal_eval(node.value)
        except Exception:
            continue
        if isinstance(value, str) and value.strip():
            found[wanted[name]] = value.strip()
    if not found:
        return
    data_dir = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'Adeon Data'
    data_dir.mkdir(parents=True, exist_ok=True)
    dest = data_dir / 'Notifications.json'
    current = {}
    try:
        if dest.is_file():
            obj = json.loads(dest.read_text(encoding='utf-8-sig'))
            if isinstance(obj, dict):
                current = obj
    except Exception:
        current = {}
    changed = False
    for key, value in found.items():
        if not str(current.get(key) or '').strip():
            current[key] = value
            changed = True
    if changed or not dest.exists():
        tmp = dest.with_suffix('.tmp')
        tmp.write_text(json.dumps(current, indent=2), encoding='utf-8')
        os.replace(tmp, dest)
        write_support_warning(target, 'Migrated legacy embedded notification settings into local Adeon Data.')


def copy_program_files(src: Path, target: Path) -> None:
    try:
        (target / 'Label Sync Secret.txt').unlink(missing_ok=True)
    except Exception:
        pass
    # Core runtime files must copy successfully or the update cannot continue.
    core = [
        'Adeon App.pyw', 'Adeon Bot.py', 'Adeon.ico', 'Adeon Update Helper.py',
    ]
    for name in core:
        sp = src / name
        if not sp.is_file():
            raise RuntimeError(f'Update package is missing required core file: {name}')
        shutil.copy2(sp, target / name)

    # Support files are repairable/preservable. In particular the accessibility
    # PowerShell feed is already embedded byte-for-byte inside Adeon Bot and is
    # self-restored at runtime. Security software may remove .ps1 files between
    # the copy and verification step, so that must never roll back an otherwise
    # healthy Adeon update.
    support = [
        'Adeon Accessibility Feed.ps1', 'Adeon Screen Vision OCR.ps1', 'Read Me Adeon.txt', 'Built In Label Sync URL.txt',
        'Configure Label Sync.bat', 'Configure Notifications.bat', 'Migrate Adeon Private Settings.ps1', 'Label Sync Setup.txt',
        'Adeon Label Sync Server.gs', 'Label Sync Manifest Example.txt',
    ]
    for name in support:
        sp = src / name
        if not sp.is_file():
            write_support_warning(target, f'Incoming support file is absent from staged package: {name}')
            continue
        try:
            # Never erase a working package-level label endpoint with an empty
            # fallback from a later release. Persistent per-device Label Sync URL.txt
            # already lives outside the program folder and is never touched here.
            if name == 'Built In Label Sync URL.txt':
                incoming = sp.read_text(encoding='utf-8', errors='ignore').strip()
                existing = target / name
                current = existing.read_text(encoding='utf-8', errors='ignore').strip() if existing.is_file() else ''
                if current and not incoming:
                    continue
            shutil.copy2(sp, target / name)
        except Exception as e:
            # Support files must never make a healthy core update roll back.
            # Accessibility helpers have runtime recovery paths; label state/secrets
            # live persistently under %LOCALAPPDATA%\Adeon Data.
            write_support_warning(target, f'Could not copy support file {name}: {e}')



def _set_reg_string(root, key_path: str, name: str, value: str) -> None:
    with winreg.CreateKeyEx(root, key_path, 0, winreg.KEY_SET_VALUE | winreg.KEY_QUERY_VALUE) as key:
        winreg.SetValueEx(key, name, 0, winreg.REG_SZ, str(value))


def register_browser_integration() -> None:
    # Removed in 1.0.65. Updates never register a browser extension.
    return


def _integration_complete(folder: Path) -> bool:
    return False


def copy_browser_integration(src: Path, target: Path) -> None:
    # Removed in 1.0.65. Never copy or register LR webpage scripts.
    remove_legacy_browser_integration(target)
    return


def remove_legacy_browser_integration(target: Path) -> None:
    """Best-effort removal of the old LR content-script integration.

    1.0.65 uses Screen Vision/UIA only. This removes Adeon-owned unpacked files
    and user-level registrations so future LR pages receive no Adeon content script.
    Machine policy is also removed when the updater happens to have permission.
    """
    local=Path(os.environ.get('LOCALAPPDATA',''))
    for folder in (target/'Adeon Browser Integration', local/'Adeon Browser Integration'):
        try: shutil.rmtree(folder, ignore_errors=True)
        except Exception: pass
    for name in ('Enable Browser Integration.bat','Register Browser Integration.ps1','Pair Existing Browser Integration.ps1','Browser Integration Path.txt'):
        try: (target/name).unlink(missing_ok=True)
        except Exception: pass
    # External-extension registration.
    for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
        for key_path in (
            rf'Software\Google\Chrome\Extensions\{EXTENSION_ID}',
            rf'Software\Wow6432Node\Google\Chrome\Extensions\{EXTENSION_ID}',
        ):
            try: winreg.DeleteKey(hive,key_path)
            except OSError: pass
    # Remove only policy values that mention Adeon's extension ID; preserve all
    # unrelated browser policy entries.
    for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
        for base in (r'Software\Policies\Chromium',r'Software\Policies\Thorium'):
            for leaf in ('ExtensionInstallForcelist','ExtensionInstallAllowlist'):
                path=base+'\\'+leaf
                try:
                    with winreg.OpenKey(hive,path,0,winreg.KEY_QUERY_VALUE|winreg.KEY_SET_VALUE) as key:
                        vals=[]; i=0
                        while True:
                            try: vals.append(winreg.EnumValue(key,i)); i+=1
                            except OSError: break
                        for name,value,_typ in vals:
                            if EXTENSION_ID.lower() in str(value or '').lower():
                                try: winreg.DeleteValue(key,name)
                                except OSError: pass
                except OSError:
                    pass


def verify_required_install(target: Path) -> None:
    # Only the executable runtime is fatal. Support files must never trap Adeon
    # in an update/rollback loop. Picker accessibility and label helper files all have independent recovery/persistent-data paths.
    required = (
        'Adeon App.pyw', 'Adeon Bot.py', 'Adeon.ico', 'Adeon Update Helper.py',
    )
    missing = [name for name in required if not (target / name).is_file()]
    if missing:
        raise RuntimeError('Required Adeon core files are missing after update: ' + ', '.join(missing))

    # Surface support health for diagnostics only. Never roll back the core app
    # because a helper .txt/.bat/.ps1/extension file was removed or unavailable.
    optional = (
        'Adeon Accessibility Feed.ps1', 'Adeon Screen Vision OCR.ps1', 'Built In Label Sync URL.txt',
        'Configure Label Sync.bat', 'Configure Notifications.bat', 'Migrate Adeon Private Settings.ps1', 'Label Sync Setup.txt',
    )
    absent = [name for name in optional if not (target / name).is_file()]
    if absent:
        write_support_warning(target, 'Non-fatal support files absent after update: ' + ', '.join(absent))


def build_exe(target: Path, py: Path, progress) -> None:
    # If the publisher supplied a ready Adeon.exe, use it. Otherwise rebuild
    # locally. Every normal Adeon installation already has PyInstaller because
    # the installer used it to create the first Adeon.exe.
    supplied = target / 'Update Staging' / 'payload' / 'Adeon.exe'
    if supplied.is_file():
        shutil.copy2(supplied, target / 'Adeon.exe')
        return

    progress('Building the updated Adeon app...')
    build = Path(tempfile.gettempdir()) / f'Adeon Update Build {os.getpid()}'
    shutil.rmtree(build, ignore_errors=True)
    (build / 'dist').mkdir(parents=True, exist_ok=True)
    (build / 'work').mkdir(parents=True, exist_ok=True)
    (build / 'spec').mkdir(parents=True, exist_ok=True)
    runtime_dir = target / 'Runtime'
    runtime_dir.mkdir(parents=True, exist_ok=True)
    cmd = [
        str(py), '-m', 'PyInstaller', '--noconfirm', '--clean', '--onefile', '--windowed', '--noupx',
        '--runtime-tmpdir', str(runtime_dir),
        '--name', 'Adeon', '--icon', str(target / 'Adeon.ico'),
        '--distpath', str(build / 'dist'), '--workpath', str(build / 'work'), '--specpath', str(build / 'spec'),
        str(target / 'Adeon App.pyw'),
    ]
    proc = subprocess.run(cmd, cwd=str(target), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                          creationflags=CREATE_NO_WINDOW, timeout=240)
    if proc.returncode != 0 or not (build / 'dist' / 'Adeon.exe').is_file():
        raise RuntimeError('Could not build the updated Adeon.exe')
    shutil.copy2(build / 'dist' / 'Adeon.exe', target / 'Adeon.exe')
    shutil.rmtree(build, ignore_errors=True)



def ensure_startup_shortcut(target: Path) -> None:
    """Keep persistent Labels available after Windows sign-in without touching the browser."""
    try:
        exe = target / 'Adeon.exe'
        icon = target / 'Adeon.ico'
        if not exe.is_file():
            return
        ps = (
            "$w=New-Object -ComObject WScript.Shell; "
            "$startup=$w.SpecialFolders.Item('Startup'); "
            "if($startup){$p=Join-Path $startup 'Adeon Labels.lnk'; "
            "$s=$w.CreateShortcut($p); "
            f"$s.TargetPath='{str(exe).replace(chr(39), chr(39)+chr(39))}'; "
            "$s.Arguments='--background'; "
            f"$s.WorkingDirectory='{str(target).replace(chr(39), chr(39)+chr(39))}'; "
            f"$s.IconLocation='{str(icon).replace(chr(39), chr(39)+chr(39))},0'; "
            "$s.Save()}"
        )
        subprocess.run(
            ['powershell.exe','-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-Command',ps],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=12,
            creationflags=CREATE_NO_WINDOW,
        )
    except Exception as e:
        write_support_warning(target, f'Could not create persistent Labels startup shortcut: {e}')

def relaunch(target: Path) -> None:
    # Immediately after an update, launch the editable app source with pythonw
    # instead of the freshly rebuilt PyInstaller one-file executable. This avoids
    # a Windows/AV race where the one-file bootloader can fail to load python*.dll
    # from its temporary _MEI extraction folder on the first launch only. The
    # normal pinned shortcut still uses Adeon.exe on later user launches.
    try:
        pyw = Path(read_text(target / 'Python Path.txt'))
        app = target / 'Adeon App.pyw'
        if pyw.is_file() and app.is_file():
            subprocess.Popen(
                [str(pyw), str(app)], cwd=str(target), creationflags=CREATE_NO_WINDOW,
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
            return
    except Exception:
        pass

    # Fallback: allow security software a short settling period before launching
    # the one-file executable.
    time.sleep(3.0)
    start_menu = Path(os.environ.get('APPDATA', '')) / 'Microsoft' / 'Windows' / 'Start Menu' / 'Programs' / 'Adeon.lnk'
    try:
        if start_menu.is_file():
            os.startfile(str(start_menu))
            return
    except Exception:
        pass
    subprocess.Popen([str(target / 'Adeon.exe')], cwd=str(target), creationflags=CREATE_NO_WINDOW)


class UpdateWindow:
    def __init__(self) -> None:
        self.root = tk.Tk()
        self.root.title('Adeon Update')
        self.root.geometry('410x180')
        self.root.resizable(False, False)
        self.root.configure(bg='#f7f8f7')
        self.root.attributes('-topmost', True)
        try:
            ico = Path(os.environ.get('LOCALAPPDATA', '')) / 'Adeon' / 'Adeon.ico'
            if ico.exists():
                self.root.iconbitmap(default=str(ico))
        except Exception:
            pass
        tk.Label(self.root, text='ADEON UPDATE', bg='#f7f8f7', fg='#12863a', font=('Segoe UI', 16, 'bold')).pack(pady=(20, 10))
        self.label = tk.Label(self.root, text='Preparing update...', bg='#f7f8f7', fg='#333333', font=('Segoe UI', 10), wraplength=360)
        self.label.pack(pady=(0, 12))
        self.step = tk.Label(self.root, text='1 / 3', bg='#f7f8f7', fg='#777777', font=('Segoe UI', 9, 'bold'))
        self.step.pack()
        self.root.update_idletasks()

    def set(self, text: str, step: int | None = None) -> None:
        try:
            self.label.config(text=text)
            if step is not None:
                self.step.config(text=f'{step} / 3')
            self.root.update()
        except Exception:
            pass

    def close(self) -> None:
        try:
            self.root.destroy()
        except Exception:
            pass


def apply_update(pending_path: Path) -> int:
    ui = UpdateWindow()
    pending = json.loads(pending_path.read_text(encoding='utf-8'))
    target = Path(pending['target']).resolve()
    payload = Path(pending['payload']).resolve()
    version = str(pending.get('version') or '')
    app_pid = int(pending.get('app_pid') or 0)
    backup = target / 'Update Backup' / f"before {version or 'update'} {time.strftime('%Y%m%d %H%M%S')}"
    backup.mkdir(parents=True, exist_ok=True)
    program_names = ['Adeon.exe', 'Adeon App.pyw', 'Adeon Bot.py', 'Adeon.ico', 'Adeon Update Helper.py', 'Adeon Accessibility Feed.ps1', 'Adeon Screen Vision OCR.ps1', 'Read Me Adeon.txt', 'Built In Label Sync URL.txt', 'Configure Label Sync.bat', 'Configure Notifications.bat', 'Migrate Adeon Private Settings.ps1', 'Label Sync Setup.txt', 'Adeon Label Sync Server.gs', 'Label Sync Manifest Example.txt']

    try:
        ui.set('Stopping the current Adeon session safely...', 1)
        deadline = time.time() + 25
        while pid_alive(app_pid) and time.time() < deadline:
            time.sleep(0.2)
            ui.root.update()
        if pid_alive(app_pid):
            subprocess.run(['taskkill', '/PID', str(app_pid), '/T', '/F'], stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, timeout=8, creationflags=CREATE_NO_WINDOW)
            time.sleep(0.8)

        migrate_legacy_private_settings(target)

        # Remove the old content-script integration first. Even if the core update
        # later rolls back, the previous Adeon build can still use Screen Vision and no old
        # extension files are restored by this updater.
        remove_legacy_browser_integration(target)

        for name in program_names:
            src = target / name
            if src.is_file():
                shutil.copy2(src, backup / name)

        ui.set('Installing the new Adeon files...', 2)
        copy_program_files(payload, target)
        remove_legacy_browser_integration(target)
        verify_required_install(target)
        py = python_exe(target)
        build_exe(target, py, lambda text: ui.set(text, 2))
        ensure_startup_shortcut(target)

        (target / 'Adeon Version.json').write_text(
            json.dumps({'version': version, 'updated_at': time.time()}, indent=2), encoding='utf-8'
        )
        ui.set('Update installed. Restarting Adeon...', 3)
        write_status(target, True, version, 'Update installed successfully')
        try:
            pending_path.unlink(missing_ok=True)
        except Exception:
            pass
        time.sleep(0.8)
        relaunch(target)
        time.sleep(1.0)
        ui.close()
        return 0
    except Exception as e:
        err = str(e)
        # Preserve an exact local reason before rollback. This makes a future
        # updater failure diagnosable instead of showing only the generic UI.
        try:
            (target / 'Adeon Update Failure.txt').write_text(
                f'Version: {version}\nTime: {time.strftime("%Y-%m-%d %H:%M:%S")}\nError: {err}\n\n{traceback.format_exc()}',
                encoding='utf-8',
            )
        except Exception:
            pass
        ui.set('Update failed. Restoring the previous Adeon version...', 3)
        try:
            for name in program_names:
                old = backup / name
                if old.is_file():
                    shutil.copy2(old, target / name)
        except Exception as rollback_error:
            err += f' | rollback error: {rollback_error}'
        write_status(target, False, version, err)
        time.sleep(1.0)
        try:
            relaunch(target)
        except Exception:
            pass
        time.sleep(1.5)
        ui.close()
        return 1


def main() -> int:
    if len(sys.argv) >= 3 and sys.argv[1] == '--apply':
        return apply_update(Path(sys.argv[2]))
    return 2


if __name__ == '__main__':
    raise SystemExit(main())
