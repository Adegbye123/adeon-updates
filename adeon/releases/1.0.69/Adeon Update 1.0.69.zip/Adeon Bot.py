#!/usr/bin/env python3
r"""
Adeon — LR Writers picker worker
================================
Reads the already-open Chrome or Thorium LR Writers window through Windows Screen Vision / accessibility and uses the visible Windows mouse/keyboard for permitted actions. It never clicks Accept and never launches a separate browser window/profile.
Persistent automation data lives under %LOCALAPPDATA%\Adeon.

Run this worker through Adeon.exe / Adeon App.pyw.
"""
from __future__ import annotations

import atexit
import base64
import ctypes
import json
import math
import hashlib
import os
import queue
import random
import re
import signal
import shutil
import subprocess
import sys
import threading
import time
import traceback
import urllib.request
import urllib.parse
import uuid
from ctypes import wintypes
from datetime import datetime
from pathlib import Path

import pyautogui
import requests

# ---------------- config ----------------
# Private notification credentials are never shipped in the public updater.
# They are loaded from %LOCALAPPDATA%\Adeon Data\Notifications.json.
PUSHOVER_USER_KEY = ""
PUSHOVER_APP_TOKEN = ""
GMAIL_TO = ""
GMAIL_WEBAPP_URL = ""
GMAIL_WEBAPP_SECRET = ""

MIN_PAY = 6.00
RELOAD_FAST_N = 3
RELOAD_SLOW_N = 2
# F5 timing: choose a fresh random delay in the requested 3-5 second range.
# Every main-loop cycle reads/scans the live DOM before F5 is considered, so a
# newly appeared order can lock refresh before the keyboard refresh is allowed.
RELOAD_FAST = (3.0, 5.0)
RELOAD_SLOW = (3.0, 5.0)
F5_HARD_MIN_GAP = 3.0
F5_SHORT_GAP_THRESHOLD = 0.0
F5_BURST_RECOVERY_GAP = 0.0
RESERVED_RELOAD = (3.0, 5.0)  # legacy value; actual visible F5 is intentionally held while reserved
RESERVED_SCROLLBAR_PASS_AT = (12.0, 36.0)  # two quick visible scrollbar down/up passes during the first reservation minute
RESERVED_SCROLLBAR_DRAG_SECONDS = 0.24
DOM_SCAN_INTERVAL = 0.10  # target live row/DOM scan cadence while the picker is active
LABEL_SCAN_INTERVAL = 0.06  # fast UIA-first label page/identity reaction cadence
IDLE_MOVE = (20.0, 60.0)
STARTUP_MOUSE_PROOF_SECONDS = 10.0
STARTUP_MOUSE_PROOF_INTERVAL = 1.35
IDLE_CLICK = (120.0, 300.0)  # safe inert-background click only; never while an order panel is open
IDLE_ACTIVE_FOR = 5 * 60.0      # after 5 active minutes, pause idle mouse activity
IDLE_REST = (3 * 60.0, 20 * 60.0)  # random 3-20 minute idle-mouse rest
RESERVE_REMINDER_AFTER = 60.0       # first short reservation reminder, at 1 minute
RESERVE_CRITICAL_START = 3 * 60.0       # critical phase begins exactly 3:00 after Reserve
RESERVE_CRITICAL_ESCALATE = 5.5 * 60.0  # from 5:30, increase alert frequency
RESERVE_CRITICAL_STAGE3 = 6 * 60.0       # further escalation
RESERVE_CRITICAL_STAGE4 = 6.5 * 60.0     # final high-frequency phase until reservation ends
RESERVE_CRITICAL_CADENCE_1 = 15.0        # 3:00-5:30
RESERVE_CRITICAL_CADENCE_2 = 10.0        # 5:30-6:00
RESERVE_CRITICAL_CADENCE_3 = 7.5         # 6:00-6:30
RESERVE_CRITICAL_CADENCE_4 = 5.0         # 6:30 onward
RESERVATION_STATUS_CHECK = 10.0      # verify every 10 seconds that the reservation still exists
NETWORK_RETRY_MIN = 3.0              # keep worker alive through temporary network loss
NETWORK_RETRY_MAX = 5.0
MIDNIGHT_RULE_START_HOUR = 0
MIDNIGHT_RULE_END_HOUR = 8       # local PC time: 00:00 <= time < 08:00
MIDNIGHT_REJECT_UNDER_MINUTES = 5 * 60
MIDNIGHT_REJECT_AFTER = 60.0     # keep it reserved for one minute, then Reject
FIND_ORDERS = "https://myaccount.lrwriters.com/findorders/all"
MY_ORDERS = "https://myaccount.lrwriters.com/myorders/inprogress"
INBOX_URL = "https://myaccount.lrwriters.com/inbox"
MY_PROGRESS_URL = "https://myaccount.lrwriters.com/myprogress"
ROW_RETRY_SEC = 12.0
RESERVE_RETRY_SEC = 0.45

pyautogui.FAILSAFE = False
pyautogui.PAUSE = 0.0

_stop = False
_paused = False
_pause_reason = ""
_resume_requested = False
_resume_source = ""
_pause_lock = threading.Lock()
_alerted: set[str] = set()
_alert_last_try: dict[str, float] = {}
_alert_inflight: set[str] = set()
_alert_cancelled: set[str] = set()
_alert_lock = threading.Lock()
_critical_receipt_lock = threading.Lock()
_critical_receipts: dict[str, str] = {}
_done: set[str] = set()
_pay_audit_seen: set[str] = set()
_click_lock = threading.Lock()
_last_click = 0.0
_last_idle_dir = ""
_ctrl_handler_ref = None  # keep the Windows console callback alive
_debug_chrome_pid = 0
_debug_port = 0
_debug_endpoint = ""
_debug_user_data_dir = ""
_last_diag_shot = 0.0

# Persistent local controller. The controller itself never touches the webpage while
# STOPPED; it only keeps the tiny dashboard + Alt+S hotkey alive.
_controller_exit = threading.Event()
_controller_start_requested = threading.Event()
_controller_lock = threading.Lock()
_controller_worker: threading.Thread | None = None
_controller_active = False

# Tiny always-on-top status ticket shown on the Windows desktop.
_status_ticket_lock = threading.Lock()
_status_ticket_state = {
    "bot": "STARTING",
    "page": "WAITING",
    "job": "SEARCHING",
    "f5": "WAIT",
    "mouse": "WAIT",
    "mode": "PICKER",
}
_status_ticket_started = False
_status_ticket_stop = threading.Event()

# Window-management constants used only to guarantee that a real mouse click
# reaches the existing Chromium browser window rather than a covering terminal/window.
HWND_TOPMOST = -1
HWND_NOTOPMOST = -2
SWP_NOSIZE = 0x0001
SWP_NOMOVE = 0x0002
SWP_SHOWWINDOW = 0x0040
GA_ROOT = 2


# ---------------- tiny desktop status ticket ----------------
def set_status_ticket(**fields) -> None:
    """Update the tiny desktop ticket and the app-visible runtime status."""
    global _runtime_file_last
    with _status_ticket_lock:
        for key, value in fields.items():
            if key in _status_ticket_state and value is not None:
                _status_ticket_state[key] = str(value)
        snapshot = dict(_status_ticket_state)
    try:
        snapshot["pid"] = os.getpid()
        snapshot["updated_at"] = time.time()
        payload = json.dumps(snapshot, ensure_ascii=False, sort_keys=True)
        if payload != _runtime_file_last:
            _runtime_file_last = payload
            _write_json_atomic(_APP_RUNTIME_FILE, snapshot)
    except Exception:
        pass


def show_action_popup(text: str, kind: str = "accept", duration: float = 2.2, bell: bool = False) -> None:
    """Show a tiny temporary Windows popup for ACCEPT / REJECT decisions."""
    label = str(text or "").strip().upper() or ("ACCEPT" if kind == "accept" else "REJECT")
    mode = str(kind or "accept").lower()

    def worker() -> None:
        try:
            if bell:
                try:
                    import winsound
                    # Short two-tone laptop bell. Never blocks the director loop.
                    winsound.Beep(988, 170)
                    time.sleep(0.10)
                    winsound.Beep(659, 420)
                except Exception:
                    try:
                        import winsound
                        winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
                    except Exception:
                        pass

            import tkinter as tk
            import tkinter.font as tkfont
            root = tk.Tk()
            root.overrideredirect(True)
            root.attributes("-topmost", True)
            try:
                root.attributes("-alpha", 0.96)
            except Exception:
                pass

            is_accept = mode == "accept"
            bg = "#159447" if is_accept else "#d62f2f"
            width = 235 if len(label) > 12 else 150
            height = 48
            sw = int(root.winfo_screenwidth() or 1920)
            root.geometry(f"{width}x{height}+{max(8, sw-width-24)}+24")
            root.configure(bg=bg)
            tk.Label(
                root, text=label, bg=bg, fg="white",
                font=("Segoe UI", 11, "bold"), padx=10, pady=8,
                anchor="center", justify="center",
            ).pack(fill="both", expand=True)
            root.after(max(700, int(float(duration) * 1000)), root.destroy)
            root.mainloop()
        except Exception as e:
            try:
                log(f"Action popup unavailable: {e}")
            except Exception:
                pass

    threading.Thread(target=worker, name="LR-Action-Popup", daemon=True).start()


def start_status_ticket() -> None:
    """Start a tiny draggable, always-on-top sticky-note status window."""
    global _status_ticket_started
    if _status_ticket_started:
        return
    _status_ticket_started = True
    _status_ticket_stop.clear()

    def worker() -> None:
        try:
            import tkinter as tk
        except Exception as e:
            log(f"Status ticket unavailable (tkinter): {e}")
            return
        try:
            root = tk.Tk()
            root.overrideredirect(True)
            root.attributes("-topmost", True)
            try:
                root.attributes("-alpha", 0.94)
            except Exception:
                pass

            width, height = 230, 104
            sh = int(root.winfo_screenheight() or 1080)
            # Bottom-left as requested; leave a small margin above the taskbar.
            root.geometry(f"{width}x{height}+18+{max(8, sh-height-58)}")
            root.configure(bg="#fff4b8")

            frame = tk.Frame(root, bg="#fff4b8", bd=1, relief="solid")
            frame.pack(fill="both", expand=True)
            header = tk.Label(
                frame, text="ADEON", anchor="w", justify="left",
                bg="#fff4b8", fg="#111111", font=("Segoe UI", 9, "bold"),
                padx=7, pady=3,
            )
            header.pack(fill="x")
            body = tk.Label(
                frame, text="", anchor="nw", justify="left",
                bg="#fff4b8", fg="#111111", font=("Segoe UI", 8),
                padx=7, pady=1,
            )
            body.pack(fill="both", expand=True)

            drag = {"x": 0, "y": 0}
            def drag_start(event):
                drag["x"] = int(event.x)
                drag["y"] = int(event.y)
            def drag_move(event):
                root.geometry(f"+{int(event.x_root)-drag['x']}+{int(event.y_root)-drag['y']}")
            for w in (frame, header, body):
                w.bind("<ButtonPress-1>", drag_start)
                w.bind("<B1-Motion>", drag_move)

            def refresh() -> None:
                if _status_ticket_stop.is_set():
                    try:
                        root.destroy()
                    except Exception:
                        pass
                    return
                with _status_ticket_lock:
                    st = dict(_status_ticket_state)
                bot = str(st.get("bot", "?")).upper()
                if bot == "CONNECTED":
                    status_color = "#138a36"
                elif bot == "STOPPED":
                    status_color = "#c62828"
                else:
                    status_color = "#6b5b00"
                header.config(text=f"ADEON  •  {bot}", fg=status_color)
                body.config(text=(
                    f"JOB    {st.get('job','?')}\n"
                    f"F5     {st.get('f5','?')}\n"
                    f"MOUSE  {st.get('mouse','?')}"
                ))
                try:
                    root.after(350, refresh)
                except Exception:
                    pass

            refresh()
            root.mainloop()
        except Exception as e:
            try:
                log(f"Status ticket failed: {e}")
            except Exception:
                pass

    threading.Thread(target=worker, name="LR-Status-Ticket", daemon=True).start()


# ---------------- diagnostics / session report ----------------
SESSION_STARTED_AT = time.time()
SESSION_ID = datetime.now().strftime("%Y%m%d_%H%M%S")
# All persistent Adeon state is anchored to LOCALAPPDATA, never to the folder
# where an installer ZIP or source file happens to be extracted/run.
_LOCAL_APPDATA = Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local")))
_BASE_DIR = _LOCAL_APPDATA / "Adeon"
try:
    _BASE_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    pass
_REPORT_DIR = _BASE_DIR / "adeon_reports"
try:
    _REPORT_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    _REPORT_DIR = Path.cwd()

# The installer records the folder that contains Install Adeon.bat/ps1.
# Every user-facing report is copied back to that visible setup folder so the
# user never has to hunt through AppData or Downloads for it.
_REPORT_DEST_FILE = _BASE_DIR / "Report Folder.txt"
try:
    _saved_report_dir = Path(_REPORT_DEST_FILE.read_text(encoding="utf-8-sig").strip()).expanduser()
    if not _saved_report_dir.is_dir():
        raise OSError("saved setup/report folder is unavailable")
    _VISIBLE_REPORT_DIR = _saved_report_dir
except Exception:
    _VISIBLE_REPORT_DIR = Path.home() / "Downloads"

_SESSION_LOG = _REPORT_DIR / f"Adeon Session {SESSION_ID}.log"
_REPORT_LOCAL = _REPORT_DIR / f"Adeon Report {SESSION_ID}.txt"
_REPORT_VISIBLE = _VISIBLE_REPORT_DIR / f"Adeon Report {SESSION_ID}.txt"
_RESERVATION_STATE_FILE = _BASE_DIR / "Adeon Reservation State.json"
_APP_WORKER_MODE = "--app-worker" in sys.argv
_LABELS_ONLY_MODE = "--labels-only" in sys.argv
_FORCE_CHROME_RESTART = "--force-chrome-restart" in sys.argv  # legacy flag, no longer required for labels
_APP_STOP_FILE = _BASE_DIR / ("Adeon Labels Stop Request.flag" if _LABELS_ONLY_MODE else "Adeon Stop Request.flag")
_APP_RUNTIME_FILE = _BASE_DIR / ("Adeon Labels Runtime.json" if _LABELS_ONLY_MODE else "Adeon Runtime.json")
_APP_ACTIVITY_LOG = _BASE_DIR / "Adeon Activity.log"
_APP_LAST_ERROR_FILE = _BASE_DIR / "Adeon Last Error.txt"
_LABEL_REFRESH_FILE = _BASE_DIR / "Adeon Labels Refresh Request.flag"
_PICKER_PID_FILE = _BASE_DIR / "Adeon Worker PID.txt"
_LABEL_DATA_DIR = _LOCAL_APPDATA / "Adeon Data"
try:
    _LABEL_DATA_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    pass
_LABEL_LOCAL_FILE = _LABEL_DATA_DIR / "Labels.json"
_LABEL_DEVICE_FILE = _LABEL_DATA_DIR / "Device ID.txt"
_LABEL_SYNC_URL_FILE = _LABEL_DATA_DIR / "Label Sync URL.txt"
_LABEL_SYNC_SECRET_FILE = _LABEL_DATA_DIR / "Label Sync Secret.txt"
_LABEL_HISTORY_FILE = _LABEL_DATA_DIR / "Label History.jsonl"
_LABEL_OUTBOX_FILE = _LABEL_DATA_DIR / "Label Outbox.json"
_LABEL_CONFLICT_FILE = _LABEL_DATA_DIR / "Label Conflicts.jsonl"
_LABEL_BACKUP_DIR = _LABEL_DATA_DIR / "Label Backups"
_NOTIFICATION_CONFIG_FILE = _LABEL_DATA_DIR / "Notifications.json"
_BUILTIN_LABEL_SYNC_URL_FILE = _BASE_DIR / "Built In Label Sync URL.txt"

def _load_notification_config() -> dict:
    try:
        obj = json.loads(_NOTIFICATION_CONFIG_FILE.read_text(encoding="utf-8-sig"))
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}

_notification_cfg = _load_notification_config()
PUSHOVER_USER_KEY = str(_notification_cfg.get("pushover_user_key") or "").strip()
PUSHOVER_APP_TOKEN = str(_notification_cfg.get("pushover_app_token") or "").strip()
GMAIL_TO = str(_notification_cfg.get("gmail_to") or "").strip()
GMAIL_WEBAPP_URL = str(_notification_cfg.get("gmail_webapp_url") or "").strip()
GMAIL_WEBAPP_SECRET = str(_notification_cfg.get("gmail_webapp_secret") or "").strip()

_LABEL_UPDATE_FEED_FILE = _BASE_DIR / "Update Feed URL.txt"
_LABEL_OFFICIAL_UPDATE_FEED = "https://raw.githubusercontent.com/Adegbye123/adeon-updates/main/adeon/manifest.json"
_LABEL_REMOTE_FALLBACK_POLL = 45.0
_LABEL_BACKUP_MIN_INTERVAL = 60.0
_LABEL_BACKUP_KEEP = 20
_LABEL_NOTIFY_BASE = "https://ntfy.sh"
_ADEON_CHROME_DATA = _BASE_DIR / "Chrome Data"
_ADEON_CHROME_MARKER = _BASE_DIR / "Chrome Profile.json"
_runtime_file_last = ""


# Picker accessibility feed. This is a browser-independent, read-only Windows UI
# Automation layer. It does not inject script into LR Writers or change the page DOM.
_ACCESS_FEED_SCRIPT = _BASE_DIR / "Adeon Accessibility Feed.ps1"
# Built-in recovery copy. The accessibility feed is a support file, not picker logic.
# If an update/AV/file-copy issue leaves it absent, reconstruct the exact signed-off
# current accessibility payload locally before starting the read-only Windows accessibility feed.
_ACCESS_FEED_RECOVERY_B64 = "IyBBREVPTl9BQ0NFU1NfRkVFRF9WRVJTSU9OPTEuMC42OQpwYXJhbSgKICAgIFtQYXJhbWV0ZXIoTWFuZGF0b3J5PSR0cnVlKV1bSW50NjRdJEh3bmQsCiAgICBbUGFyYW1ldGVyKE1hbmRhdG9yeT0kdHJ1ZSldW3N0cmluZ10kT3V0RmlsZSwKICAgIFtQYXJhbWV0ZXIoTWFuZGF0b3J5PSR0cnVlKV1bc3RyaW5nXSRTdG9wRmlsZSwKICAgIFtpbnRdJEludGVydmFsTXMgPSAxODAsCiAgICBbc3dpdGNoXSRGYXN0TGFiZWxzCikKCiRFcnJvckFjdGlvblByZWZlcmVuY2UgPSAnU2lsZW50bHlDb250aW51ZScKQWRkLVR5cGUgLUFzc2VtYmx5TmFtZSBVSUF1dG9tYXRpb25DbGllbnQKQWRkLVR5cGUgLUFzc2VtYmx5TmFtZSBVSUF1dG9tYXRpb25UeXBlcwp0cnkgeyBBZGQtVHlwZSAtQXNzZW1ibHlOYW1lIEFjY2Vzc2liaWxpdHkgfSBjYXRjaCB7fQoKQWRkLVR5cGUgQCIKdXNpbmcgU3lzdGVtOwp1c2luZyBTeXN0ZW0uVGV4dDsKdXNpbmcgU3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWM7CnVzaW5nIFN5c3RlbS5EaWFnbm9zdGljczsKdXNpbmcgU3lzdGVtLlJ1bnRpbWUuSW50ZXJvcFNlcnZpY2VzOwp1c2luZyBBY2Nlc3NpYmlsaXR5OwoKcHVibGljIHN0YXRpYyBjbGFzcyBBZGVvbk5hdGl2ZSB7CiAgICBwdWJsaWMgZGVsZWdhdGUgYm9vbCBFbnVtV2luZG93c1Byb2MoSW50UHRyIGhXbmQsIEludFB0ciBsUGFyYW0pOwogICAgW0RsbEltcG9ydCgidXNlcjMyLmRsbCIpXSBwdWJsaWMgc3RhdGljIGV4dGVybiBib29sIEVudW1DaGlsZFdpbmRvd3MoSW50UHRyIGhXbmRQYXJlbnQsIEVudW1XaW5kb3dzUHJvYyBscEVudW1GdW5jLCBJbnRQdHIgbFBhcmFtKTsKICAgIFtEbGxJbXBvcnQoInVzZXIzMi5kbGwiLCBDaGFyU2V0PUNoYXJTZXQuVW5pY29kZSldIHB1YmxpYyBzdGF0aWMgZXh0ZXJuIGludCBHZXRDbGFzc05hbWUoSW50UHRyIGhXbmQsIFN0cmluZ0J1aWxkZXIgbHBDbGFzc05hbWUsIGludCBuTWF4Q291bnQpOwogICAgW0RsbEltcG9ydCgidXNlcjMyLmRsbCIpXSBwdWJsaWMgc3RhdGljIGV4dGVybiBib29sIEdldFdpbmRvd1JlY3QoSW50UHRyIGhXbmQsIG91dCBSRUNUIGxwUmVjdCk7CiAgICBbRGxsSW1wb3J0KCJ1c2VyMzIuZGxsIiwgU2V0TGFzdEVycm9yPXRydWUpXSBwdWJsaWMgc3RhdGljIGV4dGVybiBJbnRQdHIgU2VuZE1lc3NhZ2VUaW1lb3V0KEludFB0ciBoV25kLCB1aW50IE1zZywgSW50UHRyIHdQYXJhbSwgSW50UHRyIGxQYXJhbSwgdWludCBmdUZsYWdzLCB1aW50IHVUaW1lb3V0LCBvdXQgSW50UHRyIGxwZHdSZXN1bHQpOwogICAgW1N0cnVjdExheW91dChMYXlvdXRLaW5kLlNlcXVlbnRpYWwpXSBwdWJsaWMgc3RydWN0IFJFQ1QgeyBwdWJsaWMgaW50IExlZnQ7IHB1YmxpYyBpbnQgVG9wOyBwdWJsaWMgaW50IFJpZ2h0OyBwdWJsaWMgaW50IEJvdHRvbTsgfQoKICAgIHB1YmxpYyBzdGF0aWMgdm9pZCBOdWRnZUFjY2Vzc2liaWxpdHkoSW50UHRyIGh3bmQpIHsKICAgICAgICBpZiAoaHduZCA9PSBJbnRQdHIuWmVybykgcmV0dXJuOwogICAgICAgIHRyeSB7CiAgICAgICAgICAgIEludFB0ciByZXN1bHQ7CiAgICAgICAgICAgIC8vIENocm9taXVtIGVuYWJsZXMgbmF0aXZlIGFjY2Vzc2liaWxpdHkgb24gZGVtYW5kIHdoZW4gYXNzaXN0aXZlIHRlY2hub2xvZ3kgcmVxdWVzdHMgaXQuCiAgICAgICAgICAgIC8vIFdNX0dFVE9CSkVDVCBpcyB0aGUgc3RhbmRhcmQgV2luZG93cyBhY2Nlc3NpYmlsaXR5IHJlcXVlc3QuIFRoZSBjdXN0b20gb2JqZWN0IGlkIDEKICAgICAgICAgICAgLy8gaXMgYWxzbyB1c2VkIGJ5IENocm9taXVtJ3MgYXNzaXN0aXZlLXRlY2hub2xvZ3kgZGV0ZWN0aW9uIHBhdGguCiAgICAgICAgICAgIFNlbmRNZXNzYWdlVGltZW91dChod25kLCAweDAwM0QsIEludFB0ci5aZXJvLCBuZXcgSW50UHRyKDEpLCAweDAwMDIsIDI1MCwgb3V0IHJlc3VsdCk7CiAgICAgICAgICAgIFNlbmRNZXNzYWdlVGltZW91dChod25kLCAweDAwM0QsIEludFB0ci5aZXJvLCBuZXcgSW50UHRyKHVuY2hlY2tlZCgoaW50KTB4RkZGRkZGRkMpKSwgMHgwMDAyLCAyNTAsIG91dCByZXN1bHQpOyAvLyBPQkpJRF9DTElFTlQKICAgICAgICB9IGNhdGNoIHt9CiAgICB9Cn0KCnB1YmxpYyBzdGF0aWMgY2xhc3MgQWRlb25Nc2FhIHsKICAgIHByaXZhdGUgY29uc3QgdWludCBPQkpJRF9DTElFTlQgPSAweEZGRkZGRkZDOwogICAgcHJpdmF0ZSBzdGF0aWMgcmVhZG9ubHkgR3VpZCBJSURfSUFjY2Vzc2libGUgPSBuZXcgR3VpZCgiNjE4NzM2RTAtM0MzRC0xMUNGLTgxMEMtMDBBQTAwMzg5QjcxIik7CgogICAgW0RsbEltcG9ydCgib2xlYWNjLmRsbCIpXQogICAgcHJpdmF0ZSBzdGF0aWMgZXh0ZXJuIGludCBBY2Nlc3NpYmxlT2JqZWN0RnJvbVdpbmRvdyhJbnRQdHIgaHduZCwgdWludCBkd0lkLCByZWYgR3VpZCByaWlkLCBbTWFyc2hhbEFzKFVubWFuYWdlZFR5cGUuSW50ZXJmYWNlKV0gb3V0IG9iamVjdCBwcHZPYmplY3QpOwoKICAgIFtEbGxJbXBvcnQoIm9sZWFjYy5kbGwiLCBDaGFyU2V0PUNoYXJTZXQuVW5pY29kZSldCiAgICBwcml2YXRlIHN0YXRpYyBleHRlcm4gdWludCBHZXRSb2xlVGV4dCh1aW50IGxSb2xlLCBTdHJpbmdCdWlsZGVyIGxwc3pSb2xlLCB1aW50IGNjaFJvbGVNYXgpOwoKICAgIHB1YmxpYyBjbGFzcyBOb2RlIHsKICAgICAgICBwdWJsaWMgc3RyaW5nIG5hbWUgPSAiIjsKICAgICAgICBwdWJsaWMgc3RyaW5nIHZhbHVlID0gIiI7CiAgICAgICAgcHVibGljIHN0cmluZyBjb250cm9sID0gIiI7CiAgICAgICAgcHVibGljIHN0cmluZyBhdXRvbWF0aW9uSWQgPSAiIjsKICAgICAgICBwdWJsaWMgc3RyaW5nIGNsYXNzTmFtZSA9ICIiOwogICAgICAgIHB1YmxpYyBzdHJpbmcgZnJhbWV3b3JrID0gIk1TQUEiOwogICAgICAgIHB1YmxpYyBkb3VibGUgbGVmdDsKICAgICAgICBwdWJsaWMgZG91YmxlIHRvcDsKICAgICAgICBwdWJsaWMgZG91YmxlIHdpZHRoOwogICAgICAgIHB1YmxpYyBkb3VibGUgaGVpZ2h0OwogICAgICAgIHB1YmxpYyBib29sIGVuYWJsZWQgPSB0cnVlOwogICAgICAgIHB1YmxpYyBib29sIGZvY3VzYWJsZSA9IGZhbHNlOwogICAgICAgIHB1YmxpYyBib29sIGNvbnRlbnQgPSB0cnVlOwogICAgICAgIHB1YmxpYyBib29sIGNvbnRyb2xFbGVtZW50ID0gdHJ1ZTsKICAgIH0KCiAgICBwdWJsaWMgY2xhc3MgUmVzdWx0IHsKICAgICAgICBwdWJsaWMgTGlzdDxOb2RlPiBub2RlcyA9IG5ldyBMaXN0PE5vZGU+KCk7CiAgICAgICAgcHVibGljIGludCB2aXNpdGVkID0gMDsKICAgICAgICBwdWJsaWMgc3RyaW5nIGRpYWdub3N0aWMgPSAiIjsKICAgIH0KCiAgICBwcml2YXRlIGNsYXNzIFdvcmsgewogICAgICAgIHB1YmxpYyBJQWNjZXNzaWJsZSBhY2M7CiAgICAgICAgcHVibGljIG9iamVjdCBjaGlsZDsKICAgICAgICBwdWJsaWMgaW50IGRlcHRoOwogICAgICAgIHB1YmxpYyBXb3JrKElBY2Nlc3NpYmxlIGEsIG9iamVjdCBjLCBpbnQgZCkgeyBhY2M9YTsgY2hpbGQ9YzsgZGVwdGg9ZDsgfQogICAgfQoKICAgIHByaXZhdGUgc3RhdGljIHN0cmluZyBTYWZlTmFtZShJQWNjZXNzaWJsZSBhY2MsIG9iamVjdCBjaGlsZCkgewogICAgICAgIHRyeSB7IHJldHVybiBhY2MuZ2V0X2FjY05hbWUoY2hpbGQpID8/ICIiOyB9IGNhdGNoIHsgcmV0dXJuICIiOyB9CiAgICB9CiAgICBwcml2YXRlIHN0YXRpYyBzdHJpbmcgU2FmZVZhbHVlKElBY2Nlc3NpYmxlIGFjYywgb2JqZWN0IGNoaWxkKSB7CiAgICAgICAgdHJ5IHsgcmV0dXJuIGFjYy5nZXRfYWNjVmFsdWUoY2hpbGQpID8/ICIiOyB9IGNhdGNoIHsgcmV0dXJuICIiOyB9CiAgICB9CiAgICBwcml2YXRlIHN0YXRpYyBvYmplY3QgU2FmZVJvbGUoSUFjY2Vzc2libGUgYWNjLCBvYmplY3QgY2hpbGQpIHsKICAgICAgICB0cnkgeyByZXR1cm4gYWNjLmdldF9hY2NSb2xlKGNoaWxkKTsgfSBjYXRjaCB7IHJldHVybiBudWxsOyB9CiAgICB9CiAgICBwcml2YXRlIHN0YXRpYyBvYmplY3QgU2FmZVN0YXRlKElBY2Nlc3NpYmxlIGFjYywgb2JqZWN0IGNoaWxkKSB7CiAgICAgICAgdHJ5IHsgcmV0dXJuIGFjYy5nZXRfYWNjU3RhdGUoY2hpbGQpOyB9IGNhdGNoIHsgcmV0dXJuIG51bGw7IH0KICAgIH0KICAgIHByaXZhdGUgc3RhdGljIHN0cmluZyBSb2xlTmFtZShvYmplY3Qgcm9sZSkgewogICAgICAgIHRyeSB7CiAgICAgICAgICAgIGludCByID0gQ29udmVydC5Ub0ludDMyKHJvbGUpOwogICAgICAgICAgICBTdHJpbmdCdWlsZGVyIHNiID0gbmV3IFN0cmluZ0J1aWxkZXIoMTI4KTsKICAgICAgICAgICAgaWYgKEdldFJvbGVUZXh0KCh1aW50KXIsIHNiLCAodWludClzYi5DYXBhY2l0eSkgPiAwKSByZXR1cm4gc2IuVG9TdHJpbmcoKTsKICAgICAgICAgICAgcmV0dXJuIHIuVG9TdHJpbmcoKTsKICAgICAgICB9IGNhdGNoIHsgcmV0dXJuICIiOyB9CiAgICB9CiAgICBwcml2YXRlIHN0YXRpYyBzdHJpbmcgTWFwQ29udHJvbChzdHJpbmcgcm9sZSkgewogICAgICAgIHN0cmluZyByID0gKHJvbGUgPz8gIiIpLlRvTG93ZXJJbnZhcmlhbnQoKTsKICAgICAgICBpZiAoci5Db250YWlucygicHVzaCBidXR0b24iKSB8fCByID09ICJidXR0b24iKSByZXR1cm4gIkJ1dHRvbiI7CiAgICAgICAgaWYgKHIuQ29udGFpbnMoImxpbmsiKSkgcmV0dXJuICJIeXBlcmxpbmsiOwogICAgICAgIGlmIChyLkNvbnRhaW5zKCJkb2N1bWVudCIpKSByZXR1cm4gIkRvY3VtZW50IjsKICAgICAgICBpZiAoci5Db250YWlucygidGV4dCIpIHx8IHIuQ29udGFpbnMoInN0YXRpYyIpKSByZXR1cm4gIlRleHQiOwogICAgICAgIGlmIChyLkNvbnRhaW5zKCJjb21ibyIpKSByZXR1cm4gIkNvbWJvQm94IjsKICAgICAgICBpZiAoci5Db250YWlucygibGlzdCBpdGVtIikpIHJldHVybiAiTGlzdEl0ZW0iOwogICAgICAgIGlmIChyLkNvbnRhaW5zKCJyb3ciKSkgcmV0dXJuICJEYXRhSXRlbSI7CiAgICAgICAgaWYgKHIuQ29udGFpbnMoIm1lbnUgaXRlbSIpKSByZXR1cm4gIk1lbnVJdGVtIjsKICAgICAgICBpZiAoci5Db250YWlucygicGFnZSB0YWIiKSkgcmV0dXJuICJUYWJJdGVtIjsKICAgICAgICBpZiAoci5Db250YWlucygiZWRpdGFibGUiKSB8fCByLkNvbnRhaW5zKCJlZGl0IikpIHJldHVybiAiRWRpdCI7CiAgICAgICAgcmV0dXJuIHJvbGUgPz8gIiI7CiAgICB9CiAgICBwcml2YXRlIHN0YXRpYyBib29sIElzRW5hYmxlZChvYmplY3Qgc3RhdGUpIHsKICAgICAgICB0cnkgewogICAgICAgICAgICBpbnQgcyA9IENvbnZlcnQuVG9JbnQzMihzdGF0ZSk7CiAgICAgICAgICAgIGNvbnN0IGludCBTVEFURV9TWVNURU1fVU5BVkFJTEFCTEUgPSAweDAwMDAwMDAxOwogICAgICAgICAgICByZXR1cm4gKHMgJiBTVEFURV9TWVNURU1fVU5BVkFJTEFCTEUpID09IDA7CiAgICAgICAgfSBjYXRjaCB7IHJldHVybiB0cnVlOyB9CiAgICB9CgogICAgcHJpdmF0ZSBzdGF0aWMgTm9kZSBSZWFkTm9kZShJQWNjZXNzaWJsZSBhY2MsIG9iamVjdCBjaGlsZCkgewogICAgICAgIHRyeSB7CiAgICAgICAgICAgIGludCB4PTAseT0wLHc9MCxoPTA7CiAgICAgICAgICAgIHRyeSB7IGFjYy5hY2NMb2NhdGlvbihvdXQgeCwgb3V0IHksIG91dCB3LCBvdXQgaCwgY2hpbGQpOyB9IGNhdGNoIHt9CiAgICAgICAgICAgIGlmICh3IDwgMiB8fCBoIDwgMikgcmV0dXJuIG51bGw7CiAgICAgICAgICAgIHN0cmluZyBuYW1lID0gU2FmZU5hbWUoYWNjLCBjaGlsZCk7CiAgICAgICAgICAgIHN0cmluZyB2YWx1ZSA9IFNhZmVWYWx1ZShhY2MsIGNoaWxkKTsKICAgICAgICAgICAgc3RyaW5nIHJvbGUgPSBSb2xlTmFtZShTYWZlUm9sZShhY2MsIGNoaWxkKSk7CiAgICAgICAgICAgIGlmIChTdHJpbmcuSXNOdWxsT3JXaGl0ZVNwYWNlKG5hbWUpICYmIFN0cmluZy5Jc051bGxPcldoaXRlU3BhY2UodmFsdWUpICYmIFN0cmluZy5Jc051bGxPcldoaXRlU3BhY2Uocm9sZSkpIHJldHVybiBudWxsOwogICAgICAgICAgICByZXR1cm4gbmV3IE5vZGUgewogICAgICAgICAgICAgICAgbmFtZSA9IG5hbWUgPz8gIiIsIHZhbHVlID0gdmFsdWUgPz8gIiIsIGNvbnRyb2wgPSBNYXBDb250cm9sKHJvbGUpLAogICAgICAgICAgICAgICAgbGVmdD14LCB0b3A9eSwgd2lkdGg9dywgaGVpZ2h0PWgsIGVuYWJsZWQ9SXNFbmFibGVkKFNhZmVTdGF0ZShhY2MsIGNoaWxkKSkKICAgICAgICAgICAgfTsKICAgICAgICB9IGNhdGNoIHsgcmV0dXJuIG51bGw7IH0KICAgIH0KCiAgICBwcml2YXRlIHN0YXRpYyBJQWNjZXNzaWJsZSBBc0FjY2Vzc2libGUob2JqZWN0IG8pIHsKICAgICAgICB0cnkgeyByZXR1cm4gbyBhcyBJQWNjZXNzaWJsZTsgfSBjYXRjaCB7IHJldHVybiBudWxsOyB9CiAgICB9CgogICAgcHVibGljIHN0YXRpYyBSZXN1bHQgU2NhbihJbnRQdHIgaHduZCwgaW50IG1heE5vZGVzLCBpbnQgYnVkZ2V0TXMpIHsKICAgICAgICBSZXN1bHQgcmVzdWx0ID0gbmV3IFJlc3VsdCgpOwogICAgICAgIG9iamVjdCByYXcgPSBudWxsOwogICAgICAgIEd1aWQgaWlkID0gSUlEX0lBY2Nlc3NpYmxlOwogICAgICAgIGludCBociA9IC0xOwogICAgICAgIHRyeSB7IGhyID0gQWNjZXNzaWJsZU9iamVjdEZyb21XaW5kb3coaHduZCwgT0JKSURfQ0xJRU5ULCByZWYgaWlkLCBvdXQgcmF3KTsgfSBjYXRjaCB7fQogICAgICAgIElBY2Nlc3NpYmxlIHJvb3QgPSBBc0FjY2Vzc2libGUocmF3KTsKICAgICAgICBpZiAocm9vdCA9PSBudWxsKSB7CiAgICAgICAgICAgIHJlc3VsdC5kaWFnbm9zdGljID0gIm1zYWEgQWNjZXNzaWJsZU9iamVjdEZyb21XaW5kb3cgZmFpbGVkIGhyPSIgKyBocjsKICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDsKICAgICAgICB9CgogICAgICAgIFN0b3B3YXRjaCBzdyA9IFN0b3B3YXRjaC5TdGFydE5ldygpOwogICAgICAgIFF1ZXVlPFdvcms+IHEgPSBuZXcgUXVldWU8V29yaz4oKTsKICAgICAgICBxLkVucXVldWUobmV3IFdvcmsocm9vdCwgMCwgMCkpOwogICAgICAgIEhhc2hTZXQ8c3RyaW5nPiBzZWVuID0gbmV3IEhhc2hTZXQ8c3RyaW5nPigpOwoKICAgICAgICB3aGlsZSAocS5Db3VudCA+IDAgJiYgcmVzdWx0LnZpc2l0ZWQgPCBtYXhOb2RlcyAmJiBzdy5FbGFwc2VkTWlsbGlzZWNvbmRzIDwgYnVkZ2V0TXMpIHsKICAgICAgICAgICAgV29yayBpdGVtID0gcS5EZXF1ZXVlKCk7CiAgICAgICAgICAgIHJlc3VsdC52aXNpdGVkKys7CiAgICAgICAgICAgIE5vZGUgbiA9IFJlYWROb2RlKGl0ZW0uYWNjLCBpdGVtLmNoaWxkKTsKICAgICAgICAgICAgaWYgKG4gIT0gbnVsbCkgewogICAgICAgICAgICAgICAgc3RyaW5nIGtleSA9IG4ubGVmdCsifCIrbi50b3ArInwiK24ud2lkdGgrInwiK24uaGVpZ2h0KyJ8IituLm5hbWUrInwiK24udmFsdWUrInwiK24uY29udHJvbDsKICAgICAgICAgICAgICAgIGlmIChzZWVuLkFkZChrZXkpKSByZXN1bHQubm9kZXMuQWRkKG4pOwogICAgICAgICAgICB9CgogICAgICAgICAgICBJQWNjZXNzaWJsZSBjb250YWluZXIgPSBudWxsOwogICAgICAgICAgICBpZiAoaXRlbS5jaGlsZCBpcyBpbnQgJiYgKGludClpdGVtLmNoaWxkICE9IDApIHsKICAgICAgICAgICAgICAgIHRyeSB7IGNvbnRhaW5lciA9IGl0ZW0uYWNjLmdldF9hY2NDaGlsZChpdGVtLmNoaWxkKSBhcyBJQWNjZXNzaWJsZTsgfSBjYXRjaCB7fQogICAgICAgICAgICB9IGVsc2UgewogICAgICAgICAgICAgICAgY29udGFpbmVyID0gaXRlbS5hY2M7CiAgICAgICAgICAgIH0KICAgICAgICAgICAgaWYgKGNvbnRhaW5lciA9PSBudWxsIHx8IGl0ZW0uZGVwdGggPj0gNDApIGNvbnRpbnVlOwoKICAgICAgICAgICAgaW50IGNvdW50ID0gMDsKICAgICAgICAgICAgdHJ5IHsgY291bnQgPSBjb250YWluZXIuYWNjQ2hpbGRDb3VudDsgfSBjYXRjaCB7IGNvdW50ID0gMDsgfQogICAgICAgICAgICBpZiAoY291bnQgPD0gMCkgY29udGludWU7CiAgICAgICAgICAgIGNvdW50ID0gTWF0aC5NaW4oY291bnQsIE1hdGguTWluKDEyMDAsIG1heE5vZGVzIC0gcmVzdWx0LnZpc2l0ZWQgKyA2NCkpOwoKICAgICAgICAgICAgLy8gRG8gbm90IHVzZSBvbGVhY2MgQWNjZXNzaWJsZUNoaWxkcmVuIGhlcmUuIFNvbWUgQ2hyb21pdW0gYnVpbGRzIGV4cG9zZQogICAgICAgICAgICAvLyBWQVJJQU5UIGNoaWxkIGFycmF5cyB0aGF0IFBvd2VyU2hlbGwvLk5FVCBtYXJzaGFscyBpbmNvbnNpc3RlbnRseSBhbmQKICAgICAgICAgICAgLy8gdGhhdCBwcm9kdWNlZCB0aGUgcnVudGltZSBlcnJvciAiQXJndW1lbnQgdHlwZXMgZG8gbm90IG1hdGNoIi4gV2FsawogICAgICAgICAgICAvLyBJQWNjZXNzaWJsZSBjaGlsZHJlbiBkaXJlY3RseSBpbnN0ZWFkLiBBIG51bGwgYWNjQ2hpbGQgZm9yIGFuIGluZGV4IGlzCiAgICAgICAgICAgIC8vIHN0aWxsIGEgdmFsaWQgTVNBQSBzaW1wbGUtY2hpbGQgaWQsIHNvIGVucXVldWUgdGhlIGludGVnZXIgaWQuCiAgICAgICAgICAgIGZvciAoaW50IGNoaWxkSWQ9MTsgY2hpbGRJZDw9Y291bnQgJiYgcS5Db3VudCA8IG1heE5vZGVzOyBjaGlsZElkKyspIHsKICAgICAgICAgICAgICAgIG9iamVjdCBjaGlsZE9iaiA9IG51bGw7CiAgICAgICAgICAgICAgICB0cnkgeyBjaGlsZE9iaiA9IGNvbnRhaW5lci5nZXRfYWNjQ2hpbGQoY2hpbGRJZCk7IH0gY2F0Y2gge30KICAgICAgICAgICAgICAgIElBY2Nlc3NpYmxlIGNoaWxkQWNjID0gQXNBY2Nlc3NpYmxlKGNoaWxkT2JqKTsKICAgICAgICAgICAgICAgIGlmIChjaGlsZEFjYyAhPSBudWxsKSBxLkVucXVldWUobmV3IFdvcmsoY2hpbGRBY2MsIDAsIGl0ZW0uZGVwdGgrMSkpOwogICAgICAgICAgICAgICAgZWxzZSBxLkVucXVldWUobmV3IFdvcmsoY29udGFpbmVyLCBjaGlsZElkLCBpdGVtLmRlcHRoKzEpKTsKICAgICAgICAgICAgfQogICAgICAgIH0KICAgICAgICBzdy5TdG9wKCk7CiAgICAgICAgcmVzdWx0LmRpYWdub3N0aWMgPSAibXNhYSB2aXNpdGVkPSIgKyByZXN1bHQudmlzaXRlZCArICIgbm9kZXM9IiArIHJlc3VsdC5ub2Rlcy5Db3VudCArICIgbXM9IiArIHN3LkVsYXBzZWRNaWxsaXNlY29uZHM7CiAgICAgICAgcmV0dXJuIHJlc3VsdDsKICAgIH0KfQoiQCAtUmVmZXJlbmNlZEFzc2VtYmxpZXMgQChbQWNjZXNzaWJpbGl0eS5JQWNjZXNzaWJsZV0uQXNzZW1ibHkuTG9jYXRpb24pCgpmdW5jdGlvbiBHZXQtQWRlb25WYWx1ZShbU3lzdGVtLldpbmRvd3MuQXV0b21hdGlvbi5BdXRvbWF0aW9uRWxlbWVudF0kRWwpIHsKICAgIHRyeSB7CiAgICAgICAgJHAgPSAkRWwuR2V0Q3VycmVudFBhdHRlcm4oW1N5c3RlbS5XaW5kb3dzLkF1dG9tYXRpb24uVmFsdWVQYXR0ZXJuXTo6UGF0dGVybikKICAgICAgICBpZiAoJG51bGwgLW5lICRwKSB7IHJldHVybiBbc3RyaW5nXSRwLkN1cnJlbnQuVmFsdWUgfQogICAgfSBjYXRjaCB7fQogICAgcmV0dXJuICcnCn0KCmZ1bmN0aW9uIEdldC1BZGVvblRleHQoW1N5c3RlbS5XaW5kb3dzLkF1dG9tYXRpb24uQXV0b21hdGlvbkVsZW1lbnRdJEVsKSB7CiAgICB0cnkgewogICAgICAgICRwID0gJEVsLkdldEN1cnJlbnRQYXR0ZXJuKFtTeXN0ZW0uV2luZG93cy5BdXRvbWF0aW9uLlRleHRQYXR0ZXJuXTo6UGF0dGVybikKICAgICAgICBpZiAoJG51bGwgLW5lICRwKSB7CiAgICAgICAgICAgICR0ID0gW3N0cmluZ10kcC5Eb2N1bWVudFJhbmdlLkdldFRleHQoMzAwMDApCiAgICAgICAgICAgIGlmICgkdCkgeyByZXR1cm4gJHQgfQogICAgICAgIH0KICAgIH0gY2F0Y2gge30KICAgIHJldHVybiAnJwp9CgpmdW5jdGlvbiBHZXQtUmVuZGVySG9zdChbSW50UHRyXSRQYXJlbnQpIHsKICAgICRzY3JpcHQ6YmVzdFJlbmRlciA9IFtJbnRQdHJdOjpaZXJvCiAgICAkc2NyaXB0OmJlc3RBcmVhID0gMAogICAgJGNiID0gW0FkZW9uTmF0aXZlK0VudW1XaW5kb3dzUHJvY117CiAgICAgICAgcGFyYW0oW0ludFB0cl0kY2hpbGQsIFtJbnRQdHJdJGxwKQogICAgICAgIHRyeSB7CiAgICAgICAgICAgICRzYiA9IE5ldy1PYmplY3QgU3lzdGVtLlRleHQuU3RyaW5nQnVpbGRlciAyNTYKICAgICAgICAgICAgW3ZvaWRdW0FkZW9uTmF0aXZlXTo6R2V0Q2xhc3NOYW1lKCRjaGlsZCwgJHNiLCAyNTYpCiAgICAgICAgICAgIGlmICgkc2IuVG9TdHJpbmcoKSAtZXEgJ0Nocm9tZV9SZW5kZXJXaWRnZXRIb3N0SFdORCcpIHsKICAgICAgICAgICAgICAgICRyID0gTmV3LU9iamVjdCBBZGVvbk5hdGl2ZStSRUNUCiAgICAgICAgICAgICAgICBpZiAoW0FkZW9uTmF0aXZlXTo6R2V0V2luZG93UmVjdCgkY2hpbGQsIFtyZWZdJHIpKSB7CiAgICAgICAgICAgICAgICAgICAgJGFyZWEgPSBbTWF0aF06Ok1heCgwLCAkci5SaWdodC0kci5MZWZ0KSAqIFtNYXRoXTo6TWF4KDAsICRyLkJvdHRvbS0kci5Ub3ApCiAgICAgICAgICAgICAgICAgICAgaWYgKCRhcmVhIC1ndCAkc2NyaXB0OmJlc3RBcmVhKSB7CiAgICAgICAgICAgICAgICAgICAgICAgICRzY3JpcHQ6YmVzdEFyZWEgPSAkYXJlYQogICAgICAgICAgICAgICAgICAgICAgICAkc2NyaXB0OmJlc3RSZW5kZXIgPSAkY2hpbGQKICAgICAgICAgICAgICAgICAgICB9CiAgICAgICAgICAgICAgICB9CiAgICAgICAgICAgIH0KICAgICAgICB9IGNhdGNoIHt9CiAgICAgICAgcmV0dXJuICR0cnVlCiAgICB9CiAgICB0cnkgeyBbdm9pZF1bQWRlb25OYXRpdmVdOjpFbnVtQ2hpbGRXaW5kb3dzKCRQYXJlbnQsICRjYiwgW0ludFB0cl06Olplcm8pIH0gY2F0Y2gge30KICAgIHJldHVybiAkc2NyaXB0OmJlc3RSZW5kZXIKfQoKZnVuY3Rpb24gQWRkLUFkZW9uTm9kZSgkRWwsICROb2RlcywgW3JlZl0kVXJsUmVmLCBbcmVmXSREb2N1bWVudFRleHRSZWYpIHsKICAgIHRyeSB7CiAgICAgICAgJGMgPSAkRWwuQ3VycmVudAogICAgICAgIGlmICgkYy5Jc09mZnNjcmVlbikgeyByZXR1cm4gfQogICAgICAgICRyID0gJGMuQm91bmRpbmdSZWN0YW5nbGUKICAgICAgICBpZiAoJHIuV2lkdGggLWx0IDIgLW9yICRyLkhlaWdodCAtbHQgMikgeyByZXR1cm4gfQogICAgICAgICRuYW1lID0gW3N0cmluZ10kYy5OYW1lCiAgICAgICAgJGNvbnRyb2wgPSAnJwogICAgICAgIHRyeSB7ICRjb250cm9sID0gW3N0cmluZ10kYy5Db250cm9sVHlwZS5Qcm9ncmFtbWF0aWNOYW1lIH0gY2F0Y2gge30KICAgICAgICAkYWlkID0gW3N0cmluZ10kYy5BdXRvbWF0aW9uSWQKICAgICAgICAkY2xzID0gW3N0cmluZ10kYy5DbGFzc05hbWUKICAgICAgICAkZnJhbWV3b3JrID0gW3N0cmluZ10kYy5GcmFtZXdvcmtJZAogICAgICAgICR2YWx1ZSA9ICcnCiAgICAgICAgaWYgKCRjb250cm9sIC1tYXRjaCAnRWRpdHxEb2N1bWVudHxDb21ib0JveCcpIHsgJHZhbHVlID0gR2V0LUFkZW9uVmFsdWUgJEVsIH0KICAgICAgICBpZiAoLW5vdCAkVXJsUmVmLlZhbHVlIC1hbmQgKCR2YWx1ZSAtbWF0Y2ggJ15odHRwcz86Ly8oPzp3d3dcLik/bXlhY2NvdW50XC5scndyaXRlcnNcLmNvbS8nKSkgewogICAgICAgICAgICAkVXJsUmVmLlZhbHVlID0gJHZhbHVlCiAgICAgICAgfQogICAgICAgIGlmICgtbm90ICREb2N1bWVudFRleHRSZWYuVmFsdWUgLWFuZCAkY29udHJvbCAtbWF0Y2ggJ0RvY3VtZW50JykgewogICAgICAgICAgICAkRG9jdW1lbnRUZXh0UmVmLlZhbHVlID0gR2V0LUFkZW9uVGV4dCAkRWwKICAgICAgICB9CiAgICAgICAgaWYgKC1ub3QgJG5hbWUgLWFuZCAtbm90ICR2YWx1ZSAtYW5kICRjb250cm9sIC1ub3RtYXRjaCAnQnV0dG9ufEh5cGVybGlua3xNZW51SXRlbXxUYWJJdGVtfERhdGFJdGVtfExpc3RJdGVtfEVkaXR8RG9jdW1lbnR8VGV4dCcpIHsgcmV0dXJuIH0KICAgICAgICAkTm9kZXMuQWRkKFtwc2N1c3RvbW9iamVjdF1AewogICAgICAgICAgICBuYW1lID0gJG5hbWUKICAgICAgICAgICAgdmFsdWUgPSAkdmFsdWUKICAgICAgICAgICAgY29udHJvbCA9ICRjb250cm9sCiAgICAgICAgICAgIGF1dG9tYXRpb25JZCA9ICRhaWQKICAgICAgICAgICAgY2xhc3NOYW1lID0gJGNscwogICAgICAgICAgICBmcmFtZXdvcmsgPSAkZnJhbWV3b3JrCiAgICAgICAgICAgIGxlZnQgPSBbTWF0aF06OlJvdW5kKFtkb3VibGVdJHIuTGVmdCwgMSkKICAgICAgICAgICAgdG9wID0gW01hdGhdOjpSb3VuZChbZG91YmxlXSRyLlRvcCwgMSkKICAgICAgICAgICAgd2lkdGggPSBbTWF0aF06OlJvdW5kKFtkb3VibGVdJHIuV2lkdGgsIDEpCiAgICAgICAgICAgIGhlaWdodCA9IFtNYXRoXTo6Um91bmQoW2RvdWJsZV0kci5IZWlnaHQsIDEpCiAgICAgICAgICAgIGVuYWJsZWQgPSBbYm9vbF0kYy5Jc0VuYWJsZWQKICAgICAgICAgICAgZm9jdXNhYmxlID0gW2Jvb2xdJGMuSXNLZXlib2FyZEZvY3VzYWJsZQogICAgICAgICAgICBjb250ZW50ID0gW2Jvb2xdJGMuSXNDb250ZW50RWxlbWVudAogICAgICAgICAgICBjb250cm9sRWxlbWVudCA9IFtib29sXSRjLklzQ29udHJvbEVsZW1lbnQKICAgICAgICB9KSB8IE91dC1OdWxsCiAgICB9IGNhdGNoIHt9Cn0KCmZ1bmN0aW9uIFNjYW4tQWRlb25UcmVlKCRSb290LCBbaW50XSRNYXhOb2RlcywgW2ludF0kQnVkZ2V0TXMsIFtzdHJpbmddJFZpZXc9J0NvbnRyb2wnKSB7CiAgICAkbm9kZXMgPSBOZXctT2JqZWN0IFN5c3RlbS5Db2xsZWN0aW9ucy5HZW5lcmljLkxpc3Rbb2JqZWN0XQogICAgJHVybCA9ICcnCiAgICAkZG9jdW1lbnRUZXh0ID0gJycKICAgIGlmICgkbnVsbCAtZXEgJFJvb3QpIHsKICAgICAgICByZXR1cm4gW3BzY3VzdG9tb2JqZWN0XUB7IG5vZGVzPSRub2RlczsgdXJsPSR1cmw7IGRvY3VtZW50VGV4dD0kZG9jdW1lbnRUZXh0OyB2aXNpdGVkPTAgfQogICAgfQoKICAgIGlmICgkVmlldyAtZXEgJ1JhdycpIHsgJHdhbGtlciA9IFtTeXN0ZW0uV2luZG93cy5BdXRvbWF0aW9uLlRyZWVXYWxrZXJdOjpSYXdWaWV3V2Fsa2VyIH0KICAgIGVsc2VpZiAoJFZpZXcgLWVxICdDb250ZW50JykgeyAkd2Fsa2VyID0gW1N5c3RlbS5XaW5kb3dzLkF1dG9tYXRpb24uVHJlZVdhbGtlcl06OkNvbnRlbnRWaWV3V2Fsa2VyIH0KICAgIGVsc2UgeyAkd2Fsa2VyID0gW1N5c3RlbS5XaW5kb3dzLkF1dG9tYXRpb24uVHJlZVdhbGtlcl06OkNvbnRyb2xWaWV3V2Fsa2VyIH0KCiAgICAkcXVldWUgPSBOZXctT2JqZWN0ICdTeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYy5RdWV1ZVtTeXN0ZW0uV2luZG93cy5BdXRvbWF0aW9uLkF1dG9tYXRpb25FbGVtZW50XScKICAgICRxdWV1ZS5FbnF1ZXVlKCRSb290KQogICAgJHN3ID0gW1N5c3RlbS5EaWFnbm9zdGljcy5TdG9wd2F0Y2hdOjpTdGFydE5ldygpCiAgICAkdmlzaXRlZCA9IDAKICAgIHdoaWxlICgkcXVldWUuQ291bnQgLWd0IDAgLWFuZCAkdmlzaXRlZCAtbHQgJE1heE5vZGVzIC1hbmQgJHN3LkVsYXBzZWRNaWxsaXNlY29uZHMgLWx0ICRCdWRnZXRNcykgewogICAgICAgICRlbCA9ICRxdWV1ZS5EZXF1ZXVlKCkKICAgICAgICAkdmlzaXRlZCsrCiAgICAgICAgQWRkLUFkZW9uTm9kZSAkZWwgJG5vZGVzIChbcmVmXSR1cmwpIChbcmVmXSRkb2N1bWVudFRleHQpCiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgJGNoaWxkID0gJHdhbGtlci5HZXRGaXJzdENoaWxkKCRlbCkKICAgICAgICAgICAgJHNpYmxpbmdHdWFyZCA9IDAKICAgICAgICAgICAgd2hpbGUgKCRudWxsIC1uZSAkY2hpbGQgLWFuZCAkc2libGluZ0d1YXJkIC1sdCA4MDAgLWFuZCAkdmlzaXRlZCArICRxdWV1ZS5Db3VudCAtbHQgJE1heE5vZGVzKSB7CiAgICAgICAgICAgICAgICAkcXVldWUuRW5xdWV1ZSgkY2hpbGQpCiAgICAgICAgICAgICAgICAkc2libGluZ0d1YXJkKysKICAgICAgICAgICAgICAgIHRyeSB7ICRjaGlsZCA9ICR3YWxrZXIuR2V0TmV4dFNpYmxpbmcoJGNoaWxkKSB9IGNhdGNoIHsgJGNoaWxkID0gJG51bGwgfQogICAgICAgICAgICB9CiAgICAgICAgfSBjYXRjaCB7fQogICAgfQogICAgJHN3LlN0b3AoKQogICAgcmV0dXJuIFtwc2N1c3RvbW9iamVjdF1AeyBub2Rlcz0kbm9kZXM7IHVybD0kdXJsOyBkb2N1bWVudFRleHQ9JGRvY3VtZW50VGV4dDsgdmlzaXRlZD0kdmlzaXRlZCB9Cn0KCmZ1bmN0aW9uIE1lcmdlLUFkZW9uTm9kZXMoJFByaW1hcnksICRFeHRyYSkgewogICAgJG91dCA9IE5ldy1PYmplY3QgU3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWMuTGlzdFtvYmplY3RdCiAgICAkc2VlbiA9IEB7fQogICAgZm9yZWFjaCAoJG4gaW4gQCgkUHJpbWFyeSkgKyBAKCRFeHRyYSkpIHsKICAgICAgICBpZiAoJG51bGwgLWVxICRuKSB7IGNvbnRpbnVlIH0KICAgICAgICAka2V5ID0gKFtzdHJpbmddJG4ubGVmdCkrJ3wnKyhbc3RyaW5nXSRuLnRvcCkrJ3wnKyhbc3RyaW5nXSRuLndpZHRoKSsnfCcrKFtzdHJpbmddJG4uaGVpZ2h0KSsnfCcrKFtzdHJpbmddJG4ubmFtZSkrJ3wnKyhbc3RyaW5nXSRuLnZhbHVlKSsnfCcrKFtzdHJpbmddJG4uY29udHJvbCkKICAgICAgICBpZiAoLW5vdCAkc2Vlbi5Db250YWluc0tleSgka2V5KSkgewogICAgICAgICAgICAkc2Vlblska2V5XSA9ICR0cnVlCiAgICAgICAgICAgICRvdXQuQWRkKCRuKSB8IE91dC1OdWxsCiAgICAgICAgfQogICAgfQogICAgcmV0dXJuICRvdXQKfQoKZnVuY3Rpb24gV3JpdGUtQWRlb25TbmFwc2hvdCgkT2JqZWN0KSB7CiAgICB0cnkgewogICAgICAgICRqc29uID0gJE9iamVjdCB8IENvbnZlcnRUby1Kc29uIC1Db21wcmVzcyAtRGVwdGggNgogICAgICAgICR0bXAgPSAkT3V0RmlsZSArICcudG1wJwogICAgICAgIFtTeXN0ZW0uSU8uRmlsZV06OldyaXRlQWxsVGV4dCgkdG1wLCAkanNvbiwgJHNjcmlwdDp1dGY4KQogICAgICAgIE1vdmUtSXRlbSAtTGl0ZXJhbFBhdGggJHRtcCAtRGVzdGluYXRpb24gJE91dEZpbGUgLUZvcmNlCiAgICAgICAgcmV0dXJuICR0cnVlCiAgICB9IGNhdGNoIHsgcmV0dXJuICRmYWxzZSB9Cn0KCiRtYWluUHRyID0gW0ludFB0cl06Om5ldygkSHduZCkKJHV0ZjggPSBOZXctT2JqZWN0IFN5c3RlbS5UZXh0LlVURjhFbmNvZGluZygkZmFsc2UpCiRzY3JpcHQ6dXRmOCA9ICR1dGY4CiRhY2Nlc3NpYmlsaXR5TnVkZ2VkID0gJGZhbHNlCgp3aGlsZSAoLW5vdCAoVGVzdC1QYXRoIC1MaXRlcmFsUGF0aCAkU3RvcEZpbGUpKSB7CiAgICAkZGlhZyA9ICcnCiAgICB0cnkgewogICAgICAgICRtYWluUm9vdCA9IFtTeXN0ZW0uV2luZG93cy5BdXRvbWF0aW9uLkF1dG9tYXRpb25FbGVtZW50XTo6RnJvbUhhbmRsZSgkbWFpblB0cikKICAgICAgICBpZiAoJG51bGwgLWVxICRtYWluUm9vdCkgewogICAgICAgICAgICAkZGlhZyA9ICdBdXRvbWF0aW9uRWxlbWVudC5Gcm9tSGFuZGxlKG1haW4gd2luZG93KSByZXR1cm5lZCBudWxsJwogICAgICAgICAgICBTdGFydC1TbGVlcCAtTWlsbGlzZWNvbmRzIDI1MAogICAgICAgICAgICBjb250aW51ZQogICAgICAgIH0KCiAgICAgICAgJHRpdGxlID0gJycKICAgICAgICB0cnkgeyAkdGl0bGUgPSBbc3RyaW5nXSRtYWluUm9vdC5DdXJyZW50Lk5hbWUgfSBjYXRjaCB7fQoKICAgICAgICAkcmVuZGVyUHRyID0gR2V0LVJlbmRlckhvc3QgJG1haW5QdHIKICAgICAgICBpZiAoLW5vdCAkYWNjZXNzaWJpbGl0eU51ZGdlZCkgewogICAgICAgICAgICB0cnkgewogICAgICAgICAgICAgICAgW0FkZW9uTmF0aXZlXTo6TnVkZ2VBY2Nlc3NpYmlsaXR5KCRtYWluUHRyKQogICAgICAgICAgICAgICAgaWYgKCRyZW5kZXJQdHIgLW5lIFtJbnRQdHJdOjpaZXJvKSB7IFtBZGVvbk5hdGl2ZV06Ok51ZGdlQWNjZXNzaWJpbGl0eSgkcmVuZGVyUHRyKSB9CiAgICAgICAgICAgIH0gY2F0Y2gge30KICAgICAgICAgICAgJGFjY2Vzc2liaWxpdHlOdWRnZWQgPSAkdHJ1ZQogICAgICAgICAgICBTdGFydC1TbGVlcCAtTWlsbGlzZWNvbmRzIDM1MAogICAgICAgIH0KCiAgICAgICAgJHNjYW5Sb290ID0gJG1haW5Sb290CiAgICAgICAgJHNvdXJjZSA9ICd1aWEtbWFpbi1jb250cm9sJwogICAgICAgICRyZW5kZXJSb290ID0gJG51bGwKICAgICAgICBpZiAoJHJlbmRlclB0ciAtbmUgW0ludFB0cl06Olplcm8pIHsKICAgICAgICAgICAgdHJ5IHsKICAgICAgICAgICAgICAgICRyZW5kZXJSb290ID0gW1N5c3RlbS5XaW5kb3dzLkF1dG9tYXRpb24uQXV0b21hdGlvbkVsZW1lbnRdOjpGcm9tSGFuZGxlKCRyZW5kZXJQdHIpCiAgICAgICAgICAgICAgICBpZiAoJG51bGwgLW5lICRyZW5kZXJSb290KSB7CiAgICAgICAgICAgICAgICAgICAgJHNjYW5Sb290ID0gJHJlbmRlclJvb3QKICAgICAgICAgICAgICAgICAgICAkc291cmNlID0gJ3VpYS1yZW5kZXItY29udHJvbCcKICAgICAgICAgICAgICAgIH0KICAgICAgICAgICAgfSBjYXRjaCB7fQogICAgICAgIH0KCiAgICAgICAgJHNjYW4gPSAkKGlmICgkRmFzdExhYmVscykgewogICAgICAgICAgICBTY2FuLUFkZW9uVHJlZSAkc2NhblJvb3QgMTgwMCA1MDAgJ0NvbnRyb2wnCiAgICAgICAgfSBlbHNlIHsKICAgICAgICAgICAgU2Nhbi1BZGVvblRyZWUgJHNjYW5Sb290IDI2MDAgMTUwMCAnQ29udHJvbCcKICAgICAgICB9KQoKICAgICAgICAjIENocm9taXVtJ3MgVUlBIHByb3ZpZGVyIGlzIG5vdCBhbHdheXMgY29tcGxldGUuIFRyeSB0aGUgUmF3IHZpZXcgYmVmb3JlCiAgICAgICAgIyBmYWxsaW5nIGJhY2sgdG8gTVNBQS9JQWNjZXNzaWJsZSwgd2hpY2ggQ2hyb21pdW0gaGFzIHN1cHBvcnRlZCBmb3IgeWVhcnMuCiAgICAgICAgaWYgKCRzY2FuLm5vZGVzLkNvdW50IC1sdCA0IC1hbmQgJG51bGwgLW5lICRyZW5kZXJSb290KSB7CiAgICAgICAgICAgICRyYXcgPSAkKGlmICgkRmFzdExhYmVscykgewogICAgICAgICAgICAgICAgU2Nhbi1BZGVvblRyZWUgJHJlbmRlclJvb3QgMjgwMCA3MDAgJ1JhdycKICAgICAgICAgICAgfSBlbHNlIHsKICAgICAgICAgICAgICAgIFNjYW4tQWRlb25UcmVlICRyZW5kZXJSb290IDUwMDAgMjIwMCAnUmF3JwogICAgICAgICAgICB9KQogICAgICAgICAgICBpZiAoJHJhdy5ub2Rlcy5Db3VudCAtZ3QgJHNjYW4ubm9kZXMuQ291bnQpIHsKICAgICAgICAgICAgICAgICRzY2FuID0gJHJhdwogICAgICAgICAgICAgICAgJHNvdXJjZSA9ICd1aWEtcmVuZGVyLXJhdycKICAgICAgICAgICAgfQogICAgICAgIH0KCiAgICAgICAgaWYgKCRzY2FuLm5vZGVzLkNvdW50IC1sdCA0IC1hbmQgJHNjYW5Sb290IC1uZSAkbWFpblJvb3QpIHsKICAgICAgICAgICAgJGZhbGxiYWNrID0gJChpZiAoJEZhc3RMYWJlbHMpIHsKICAgICAgICAgICAgICAgIFNjYW4tQWRlb25UcmVlICRtYWluUm9vdCAxODAwIDQ1MCAnUmF3JwogICAgICAgICAgICB9IGVsc2UgewogICAgICAgICAgICAgICAgU2Nhbi1BZGVvblRyZWUgJG1haW5Sb290IDI2MDAgMTQwMCAnUmF3JwogICAgICAgICAgICB9KQogICAgICAgICAgICBpZiAoJGZhbGxiYWNrLm5vZGVzLkNvdW50IC1ndCAkc2Nhbi5ub2Rlcy5Db3VudCkgewogICAgICAgICAgICAgICAgJHNjYW4gPSAkZmFsbGJhY2sKICAgICAgICAgICAgICAgICRzb3VyY2UgPSAndWlhLW1haW4tcmF3JwogICAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAjIElmIFVJQSBzdGlsbCBleHBvc2VzIG9ubHkgYnJvd3NlciBjaHJvbWUsIHF1ZXJ5IE1pY3Jvc29mdCdzIGxlZ2FjeQogICAgICAgICMgQWN0aXZlIEFjY2Vzc2liaWxpdHkgaW50ZXJmYWNlIGRpcmVjdGx5LiBDaHJvbWl1bSBkb2N1bWVudHMgTVNBQSAvCiAgICAgICAgIyBJQWNjZXNzaWJsZSBhcyBhIHN1cHBvcnRlZCBXaW5kb3dzIGFjY2Vzc2liaWxpdHkgQVBJLgogICAgICAgICRtc2FhRGlhZyA9ICcnCiAgICAgICAgaWYgKCRzY2FuLm5vZGVzLkNvdW50IC1sdCA0IC1vciAoW3N0cmluZ10kc2Nhbi5kb2N1bWVudFRleHQpLkxlbmd0aCAtbHQgMjApIHsKICAgICAgICAgICAgW0ludFB0cl0kbXNhYVRhcmdldCA9ICQoaWYgKCRyZW5kZXJQdHIgLW5lIFtJbnRQdHJdOjpaZXJvKSB7ICRyZW5kZXJQdHIgfSBlbHNlIHsgJG1haW5QdHIgfSkKICAgICAgICAgICAgdHJ5IHsKICAgICAgICAgICAgICAgICRtciA9ICQoaWYgKCRGYXN0TGFiZWxzKSB7CiAgICAgICAgICAgICAgICAgICAgW0FkZW9uTXNhYV06OlNjYW4oW0ludFB0cl0kbXNhYVRhcmdldCwgW2ludF0yODAwLCBbaW50XTcwMCkKICAgICAgICAgICAgICAgIH0gZWxzZSB7CiAgICAgICAgICAgICAgICAgICAgW0FkZW9uTXNhYV06OlNjYW4oW0ludFB0cl0kbXNhYVRhcmdldCwgW2ludF01MDAwLCBbaW50XTI1MDApCiAgICAgICAgICAgICAgICB9KQogICAgICAgICAgICAgICAgJG1zYWFEaWFnID0gW3N0cmluZ10kbXIuZGlhZ25vc3RpYwogICAgICAgICAgICAgICAgaWYgKCRudWxsIC1uZSAkbXIgLWFuZCAkbXIubm9kZXMuQ291bnQgLWd0IDApIHsKICAgICAgICAgICAgICAgICAgICAkc2Nhbi5ub2RlcyA9IE1lcmdlLUFkZW9uTm9kZXMgJHNjYW4ubm9kZXMgJG1yLm5vZGVzCiAgICAgICAgICAgICAgICAgICAgJHNjYW4udmlzaXRlZCA9IFtpbnRdJHNjYW4udmlzaXRlZCArIFtpbnRdJG1yLnZpc2l0ZWQKICAgICAgICAgICAgICAgICAgICAkc291cmNlID0gJHNvdXJjZSArICcrbXNhYScKICAgICAgICAgICAgICAgIH0KICAgICAgICAgICAgfSBjYXRjaCB7CiAgICAgICAgICAgICAgICAkbXNhYURpYWcgPSAnbXNhYSBleGNlcHRpb246ICcgKyBbc3RyaW5nXSRfLkV4Y2VwdGlvbi5NZXNzYWdlCiAgICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgICR1cmwgPSBbc3RyaW5nXSRzY2FuLnVybAogICAgICAgICRkb2N1bWVudFRleHQgPSBbc3RyaW5nXSRzY2FuLmRvY3VtZW50VGV4dAogICAgICAgIGlmICgtbm90ICR1cmwpIHsKICAgICAgICAgICAgZm9yZWFjaCAoJG4gaW4gJHNjYW4ubm9kZXMpIHsKICAgICAgICAgICAgICAgIGlmICgoJG4udmFsdWUgLWFzIFtzdHJpbmddKSAtbWF0Y2ggJ15odHRwcz86Ly8oPzp3d3dcLik/bXlhY2NvdW50XC5scndyaXRlcnNcLmNvbS8nKSB7CiAgICAgICAgICAgICAgICAgICAgJHVybCA9IFtzdHJpbmddJG4udmFsdWUKICAgICAgICAgICAgICAgICAgICBicmVhawogICAgICAgICAgICAgICAgfQogICAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICBpZiAoLW5vdCAkZG9jdW1lbnRUZXh0KSB7CiAgICAgICAgICAgICR0ZXh0cyA9IE5ldy1PYmplY3QgU3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWMuTGlzdFtzdHJpbmddCiAgICAgICAgICAgIGZvcmVhY2ggKCRuIGluICRzY2FuLm5vZGVzKSB7CiAgICAgICAgICAgICAgICAkdCA9IFtzdHJpbmddJChpZiAoJG4ubmFtZSkgeyAkbi5uYW1lIH0gZWxzZSB7ICRuLnZhbHVlIH0pCiAgICAgICAgICAgICAgICBpZiAoJHQgLWFuZCAkdC5MZW5ndGggLWx0IDEwMDApIHsgJHRleHRzLkFkZCgkdCkgfCBPdXQtTnVsbCB9CiAgICAgICAgICAgICAgICBpZiAoKCR0ZXh0cyAtam9pbiAnICcpLkxlbmd0aCAtZ3QgMzAwMDApIHsgYnJlYWsgfQogICAgICAgICAgICB9CiAgICAgICAgICAgICRkb2N1bWVudFRleHQgPSAoJHRleHRzIC1qb2luICcgJykKICAgICAgICB9CgogICAgICAgICRzYW1wbGVQYXJ0cyA9IE5ldy1PYmplY3QgU3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWMuTGlzdFtzdHJpbmddCiAgICAgICAgZm9yZWFjaCAoJG4gaW4gQCgkc2Nhbi5ub2RlcyB8IFNlbGVjdC1PYmplY3QgLUZpcnN0IDgpKSB7CiAgICAgICAgICAgICRzbiA9IFtzdHJpbmddJChpZiAoJG4ubmFtZSkgeyAkbi5uYW1lIH0gZWxzZSB7ICRuLnZhbHVlIH0pCiAgICAgICAgICAgIGlmICgkc24pIHsKICAgICAgICAgICAgICAgICRzbiA9ICgkc24gLXJlcGxhY2UgJ1tcclxuXSsnLCcgJyAtcmVwbGFjZSAnXHMrJywnICcpLlRyaW0oKQogICAgICAgICAgICAgICAgaWYgKCRzbi5MZW5ndGggLWd0IDgwKSB7ICRzbiA9ICRzbi5TdWJzdHJpbmcoMCw4MCkgfQogICAgICAgICAgICAgICAgaWYgKCRzbikgeyAkc2FtcGxlUGFydHMuQWRkKCRzbikgfCBPdXQtTnVsbCB9CiAgICAgICAgICAgIH0KICAgICAgICB9CiAgICAgICAgJHNhbXBsZURpYWcgPSAkKGlmICgkc2FtcGxlUGFydHMuQ291bnQgLWd0IDApIHsgJyBzYW1wbGU9JyArICgkc2FtcGxlUGFydHMgLWpvaW4gJyB8ICcpIH0gZWxzZSB7ICcnIH0pCgogICAgICAgIGlmICgkc2Nhbi5ub2Rlcy5Db3VudCAtbHQgMyAtYW5kIC1ub3QgJGRvY3VtZW50VGV4dCkgewogICAgICAgICAgICAkZGlhZyA9ICJhY2Nlc3NpYmlsaXR5IHRyZWUgaXMgcHJlc2VudCBidXQgQ2hyb21pdW0gZXhwb3NlZCBubyB1c2VmdWwgcGFnZSBjb250cm9scyAoJHNvdXJjZSkgJG1zYWFEaWFnJHNhbXBsZURpYWciCiAgICAgICAgfSBlbHNlIHsKICAgICAgICAgICAgJGRpYWcgPSAib2s6JHNvdXJjZSB2aXNpdGVkPSQoJHNjYW4udmlzaXRlZCkgbm9kZXM9JCgkc2Nhbi5ub2Rlcy5Db3VudCkgJG1zYWFEaWFnJHNhbXBsZURpYWciCiAgICAgICAgfQoKICAgICAgICAkb2JqID0gW29yZGVyZWRdQHsKICAgICAgICAgICAgdHMgPSBbRGF0ZVRpbWVPZmZzZXRdOjpVdGNOb3cuVG9Vbml4VGltZU1pbGxpc2Vjb25kcygpIC8gMTAwMC4wCiAgICAgICAgICAgIGh3bmQgPSAkSHduZAogICAgICAgICAgICByZW5kZXJId25kID0gW0ludDY0XSRyZW5kZXJQdHIKICAgICAgICAgICAgdGl0bGUgPSAkdGl0bGUKICAgICAgICAgICAgdXJsID0gJHVybAogICAgICAgICAgICBkb2N1bWVudFRleHQgPSAkZG9jdW1lbnRUZXh0CiAgICAgICAgICAgIG5vZGVDb3VudCA9ICRzY2FuLm5vZGVzLkNvdW50CiAgICAgICAgICAgIGRpYWdub3N0aWMgPSAkZGlhZwogICAgICAgICAgICBub2RlcyA9ICRzY2FuLm5vZGVzCiAgICAgICAgfQogICAgICAgIFt2b2lkXShXcml0ZS1BZGVvblNuYXBzaG90ICRvYmopCiAgICB9IGNhdGNoIHsKICAgICAgICAkZGlhZyA9ICdmZWVkIGV4Y2VwdGlvbjogJyArIFtzdHJpbmddJF8uRXhjZXB0aW9uLk1lc3NhZ2UKICAgICAgICAkb2JqID0gW29yZGVyZWRdQHsKICAgICAgICAgICAgdHMgPSBbRGF0ZVRpbWVPZmZzZXRdOjpVdGNOb3cuVG9Vbml4VGltZU1pbGxpc2Vjb25kcygpIC8gMTAwMC4wCiAgICAgICAgICAgIGh3bmQgPSAkSHduZAogICAgICAgICAgICByZW5kZXJId25kID0gMAogICAgICAgICAgICB0aXRsZSA9ICcnCiAgICAgICAgICAgIHVybCA9ICcnCiAgICAgICAgICAgIGRvY3VtZW50VGV4dCA9ICcnCiAgICAgICAgICAgIG5vZGVDb3VudCA9IDAKICAgICAgICAgICAgZGlhZ25vc3RpYyA9ICRkaWFnCiAgICAgICAgICAgIG5vZGVzID0gQCgpCiAgICAgICAgfQogICAgICAgIFt2b2lkXShXcml0ZS1BZGVvblNuYXBzaG90ICRvYmopCiAgICB9CiAgICBTdGFydC1TbGVlcCAtTWlsbGlzZWNvbmRzICQoaWYgKCRGYXN0TGFiZWxzKSB7IFtNYXRoXTo6TWF4KDgwLCAkSW50ZXJ2YWxNcykgfSBlbHNlIHsgW01hdGhdOjpNYXgoMTIwLCAkSW50ZXJ2YWxNcykgfSkKfQo="
_ACCESS_FEED_RECOVERY_SHA256 = "edd962b83f909c854c23fb445d31c73f525e3efe1e051b161df324f784ef40e8"
_ACCESS_SNAPSHOT_FILE = _BASE_DIR / "Adeon Accessibility Snapshot.json"
_ACCESS_STOP_FILE = _BASE_DIR / "Adeon Accessibility Stop.flag"
_VISION_OCR_SCRIPT = _BASE_DIR / "Adeon Screen Vision OCR.ps1"
_VISION_CAPTURE_DIR = _LABEL_DATA_DIR / "Screen Vision Captures"
_VISION_OCR_RECOVERY_B64 = "cGFyYW0oCiAgICBbc3RyaW5nXSRJbWFnZVBhdGggPSAnJywKICAgIFtzd2l0Y2hdJExvb3AKKQoKJEVycm9yQWN0aW9uUHJlZmVyZW5jZSA9ICdTdG9wJwokdXRmOCA9IE5ldy1PYmplY3QgU3lzdGVtLlRleHQuVVRGOEVuY29kaW5nKCRmYWxzZSkKW0NvbnNvbGVdOjpPdXRwdXRFbmNvZGluZyA9ICR1dGY4CgpBZGQtVHlwZSAtQXNzZW1ibHlOYW1lIFN5c3RlbS5SdW50aW1lLldpbmRvd3NSdW50aW1lCiRudWxsID0gW1dpbmRvd3MuU3RvcmFnZS5TdG9yYWdlRmlsZSwgV2luZG93cy5TdG9yYWdlLCBDb250ZW50VHlwZT1XaW5kb3dzUnVudGltZV0KJG51bGwgPSBbV2luZG93cy5TdG9yYWdlLkZpbGVBY2Nlc3NNb2RlLCBXaW5kb3dzLlN0b3JhZ2UsIENvbnRlbnRUeXBlPVdpbmRvd3NSdW50aW1lXQokbnVsbCA9IFtXaW5kb3dzLlN0b3JhZ2UuU3RyZWFtcy5JUmFuZG9tQWNjZXNzU3RyZWFtLCBXaW5kb3dzLlN0b3JhZ2UuU3RyZWFtcywgQ29udGVudFR5cGU9V2luZG93c1J1bnRpbWVdCiRudWxsID0gW1dpbmRvd3MuR3JhcGhpY3MuSW1hZ2luZy5CaXRtYXBEZWNvZGVyLCBXaW5kb3dzLkdyYXBoaWNzLkltYWdpbmcsIENvbnRlbnRUeXBlPVdpbmRvd3NSdW50aW1lXQokbnVsbCA9IFtXaW5kb3dzLkdyYXBoaWNzLkltYWdpbmcuU29mdHdhcmVCaXRtYXAsIFdpbmRvd3MuRm91bmRhdGlvbiwgQ29udGVudFR5cGU9V2luZG93c1J1bnRpbWVdCiRudWxsID0gW1dpbmRvd3MuTWVkaWEuT2NyLk9jckVuZ2luZSwgV2luZG93cy5Gb3VuZGF0aW9uLCBDb250ZW50VHlwZT1XaW5kb3dzUnVudGltZV0KJG51bGwgPSBbV2luZG93cy5NZWRpYS5PY3IuT2NyUmVzdWx0LCBXaW5kb3dzLkZvdW5kYXRpb24sIENvbnRlbnRUeXBlPVdpbmRvd3NSdW50aW1lXQokbnVsbCA9IFtXaW5kb3dzLkZvdW5kYXRpb24uSUFzeW5jT3BlcmF0aW9uYDEsIFdpbmRvd3MuRm91bmRhdGlvbiwgQ29udGVudFR5cGU9V2luZG93c1J1bnRpbWVdCgpmdW5jdGlvbiBXYWl0LVdpblJ0KFtvYmplY3RdJE9wZXJhdGlvbiwgW1R5cGVdJFJlc3VsdFR5cGUpIHsKICAgICRhc1Rhc2sgPSBbU3lzdGVtLldpbmRvd3NSdW50aW1lU3lzdGVtRXh0ZW5zaW9uc10uR2V0TWV0aG9kcygpIHwKICAgICAgICBXaGVyZS1PYmplY3QgewogICAgICAgICAgICAkXy5OYW1lIC1lcSAnQXNUYXNrJyAtYW5kICRfLklzR2VuZXJpY01ldGhvZCAtYW5kCiAgICAgICAgICAgICRfLkdldFBhcmFtZXRlcnMoKS5Db3VudCAtZXEgMSAtYW5kCiAgICAgICAgICAgICRfLkdldFBhcmFtZXRlcnMoKVswXS5QYXJhbWV0ZXJUeXBlLk5hbWUgLWVxICdJQXN5bmNPcGVyYXRpb25gMScKICAgICAgICB9IHwgU2VsZWN0LU9iamVjdCAtRmlyc3QgMQogICAgaWYgKCRudWxsIC1lcSAkYXNUYXNrKSB7IHRocm93ICdDb3VsZCBub3QgbG9jYXRlIFdpblJUIEFzVGFzayBoZWxwZXIuJyB9CiAgICAkdGFzayA9ICRhc1Rhc2suTWFrZUdlbmVyaWNNZXRob2QoJFJlc3VsdFR5cGUpLkludm9rZSgkbnVsbCwgQCgkT3BlcmF0aW9uKSkKICAgICR0YXNrLldhaXQoKQogICAgcmV0dXJuICR0YXNrLlJlc3VsdAp9CgokZW5naW5lID0gW1dpbmRvd3MuTWVkaWEuT2NyLk9jckVuZ2luZV06OlRyeUNyZWF0ZUZyb21Vc2VyUHJvZmlsZUxhbmd1YWdlcygpCmlmICgkbnVsbCAtZXEgJGVuZ2luZSkgeyB0aHJvdyAnV2luZG93cyBPQ1IgZW5naW5lIGlzIHVuYXZhaWxhYmxlIGZvciB0aGUgY3VycmVudCBsYW5ndWFnZSBwcm9maWxlLicgfQoKZnVuY3Rpb24gSW52b2tlLUFkZW9uT2NyKFtzdHJpbmddJFBhdGgpIHsKICAgICRzdHJlYW0gPSAkbnVsbAogICAgdHJ5IHsKICAgICAgICAkcmVzb2x2ZWQgPSAoUmVzb2x2ZS1QYXRoIC1MaXRlcmFsUGF0aCAkUGF0aCkuUGF0aAogICAgICAgICRmaWxlID0gV2FpdC1XaW5SdCAoW1dpbmRvd3MuU3RvcmFnZS5TdG9yYWdlRmlsZV06OkdldEZpbGVGcm9tUGF0aEFzeW5jKCRyZXNvbHZlZCkpIChbV2luZG93cy5TdG9yYWdlLlN0b3JhZ2VGaWxlXSkKICAgICAgICAkc3RyZWFtID0gV2FpdC1XaW5SdCAoJGZpbGUuT3BlbkFzeW5jKFtXaW5kb3dzLlN0b3JhZ2UuRmlsZUFjY2Vzc01vZGVdOjpSZWFkKSkgKFtXaW5kb3dzLlN0b3JhZ2UuU3RyZWFtcy5JUmFuZG9tQWNjZXNzU3RyZWFtXSkKICAgICAgICAkZGVjb2RlciA9IFdhaXQtV2luUnQgKFtXaW5kb3dzLkdyYXBoaWNzLkltYWdpbmcuQml0bWFwRGVjb2Rlcl06OkNyZWF0ZUFzeW5jKCRzdHJlYW0pKSAoW1dpbmRvd3MuR3JhcGhpY3MuSW1hZ2luZy5CaXRtYXBEZWNvZGVyXSkKICAgICAgICAkYml0bWFwID0gV2FpdC1XaW5SdCAoJGRlY29kZXIuR2V0U29mdHdhcmVCaXRtYXBBc3luYygpKSAoW1dpbmRvd3MuR3JhcGhpY3MuSW1hZ2luZy5Tb2Z0d2FyZUJpdG1hcF0pCiAgICAgICAgJHJlc3VsdCA9IFdhaXQtV2luUnQgKCRlbmdpbmUuUmVjb2duaXplQXN5bmMoJGJpdG1hcCkpIChbV2luZG93cy5NZWRpYS5PY3IuT2NyUmVzdWx0XSkKCiAgICAgICAgJG91dExpbmVzID0gQCgpCiAgICAgICAgZm9yZWFjaCAoJGxpbmUgaW4gJHJlc3VsdC5MaW5lcykgewogICAgICAgICAgICAkb3V0V29yZHMgPSBAKCkKICAgICAgICAgICAgJGxlZnQgPSBbZG91YmxlXTo6UG9zaXRpdmVJbmZpbml0eQogICAgICAgICAgICAkdG9wID0gW2RvdWJsZV06OlBvc2l0aXZlSW5maW5pdHkKICAgICAgICAgICAgJHJpZ2h0ID0gW2RvdWJsZV06Ok5lZ2F0aXZlSW5maW5pdHkKICAgICAgICAgICAgJGJvdHRvbSA9IFtkb3VibGVdOjpOZWdhdGl2ZUluZmluaXR5CiAgICAgICAgICAgIGZvcmVhY2ggKCR3b3JkIGluICRsaW5lLldvcmRzKSB7CiAgICAgICAgICAgICAgICAkciA9ICR3b3JkLkJvdW5kaW5nUmVjdAogICAgICAgICAgICAgICAgJHggPSBbZG91YmxlXSRyLlg7ICR5ID0gW2RvdWJsZV0kci5ZOyAkdyA9IFtkb3VibGVdJHIuV2lkdGg7ICRoID0gW2RvdWJsZV0kci5IZWlnaHQKICAgICAgICAgICAgICAgIGlmICgkeCAtbHQgJGxlZnQpIHsgJGxlZnQgPSAkeCB9CiAgICAgICAgICAgICAgICBpZiAoJHkgLWx0ICR0b3ApIHsgJHRvcCA9ICR5IH0KICAgICAgICAgICAgICAgIGlmICgoJHggKyAkdykgLWd0ICRyaWdodCkgeyAkcmlnaHQgPSAkeCArICR3IH0KICAgICAgICAgICAgICAgIGlmICgoJHkgKyAkaCkgLWd0ICRib3R0b20pIHsgJGJvdHRvbSA9ICR5ICsgJGggfQogICAgICAgICAgICAgICAgJG91dFdvcmRzICs9IFtvcmRlcmVkXUB7IHRleHQgPSBbc3RyaW5nXSR3b3JkLlRleHQ7IHggPSAkeDsgeSA9ICR5OyB3ID0gJHc7IGggPSAkaCB9CiAgICAgICAgICAgIH0KICAgICAgICAgICAgJGJvdW5kcyA9ICRudWxsCiAgICAgICAgICAgIGlmICgkb3V0V29yZHMuQ291bnQgLWd0IDApIHsKICAgICAgICAgICAgICAgICRib3VuZHMgPSBbb3JkZXJlZF1AeyB4ID0gJGxlZnQ7IHkgPSAkdG9wOyB3ID0gKCRyaWdodCAtICRsZWZ0KTsgaCA9ICgkYm90dG9tIC0gJHRvcCkgfQogICAgICAgICAgICB9CiAgICAgICAgICAgICRvdXRMaW5lcyArPSBbb3JkZXJlZF1AeyB0ZXh0ID0gW3N0cmluZ10kbGluZS5UZXh0OyBib3VuZHMgPSAkYm91bmRzOyB3b3JkcyA9ICRvdXRXb3JkcyB9CiAgICAgICAgfQoKICAgICAgICByZXR1cm4gW29yZGVyZWRdQHsKICAgICAgICAgICAgb2sgPSAkdHJ1ZQogICAgICAgICAgICBiYWNrZW5kID0gJ1dpbmRvd3MuTWVkaWEuT2NyJwogICAgICAgICAgICBsYW5ndWFnZSA9IFtzdHJpbmddJGVuZ2luZS5SZWNvZ25pemVyTGFuZ3VhZ2UuTGFuZ3VhZ2VUYWcKICAgICAgICAgICAgdGV4dCA9IFtzdHJpbmddJHJlc3VsdC5UZXh0CiAgICAgICAgICAgIGxpbmVzID0gJG91dExpbmVzCiAgICAgICAgfQogICAgfQogICAgZmluYWxseSB7CiAgICAgICAgaWYgKCRudWxsIC1uZSAkc3RyZWFtKSB7CiAgICAgICAgICAgIHRyeSB7ICRzdHJlYW0uRGlzcG9zZSgpIH0gY2F0Y2gge30KICAgICAgICB9CiAgICB9Cn0KCmZ1bmN0aW9uIFdyaXRlLU9uZVJlc3VsdChbc3RyaW5nXSRQYXRoKSB7CiAgICB0cnkgewogICAgICAgICRvYmogPSBJbnZva2UtQWRlb25PY3IgJFBhdGgKICAgICAgICBbQ29uc29sZV06Ok91dC5Xcml0ZUxpbmUoKCRvYmogfCBDb252ZXJ0VG8tSnNvbiAtRGVwdGggOCAtQ29tcHJlc3MpKQogICAgfQogICAgY2F0Y2ggewogICAgICAgIFtDb25zb2xlXTo6T3V0LldyaXRlTGluZSgoW29yZGVyZWRdQHsgb2sgPSAkZmFsc2U7IGVycm9yID0gW3N0cmluZ10kXy5FeGNlcHRpb24uTWVzc2FnZSB9IHwgQ29udmVydFRvLUpzb24gLUNvbXByZXNzKSkKICAgIH0KICAgIFtDb25zb2xlXTo6T3V0LkZsdXNoKCkKfQoKaWYgKCRMb29wKSB7CiAgICB3aGlsZSAoJHRydWUpIHsKICAgICAgICAkbGluZSA9IFtDb25zb2xlXTo6SW4uUmVhZExpbmUoKQogICAgICAgIGlmICgkbnVsbCAtZXEgJGxpbmUpIHsgYnJlYWsgfQogICAgICAgIGlmICgkbGluZSAtZXEgJ19fUVVJVF9fJykgeyBicmVhayB9CiAgICAgICAgaWYgKFtzdHJpbmddOjpJc051bGxPcldoaXRlU3BhY2UoJGxpbmUpKSB7IGNvbnRpbnVlIH0KICAgICAgICBXcml0ZS1PbmVSZXN1bHQgJGxpbmUKICAgIH0KICAgIGV4aXQgMAp9CgppZiAoW3N0cmluZ106OklzTnVsbE9yV2hpdGVTcGFjZSgkSW1hZ2VQYXRoKSkgewogICAgW29yZGVyZWRdQHsgb2sgPSAkZmFsc2U7IGVycm9yID0gJ0ltYWdlUGF0aCBpcyByZXF1aXJlZCB1bmxlc3MgLUxvb3AgaXMgdXNlZC4nIH0gfCBDb252ZXJ0VG8tSnNvbiAtQ29tcHJlc3MKICAgIGV4aXQgMgp9CgpXcml0ZS1PbmVSZXN1bHQgJEltYWdlUGF0aAo="
_VISION_OCR_RECOVERY_SHA256 = "92ee209e1c9cb3b953985ee5475ec03094556d0ac1290871579da6a4e711bbd1"
_vision_last_seen = 0.0
_vision_last_snapshot: dict = {}
_vision_last_hash = ""
_vision_last_capture_at = 0.0
_vision_last_ocr_at = 0.0
_vision_hwnd = 0
# Last positively OCR-verified Find Orders earnings-column centers. OCR can
# temporarily miss a header after F5 while still reading every row; retaining the
# verified column geometry prevents those rows from degrading to $0/unknown.
_vision_pay_header_hwnd = 0
_vision_pay_header_seen_at = 0.0
_vision_aplus_x = 0.0
_vision_you_x = 0.0
_vision_ocr_proc = None
_vision_ocr_queue = queue.Queue()
_vision_ocr_reader_thread = None
_vision_ocr_lock = threading.Lock()
_uia_proc = None
_uia_hwnd = 0
_uia_last_seen = 0.0
_uia_last_title = ""


def _uia_stop_feed() -> None:
    global _uia_proc, _uia_hwnd
    try:
        _ACCESS_STOP_FILE.write_text("stop", encoding="utf-8")
    except Exception:
        pass
    proc = _uia_proc
    _uia_proc = None
    _uia_hwnd = 0
    if proc is not None:
        try:
            proc.wait(timeout=1.0)
        except Exception:
            try:
                proc.terminate()
            except Exception:
                pass


def _uia_feed_live(max_age: float = 2.0) -> bool:
    global _uia_last_seen
    try:
        obj = _read_json(_ACCESS_SNAPSHOT_FILE)
        ts = float(obj.get("ts") or 0.0)
        if ts <= 0:
            return False
        age = time.time() - ts
        if age <= float(max_age):
            _uia_last_seen = ts
            return True
    except Exception:
        pass
    return False


def _uia_start_feed(hwnd: int) -> bool:
    """Start the local read-only Windows accessibility feed for one existing browser window.

    v1.0.50 first nudges Chromium accessibility, then tries UI Automation and MSAA/IAccessible with bounded readers. This remains read-only and browser-independent.
    """
    global _uia_proc, _uia_hwnd
    hwnd = int(hwnd or 0)
    if hwnd <= 0:
        note_issue("UIA_NO_WINDOW", "Windows accessibility did not receive a usable browser window handle", "ERROR", throttle=0)
        return False
    if not _ACCESS_FEED_SCRIPT.is_file():
        try:
            recovered = base64.b64decode(_ACCESS_FEED_RECOVERY_B64.encode("ascii"), validate=True)
            digest = hashlib.sha256(recovered).hexdigest().lower()
            if digest != _ACCESS_FEED_RECOVERY_SHA256.lower():
                raise RuntimeError("built-in accessibility recovery checksum mismatch")
            _ACCESS_FEED_SCRIPT.parent.mkdir(parents=True, exist_ok=True)
            tmp = _ACCESS_FEED_SCRIPT.with_suffix(".ps1.repair")
            tmp.write_bytes(recovered)
            os.replace(tmp, _ACCESS_FEED_SCRIPT)
            log("WINDOWS ACCESSIBILITY SELF-REPAIR: restored Adeon Accessibility Feed.ps1 from the built-in recovery copy.")
        except Exception as e:
            note_issue("UIA_FEED_MISSING", "Adeon Accessibility Feed.ps1 is missing and self-repair failed", "ERROR", str(e), throttle=0)
            return False
    try:
        # Do not overwrite a newer accessibility helper merely because its hash differs
        # from the built-in recovery copy. That caused 1.0.53 to silently restore the
        # older MSAA implementation on every Picker start. Accept any structurally valid
        # installed helper; use the built-in copy only when the file is missing or clearly
        # incomplete/legacy.
        feed_bytes = _ACCESS_FEED_SCRIPT.read_bytes()
        feed_text = feed_bytes.decode("utf-8", errors="ignore")
        feed_ok = (
            len(feed_bytes) >= 8000
            and "ADEON_ACCESS_FEED_VERSION=" in feed_text
            and "class AdeonMsaa" in feed_text
            and "get_accChild" in feed_text
            and "AccessibleChildren(" not in feed_text
            and "Write-AdeonSnapshot" in feed_text
        )
        if not feed_ok:
            recovered = base64.b64decode(_ACCESS_FEED_RECOVERY_B64.encode("ascii"), validate=True)
            digest = hashlib.sha256(recovered).hexdigest().lower()
            if digest != _ACCESS_FEED_RECOVERY_SHA256.lower():
                raise RuntimeError("built-in accessibility recovery checksum mismatch")
            tmp = _ACCESS_FEED_SCRIPT.with_suffix(".ps1.repair")
            tmp.write_bytes(recovered)
            os.replace(tmp, _ACCESS_FEED_SCRIPT)
            log("WINDOWS ACCESSIBILITY SELF-REPAIR: replaced an incomplete/legacy accessibility feed with the current built-in copy.")
        else:
            log("WINDOWS ACCESSIBILITY FEED VERIFIED: current installed helper accepted; built-in recovery was not used.")
    except Exception as e:
        note_issue("UIA_FEED_VERIFY", "Adeon could not verify or repair the Windows accessibility feed", "ERROR", str(e), throttle=0)
        return False

    def raw_useful(max_age: float = 2.0) -> tuple[bool, str]:
        try:
            obj = _read_json(_ACCESS_SNAPSHOT_FILE)
            ts = float(obj.get("ts") or 0.0)
            if ts <= 0 or time.time() - ts > max_age:
                return False, "no fresh accessibility snapshot"
            node_count = int(obj.get("nodeCount") or 0)
            doc_len = len(str(obj.get("documentText") or "").strip())
            url = str(obj.get("url") or "").strip()
            diag = str(obj.get("diagnostic") or "").strip()
            useful = node_count >= 3 or doc_len >= 20 or bool(url)
            return useful, f"nodes={node_count} text={doc_len} url={'yes' if url else 'no'} diag={diag}"
        except Exception as e:
            return False, f"snapshot read error: {e}"

    if _uia_proc is not None and _uia_proc.poll() is None and _uia_hwnd == hwnd:
        useful, _detail = raw_useful(2.0)
        if useful:
            return True

    _uia_stop_feed()
    try:
        _ACCESS_STOP_FILE.unlink(missing_ok=True)
        _ACCESS_SNAPSHOT_FILE.unlink(missing_ok=True)
    except Exception:
        pass
    ps = shutil.which("powershell.exe") or shutil.which("powershell")
    if not ps:
        note_issue("UIA_POWERSHELL_MISSING", "Windows PowerShell is unavailable, so the accessibility feed cannot start", "ERROR", throttle=0)
        return False
    try:
        _uia_cmd = [
            ps, "-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
            "-File", str(_ACCESS_FEED_SCRIPT), "-Hwnd", str(hwnd),
            "-OutFile", str(_ACCESS_SNAPSHOT_FILE), "-StopFile", str(_ACCESS_STOP_FILE),
            "-IntervalMs", ("80" if _LABELS_ONLY_MODE else "180")
        ]
        if _LABELS_ONLY_MODE:
            _uia_cmd.append("-FastLabels")
        _uia_proc = subprocess.Popen(
            _uia_cmd,
            cwd=str(_BASE_DIR),
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        _uia_hwnd = hwnd
        deadline = time.time() + 12.0
        last_detail = "feed started; waiting for Chromium accessibility tree"
        while time.time() < deadline and not _stop:
            useful, detail = raw_useful(2.5)
            if useful:
                log(f"WINDOWS ACCESSIBILITY PROBE OK: {detail}")
                return True
            if detail:
                last_detail = detail
            if _uia_proc.poll() is not None:
                last_detail = f"feed process exited with code {_uia_proc.returncode}; {last_detail}"
                break
            time.sleep(0.15)
        note_issue(
            "UIA_FEED_UNUSABLE",
            "Thorium was found, but Windows accessibility did not expose a usable LR page tree",
            "ERROR",
            last_detail,
            throttle=0,
        )
    except Exception as e:
        note_issue("UIA_FEED_START", "Could not start the Windows accessibility feed", "ERROR", str(e), throttle=0)
    return False


def _uia_norm(value: object) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def _uia_screen_pos(node: dict, render_rect: tuple[int, int, int, int]) -> dict | None:
    try:
        sl = float(node.get("left") or 0)
        st = float(node.get("top") or 0)
        w = float(node.get("width") or 0)
        h = float(node.get("height") or 0)
        if w < 2 or h < 2:
            return None
        sx = sl + w / 2.0
        sy = st + h / 2.0
        rl, rt, rr, rb = render_rect
        return {
            "vx": sx - rl, "vy": sy - rt,
            "left": sl - rl, "top": st - rt, "w": w, "h": h,
            "sx": sx, "sy": sy,
            "screenLeft": sl, "screenTop": st, "screenW": w, "screenH": h,
            "uia": True,
            "uiaName": _uia_norm(node.get("name") or node.get("value")),
            "uiaControl": str(node.get("control") or ""),
            "uiaAutomationId": str(node.get("automationId") or ""),
        }
    except Exception:
        return None


def _uia_visible_nodes(raw: dict, render_rect: tuple[int, int, int, int]) -> list[dict]:
    rl, rt, rr, rb = render_rect
    out = []
    for n in raw.get("nodes") or []:
        if not isinstance(n, dict):
            continue
        try:
            l=float(n.get("left") or 0); t=float(n.get("top") or 0)
            w=float(n.get("width") or 0); h=float(n.get("height") or 0)
            if w < 2 or h < 2 or l+w <= rl or l >= rr or t+h <= rt or t >= rb:
                continue
            out.append(n)
        except Exception:
            continue
    return out


def _uia_best_named(nodes: list[dict], label: str, controls: tuple[str, ...] = ()) -> dict | None:
    want = re.sub(r"[‘’]", "'", _uia_norm(label)).lower()
    best = None
    best_score = -1
    for n in nodes:
        name = re.sub(r"[‘’]", "'", _uia_norm(n.get("name") or n.get("value"))).lower()
        if name != want and name != want + " order":
            continue
        control = str(n.get("control") or "")
        if controls and not any(c.lower() in control.lower() for c in controls):
            continue
        try:
            area = float(n.get("width") or 0) * float(n.get("height") or 0)
        except Exception:
            area = 0
        score = (5000 if "Button" in control else 3000 if "Hyperlink" in control else 0) - min(area, 20000) / 100.0
        if score > best_score:
            best, best_score = n, score
    return best


def _uia_build_snapshot(raw: dict, hwnd: int) -> dict:
    """Convert a flat Windows accessibility tree into the subset of Adeon's page snapshot used by Picker."""
    global _uia_last_seen, _uia_last_title
    title = _uia_norm(raw.get("title")) or _title(hwnd)
    _uia_last_title = title
    ts = float(raw.get("ts") or time.time())
    _uia_last_seen = ts

    render = find_render(hwnd)
    render_rect = _screen_rect(render) if render else None
    if not render_rect:
        render_rect = _screen_rect(hwnd)
    if not render_rect:
        return {}
    rl, rt, rr, rb = render_rect
    inner_w, inner_h = max(1, rr-rl), max(1, rb-rt)
    nodes = _uia_visible_nodes(raw, render_rect)

    # Prefer the real address-bar ValuePattern. No keyboard focus or clipboard is used.
    url = _uia_norm(raw.get("url"))
    if not url:
        for n in raw.get("nodes") or []:
            val = _uia_norm(n.get("value"))
            if re.match(r"^https?://(?:www\.)?myaccount\.lrwriters\.com/", val, re.I):
                url = val
                break

    # Build readable page text from the accessibility document and visible names.
    doc_text = _uia_norm(raw.get("documentText"))
    sorted_nodes = sorted(nodes, key=lambda n: (float(n.get("top") or 0), float(n.get("left") or 0)))
    pieces=[]; seen=set()
    for n in sorted_nodes:
        txt=_uia_norm(n.get("name") or n.get("value"))
        if not txt or txt in seen:
            continue
        seen.add(txt); pieces.append(txt)
    body_text = doc_text if len(doc_text) >= 40 else " ".join(pieces)
    body_low = body_text.lower()

    my_headers = ("your price" in body_low and "payout date" in body_low)
    # LR's current Find Orders header does not say "Order number". It uses
    # Subject / Type of work / You'll earn / Size / Deadline / Additional info,
    # and the empty state says there are no available orders. Recognize the real
    # visible page instead of requiring an obsolete header.
    find_headers = bool(
        (("you'll earn" in body_low or "you will earn" in body_low)
         and ("deadline" in body_low or "time left" in body_low)
         and ("subject" in body_low or "type of work" in body_low))
        or "no available orders" in body_low
        or "don't have any available orders" in body_low
        or "dont have any available orders" in body_low
        or "do not have any available orders" in body_low
        or "available orders at the moment" in body_low
        or "show on-line orders" in body_low
        or "show online orders" in body_low
    )
    on_my = bool(re.search(r"/myorders(?:[/#?]|$)", url, re.I) or my_headers)
    on_find = bool(re.search(r"/findorders/", url, re.I) or (find_headers and not on_my))
    on_inbox = bool(re.search(r"/inbox(?:[/#?]|$)", url, re.I))
    on_progress = bool(re.search(r"/(?:myprogress|progress)(?:[/#?]|$)", url, re.I))
    if not url:
        if on_my: url = MY_ORDERS
        elif on_find: url = FIND_ORDERS
        elif on_inbox: url = "https://myaccount.lrwriters.com/inbox"
        elif on_progress: url = "https://myaccount.lrwriters.com/myprogress"

    # Header x-coordinates let pay parsing prefer A+ earns, then You'll earn.
    def header_x(names: tuple[str, ...]) -> float:
        for n in nodes:
            nm=_uia_norm(n.get("name")).lower()
            if nm in names:
                return float(n.get("left") or 0)+float(n.get("width") or 0)/2.0
        return 0.0
    aplus_x = header_x(("a+ earns", "a+ level earns", "a + earns"))
    you_x = header_x(("you'll earn", "you will earn"))

    order_re = re.compile(r"\b[A-Z]{1,6}\d{6,}-\d+\b", re.I)
    row_by_order = {}
    for n in nodes:
        nm=_uia_norm(n.get("name") or n.get("value"))
        m=order_re.search(nm)
        if not m:
            continue
        order=m.group(0).upper()
        try:
            cy=float(n.get("top") or 0)+float(n.get("height") or 0)/2.0
            area=float(n.get("width") or 0)*float(n.get("height") or 0)
        except Exception:
            continue
        if cy < rt + 35:
            continue
        score=(4000 if any(k in str(n.get("control") or "") for k in ("DataItem","ListItem","Hyperlink")) else 0)
        score += min(area, 50000)/50.0 + min(len(nm), 200)
        prev=row_by_order.get(order)
        if not prev or score>prev[0]:
            row_by_order[order]=(score,n)

    rows=[]
    for order, (_score, anchor) in row_by_order.items():
        ay=float(anchor.get("top") or 0); ah=float(anchor.get("height") or 0); ac=ay+ah/2.0
        band=max(28.0, min(65.0, ah*0.8+18.0))
        peers=[]
        for n in nodes:
            try:
                cy=float(n.get("top") or 0)+float(n.get("height") or 0)/2.0
                if abs(cy-ac) <= band:
                    txt=_uia_norm(n.get("name") or n.get("value"))
                    if txt: peers.append(n)
            except Exception:
                pass
        peers.sort(key=lambda n: float(n.get("left") or 0))
        texts=[]
        for n in peers:
            t=_uia_norm(n.get("name") or n.get("value"))
            if t and t not in texts: texts.append(t)
        row_text=" ".join(texts)
        if _row_is_lr_notification_noise(row_text):
            note_issue("REVISION_BANNER_IGNORED", "Ignored an LR revision notification that contained an order number", "INFO", row_text[:180], throttle=20.0)
            continue
        money=[]
        for n in peers:
            t=_uia_norm(n.get("name") or n.get("value"))
            mm=re.search(r"\$\s*([0-9]+(?:\.[0-9]{1,2})?)", t)
            if not mm: continue
            try:
                value=float(mm.group(1)); cx=float(n.get("left") or 0)+float(n.get("width") or 0)/2.0
                money.append((cx,value,n))
            except Exception: pass
        aplus=0.0; you=0.0; pay=0.0; pay_kind=""; pay_source=""
        if money and aplus_x:
            aplus=min(money, key=lambda x: abs(x[0]-aplus_x))[1]
        if money and you_x:
            you=min(money, key=lambda x: abs(x[0]-you_x))[1]
        if aplus>0:
            pay=aplus; pay_kind="A+ earns"; pay_source="Windows accessibility header position"
        elif you>0:
            pay=you; pay_kind="You'll earn"; pay_source="Windows accessibility header position"
        elif money:
            pay=money[0][1]; you=pay; pay_kind="You'll earn"; pay_source="Windows accessibility first visible amount"
        # Prefer a wide row-like element if accessibility exposes one; otherwise click the order-number element itself.
        row_node=anchor
        same_order_nodes=[n for n in peers if order.lower() in _uia_norm(n.get("name") or n.get("value")).lower()]
        wide=[n for n in same_order_nodes if float(n.get("width") or 0)>=260 and float(n.get("height") or 0)<=130]
        if wide: row_node=max(wide, key=lambda n: float(n.get("width") or 0))
        pos=_uia_screen_pos(row_node, render_rect)
        if not pos: continue
        order_anchor_pos=_uia_screen_pos(anchor, render_rect) or pos
        pos.update({
            "id":"", "orderNo":order, "text":row_text[:180], "deadlineText":row_text[:900],
            "orderScreenLeft":float(order_anchor_pos.get("screenLeft") or pos.get("screenLeft") or 0.0),
            "pay":float(pay), "paySource":pay_source, "payKind":pay_kind,
            "aPlusEarn":float(aplus), "aPlusEarnSource":("Windows accessibility" if aplus else ""),
            "youEarn":float(you), "youEarnSource":("Windows accessibility" if you else ""),
            "tutor":bool(re.search(r"\btutor(?:ing)?\b", row_text, re.I)),
        })
        rows.append(pos)

    reserve_n=_uia_best_named(nodes,"reserve",("Button","Hyperlink"))
    accept_n=_uia_best_named(nodes,"accept",("Button","Hyperlink"))
    reject_n=_uia_best_named(nodes,"reject",("Button","Hyperlink"))
    still_n=(
        _uia_best_named(nodes,"yes, i'm here",("Button","Hyperlink"))
        or _uia_best_named(nodes,"yes i'm here",("Button","Hyperlink"))
        or _uia_best_named(nodes,"yes, i am here",("Button","Hyperlink"))
        or _uia_best_named(nodes,"yes i am here",("Button","Hyperlink"))
    )
    nav_find_n=_uia_best_named(nodes,"find orders")
    nav_my_n=_uia_best_named(nodes,"my orders")
    nav_inbox_n=_uia_best_named(nodes,"inbox")
    nav_progress_n=_uia_best_named(nodes,"my progress")
    files_n=_uia_best_named(nodes,"files",("Button",)) or _uia_best_named(nodes,"order files",("Button",))

    reserve=_uia_screen_pos(reserve_n,render_rect) if reserve_n else None
    accept=_uia_screen_pos(accept_n,render_rect) if accept_n else None
    reject=_uia_screen_pos(reject_n,render_rect) if reject_n else None
    still=_uia_screen_pos(still_n,render_rect) if still_n else None
    panel_open=bool(reserve or accept or reject)

    panel_text=""
    if panel_open:
        right_nodes=[]
        for n in sorted_nodes:
            try:
                cx=float(n.get("left") or 0)+float(n.get("width") or 0)/2.0
                if cx >= rl + inner_w*0.48:
                    t=_uia_norm(n.get("name") or n.get("value"))
                    if t: right_nodes.append(t)
            except Exception: pass
        panel_text=" ".join(dict.fromkeys(right_nodes))[:30000]

    logged_out=bool(("sign in" in body_low or "log in" in body_low) and not on_find and not on_my and "lr writers" in (title+" "+body_text).lower())
    url_id=""
    m=re.search(r"/findorders/all/([^/?#]+)",url,re.I) or re.search(r"/order/([^/?#]+)",url,re.I)
    if m: url_id=m.group(1)

    snap={
        "uia":True, "uiaHwnd":int(hwnd), "uiaTs":ts,
        "url":url, "urlId":url_id, "pageTitle":title,
        "innerW":float(inner_w), "innerH":float(inner_h), "rows":rows,
        "reserve":reserve, "accept":accept, "reject":reject, "stillHere":still,
        "reserveDisabled":bool(reserve_n is not None and not bool(reserve_n.get("enabled",True))),
        "panelOpen":panel_open, "panelText":panel_text, "panelDeepText":panel_text,
        "panelScroll":None, "filesToggle":(_uia_screen_pos(files_n,render_rect) if files_n else None),
        "acceptedGone":False, "loggedOut":logged_out,
        "bodyText":body_text[:30000], "bodyTextExcerpt":body_text[:1000],
        "detailAnchorText":panel_text[:30000], "detailDeepAnchorText":panel_text[:30000],
        "onMyOrders":on_my, "labelCount":0, "labelStore":{}, "sideOrderPanelOpen":panel_open,
        "lastClick":None,
        "navFind":(_uia_screen_pos(nav_find_n,render_rect) if nav_find_n else None),
        "navMy":(_uia_screen_pos(nav_my_n,render_rect) if nav_my_n else None),
        "navInbox":(_uia_screen_pos(nav_inbox_n,render_rect) if nav_inbox_n else None),
        "navProgress":(_uia_screen_pos(nav_progress_n,render_rect) if nav_progress_n else None),
        "onFind":on_find, "onInbox":on_inbox, "onProgress":on_progress,
        # No idle points are fabricated. Without DOM hit-testing, fail closed.
        "idleMovePoints":[], "idleClickPoints":[],
    }
    return snap


def _uia_read_snapshot(hwnd: int = 0) -> dict:
    try:
        raw=_read_json(_ACCESS_SNAPSHOT_FILE)
        if not raw:
            return {}
        if time.time()-float(raw.get("ts") or 0.0)>2.5:
            return {}
        target=int(hwnd or raw.get("hwnd") or _uia_hwnd or 0)
        if target<=0:
            return {}
        return _uia_build_snapshot(raw,target)
    except Exception:
        return {}



def _vision_stop_ocr_process() -> None:
    global _vision_ocr_proc, _vision_ocr_reader_thread
    proc = _vision_ocr_proc
    _vision_ocr_proc = None
    _vision_ocr_reader_thread = None
    if proc is None:
        return
    try:
        if proc.stdin:
            proc.stdin.write("__QUIT__\n")
            proc.stdin.flush()
    except Exception:
        pass
    try:
        proc.wait(timeout=0.8)
    except Exception:
        try:
            proc.terminate()
        except Exception:
            pass


def _vision_start_ocr_process() -> bool:
    """Keep Windows OCR warm so each changed frame does not start PowerShell again."""
    global _vision_ocr_proc, _vision_ocr_reader_thread, _vision_ocr_queue
    proc = _vision_ocr_proc
    if proc is not None and proc.poll() is None:
        return True
    _vision_stop_ocr_process()
    try:
        while True:
            _vision_ocr_queue.get_nowait()
    except Exception:
        pass
    try:
        proc = subprocess.Popen(
            [
                "powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                "-File", str(_VISION_OCR_SCRIPT), "-Loop",
            ],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, encoding="utf-8", errors="replace", bufsize=1,
            creationflags=0x08000000,
        )
        _vision_ocr_proc = proc

        def reader() -> None:
            try:
                while proc.poll() is None:
                    line = proc.stdout.readline() if proc.stdout else ""
                    if not line:
                        if proc.poll() is not None:
                            break
                        time.sleep(0.01)
                        continue
                    _vision_ocr_queue.put(line.rstrip("\r\n"))
            except Exception:
                pass

        t = threading.Thread(target=reader, name="AdeonVisionOCRReader", daemon=True)
        _vision_ocr_reader_thread = t
        t.start()
        return True
    except Exception as e:
        note_issue("VISION_OCR_START_FAILED", "Persistent Windows OCR helper could not start", "WARN", str(e), throttle=30.0)
        _vision_ocr_proc = None
        return False


def _vision_ocr_image(path: Path, timeout: float = 3.2) -> dict:
    """OCR one image through the warm helper. Restart once if the helper died."""
    if not _vision_ensure_helper():
        return {}
    with _vision_ocr_lock:
        for attempt in range(2):
            if not _vision_start_ocr_process():
                return {}
            proc = _vision_ocr_proc
            try:
                while True:
                    _vision_ocr_queue.get_nowait()
            except Exception:
                pass
            try:
                if proc is None or proc.stdin is None:
                    raise RuntimeError("OCR helper stdin unavailable")
                proc.stdin.write(str(path) + "\n")
                proc.stdin.flush()
                line = _vision_ocr_queue.get(timeout=max(0.5, float(timeout)))
                raw = json.loads(line) if line else {}
                if isinstance(raw, dict) and raw.get("ok"):
                    return raw
                detail = str((raw or {}).get("error") or "Windows OCR returned no result")[:400]
                note_issue("VISION_OCR_FAILED", "Windows screen OCR could not read the existing browser", "WARN", detail, throttle=30.0)
                return {}
            except queue.Empty:
                note_issue("VISION_OCR_TIMEOUT", "Windows screen OCR timed out; browser remains untouched", "WARN", throttle=30.0)
                _vision_stop_ocr_process()
            except Exception as e:
                if attempt == 0:
                    _vision_stop_ocr_process()
                    continue
                note_issue("VISION_OCR_FAILED", "Windows screen OCR helper failed", "WARN", str(e), throttle=30.0)
        return {}


def _vision_ensure_helper() -> bool:
    """Restore the small Windows OCR helper if an update/AV removed it."""
    try:
        good = False
        if _VISION_OCR_SCRIPT.is_file():
            raw = _VISION_OCR_SCRIPT.read_bytes()
            good = hashlib.sha256(raw).hexdigest().lower() == _VISION_OCR_RECOVERY_SHA256.lower()
        if not good:
            raw = base64.b64decode(_VISION_OCR_RECOVERY_B64.encode("ascii"), validate=True)
            if hashlib.sha256(raw).hexdigest().lower() != _VISION_OCR_RECOVERY_SHA256.lower():
                return False
            tmp = _VISION_OCR_SCRIPT.with_suffix(".ps1.repair")
            tmp.write_bytes(raw)
            os.replace(tmp, _VISION_OCR_SCRIPT)
            log("SCREEN VISION SELF-REPAIR: restored Adeon Screen Vision OCR.ps1 from the built-in copy.")
        return _VISION_OCR_SCRIPT.is_file()
    except Exception as e:
        note_issue("VISION_HELPER_REPAIR_FAILED", "Screen Vision OCR helper could not be restored", "WARN", str(e), throttle=30.0)
        return False


def _vision_pos_from_bounds(bounds: dict | None, origin: tuple[int,int], text: str = "") -> dict | None:
    if not isinstance(bounds, dict):
        return None
    try:
        x=float(bounds.get("x") or 0); y=float(bounds.get("y") or 0)
        w=float(bounds.get("w") or bounds.get("width") or 0); h=float(bounds.get("h") or bounds.get("height") or 0)
        if w < 2 or h < 2:
            return None
        sl=float(origin[0])+x; st=float(origin[1])+y
        return {
            "sx": sl+w/2.0, "sy": st+h/2.0,
            "screenLeft": sl, "screenTop": st, "screenW": w, "screenH": h,
            "uia": True, "vision": True, "uiaName": str(text or ""), "uiaControl": "OCR",
        }
    except Exception:
        return None


def _vision_find_line(lines: list[dict], phrases: tuple[str,...]) -> dict | None:
    best=None; best_score=-1
    for line in lines:
        txt=re.sub(r"\s+"," ",str(line.get("text") or "")).strip()
        low=txt.lower()
        if not low:
            continue
        for phrase in phrases:
            p=phrase.lower()
            if p in low:
                score=1000-len(low)+len(p)*4
                if low==p: score+=500
                if score>best_score:
                    best=line; best_score=score
    return best


def _vision_find_exact_action_line(lines: list[dict], labels: tuple[str,...], *, inner_w: float = 0.0) -> dict | None:
    """Find an action button by its own OCR text, never by substring.

    This intentionally rejects text such as ``Show reserved`` which previously
    matched ``reserve`` and created a false Reserve button on Find Orders.
    Action buttons are also expected in the page body/right-side order panel,
    not in browser chrome or left navigation.
    """
    wanted={re.sub(r"[^a-z0-9]+"," ",str(x).lower()).strip() for x in labels}
    best=None; best_score=-1.0
    for line in lines:
        txt=re.sub(r"\s+"," ",str(line.get("text") or "")).strip()
        norm=re.sub(r"[^a-z0-9]+"," ",txt.lower()).strip()
        if norm not in wanted:
            continue
        bd=line.get("bounds") or {}
        try:
            x=float(bd.get("x") or 0); y=float(bd.get("y") or 0)
            w=float(bd.get("w") or bd.get("width") or 0); h=float(bd.get("h") or bd.get("height") or 0)
            cx=x+w/2.0; cy=y+h/2.0
        except Exception:
            continue
        if w < 8 or h < 8 or cy < 95:
            continue
        if inner_w and cx < inner_w*0.30:
            continue
        score=1000.0 - abs(len(norm)-7)*2.0 + cx/max(1.0,inner_w or 1.0)*20.0
        if score>best_score:
            best=line; best_score=score
    return best


def _vision_build_snapshot(raw: dict, hwnd: int, rect: tuple[int,int,int,int]) -> dict:
    global _vision_last_seen, _vision_pay_header_hwnd, _vision_pay_header_seen_at, _vision_aplus_x, _vision_you_x
    ts=time.time(); _vision_last_seen=ts
    l,t,r,b=rect; inner_w=max(1,r-l); inner_h=max(1,b-t)
    title=_title(hwnd)
    lines=[x for x in (raw.get("lines") or []) if isinstance(x,dict)]
    lines.sort(key=lambda q: (float((q.get("bounds") or {}).get("y") or 0), float((q.get("bounds") or {}).get("x") or 0)))
    body_text=re.sub(r"\s+"," ",str(raw.get("text") or "")).strip()
    body_low=body_text.lower()
    # Windows OCR normally sees Thorium/Chrome's visible address bar. Use that
    # exact LR URL whenever available; it is much stronger page-state evidence
    # than guessing from navigation labels that appear on every LR page.
    observed_url=""
    um=re.search(r"https?://myaccount\.lrwriters\.com/[A-Za-z0-9_./?#=&%+:-]*",body_text,re.I)
    if um:
        observed_url=str(um.group(0)).rstrip(".,);]}")

    find_headers=bool(
        (("you'll earn" in body_low or "you will earn" in body_low)
         and ("deadline" in body_low or "time left" in body_low)
         and ("subject" in body_low or "type of work" in body_low))
        or "no available orders" in body_low
        or "don't have any available orders" in body_low
        or "dont have any available orders" in body_low
        or "do not have any available orders" in body_low
        or "available orders at the moment" in body_low
        or "show on-line orders" in body_low
        or "show online orders" in body_low
    )
    my_headers=(
        ("your price" in body_low and "payout date" in body_low)
        or ("my orders" in body_low and "in progress" in body_low)
        or ("my orders" in body_low and "final paper" in body_low)
    )
    url_low=observed_url.lower()
    on_my=bool(re.search(r"/myorders(?:[/#?]|$)",url_low,re.I) or (my_headers and not find_headers))
    on_find=bool(re.search(r"/findorders/",url_low,re.I) or (find_headers and not on_my))
    on_inbox=bool(re.search(r"/inbox(?:[/#?]|$)",url_low,re.I))
    on_progress=bool(re.search(r"/(?:myprogress|progress)(?:[/#?]|$)",url_low,re.I))
    url = observed_url or (MY_ORDERS if on_my else FIND_ORDERS if on_find else "")

    nav_find_line=_vision_find_line(lines,("find orders",))
    nav_my_line=_vision_find_line(lines,("my orders",))
    nav_inbox_line=_vision_find_line(lines,("inbox",))
    nav_progress_line=_vision_find_line(lines,("my progress",))

    # Action buttons must be exact OCR labels inside a real LR order-detail
    # context.  Build that context ONLY from the right-side drawer area so an
    # order number in the underlying Find Orders table can never impersonate
    # the currently open panel.
    panel_markers=(
        "order info", "operator messages", "order files", "final ddl",
        "formatting style", "country of origin", "complexity", "file format",
        "additional materials", "grading rubric", "sources",
    )
    order_re=re.compile(r"\b[A-Z]{1,6}\d{6,}-\d+\b",re.I)
    right_panel_lines=[]
    for ln in lines:
        bd=(ln or {}).get("bounds") or {}
        try:
            cx=float(bd.get("x") or 0)+float(bd.get("w") or 0)/2.0
            if cx >= inner_w*0.47:
                tx=re.sub(r"\s+"," ",str((ln or {}).get("text") or "")).strip()
                if tx: right_panel_lines.append(tx)
        except Exception:
            pass
    panel_candidate_text=" ".join(right_panel_lines)
    panel_candidate_low=panel_candidate_text.lower()
    panel_marker_hits=sum(1 for marker in panel_markers if marker in panel_candidate_low)
    panel_identity_match=order_re.search(panel_candidate_text)
    panel_identity_visible=bool(panel_identity_match)
    action_context=bool(panel_identity_visible and panel_marker_hits>=1)

    reserve_line=_vision_find_exact_action_line(lines,("reserve","reserve order"),inner_w=inner_w) if action_context else None
    accept_line=_vision_find_exact_action_line(lines,("accept","accept order"),inner_w=inner_w) if action_context else None
    reject_line=_vision_find_exact_action_line(lines,("reject","reject order"),inner_w=inner_w) if action_context else None
    still_line=_vision_find_exact_action_line(lines,("yes i'm here","yes i am here"),inner_w=inner_w)
    files_line=_vision_find_line(lines,("order files",)) if action_context else None

    def pos(line):
        return _vision_pos_from_bounds((line or {}).get("bounds"),(l,t),str((line or {}).get("text") or "")) if line else None

    # Locate the earnings columns from OCR WORD geometry.  Never take the
    # first dollar amount on a row: the v1.0.55/56 screen reader could join
    # unrelated text and turn a small amount into a false high value.  v36's
    # policy is preserved: prefer A+ earns when that column exists, otherwise
    # use You'll earn.
    def phrase_x(phrases: tuple[str, ...]) -> float:
        wanted=[tuple(re.sub(r"[^a-z0-9+']+"," ",p.lower()).split()) for p in phrases]
        for line in lines:
            words=line.get("words") if isinstance(line.get("words"),list) else []
            norm=[]
            for w0 in words:
                wt=re.sub(r"[^a-z0-9+']+","",str((w0 or {}).get("text") or "").lower())
                norm.append(wt)
            for parts in wanted:
                if not parts: continue
                n=len(parts)
                for j in range(0,max(0,len(norm)-n+1)):
                    if tuple(norm[j:j+n])==parts:
                        try:
                            first=words[j]; last=words[j+n-1]
                            x1=float(first.get("x") or 0); x2=float(last.get("x") or 0)+float(last.get("w") or 0)
                            return (x1+x2)/2.0
                        except Exception:
                            pass
        # Last fallback only if OCR emitted the header as one compact line.
        for phrase in phrases:
            ln=_vision_find_line(lines,(phrase,))
            bd=(ln or {}).get("bounds") or {}
            try:
                w=float(bd.get("w") or 0)
                if 8 <= w <= inner_w*0.22:
                    return float(bd.get("x") or 0)+w/2.0
            except Exception:
                pass
        return 0.0

    aplus_x=phrase_x(("a+ earns","a + earns","a+ level earns"))
    you_x=phrase_x(("you'll earn","you will earn"))
    if aplus_x or you_x:
        _vision_pay_header_hwnd=int(hwnd)
        _vision_pay_header_seen_at=ts
        if aplus_x: _vision_aplus_x=float(aplus_x)
        if you_x: _vision_you_x=float(you_x)
    elif int(_vision_pay_header_hwnd or 0)==int(hwnd) and ts-float(_vision_pay_header_seen_at or 0.0) <= 180.0:
        # Reuse only geometry that was positively read in this same browser window.
        # It expires quickly and every candidate amount is still independently
        # checked against the exact row/order before a Reserve click.
        aplus_x=float(_vision_aplus_x or 0.0)
        you_x=float(_vision_you_x or 0.0)

    def money_words() -> list[dict]:
        out=[]
        for line0 in lines:
            words=line0.get("words") if isinstance(line0.get("words"),list) else []
            for j,w0 in enumerate(words):
                txt0=str((w0 or {}).get("text") or "").strip()
                candidates=[]
                if txt0.startswith("$"):
                    candidates.append(txt0)
                elif txt0 == "$" and j+1 < len(words):
                    candidates.append("$"+str((words[j+1] or {}).get("text") or "").strip())
                elif j>0 and str((words[j-1] or {}).get("text") or "").strip()=="$":
                    candidates.append("$"+txt0)
                value=None; token=""
                for cand in candidates:
                    mm=re.fullmatch(r"\$\s*([0-9]{1,4}(?:,[0-9]{3})*(?:\.[0-9]{2})?)",cand)
                    if mm:
                        try:
                            value=float(mm.group(1).replace(",","")); token=cand
                        except Exception:
                            value=None
                        break
                if value is None:
                    continue
                try:
                    x=float((w0 or {}).get("x") or 0); y=float((w0 or {}).get("y") or 0)
                    ww=float((w0 or {}).get("w") or 0); hh=float((w0 or {}).get("h") or 0)
                    if txt0=="$" and j+1<len(words):
                        w1=words[j+1] or {}
                        x2=float(w1.get("x") or 0)+float(w1.get("w") or 0)
                        ww=max(ww,x2-x)
                        hh=max(hh,float(w1.get("h") or 0))
                    out.append({"value":value,"token":token,"x":x,"y":y,"w":ww,"h":hh,"cx":x+ww/2.0,"cy":y+hh/2.0})
                except Exception:
                    pass
        return out

    money_nodes=money_words()
    header_noise=("order number","subject","type of work","you'll earn","you will earn","deadline","time left","additional info")
    # Order-number vertical centers define non-overlapping row bands. This is more
    # reliable than demanding the earnings number sit within a fixed 34 px of the
    # Order Number when a row wraps onto multiple text lines.
    order_centers=[]
    for line0 in lines:
        tx0=re.sub(r"\s+"," ",str((line0 or {}).get("text") or "")).strip()
        mm0=order_re.search(tx0)
        if not mm0: continue
        bd0=(line0 or {}).get("bounds") or {}
        try:
            cy0=float(bd0.get("y") or 0)+float(bd0.get("h") or 0)/2.0
        except Exception:
            continue
        order_centers.append((cy0,str(mm0.group(0)).upper()))
    order_centers.sort(key=lambda q:q[0])

    rows=[]; seen=set()
    for i,line in enumerate(lines):
        txt=re.sub(r"\s+"," ",str(line.get("text") or "")).strip()
        m=order_re.search(txt)
        if not m: continue
        order=m.group(0).upper()
        if order in seen: continue
        seen.add(order)
        bd=line.get("bounds") or {}
        try:
            cy=float(bd.get("y") or 0)+float(bd.get("h") or 0)/2.0
        except Exception:
            cy=0.0
        nearby=[]
        for other in lines:
            ob=other.get("bounds") or {}
            try:
                ocy=float(ob.get("y") or 0)+float(ob.get("h") or 0)/2.0
                if abs(ocy-cy)<=30:
                    ot=re.sub(r"\s+"," ",str(other.get("text") or "")).strip()
                    if ot and not any(h in ot.lower() for h in header_noise) and ot not in nearby:
                        nearby.append(ot)
            except Exception: pass
        row_text=" ".join(nearby) or txt
        if _row_is_lr_notification_noise(row_text):
            note_issue("REVISION_BANNER_IGNORED", "Ignored an LR revision notification that contained an order number", "INFO", row_text[:180], throttle=20.0)
            continue
        # Use the vertical territory bounded by adjacent order numbers. Fall back
        # to a moderate local band if OCR produced only one order number.
        center_index=None
        for oi,(ocy,oid) in enumerate(order_centers):
            if oid==order and abs(ocy-cy)<=6:
                center_index=oi; break
        if center_index is not None:
            prev_y=order_centers[center_index-1][0] if center_index>0 else cy-70.0
            next_y=order_centers[center_index+1][0] if center_index+1<len(order_centers) else cy+70.0
            band_top=(prev_y+cy)/2.0
            band_bottom=(cy+next_y)/2.0
            row_money=[q for q in money_nodes if band_top <= float(q.get("cy") or 0) < band_bottom]
        else:
            row_money=[q for q in money_nodes if abs(float(q.get("cy") or 0)-cy)<=55]
        pay=0.0; aplus=0.0; you=0.0; pay_kind=""; pay_source=""; pay_node=None
        # Require a known earnings-column x. If the header cannot be located,
        # Screen Vision fails closed instead of guessing from another dollar amount.
        if aplus_x and row_money:
            cand=min(row_money,key=lambda q:abs(float(q.get("cx") or 0)-aplus_x))
            if abs(float(cand.get("cx") or 0)-aplus_x)<=max(65.0,inner_w*0.075):
                aplus=float(cand.get("value") or 0); pay=aplus; pay_node=cand
                pay_kind="A+ earns"; pay_source="Windows OCR verified A+ column"
        if pay<=0 and you_x and row_money:
            cand=min(row_money,key=lambda q:abs(float(q.get("cx") or 0)-you_x))
            if abs(float(cand.get("cx") or 0)-you_x)<=max(65.0,inner_w*0.075):
                you=float(cand.get("value") or 0); pay=you; pay_node=cand
                pay_kind="You'll earn"; pay_source="Windows OCR verified You'll earn column"
        rp=pos(line)
        if not rp: continue
        rp.update({
            "id":"", "orderNo":order, "text":row_text[:220], "deadlineText":row_text[:1200],
            "orderScreenLeft":float(rp.get("screenLeft") or 0.0),
            "pay":float(pay), "paySource":pay_source, "payKind":pay_kind,
            "aPlusEarn":float(aplus), "aPlusEarnSource":("Windows OCR column" if aplus else ""),
            "youEarn":float(you), "youEarnSource":("Windows OCR column" if you else ""),
            "visionPayToken":str((pay_node or {}).get("token") or ""),
            "visionPayScreenX":(float(l)+float((pay_node or {}).get("cx") or 0) if pay_node else 0.0),
            "visionPayScreenY":(float(t)+float((pay_node or {}).get("cy") or 0) if pay_node else 0.0),
            "visionPayColumnScreenX":(float(l)+(aplus_x if pay_kind=="A+ earns" else you_x) if pay_kind else 0.0),
            "visionPayGeometryVerified":bool(pay_node and pay_kind),
            "visionRowScreenY":float(t)+cy,
            "tutor":bool(re.search(r"\btutor(?:ing)?\b",row_text,re.I)),
        })
        rows.append(rp)

    reserve=pos(reserve_line); accept=pos(accept_line); reject=pos(reject_line); still=pos(still_line)
    panel_open=bool(reserve or accept or reject)
    panel_text=panel_candidate_text[:12000] if panel_open else ""
    panel_id=(str(panel_identity_match.group(0)).upper() if (panel_open and panel_identity_match) else "")
    # When the detail drawer is open Screen Vision cannot read the browser URL,
    # so expose the independently OCR-verified right-panel order number as the
    # same identity field the v36 safety gates already understand.
    url_id=panel_id
    if not url_id and observed_url:
        mu=re.search(r"/(?:findorders/(?:all/)?|order/)([A-Z]{1,6}\d{6,}-\d+)(?:[/?#]|$)",observed_url,re.I)
        if mu: url_id=str(mu.group(1)).upper()
    logged_out=bool(("sign in" in body_low or "log in" in body_low) and "lr" in (title+" "+body_text).lower())

    # Optional second pay gate from the opened order drawer. Only accept an
    # amount explicitly adjacent to an earnings label; unrelated prices are ignored.
    panel_pay=0.0
    if panel_open:
        pm=re.search(r"(?:a\s*\+\s*earns|you(?:'|’)ll\s+earn|you\s+will\s+earn)[^$]{0,80}\$\s*([0-9]{1,4}(?:,[0-9]{3})*(?:\.[0-9]{2})?)",panel_text,re.I)
        if pm:
            try: panel_pay=float(pm.group(1).replace(",",""))
            except Exception: panel_pay=0.0

    return {
        "uia":True, "vision":True, "uiaHwnd":int(hwnd), "uiaTs":ts,
        "url":url, "urlId":url_id, "pageTitle":title,
        "innerW":float(inner_w), "innerH":float(inner_h), "rows":rows,
        "reserve":reserve, "accept":accept, "reject":reject, "stillHere":still,
        "reserveDisabled":False,
        "panelOpen":panel_open, "panelText":panel_text, "panelDeepText":panel_text,
        "visionPanelContext":action_context, "visionPanelMarkers":int(panel_marker_hits),
        "visionPanelOrder":panel_id, "visionPanelPay":float(panel_pay),
        "panelScroll":None, "filesToggle":pos(files_line),
        "acceptedGone":False, "loggedOut":logged_out,
        "bodyText":body_text[:30000], "bodyTextExcerpt":body_text[:1200],
        "detailAnchorText":panel_text[:30000], "detailDeepAnchorText":panel_text[:30000],
        "onMyOrders":on_my, "labelCount":0, "labelStore":{}, "sideOrderPanelOpen":panel_open,
        "lastClick":None,
        "navFind":pos(nav_find_line), "navMy":pos(nav_my_line), "navInbox":pos(nav_inbox_line), "navProgress":pos(nav_progress_line),
        "onFind":on_find, "onInbox":on_inbox, "onProgress":on_progress,
        "idleMovePoints":[], "idleClickPoints":[],
    }


def _same_browser_process_foreground(hwnd: int) -> bool:
    """True when the foreground HWND is the browser main window or a same-process child/popup."""
    try:
        hwnd=int(hwnd or 0)
        if hwnd<=0:return False
        fg=int(user32.GetForegroundWindow() or 0)
        if not fg:return True
        if fg==hwnd:return True
        p1=ctypes.c_ulong(0); p2=ctypes.c_ulong(0)
        user32.GetWindowThreadProcessId(fg,ctypes.byref(p1))
        user32.GetWindowThreadProcessId(hwnd,ctypes.byref(p2))
        return bool(p1.value and p2.value and p1.value==p2.value)
    except Exception:
        return False


def _vision_read_snapshot(hwnd: int, force: bool=False) -> dict:
    """Read the visible existing browser with a screenshot + Windows built-in OCR.

    The browser must be visible (not minimized). No extension, DOM injection or DevTools is used.
    Repeated reads are cached; OCR is rerun when the pixels change or the cache ages out.
    """
    global _vision_last_seen, _vision_last_snapshot, _vision_last_hash, _vision_last_capture_at, _vision_last_ocr_at, _vision_hwnd
    try:
        if hwnd<=0 or bool(user32.IsIconic(hwnd)):
            return {}
        # Screen Vision reads visible pixels.  If another application/window is
        # in front of the LR browser, those foreign pixels would contaminate OCR.
        # Fail closed until the exact LR browser is foreground again.
        try:
            fg=int(user32.GetForegroundWindow() or 0)
        except Exception:
            fg=0
        if fg and not _same_browser_process_foreground(hwnd):
            note_issue(
                "VISION_BROWSER_NOT_FOREGROUND",
                "Screen Vision paused because the LR browser is not the foreground window",
                "INFO",
                "Bring the existing LR Thorium/Chrome window to the front; no clicks or F5 will run while it is covered.",
                throttle=20.0,
            )
            return {}
        if not _vision_ensure_helper():
            return {}
        rect=_screen_rect(hwnd)
        if not rect:
            return {}
        l,t,r,b=rect; w=max(1,r-l); h=max(1,b-t)
        if w<600 or h<350:
            return {}
        now=time.time()
        if not force and _vision_last_snapshot and _vision_hwnd==hwnd and now-_vision_last_capture_at<0.10:
            _vision_last_seen=now
            snap=dict(_vision_last_snapshot); snap["uiaTs"]=now
            return snap
        _vision_last_capture_at=now
        image=pyautogui.screenshot(region=(int(l),int(t),int(w),int(h)))
        # Tiny grayscale fingerprint lets the 100 ms loop notice changes without OCRing every pass.
        small=image.convert("L").resize((48,27))
        digest=hashlib.blake2s(small.tobytes(),digest_size=12).hexdigest()
        if (not force and _vision_last_snapshot and _vision_hwnd==hwnd and digest==_vision_last_hash
                and now-_vision_last_ocr_at<1.5):
            _vision_last_seen=now
            snap=dict(_vision_last_snapshot); snap["uiaTs"]=now
            return snap
        # Never reuse one PNG path. Windows.Media.Ocr can still have the previous
        # StorageFile/stream open when the next 100 ms capture arrives; overwriting
        # that same file caused intermittent WinError/Errno 22 failures. Give every
        # OCR read its own short-lived file under persistent Adeon Data instead.
        capture_path = _VISION_CAPTURE_DIR / (
            f"capture-{os.getpid()}-{threading.get_ident()}-{uuid.uuid4().hex[:12]}.png"
        )
        raw = {}
        try:
            _VISION_CAPTURE_DIR.mkdir(parents=True, exist_ok=True)
            image.save(str(capture_path), format="PNG")
            raw = _vision_ocr_image(capture_path, timeout=3.2)
        finally:
            try:
                capture_path.unlink(missing_ok=True)
            except Exception:
                pass
        if not raw:
            return {}
        snap=_vision_build_snapshot(raw,hwnd,rect)
        _vision_last_hash=digest; _vision_last_ocr_at=now; _vision_hwnd=int(hwnd)
        _vision_last_snapshot=dict(snap); _vision_last_seen=now
        return snap
    except Exception as e:
        note_issue("VISION_READ_FAILED","Screen Vision could not read the visible browser","WARN",str(e),throttle=30.0)
        return {}


def _vision_live(max_age: float=2.5) -> bool:
    return bool(_vision_last_snapshot) and (time.time()-float(_vision_last_seen or 0.0)<=max_age)

def _picker_worker_is_alive() -> bool:
    """Best-effort check so labels never navigate away from the live picker tab."""
    try:
        pid = int(_read_text_file(_PICKER_PID_FILE) or "0")
        if pid <= 0:
            return False
        PROCESS_SYNCHRONIZE = 0x00100000
        WAIT_TIMEOUT = 0x00000102
        k32 = ctypes.windll.kernel32
        h = k32.OpenProcess(PROCESS_SYNCHRONIZE, False, pid)
        if not h:
            return False
        try:
            return int(k32.WaitForSingleObject(h, 0)) == WAIT_TIMEOUT
        finally:
            k32.CloseHandle(h)
    except Exception:
        return False


def _write_json_atomic(path: Path, data: dict) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        raw=json.dumps(data, ensure_ascii=False, indent=2)
        with tmp.open("w",encoding="utf-8") as fh:
            fh.write(raw)
            fh.flush()
            try: os.fsync(fh.fileno())
            except Exception: pass
        tmp.replace(path)
    except Exception:
        pass


def _read_json(path: Path) -> dict:
    try:
        obj = json.loads(path.read_text(encoding="utf-8"))
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def _read_text_file(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8-sig").strip()
    except Exception:
        return ""


def _append_jsonl(path: Path, obj: dict) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":")) + "\n")
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except Exception:
                pass
    except Exception:
        pass


def _label_device_id() -> str:
    value = _read_text_file(_LABEL_DEVICE_FILE)
    if value:
        return value
    value = (os.environ.get("COMPUTERNAME") or "PC").strip() + "-" + uuid.uuid4().hex[:10]
    try:
        _LABEL_DEVICE_FILE.write_text(value, encoding="utf-8")
    except Exception:
        pass
    return value


def _clean_label_state(obj: dict | None) -> dict:
    obj = obj or {}
    labels0 = obj.get("labels") if isinstance(obj.get("labels"), dict) else {}
    times0 = obj.get("times") if isinstance(obj.get("times"), dict) else {}
    revs0 = obj.get("revisions") if isinstance(obj.get("revisions"), dict) else {}
    labels: dict[str, str] = {}
    times: dict[str, float] = {}
    revisions: dict[str, int] = {}
    keys = set(labels0) | set(times0) | set(revs0)
    for raw_key in keys:
        key = str(raw_key or "").strip().upper()[:80]
        if not key:
            continue
        raw_value = labels0.get(raw_key, labels0.get(key, ""))
        value = str(raw_value or "").strip().upper()
        try:
            ts = max(0.0, float(times0.get(raw_key, times0.get(key, 0.0)) or 0.0))
        except Exception:
            ts = 0.0
        try:
            rev = max(0, int(revs0.get(raw_key, revs0.get(key, 0)) or 0))
        except Exception:
            rev = 0
        if value:
            labels[key] = value
        times[key] = ts
        revisions[key] = rev
    try:
        server_rev = max(0, int(obj.get("server_rev", 0) or 0))
    except Exception:
        server_rev = 0
    return {"labels": labels, "times": times, "revisions": revisions, "server_rev": server_rev}


def _merge_label_states(a: dict | None, b: dict | None) -> dict:
    """Compatibility merge for local/page or legacy-server snapshots.

    Protocol-2 remote snapshots use server revisions in LabelSyncManager.merge_remote().
    This helper keeps the old timestamp merge for legacy data while carrying revisions.
    """
    aa = _clean_label_state(a)
    bb = _clean_label_state(b)
    out_labels: dict[str, str] = {}
    out_times: dict[str, float] = {}
    out_revs: dict[str, int] = {}
    keys = set(aa["times"]) | set(bb["times"]) | set(aa["labels"]) | set(bb["labels"])
    for key in keys:
        ta = float(aa["times"].get(key, 0.0) or 0.0)
        tb = float(bb["times"].get(key, 0.0) or 0.0)
        if tb > ta:
            chosen = bb["labels"].get(key, "")
            ts = tb
            rev = max(int(aa["revisions"].get(key, 0) or 0), int(bb["revisions"].get(key, 0) or 0))
        else:
            chosen = aa["labels"].get(key, "")
            ts = ta
            rev = max(int(aa["revisions"].get(key, 0) or 0), int(bb["revisions"].get(key, 0) or 0))
        out_times[key] = ts
        out_revs[key] = rev
        if chosen:
            out_labels[key] = chosen
    return {
        "labels": out_labels,
        "times": out_times,
        "revisions": out_revs,
        "server_rev": max(int(aa.get("server_rev", 0) or 0), int(bb.get("server_rev", 0) or 0)),
    }


def _discover_label_sync_url_from_manifest() -> str:
    """Discover the shared label endpoint without any per-computer setup."""
    feeds = []
    configured = _read_text_file(_LABEL_UPDATE_FEED_FILE)
    if configured:
        feeds.append(configured)
    if _LABEL_OFFICIAL_UPDATE_FEED not in feeds:
        feeds.append(_LABEL_OFFICIAL_UPDATE_FEED)
    for feed in feeds:
        if not str(feed).lower().startswith(("https://", "http://")):
            continue
        try:
            r = requests.get(str(feed), timeout=2.5, headers={"Accept": "application/json"})
            if not (200 <= r.status_code < 300):
                continue
            data = r.json() if r.content else {}
            if not isinstance(data, dict):
                continue
            candidates = [
                data.get("label_sync_url"),
                (data.get("labels") or {}).get("sync_url") if isinstance(data.get("labels"), dict) else None,
                (data.get("label_sync") or {}).get("url") if isinstance(data.get("label_sync"), dict) else None,
            ]
            for value in candidates:
                value = str(value or "").strip()
                if value.lower().startswith("https://"):
                    try:
                        _LABEL_SYNC_URL_FILE.write_text(value, encoding="utf-8")
                    except Exception:
                        pass
                    return value
        except Exception:
            continue
    return ""


class LabelSyncManager:
    """No-loss local label journal plus independent cross-device synchronization.

    Every local edit is first persisted outside the Adeon program folder, then queued
    for the remote label service. The queue survives reboots and updates. Protocol-2
    servers assign per-order revisions, preserve an append-only server history, and
    reject stale offline overwrites instead of silently destroying a newer label.
    A private ntfy topic carries only a generic "changed" ping so other laptops can
    pull the persistent label server immediately without constant 200 ms web polling.
    """
    def __init__(self) -> None:
        self.device = _label_device_id()
        self.lock = threading.RLock()
        self.state = self._load_state_with_recovery()
        self.outbox = self._load_outbox()
        self.url = (
            _read_text_file(_LABEL_SYNC_URL_FILE)
            or _read_text_file(_BUILTIN_LABEL_SYNC_URL_FILE)
            or _discover_label_sync_url_from_manifest()
        )
        self.secret = _read_text_file(_LABEL_SYNC_SECRET_FILE)
        self.last_remote_poll = 0.0
        self.last_remote_push = 0.0
        self.last_remote_error = 0.0
        self.last_backup_at = 0.0
        self.remote_hint = threading.Event()
        self._notify_stop = threading.Event()
        self._notify_thread = None
        if self.configured():
            log("LABEL SYNC READY: shared endpoint configured; persistent cross-device sync is active.")
            self._start_notify_listener()
        else:
            log("LABEL SYNC LOCAL ONLY: a valid HTTPS endpoint and local shared secret are both required; labels remain safe on this laptop until sync is fully configured.")

    def configured(self) -> bool:
        return bool(self.url.lower().startswith("https://") and self.secret)

    def snapshot(self) -> dict:
        with self.lock:
            return {
                "labels": dict(self.state.get("labels") or {}),
                "times": dict(self.state.get("times") or {}),
                "revisions": dict(self.state.get("revisions") or {}),
                "server_rev": int(self.state.get("server_rev", 0) or 0),
            }

    def _load_state_with_recovery(self) -> dict:
        direct = _read_json(_LABEL_LOCAL_FILE)
        if direct:
            return _clean_label_state(direct)
        # If the main snapshot was damaged or missing, recover the newest valid backup.
        try:
            _LABEL_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
            backups = sorted(_LABEL_BACKUP_DIR.glob("Labels *.json"), key=lambda p: p.stat().st_mtime, reverse=True)
            for backup in backups:
                obj = _read_json(backup)
                if obj:
                    recovered = _clean_label_state(obj)
                    _write_json_atomic(_LABEL_LOCAL_FILE, recovered)
                    log(f"LABEL RECOVERY: restored local snapshot from {backup.name}.")
                    return recovered
        except Exception:
            pass
        # Last resort: replay the local append-only journal. This preserves edits even
        # when both the active snapshot and a backup were interrupted during a crash.
        rebuilt = {"labels": {}, "times": {}, "revisions": {}, "server_rev": 0}
        try:
            if _LABEL_HISTORY_FILE.exists():
                for line in _LABEL_HISTORY_FILE.read_text(encoding="utf-8", errors="ignore").splitlines():
                    try:
                        ev = json.loads(line)
                    except Exception:
                        continue
                    if not isinstance(ev, dict):
                        continue
                    key = str(ev.get("order") or "").strip().upper()[:80]
                    if not key:
                        continue
                    value = str(ev.get("value") or "").strip().upper()
                    try:
                        ts = float(ev.get("client_time") or ev.get("time") or 0.0)
                    except Exception:
                        ts = 0.0
                    # Replay in durable journal order, not wall-clock order. Device
                    # clocks can differ, while append order reflects what Adeon actually
                    # accepted/applied. Thus a later remote conflict resolution correctly
                    # supersedes an older offline local proposal during disaster recovery.
                    rebuilt["times"][key] = ts
                    try:
                        rebuilt["revisions"][key] = max(int(rebuilt["revisions"].get(key, 0) or 0), int(ev.get("revision", 0) or 0))
                    except Exception:
                        pass
                    if value:
                        rebuilt["labels"][key] = value
                    else:
                        rebuilt["labels"].pop(key, None)
                if rebuilt["times"]:
                    _write_json_atomic(_LABEL_LOCAL_FILE, rebuilt)
                    log("LABEL RECOVERY: rebuilt local labels from append-only history.")
        except Exception:
            pass
        return _clean_label_state(rebuilt)

    def _load_outbox(self) -> list[dict]:
        obj = _read_json(_LABEL_OUTBOX_FILE)
        rows = obj.get("events") if isinstance(obj.get("events"), list) else []
        out = []
        for ev in rows:
            if not isinstance(ev, dict):
                continue
            key = str(ev.get("order") or "").strip().upper()[:80]
            if key:
                ev = dict(ev)
                ev["order"] = key
                out.append(ev)
        return out

    def _save_outbox(self) -> None:
        with self.lock:
            payload = {"events": list(self.outbox), "saved_at": time.time(), "device": self.device}
        _write_json_atomic(_LABEL_OUTBOX_FILE, payload)

    def _backup_if_due(self, force: bool = False) -> None:
        now = time.time()
        if not force and now - self.last_backup_at < _LABEL_BACKUP_MIN_INTERVAL:
            return
        self.last_backup_at = now
        try:
            _LABEL_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now().strftime("%Y%m%d %H%M%S")
            dest = _LABEL_BACKUP_DIR / f"Labels {stamp}.json"
            _write_json_atomic(dest, self.snapshot())
            backups = sorted(_LABEL_BACKUP_DIR.glob("Labels *.json"), key=lambda p: p.stat().st_mtime, reverse=True)
            for old in backups[_LABEL_BACKUP_KEEP:]:
                try:
                    old.unlink()
                except Exception:
                    pass
        except Exception:
            pass

    def _save(self) -> None:
        payload = self.snapshot()
        payload.update({"saved_at": time.time(), "device": self.device})
        _write_json_atomic(_LABEL_LOCAL_FILE, payload)
        self._backup_if_due(False)

    def _queue_local_event(self, key: str, value: str, client_time: float, base_rev: int) -> None:
        event = {
            "event_id": f"{self.device}-{uuid.uuid4().hex}",
            "device": self.device,
            "order": key,
            "value": value,
            "client_time": float(client_time or time.time()),
            "base_rev": int(base_rev or 0),
            "queued_at": time.time(),
        }
        with self.lock:
            # Coalesce rapid keystrokes for one order. The append-only local history
            # still records each observed value, while the network queue carries only
            # the newest unsent value for that order.
            self.outbox = [e for e in self.outbox if str(e.get("order") or "") != key]
            self.outbox.append(event)
        _append_jsonl(_LABEL_HISTORY_FILE, {**event, "kind": "local_edit"})
        self._save_outbox()

    def merge_page(self, page_state: dict | None) -> bool:
        page = _clean_label_state(page_state)
        changed = False
        queued = []
        with self.lock:
            keys = set(page["times"]) | set(page["labels"]) | set(self.state.get("times") or {}) | set(self.state.get("labels") or {})
            for key in keys:
                old_ts = float((self.state.get("times") or {}).get(key, 0.0) or 0.0)
                new_ts = float(page["times"].get(key, 0.0) or 0.0)
                if new_ts <= old_ts + 1e-7:
                    continue
                old_value = str((self.state.get("labels") or {}).get(key, "") or "")
                new_value = str(page["labels"].get(key, "") or "")
                self.state.setdefault("times", {})[key] = new_ts
                if new_value:
                    self.state.setdefault("labels", {})[key] = new_value
                else:
                    self.state.setdefault("labels", {}).pop(key, None)
                base_rev = int(self.state.setdefault("revisions", {}).get(key, 0) or 0)
                if new_value != old_value:
                    changed = True
                    queued.append((key, new_value, new_ts, base_rev))
        if changed:
            # Journal/outbox first, then replace the current snapshot. A crash at
            # either point still leaves at least one durable recovery source.
            for key, value, ts, base_rev in queued:
                self._queue_local_event(key, value, ts, base_rev)
            self._save()
        return changed

    def merge_remote(self, remote_state: dict | None) -> bool:
        remote = _clean_label_state(remote_state)
        changed = False
        with self.lock:
            local_revs = self.state.setdefault("revisions", {})
            local_times = self.state.setdefault("times", {})
            local_labels = self.state.setdefault("labels", {})
            protocol2 = bool(remote.get("revisions")) or int(remote.get("server_rev", 0) or 0) > 0
            keys = set(remote["times"]) | set(remote["labels"]) | set(remote["revisions"])
            for key in keys:
                rr = int(remote["revisions"].get(key, 0) or 0)
                lr = int(local_revs.get(key, 0) or 0)
                rt = float(remote["times"].get(key, 0.0) or 0.0)
                lt = float(local_times.get(key, 0.0) or 0.0)
                should_take = (rr > lr) if protocol2 else (rt > lt)
                if not should_take:
                    continue
                value = str(remote["labels"].get(key, "") or "")
                before = str(local_labels.get(key, "") or "")
                if value:
                    local_labels[key] = value
                else:
                    local_labels.pop(key, None)
                local_times[key] = rt
                local_revs[key] = rr
                changed = changed or (before != value or rr != lr or abs(rt-lt) > 1e-7)
                _append_jsonl(_LABEL_HISTORY_FILE, {
                    "kind": "remote_apply", "order": key, "value": value,
                    "client_time": rt, "revision": rr, "time": time.time(),
                })
            self.state["server_rev"] = max(int(self.state.get("server_rev", 0) or 0), int(remote.get("server_rev", 0) or 0))
        if changed:
            self._save()
        return changed

    def _notification_topic(self) -> str:
        if not self.configured() or not self.secret:
            return ""
        digest = hashlib.sha256((self.url + "|" + self.secret).encode("utf-8", errors="ignore")).hexdigest()[:40]
        return "adeon-label-" + digest

    def _start_notify_listener(self) -> None:
        topic = self._notification_topic()
        if not topic or (self._notify_thread and self._notify_thread.is_alive()):
            return
        def run() -> None:
            backoff = 2.0
            while not self._notify_stop.is_set():
                try:
                    with requests.get(f"{_LABEL_NOTIFY_BASE}/{topic}/sse", stream=True, timeout=(5.0, 70.0), headers={"Accept": "text/event-stream"}) as r:
                        if not (200 <= r.status_code < 300):
                            raise RuntimeError(f"HTTP {r.status_code}")
                        backoff = 2.0
                        for raw in r.iter_lines(decode_unicode=True):
                            if self._notify_stop.is_set():
                                return
                            line = str(raw or "").strip()
                            if not line.startswith("data:"):
                                continue
                            try:
                                data = json.loads(line[5:].strip())
                            except Exception:
                                data = {}
                            if isinstance(data, dict) and str(data.get("event") or "") == "message":
                                # The notification carries no label text. It merely wakes
                                # the client so the persistent private label server is read.
                                self.remote_hint.set()
                except Exception as e:
                    if time.time() - self.last_remote_error > 30.0:
                        self.last_remote_error = time.time()
                        log(f"LABEL LIVE SYNC notifier unavailable; fallback polling remains active: {e}")
                    self._notify_stop.wait(backoff)
                    backoff = min(30.0, backoff * 1.6)
        self._notify_thread = threading.Thread(target=run, name="Adeon-Label-LiveSync", daemon=True)
        self._notify_thread.start()

    def _publish_change_ping(self) -> None:
        topic = self._notification_topic()
        if not topic:
            return
        def send() -> None:
            try:
                requests.post(
                    f"{_LABEL_NOTIFY_BASE}/{topic}",
                    data=b"changed",
                    headers={"Title": "Adeon label update", "Priority": "min", "Tags": "label"},
                    timeout=3.0,
                )
            except Exception:
                pass
        threading.Thread(target=send, name="Adeon-Label-Ping", daemon=True).start()

    def poll_remote(self, force: bool = False) -> bool:
        if not self.configured():
            return False
        now = time.time()
        hinted = self.remote_hint.is_set()
        if not force and not hinted and now - self.last_remote_poll < _LABEL_REMOTE_FALLBACK_POLL:
            return False
        self.remote_hint.clear()
        self.last_remote_poll = now
        headers = {"Content-Type": "application/json", "Accept": "application/json", "X-Adeon-Device": self.device}
        try:
            body = {
                "protocol": 2,
                "action": "pull",
                "device": self.device,
                "since": int(self.state.get("server_rev", 0) or 0),
                "events": [],
                "secret": self.secret,
            }
            r = requests.post(self.url, json=body, headers=headers, timeout=4.0)
            if not (200 <= r.status_code < 300):
                raise RuntimeError(f"HTTP {r.status_code}")
            data = r.json() if r.content else {}
            if isinstance(data, dict) and data.get("ok") is False:
                raise RuntimeError(str(data.get("error") or "label sync server rejected request"))
            remote_state = data.get("state") if isinstance(data, dict) and isinstance(data.get("state"), dict) else data
            return self.merge_remote(remote_state if isinstance(remote_state, dict) else {})
        except Exception as e:
            if now - self.last_remote_error > 30.0:
                self.last_remote_error = now
                log(f"LABEL SYNC read unavailable: {e}")
            return False

    def push_remote(self, force: bool = False) -> bool:
        if not self.configured():
            return False
        with self.lock:
            events = [dict(e) for e in self.outbox]
        if not events:
            return False
        now = time.time()
        if not force and now - self.last_remote_push < 0.20:
            return False
        self.last_remote_push = now
        headers = {"Content-Type": "application/json", "Accept": "application/json", "X-Adeon-Device": self.device}
        if self.secret:
            headers["X-Adeon-Secret"] = self.secret
        body = {
            "protocol": 2,
            "device": self.device,
            "events": events,
            "state": self.snapshot(),  # legacy server fallback
            "secret": self.secret,
        }
        try:
            r = requests.post(self.url, json=body, headers=headers, timeout=5.0)
            if not (200 <= r.status_code < 300):
                raise RuntimeError(f"HTTP {r.status_code}")
            try:
                data = r.json() if r.content else {}
            except Exception:
                data = {}
            if isinstance(data, dict) and data.get("ok") is False:
                raise RuntimeError(str(data.get("error") or "label sync server rejected request"))

            protocol2 = isinstance(data, dict) and int(data.get("protocol", 0) or 0) >= 2
            if protocol2:
                accepted = {str(x) for x in (data.get("accepted") or [])}
                conflicts = data.get("conflicts") if isinstance(data.get("conflicts"), list) else []
                conflict_ids = {str(c.get("event_id") or "") for c in conflicts if isinstance(c, dict)}
                done = accepted | conflict_ids
                if done:
                    with self.lock:
                        self.outbox = [e for e in self.outbox if str(e.get("event_id") or "") not in done]
                    self._save_outbox()
                for conflict in conflicts:
                    if isinstance(conflict, dict):
                        _append_jsonl(_LABEL_CONFLICT_FILE, {**conflict, "saved_at": time.time(), "device": self.device})
                remote_state = data.get("state") if isinstance(data.get("state"), dict) else {}
                self.merge_remote(remote_state)
            else:
                # Old server compatibility: it accepted the current merged snapshot.
                with self.lock:
                    self.outbox = []
                self._save_outbox()
                remote_state = data.get("state") if isinstance(data, dict) and isinstance(data.get("state"), dict) else {}
                if remote_state:
                    self.merge_remote(remote_state)
            self._publish_change_ping()
            return True
        except Exception as e:
            if now - self.last_remote_error > 30.0:
                self.last_remote_error = now
                log(f"LABEL SYNC write unavailable; edit remains safely queued locally: {e}")
            return False

    def set_local_label(self, order: str, value: str) -> bool:
        key=str(order or "").strip().upper()[:80]
        if not key:
            return False
        val=str(value or "").strip().upper()
        ts=time.time()
        page={"labels":({key:val} if val else {}),"times":{key:ts},"revisions":{},"server_rev":0}
        return self.merge_page(page)

    def close(self) -> None:
        self._notify_stop.set()
        self._backup_if_due(True)


class LabelOverlayManager:
    """Persistent Windows label editors physically bound to visible Order Numbers.

    Each overlay is keyed by the exact LR order number, never by a remembered screen
    slot.  Every fresh My Orders frame rebuilds the visible order->screen-position map.
    If an exact order number is not visible in the current frame, its overlay is hidden
    immediately instead of being left floating at stale coordinates.
    """
    LABEL_WIDTH = 94
    LABEL_HEIGHT = 20
    LABEL_GAP = 12

    def __init__(self) -> None:
        self.commands=queue.Queue(maxsize=3)
        self.edits=queue.Queue()
        self.stop_event=threading.Event()
        self.thread=threading.Thread(target=self._run,name="AdeonLabelOverlay",daemon=True)
        self.thread.start()

    def update(self, snap: dict, state: dict) -> None:
        try:
            snap=snap or {}
            rows=[]
            on_my=bool(snap.get("onMyOrders"))
            panel_open=bool(snap.get("sideOrderPanelOpen"))
            if on_my:
                for r in snap.get("rows") or []:
                    key=str(r.get("orderNo") or row_key(r) or "").strip().upper()
                    if not re.fullmatch(r"[A-Z]{1,6}\d{6,}-\d+",key,re.I):
                        continue
                    try:
                        top=float(r.get("screenTop") or 0); h=float(r.get("screenH") or 0)
                        sy=float(r.get("visionRowScreenY") or r.get("sy") or (top+h/2.0))
                        order_left=float(r.get("orderScreenLeft") or r.get("screenLeft") or 0)
                    except Exception:
                        continue
                    if sy <= 0 or order_left <= 0:
                        continue
                    rows.append({"order":key,"top":top,"h":h,"sy":sy,"orderLeft":order_left})
            url=str(snap.get("url") or "").lower()
            exact_my=bool(re.search(r"^https?://myaccount\.lrwriters\.com/myorders/(?:inprogress|revisions?)(?:[/?#]|$)",url,re.I))
            payload={
                "rows":rows,
                "labels":dict((state or {}).get("labels") or {}),
                "hwnd":int(snap.get("uiaHwnd") or 0),
                "onMyOrders":on_my,
                "exactMyOrders":exact_my,
                "panelOpen":panel_open,
                "url":url,
                "pageKnown":bool(url),
                "bodyText":str(snap.get("bodyText") or "")[:8000],
                "frameTs":float(snap.get("uiaTs") or time.time()),
                "ts":time.time(),
            }
            while self.commands.qsize()>1:
                try:self.commands.get_nowait()
                except Exception:break
            self.commands.put_nowait(payload)
        except Exception:
            pass

    def refresh_state(self, state: dict) -> None:
        """Refresh saved/synced label text without altering last confirmed browser geometry."""
        try:
            payload={
                "preserveGeometry":True,
                "labels":dict((state or {}).get("labels") or {}),
                "ts":time.time(),
            }
            while self.commands.qsize()>1:
                try:self.commands.get_nowait()
                except Exception:break
            self.commands.put_nowait(payload)
        except Exception:
            pass

    def drain_edits(self) -> list[tuple[str,str]]:
        out=[]
        while True:
            try: out.append(self.edits.get_nowait())
            except Exception: break
        return out

    def close(self) -> None:
        self.stop_event.set()
        try:self.commands.put_nowait({"stop":True})
        except Exception:pass

    def _run(self) -> None:
        try:
            import tkinter as tk
            import tkinter.font as tkfont
            import statistics
            root=tk.Tk(); root.withdraw()
            wins={}
            last_payload={"rows":[],"labels":{},"hwnd":0,"onMyOrders":False,"exactMyOrders":False,"panelOpen":False,"bodyText":"","ts":0.0}
            last_good_hwnd=0
            last_visible_geometry={}
            last_visible_set=set()
            # 1.0.69: identity-first row tracker.  We keep an order at its last
            # exact anchor through an isolated OCR miss only when the surrounding
            # rows prove that the table itself has not moved.  Any positive layout
            # transition (filter/sort/scroll/removal) invalidates stale geometry.
            last_bound_map={}
            missing_since={}
            held_missing_logged=set()
            blank_table_since=0.0

            def text_value(ent):
                try:return re.sub(r"\s+"," ",str(ent.get("1.0","end-1c") or "")).strip().upper()
                except Exception:return ""

            def set_text(ent, value):
                value=str(value or "").strip().upper()
                try:
                    cur=text_value(ent)
                    if cur==value:return
                    ent.delete("1.0","end")
                    ent.insert("1.0",value)
                    ent.tag_add("center","1.0","end")
                except Exception:pass

            def commit(order, ent):
                try:self.edits.put((str(order).strip().upper(),text_value(ent)))
                except Exception:pass

            def remove(order):
                rec=wins.pop(order,None)
                last_visible_geometry.pop(order,None)
                if rec:
                    try:rec[0].destroy()
                    except Exception:pass

            _font_cache={}
            LABEL_FONT_MAX_PX=9
            LABEL_FONT_MIN_PX=1
            LABEL_TEXT_INSET_X=6
            LABEL_TEXT_INSET_Y=4

            def font_for(px):
                f=_font_cache.get(px)
                if f is None:
                    f=tkfont.Font(family="Segoe UI",size=-px,weight="normal")
                    _font_cache[px]=f
                return f

            def wrapped_lines(text, font, max_width):
                text=re.sub(r"\s+"," ",str(text or "")).strip()
                if not text:return [""]
                words=text.split(" ")
                lines=[]; cur=""
                for word in words:
                    trial=word if not cur else cur+" "+word
                    if font.measure(trial)<=max_width:
                        cur=trial; continue
                    if cur:
                        lines.append(cur); cur=""
                    if font.measure(word)<=max_width:
                        cur=word; continue
                    chunk=""
                    for ch in word:
                        trial2=chunk+ch
                        if chunk and font.measure(trial2)>max_width:
                            lines.append(chunk); chunk=ch
                        else:
                            chunk=trial2
                    cur=chunk
                if cur:lines.append(cur)
                return lines or [""]

            def apply_font(ent, value):
                # Word-like centered wrapping: use horizontal + vertical space first,
                # then choose the LARGEST font whose complete text fits. Never shrink
                # below what is actually required for the current value.
                try:
                    text=re.sub(r"\s+"," ",str(value or "")).strip()
                    usable_w=max(8,self.LABEL_WIDTH-LABEL_TEXT_INSET_X)
                    usable_h=max(8,self.LABEL_HEIGHT-LABEL_TEXT_INSET_Y)
                    chosen=LABEL_FONT_MIN_PX; chosen_lines=[text] if text else [""]
                    for px in range(LABEL_FONT_MAX_PX,LABEL_FONT_MIN_PX-1,-1):
                        f=font_for(px)
                        lines=wrapped_lines(text,f,usable_w)
                        line_h=max(1,int(f.metrics("linespace") or px))
                        if len(lines)*line_h<=usable_h:
                            chosen=px; chosen_lines=lines; break
                    f=font_for(chosen)
                    line_h=max(1,int(f.metrics("linespace") or chosen))
                    total_h=max(line_h,len(chosen_lines)*line_h)
                    pad_y=max(0,int((usable_h-total_h)/2))
                    ent.configure(font=f,wrap="word",padx=2,pady=pad_y)
                    ent.tag_configure("center",justify="center")
                    ent.tag_add("center","1.0","end")
                    try:ent.see("1.0")
                    except Exception:pass
                except Exception:
                    pass

            def overlay_focus_order():
                try:
                    f=root.focus_get()
                    for order,rec in wins.items():
                        if f is rec[1]:return order
                except Exception:pass
                return ""

            def _window_pid(hwnd: int) -> int:
                if not hwnd:return 0
                try:
                    pid=ctypes.c_ulong(0)
                    user32.GetWindowThreadProcessId(int(hwnd),ctypes.byref(pid))
                    return int(pid.value or 0)
                except Exception:return 0

            def browser_is_foreground(hwnd: int) -> bool:
                # Chromium may give focus to a browser-owned child/popup HWND.
                # Treat the same browser process as foreground instead of requiring
                # exact HWND equality, which caused label flicker in 1.0.69.
                if not hwnd:return False
                try:
                    fg=int(user32.GetForegroundWindow() or 0)
                    if fg==int(hwnd):return True
                    a=_window_pid(fg); b=_window_pid(int(hwnd))
                    return bool(a and b and a==b)
                except Exception:return False

            def foreground_title() -> str:
                try:
                    fg=int(user32.GetForegroundWindow() or 0)
                    if not fg:return ""
                    n=int(user32.GetWindowTextLengthW(fg) or 0)
                    buf=ctypes.create_unicode_buffer(max(2,n+2))
                    user32.GetWindowTextW(fg,buf,len(buf))
                    return str(buf.value or "")
                except Exception:return ""

            def browser_title_is_lr(hwnd: int) -> bool:
                if not hwnd:return False
                try:
                    n=int(user32.GetWindowTextLengthW(hwnd) or 0)
                    buf=ctypes.create_unicode_buffer(max(2,n+2))
                    user32.GetWindowTextW(hwnd,buf,len(buf))
                    title=str(buf.value or "").lower()
                    return bool("writer tool" in title or "lr writers" in title or "lrwriters" in title or "myaccount.lrwriters.com" in title)
                except Exception:return False

            def make_editor(order, value):
                win=tk.Toplevel(root); win.overrideredirect(True); win.attributes("-topmost",True)
                ent=tk.Text(
                    win,font=font_for(LABEL_FONT_MAX_PX),wrap="word",
                    bd=1,relief="solid",highlightthickness=0,
                    padx=2,pady=0,undo=False,exportselection=False
                )
                ent.pack(fill="both",expand=True)
                ent.tag_configure("center",justify="center")
                ent.insert("1.0",str(value or "").strip().upper())
                ent.tag_add("center","1.0","end")
                pending={"id":None}
                def on_return(e,o=order,w=ent):
                    commit(o,w); return "break"
                def on_focus_out(e,o=order,w=ent):
                    commit(o,w)
                def on_key(e,o=order,w=ent,pending=pending):
                    try:
                        raw=str(w.get("1.0","end-1c") or "")
                        upper=raw.upper()
                        if raw!=upper:
                            idx=w.index("insert")
                            w.delete("1.0","end"); w.insert("1.0",upper)
                            try:w.mark_set("insert",idx)
                            except Exception:w.mark_set("insert","end-1c")
                        w.tag_add("center","1.0","end")
                        apply_font(w,text_value(w))
                        if pending["id"]:root.after_cancel(pending["id"])
                    except Exception:pass
                    pending["id"]=root.after(350,lambda:commit(o,w))
                ent.bind("<Return>",on_return)
                ent.bind("<FocusOut>",on_focus_out)
                ent.bind("<KeyRelease>",on_key)
                apply_font(ent,value)
                return win,ent

            def tick():
                nonlocal last_payload,last_good_hwnd,last_visible_set,last_bound_map,missing_since,held_missing_logged,blank_table_since
                if self.stop_event.is_set():
                    for k in list(wins):remove(k)
                    try:root.destroy()
                    except Exception:pass
                    return

                got_payload=False
                try:
                    while True:
                        incoming=self.commands.get_nowait(); got_payload=True
                        if incoming.get("preserveGeometry"):
                            # Remote/local label text changed while no trustworthy new
                            # browser frame was available. Update text only; never turn
                            # "no frame" into "left My Orders" or erase anchors.
                            last_payload=dict(last_payload)
                            last_payload["labels"]=dict(incoming.get("labels") or {})
                            last_payload["ts"]=float(incoming.get("ts") or time.time())
                        else:
                            last_payload=incoming
                except Exception:pass
                if last_payload.get("stop"):
                    self.stop_event.set(); tick(); return

                labels=last_payload.get("labels") or {}
                if last_payload.get("hwnd"):
                    last_good_hwnd=int(last_payload.get("hwnd") or last_good_hwnd or 0)

                focus_order=overlay_focus_order()
                exact_my=bool(last_payload.get("exactMyOrders"))
                panel_open=bool(last_payload.get("panelOpen"))
                browser_front=browser_is_foreground(last_good_hwnd)
                browser_ok=bool(browser_front and browser_title_is_lr(last_good_hwnd))
                fg_title=foreground_title().strip().lower()
                adeon_front=bool(fg_title.startswith("adeon"))

                # 1.0.69 identity-first binding rule.
                #
                # A label belongs to an ORDER NUMBER, never to a row slot.  The current
                # readable frame is authoritative when the table structure changes.  But
                # one OCR miss must not make an otherwise unchanged row disappear.  To
                # distinguish those cases we compare the geometry/order of the rows that
                # are positively recognized in both frames.
                current_rows=[]
                overlay_has_focus=bool(focus_order)
                if exact_my and not panel_open and browser_ok:
                    current_rows=[dict(x) for x in (last_payload.get("rows") or [])]

                # Reject x-position outliers before identity tracking.  All Order Number
                # cells belong to one table column.
                if current_rows:
                    xs=[float(x.get("orderLeft") or 0) for x in current_rows if float(x.get("orderLeft") or 0)>0]
                    if xs:
                        med=float(statistics.median(xs))
                        current_rows=[x for x in current_rows if abs(float(x.get("orderLeft") or 0)-med)<=35.0]
                        # One table = one Order Number column. Force every label to the
                        # same verified x anchor so OCR width jitter cannot make boxes
                        # look scattered horizontally.
                        for _row in current_rows:
                            _row["orderLeft"]=med

                current_map={str(x.get("order") or "").strip().upper():x for x in current_rows if str(x.get("order") or "").strip()}
                current_set=set(current_map)

                def _ordered(mp):
                    try:
                        return [o for o,_ in sorted(mp.items(),key=lambda kv:float((kv[1] or {}).get("sy") or 0))]
                    except Exception:
                        return list(mp)

                def _same_neighbor_slot(order, previous, current):
                    """True only when unchanged neighbors prove this old row slot still exists."""
                    try:
                        seq=_ordered(previous)
                        if order not in seq:return False
                        i=seq.index(order)
                        prev_o=seq[i-1] if i>0 else ""
                        next_o=seq[i+1] if i+1<len(seq) else ""
                        if not prev_o or not next_o:return False
                        if prev_o not in current or next_o not in current:return False
                        py0=float(previous[prev_o].get("sy") or 0); py1=float(current[prev_o].get("sy") or 0)
                        ny0=float(previous[next_o].get("sy") or 0); ny1=float(current[next_o].get("sy") or 0)
                        return abs(py1-py0)<=4.0 and abs(ny1-ny0)<=4.0
                    except Exception:
                        return False

                def _layout_transition(previous, current):
                    if not previous or not current:return False
                    prev_set=set(previous); cur_set=set(current); common=prev_set & cur_set
                    if not common:return True
                    # A sort changes the relative order of the same IDs.
                    old_common=[o for o in _ordered(previous) if o in common]
                    new_common=[o for o in _ordered(current) if o in common]
                    if old_common!=new_common:return True
                    # Scroll/reflow/removal moves the common rows.  One moved row is
                    # enough when it moves by roughly half a row; widespread smaller
                    # movement is also treated as a transition.
                    deltas=[abs(float(current[o].get("sy") or 0)-float(previous[o].get("sy") or 0)) for o in common]
                    if deltas and max(deltas)>=12.0:return True
                    if deltas and statistics.median(deltas)>=5.0:return True
                    # A filter usually removes a substantial part of the visible set.
                    removed=len(prev_set-cur_set)
                    if removed>=max(3,int(math.ceil(len(prev_set)*0.30))):return True
                    return False

                render_map={}
                positive_page_change=bool(not exact_my or panel_open)

                if positive_page_change:
                    # Leaving My Orders / opening the side panel is a positive state
                    # change.  Nothing from the old table is allowed to float here.
                    last_bound_map={}
                    missing_since.clear(); held_missing_logged.clear()
                    last_visible_set=set(); blank_table_since=0.0
                elif (overlay_has_focus or adeon_front) and not browser_ok:
                    # Clicking a native label editor OR the Adeon dashboard makes a
                    # native Adeon window foreground. Keep all last-confirmed labels at
                    # their exact anchors; do not hide/reflow them just because Screen
                    # Vision correctly refuses to OCR through another foreground window.
                    render_map=dict(last_bound_map)
                elif browser_ok:
                    if current_map:
                        blank_table_since=0.0
                        transition=_layout_transition(last_bound_map,current_map)
                        if transition:
                            # Filter/sort/scroll/actual row removal: old geometry is now
                            # invalid.  Withdraw before rendering the freshly identified
                            # table so no label can fly through empty space.
                            for _o,_rec in list(wins.items()):
                                try:_rec[0].withdraw()
                                except Exception:pass
                            last_bound_map={o:dict(v) for o,v in current_map.items()}
                            missing_since.clear(); held_missing_logged.clear()
                        else:
                            now=time.time()
                            previous=dict(last_bound_map)
                            merged={o:dict(v) for o,v in previous.items()}
                            for o,v in current_map.items():
                                merged[o]=dict(v)
                                missing_since.pop(o,None); held_missing_logged.discard(o)
                            # For an isolated OCR miss in the middle of an unchanged
                            # table, unchanged neighbors prove the row slot still exists.
                            # Keep that exact order's previous anchor instead of dropping
                            # its box. Edge rows (no two-sided proof) get a short grace
                            # only, avoiding a stale bottom/top label after a real removal.
                            for o in set(previous)-current_set:
                                if _same_neighbor_slot(o,previous,current_map):
                                    if o not in held_missing_logged:
                                        log(f"LABEL ANCHOR HOLD: {o} missed by one OCR frame; unchanged neighboring Order Numbers prove the same row is still present.")
                                        held_missing_logged.add(o)
                                    continue
                                t0=missing_since.setdefault(o,now)
                                if now-t0>0.30:
                                    merged.pop(o,None); missing_since.pop(o,None); held_missing_logged.discard(o)
                            last_bound_map=merged
                        render_map=dict(last_bound_map)
                    else:
                        # A totally blank OCR frame is not enough evidence that the table
                        # vanished.  Keep the last confirmed map briefly.  If the page
                        # positively says there are no orders/results, clear immediately;
                        # otherwise a sustained blank frame clears after a short debounce.
                        # This bridges OCR flicker without leaving labels floating after a
                        # filter that genuinely produces an empty table.
                        body_low=str(last_payload.get("bodyText") or "").lower()
                        no_rows_positive=bool(re.search(r"\b(?:no orders|no results|nothing found|no matching orders|no orders found)\b",body_low,re.I))
                        now=time.time()
                        if no_rows_positive:
                            last_bound_map={}; missing_since.clear(); held_missing_logged.clear(); blank_table_since=0.0
                            render_map={}
                        else:
                            if blank_table_since<=0: blank_table_since=now
                            if now-blank_table_since<=0.35:
                                render_map=dict(last_bound_map)
                            else:
                                last_bound_map={}; missing_since.clear(); held_missing_logged.clear()
                                render_map={}

                current_set=set(render_map)
                if got_payload and current_set!=last_visible_set:
                    last_visible_set=set(current_set)

                br=_screen_rect(last_good_hwnd) if last_good_hwnd else None
                wanted=set()
                if br and render_map and (browser_ok or overlay_has_focus or adeon_front):
                    bl,bt,brx,bby=br
                    for order,item in render_map.items():
                        sy=float(item.get("sy") or 0)
                        order_left=float(item.get("orderLeft") or 0)
                        if sy<=0 or order_left<=0:continue
                        y=int(round(sy-self.LABEL_HEIGHT/2.0))
                        x=int(round(order_left-self.LABEL_GAP-self.LABEL_WIDTH))
                        x=max(int(bl+4),min(x,int(brx-self.LABEL_WIDTH-4)))
                        y=max(int(bt+4),min(y,int(bby-self.LABEL_HEIGHT-4)))
                        wanted.add(order)
                        value=str(labels.get(order,"") or "").strip().upper()
                        if order not in wins:
                            wins[order]=make_editor(order,value)
                        win,ent=wins[order]
                        try:
                            if root.focus_get() is not ent:
                                set_text(ent,value)
                            apply_font(ent,text_value(ent))
                            win.geometry(f"{self.LABEL_WIDTH}x{self.LABEL_HEIGHT}+{x}+{y}")
                            last_visible_geometry[order]=(x,y)
                            win.deiconify(); win.lift()
                        except Exception:pass

                for order,rec in list(wins.items()):
                    if order not in wanted:
                        try:rec[0].withdraw()
                        except Exception:pass

                # Keep saved state flowing into cached editors without showing them at
                # stale coordinates.  Display position always comes from render_map.
                for order,rec in list(wins.items()):
                    win,ent=rec
                    value=str(labels.get(order,"") or "").strip().upper()
                    try:
                        if root.focus_get() is not ent:
                            set_text(ent,value)
                        apply_font(ent,text_value(ent))
                    except Exception:pass

                root.after(50,tick)

            root.after(25,tick); root.mainloop()
        except Exception as e:
            log(f"LABEL OVERLAY unavailable: {e}")


def save_reservation_state(data: dict) -> None:
    _write_json_atomic(_RESERVATION_STATE_FILE, data or {})


def load_reservation_state() -> dict:
    try:
        if not _RESERVATION_STATE_FILE.exists():
            return {}
        data = json.loads(_RESERVATION_STATE_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def clear_reservation_state() -> None:
    try:
        _RESERVATION_STATE_FILE.unlink(missing_ok=True)
    except Exception:
        pass


def app_stop_requested() -> bool:
    if not _APP_WORKER_MODE:
        return False
    try:
        return _APP_STOP_FILE.exists()
    except Exception:
        return False

def stop_requested_now() -> bool:
    """Fast fail-closed check used immediately before any physical action."""
    return bool(_stop or app_stop_requested())


def start_app_stop_watchdog() -> threading.Thread | None:
    """Watch the app stop flag at 25 ms so Alt+S cannot be missed by a busy loop."""
    if not _APP_WORKER_MODE:
        return None

    def worker() -> None:
        global _stop, _stop_reason
        while not _stop:
            if app_stop_requested():
                if not str(_stop_reason or "").strip() or _stop_reason == "normal shutdown":
                    _stop_reason = "Adeon app / Alt+S stop requested"
                _stop = True
                try:
                    set_status_ticket(bot="STOPPED", page="OFF", job="-", f5="OFF", mouse="OFF")
                except Exception:
                    pass
                log("APP STOP WATCHDOG: stop flag detected. No new F5/click/mouse action may start.")
                break
            time.sleep(0.025)

    t = threading.Thread(target=worker, name="AdeonAppStopWatchdog", daemon=True)
    t.start()
    return t


_log_lock = threading.Lock()
_issue_lock = threading.Lock()
_issues: list[dict] = []
_issue_last: dict[str, float] = {}
_stats: dict[str, int] = {
    "dom_reads": 0, "brain_read_errors": 0, "reconnects": 0,
    "row_clicks": 0, "reserve_clicks": 0, "click_refusals": 0,
    "f5": 0, "reservations_confirmed": 0, "alerts_sent": 0,
    "alert_failures": 0, "loop_errors": 0, "left_find_orders": 0,
    "trusted_native_clicks": 0, "untrusted_clicks": 0, "manual_accepts": 0,
    "manual_rejects": 0, "reject_clicks": 0, "midnight_auto_rejects": 0,
    "soft_pauses": 0, "soft_resumes": 0, "logout_pauses": 0, "logout_stops": 0,
    "alerts_cancelled": 0, "idle_pause_cycles": 0,
    "nav_clicks": 0, "my_orders_visits": 0, "reservation_status_checks": 0,
    "panel_inspection_scrolls": 0, "panel_files_toggles": 0,
    "reservation_state_restores": 0,
}
_last_state: dict[str, object] = {}
_report_written = False
_stop_reason = "normal shutdown"


def record_stat(name: str, amount: int = 1) -> None:
    _stats[name] = int(_stats.get(name, 0)) + amount


def write_last_error(message: str) -> None:
    try:
        _APP_LAST_ERROR_FILE.write_text(str(message or "Unknown Adeon worker error"), encoding="utf-8")
    except Exception:
        pass


def log(msg: str) -> None:
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{stamp}] {msg}"
    # The installed worker is windowless, but direct/debug runs can inherit a
    # legacy Windows console encoding such as cp1252. Never let an emoji or
    # non-ASCII DOM character crash the automation merely because print()
    # cannot encode it. The UTF-8 log files below remain authoritative.
    try:
        if getattr(sys, "stdout", None) is not None:
            try:
                print(line, flush=True)
            except UnicodeEncodeError:
                enc = getattr(sys.stdout, "encoding", None) or "ascii"
                safe = line.encode(enc, errors="replace").decode(enc, errors="replace")
                print(safe, flush=True)
    except Exception:
        pass
    try:
        with _log_lock:
            with _SESSION_LOG.open("a", encoding="utf-8") as fh:
                fh.write(line + "\n")
            with _APP_ACTIVITY_LOG.open("a", encoding="utf-8") as fh:
                fh.write(line + "\n")
    except Exception:
        pass


def note_issue(code: str, message: str, severity: str = "WARN", details: str = "", throttle: float = 5.0) -> None:
    now = time.time()
    with _issue_lock:
        last = _issue_last.get(code, 0.0)
        if throttle and last and now - last < throttle:
            return
        _issue_last[code] = now
        _issues.append({
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "severity": severity, "code": code, "message": message,
            "details": str(details)[:1000],
        })
    log(f"{severity} [{code}] {message}" + (f" | {str(details)[:300]}" if details else ""))


def capture_diagnostic(label: str, min_interval: float = 8.0) -> str:
    """Save a full-screen diagnostic image without interrupting the bot."""
    global _last_diag_shot
    now = time.time()
    if _last_diag_shot and now - _last_diag_shot < min_interval:
        return ""
    _last_diag_shot = now
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(label))[:60] or "diagnostic"
    path = _REPORT_DIR / f"Adeon {SESSION_ID}_{datetime.now().strftime('%H%M%S')}_{safe}.png"
    try:
        pyautogui.screenshot(str(path))
        log(f"Diagnostic screenshot saved: {path}")
        return str(path)
    except Exception as e:
        log(f"Diagnostic screenshot failed: {e}")
        return ""


def update_last_state(snap: dict | None = None, **extra) -> None:
    if snap:
        _last_state.update({
            "url": str(snap.get("url") or "")[:300],
            "page_title": str(snap.get("pageTitle") or "")[:200],
            "rows_seen": len(snap.get("rows") or []),
            "panel_open": bool(snap.get("panelOpen")),
            "reserve_visible": bool(snap.get("reserve")),
            "accept_visible": bool(snap.get("accept")),
            "reject_visible": bool(snap.get("reject")),
            "reserve_disabled": bool(snap.get("reserveDisabled")),
            "accepted_gone": bool(snap.get("acceptedGone")),
            "panel_text_excerpt": str(snap.get("panelText") or "")[:500].replace("\\n", " "),
            "last_good_dom": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        })
    _last_state.update(extra)


def write_shutdown_report(reason: str | None = None) -> str:
    global _report_written
    if _report_written:
        return str(_REPORT_VISIBLE if _REPORT_VISIBLE.exists() else _REPORT_LOCAL)
    _report_written = True
    ended = time.time()
    duration = max(0.0, ended - SESSION_STARTED_AT)
    early_exit = duration < 5.0 and int(_stats.get("dom_reads", 0)) == 0
    status = "REVIEW NEEDED" if (early_exit or any(str(i.get("severity", "")).upper() in ("WARN", "ERROR") for i in _issues)) else "NO ACTIONABLE ANOMALIES RECORDED"
    lines = [
        "LR WRITERS BOT SESSION REPORT", "=" * 30,
        f"Session: {SESSION_ID}",
        f"Started: {datetime.fromtimestamp(SESSION_STARTED_AT).strftime('%Y-%m-%d %H:%M:%S')}",
        f"Ended: {datetime.fromtimestamp(ended).strftime('%Y-%m-%d %H:%M:%S')}",
        f"Duration: {duration / 60:.1f} minutes",
        f"Stop reason: {reason or _stop_reason}", f"Status: {status}", "",
        "CONFIGURATION", f"Minimum preferred earnings: ${MIN_PAY:.2f} (A+ earns when present, otherwise You\'ll earn)",
        f"Fast refresh: {RELOAD_FAST[0]:.1f}-{RELOAD_FAST[1]:.1f}s x {RELOAD_FAST_N}",
        f"Slow refresh: {RELOAD_SLOW[0]:.1f}-{RELOAD_SLOW[1]:.1f}s x {RELOAD_SLOW_N}",
        f"Absolute minimum between any two F5 presses: {F5_HARD_MIN_GAP:.1f}s",
        f"Scheduled F5 range while searching: {min(RELOAD_FAST[0], RELOAD_SLOW[0]):.1f}-{max(RELOAD_FAST[1], RELOAD_SLOW[1]):.1f}s",
        f"Actual minimum spacing between F5 presses: {F5_HARD_MIN_GAP:.1f}s",
        "Reserved F5: held completely until the reservation ends",
        "Allowed physical clicks: order row, Reserve, exact Yes, I\'m here keep-alive confirmation, and DOM-verified inert background idle clicks",
        "Same order row: one successful physical click maximum per session",
        "Accept click: forbidden by code; trusted manual Accept is only observed",
        f"Idle mouse rhythm: active 5 min, then rests randomly {IDLE_REST[0]/60:.0f}-{IDLE_REST[1]/60:.0f} min; job clicks/F5 continue",
        f"Midnight rule: {MIDNIGHT_RULE_START_HOUR:02d}:00-{MIDNIGHT_RULE_END_HOUR:02d}:00 local; if remaining time is under {MIDNIGHT_REJECT_UNDER_MINUTES/60:.0f}h, show Reject cues only after {MIDNIGHT_REJECT_AFTER/60:.0f} min reserved; never auto-Reject",
        "Control: Alt+S toggles the active bot session START/STOP; there is no pause mode",
        "Logout safety: active session stops immediately; no automatic navigation/login/F5/mouse action occurs while stopped",
        "Alerts: full Reserved report, 1-minute reminder, then Critical Alert from 3:00 reserved; 15s cadence until 5:30, then 10s, 7.5s, and 5s escalation until reservation ends", "", "COUNTERS",
    ]
    for key in sorted(_stats): lines.append(f"{key}: {_stats[key]}")
    lines += ["", "LAST KNOWN STATE"]
    if _last_state:
        for key in sorted(_last_state): lines.append(f"{key}: {_last_state[key]}")
    else:
        lines.append("No valid DOM snapshot was recorded.")
    lines += ["", f"ANOMALIES / NOTES ({len(_issues)})"]
    if _issues:
        for i, item in enumerate(_issues, 1):
            lines.append(f"{i}. [{item['time']}] {item['severity']} {item['code']} - {item['message']}")
            if item.get("details"): lines.append(f"   Details: {item['details']}")
    else:
        lines.append("None recorded.")

    if early_exit:
        lines += [
            "",
            "EARLY EXIT DIAGNOSTIC",
            "The worker ended before it completed a single DOM read.",
            "This report is intentionally marked REVIEW NEEDED even if no exception was recorded.",
        ]

    # Make the one report fully self-contained. Users should never need to hunt
    # for a separate .log file just to diagnose a failure.
    try:
        session_text = _SESSION_LOG.read_text(encoding="utf-8", errors="replace").strip()
    except Exception as e:
        session_text = f"(session log could not be read: {e})"
    if not session_text:
        session_text = "(no session log lines were recorded)"

    try:
        activity_lines = _APP_ACTIVITY_LOG.read_text(encoding="utf-8", errors="replace").splitlines()
        activity_tail = "\n".join(activity_lines[-120:]).strip()
    except Exception as e:
        activity_tail = f"(activity log could not be read: {e})"
    if not activity_tail:
        activity_tail = "(no activity log lines were recorded)"

    lines += [
        "", "FULL SESSION LOG (EMBEDDED)", session_text,
        "", "ACTIVITY LOG TAIL (LAST 120 LINES)", activity_tail,
        "", "REPORT / LOG FILE LOCATIONS",
        f"Visible report folder (same folder as Adeon setup): {_VISIBLE_REPORT_DIR}",
        f"Visible report: {_REPORT_VISIBLE}",
        f"Session log: {_SESSION_LOG}",
        f"Activity log: {_APP_ACTIVITY_LOG}",
        "",
        "This report already contains the diagnostic log needed for review.",
    ]
    text = "\n".join(lines) + "\n"
    paths=[]
    try:
        _REPORT_LOCAL.write_text(text, encoding="utf-8"); paths.append(_REPORT_LOCAL)
    except Exception:
        pass
    try:
        _VISIBLE_REPORT_DIR.mkdir(parents=True, exist_ok=True)
        _REPORT_VISIBLE.write_text(text, encoding="utf-8"); paths.append(_REPORT_VISIBLE)
    except Exception as e:
        try:
            with _SESSION_LOG.open("a", encoding="utf-8") as fh:
                fh.write(f"Report copy to setup folder failed: {e}\n")
        except Exception:
            pass
    result=str(paths[-1] if paths else _REPORT_LOCAL)
    try:
        if getattr(sys, "stdout", None) is not None:
            print(f"\nSession report saved: {result}", flush=True)
            print(f"Full session log: {_SESSION_LOG}", flush=True)
    except Exception:
        pass
    return result


def request_stop(reason: str = "") -> None:
    """Stop the active session without overwriting a more specific stop reason."""
    global _stop, _stop_reason
    wanted = str(reason or "").strip()
    if wanted:
        _stop_reason = wanted
    elif not str(_stop_reason or "").strip() or _stop_reason == "normal shutdown":
        _stop_reason = "Ctrl+C / console exit requested"
    _stop = True
    _controller_exit.set()


def hard_stop_logout(reason: str = "LR Writers logout detected") -> None:
    """Terminate this bot session immediately when LR Writers is logged out.

    No automatic navigation/login attempt is made. The active worker ends and the
    controller remains inert at STOPPED so the user can log in manually and press
    Alt+S to start a fresh session.
    """
    global _stop, _stop_reason, _paused, _resume_requested, _resume_source
    if _stop:
        return
    with _pause_lock:
        _paused = False
        _resume_requested = False
        _resume_source = ""
    _stop_reason = reason or "LR Writers logout detected — hard stop"
    _stop = True
    record_stat("logout_stops")
    set_status_ticket(bot="STOPPED", page="LOGGED OUT", job="-", f5="OFF", mouse="OFF")
    log(f"LOGOUT HARD STOP: {_stop_reason}. No automatic login/navigation will be attempted. Log back in manually, then press Alt+S to start a fresh session.")


def soft_pause(reason: str, *, logout: bool = False) -> None:
    """Manual pause only: pause browser input without exiting so Ctrl+A or Alt+A can resume later."""
    global _paused, _pause_reason, _resume_requested
    with _pause_lock:
        if _paused:
            if reason:
                _pause_reason = reason
            return
        _paused = True
        _pause_reason = reason or "manual hotkey pause"
        _resume_requested = False
    record_stat("soft_pauses")
    if logout:
        record_stat("logout_pauses")
    set_status_ticket(bot="PAUSED", page="LOGGED OUT" if logout else "ONLINE", f5="PAUSED", mouse="PAUSED")
    log(f"SOFT PAUSE: {_pause_reason}. No F5, mouse movement, clicks, or new alerts will be started until Ctrl+A or Alt+A resumes on Find Orders.")


def request_pause_toggle(source: str = "Ctrl+A") -> None:
    """Manual hotkey pause/resume. Logout never uses this path; logout hard-stops."""
    global _resume_requested, _resume_source
    if _stop:
        return
    source = str(source or "hotkey")
    with _pause_lock:
        paused = bool(_paused)
        if paused:
            if _resume_requested:
                return
            _resume_requested = True
            _resume_source = source
    if paused:
        log(f"{source} detected while paused. Resume requested; bot will continue only if the controlled tab is back on Find Orders and not logged out.")
    else:
        soft_pause(f"{source} manual pause")


def request_ctrl_a_toggle() -> None:
    request_pause_toggle("Ctrl+A")


# Only a real Adeon app-worker session should generate a session report.
# Launching Adeon Bot.py directly merely redirects to Adeon.exe and must not
# create a misleading zero-action "normal shutdown" report.
if _APP_WORKER_MODE:
    atexit.register(write_shutdown_report)


# ---------------- Windows DPI + Chrome window ----------------
user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32

EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)


class RECT(ctypes.Structure):
    _fields_ = [
        ("left", ctypes.c_long),
        ("top", ctypes.c_long),
        ("right", ctypes.c_long),
        ("bottom", ctypes.c_long),
    ]


class POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


class MSG(ctypes.Structure):
    _fields_ = [
        ("hwnd", wintypes.HWND),
        ("message", wintypes.UINT),
        ("wParam", wintypes.WPARAM),
        ("lParam", wintypes.LPARAM),
        ("time", wintypes.DWORD),
        ("pt", POINT),
        ("lPrivate", wintypes.DWORD),
    ]


# Explicit signatures avoid handle truncation/argument ambiguity on 64-bit Windows.
try:
    user32.WindowFromPoint.argtypes = [POINT]
    user32.WindowFromPoint.restype = wintypes.HWND
    user32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
    user32.GetAncestor.restype = wintypes.HWND
    user32.SetWindowPos.argtypes = [
        wintypes.HWND, wintypes.HWND,
        ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.UINT,
    ]
    user32.SetWindowPos.restype = wintypes.BOOL
    user32.BringWindowToTop.argtypes = [wintypes.HWND]
    user32.BringWindowToTop.restype = wintypes.BOOL
    user32.SetForegroundWindow.argtypes = [wintypes.HWND]
    user32.SetForegroundWindow.restype = wintypes.BOOL
except Exception:
    pass


def dpi_aware() -> None:
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            user32.SetProcessDPIAware()
        except Exception:
            pass


def _cls(hwnd) -> str:
    buf = ctypes.create_unicode_buffer(256)
    user32.GetClassNameW(hwnd, buf, 256)
    return buf.value


def _title(hwnd) -> str:
    n = user32.GetWindowTextLengthW(hwnd)
    buf = ctypes.create_unicode_buffer(n + 1)
    user32.GetWindowTextW(hwnd, buf, n + 1)
    return buf.value


def _visible(hwnd) -> bool:
    return bool(user32.IsWindowVisible(hwnd))


def chrome_debug_pid(port: int | None = None) -> int:
    """Return the Windows PID that owns Adeon's current local Chrome DevTools port."""
    target_port = int(port or _debug_port or 0)
    if target_port <= 0:
        return 0
    needle = f":{target_port}"
    try:
        out = subprocess.run(
            ["netstat", "-ano", "-p", "tcp"],
            capture_output=True, text=True, timeout=3, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
        ).stdout
        for line in out.splitlines():
            up = line.upper()
            if needle not in line or "LISTENING" not in up:
                continue
            parts = line.split()
            if parts and parts[-1].isdigit():
                return int(parts[-1])
    except Exception:
        pass
    return 0


def _window_pid(hwnd: int) -> int:
    try:
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        return int(pid.value)
    except Exception:
        return 0


def find_chrome_main(preferred_title: str = "") -> int:
    """Return the Chrome window owned by Adeon's connected DevTools browser whenever possible."""
    exact_pid: list[int] = []
    likely_pid: list[int] = []
    any_pid: list[int] = []
    exact: list[int] = []
    likely: list[int] = []
    want = (preferred_title or "").strip().lower()
    target_pid = int(_debug_chrome_pid or 0)

    def cb(hwnd, _):
        if not _visible(hwnd) or "Chrome_WidgetWin_1" not in _cls(hwnd):
            return True
        h = int(hwnd)
        title = _title(hwnd).lower()
        same_pid = bool(target_pid and _window_pid(h) == target_pid)
        is_exact = bool(want and want in title)
        is_likely = any(k in title for k in (
            "lrwriters", "lr writers", "find orders", "findorders",
            "myaccount", "livingston", "irlwriters", "writer tool"
        ))
        if same_pid:
            any_pid.append(h)
            if is_exact:
                exact_pid.append(h)
            if is_likely:
                likely_pid.append(h)
        if is_exact:
            exact.append(h)
        if is_likely:
            likely.append(h)
        return True

    user32.EnumWindows(EnumWindowsProc(cb), 0)
    # A PID match is strongest. Title is only the fallback when PID discovery fails.
    return (exact_pid or likely_pid or any_pid or exact or likely or [0])[0]


def find_render(parent: int) -> int:
    found: list[int] = []

    def cb(hwnd, _):
        if _cls(hwnd) == "Chrome_RenderWidgetHostHWND" and _visible(hwnd):
            found.append(int(hwnd))
        return True

    if parent:
        user32.EnumChildWindows(parent, EnumWindowsProc(cb), 0)
    best, area = 0, 0
    for h in found:
        r = RECT()
        user32.GetClientRect(h, ctypes.byref(r))
        a = max(0, r.right - r.left) * max(0, r.bottom - r.top)
        if a > area:
            best, area = h, a
    return best


def render_origin(hwnd: int) -> tuple[int, int]:
    pt = POINT(0, 0)
    user32.ClientToScreen(hwnd, ctypes.byref(pt))
    return int(pt.x), int(pt.y)


def focus_hwnd(hwnd: int) -> None:
    """Bring Chrome forward without changing its size/state or synthesizing Alt keys."""
    if not hwnd:
        return
    attached = []
    try:
        fg = int(user32.GetForegroundWindow() or 0)
        fg_tid = int(user32.GetWindowThreadProcessId(fg, None) or 0)
        target_tid = int(user32.GetWindowThreadProcessId(hwnd, None) or 0)
        my_tid = int(kernel32.GetCurrentThreadId())
        for tid in {fg_tid, target_tid}:
            if tid and tid != my_tid:
                try:
                    if user32.AttachThreadInput(my_tid, tid, True):
                        attached.append(tid)
                except Exception:
                    pass

        # IMPORTANT: SW_RESTORE (9) was restoring a maximized browser immediately
        # before a click. That changed the viewport after the DOM coordinates had
        # already been read and caused the mouse to tap the wrong place.
        if bool(user32.IsIconic(hwnd)):
            user32.ShowWindow(hwnd, 9)  # restore only when genuinely minimized
        else:
            user32.ShowWindow(hwnd, 5)  # SW_SHOW; preserve current size/state

        user32.BringWindowToTop(hwnd)
        user32.SetForegroundWindow(hwnd)
    except Exception:
        try:
            if bool(user32.IsIconic(hwnd)):
                user32.ShowWindow(hwnd, 9)
            else:
                user32.ShowWindow(hwnd, 5)
            user32.BringWindowToTop(hwnd)
            user32.SetForegroundWindow(hwnd)
        except Exception:
            pass
    finally:
        try:
            my_tid = int(kernel32.GetCurrentThreadId())
            for tid in attached:
                user32.AttachThreadInput(my_tid, tid, False)
        except Exception:
            pass


def _root_window_at(x: int, y: int) -> int:
    """Return the top-level window that would receive a physical click at x,y."""
    try:
        pt = POINT(int(x), int(y))
        hit = int(user32.WindowFromPoint(pt) or 0)
        if not hit:
            return 0
        return int(user32.GetAncestor(hit, GA_ROOT) or hit)
    except Exception:
        return 0


def _prepare_chrome_for_physical_click(main: int, x: int, y: int, label: str) -> bool:
    """Temporarily put Chrome above topmost terminals and verify click ownership."""
    if not main:
        return False
    try:
        if bool(user32.IsIconic(main)):
            user32.ShowWindow(main, 9)
        else:
            user32.ShowWindow(main, 5)
        user32.SetWindowPos(
            main, HWND_TOPMOST, 0, 0, 0, 0,
            SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW,
        )
        focus_hwnd(main)
        time.sleep(0.055)
        root = _root_window_at(x, y)
        if root != int(main):
            occ_title = _title(root) if root else "unknown"
            occ_cls = _cls(root) if root else "unknown"
            shot = capture_diagnostic("click_occluded", min_interval=3.0)
            note_issue(
                "CLICK_OCCLUDED",
                "Physical click was blocked because another window still covered the target",
                "ERROR",
                f"label={label} point=({x},{y}) expected_hwnd={main} actual_hwnd={root} "
                f"actual_class={occ_cls} actual_title={occ_title!r} screenshot={shot}",
                throttle=3.0,
            )
            return False
        return True
    except Exception as e:
        note_issue(
            "CLICK_WINDOW_PREP_FAILED",
            "Could not safely expose Chrome for the physical click",
            "ERROR",
            str(e),
            throttle=3.0,
        )
        return False


def _release_chrome_topmost(main: int) -> None:
    if not main:
        return
    try:
        user32.SetWindowPos(
            main, HWND_NOTOPMOST, 0, 0, 0, 0,
            SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW,
        )
    except Exception:
        pass

def install_ctrl_c() -> None:
    global _ctrl_handler_ref
    try:
        signal.signal(signal.SIGINT, request_stop)
    except Exception:
        pass
    if sys.platform == "win32":
        try:
            signal.signal(signal.SIGBREAK, request_stop)
        except Exception:
            pass
        Handler = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_uint)

        def _handler(ctrl):
            request_stop()
            return True

        _ctrl_handler_ref = Handler(_handler)
        kernel32.SetConsoleCtrlHandler(_ctrl_handler_ref, True)


def request_alt_s_toggle() -> None:
    """Alt+S is the only normal bot control: START when stopped, STOP when active."""
    global _stop, _stop_reason, _controller_active
    with _controller_lock:
        active = bool(_controller_active and _controller_worker and _controller_worker.is_alive())
        if active:
            _stop_reason = "Alt+S stop requested"
            _stop = True
            # Show the requested red STOPPED state immediately. The worker then
            # finishes its cleanup/report without performing another web action.
            set_status_ticket(bot="STOPPED", page="OFF", job="-", f5="OFF", mouse="OFF")
            log("ALT+S: STOP requested. Bot web activity is stopping now.")
        else:
            _controller_start_requested.set()
            log("ALT+S: START requested.")


def start_alt_s_monitor() -> threading.Thread:
    """Reserve Alt+S globally so the same key combination toggles START/STOP."""
    HOTKEY_ID = 0x4C54  # LT
    MOD_ALT = 0x0001
    MOD_NOREPEAT = 0x4000
    VK_S = 0x53
    WM_HOTKEY = 0x0312

    def worker() -> None:
        registered = False
        try:
            registered = bool(user32.RegisterHotKey(None, HOTKEY_ID, MOD_ALT | MOD_NOREPEAT, VK_S))
            if not registered:
                log("ERROR: Could not reserve Alt+S globally. Another program may already own that hotkey.")
                return
            msg = MSG()
            while not _controller_exit.is_set():
                result = int(user32.GetMessageW(ctypes.byref(msg), None, 0, 0))
                if result <= 0:
                    break
                if int(msg.message) == WM_HOTKEY and int(msg.wParam) == HOTKEY_ID:
                    request_alt_s_toggle()
        except Exception as e:
            log(f"ERROR: Global Alt+S monitor failed: {e}")
        finally:
            if registered:
                try:
                    user32.UnregisterHotKey(None, HOTKEY_ID)
                except Exception:
                    pass

    t = threading.Thread(target=worker, name="LR-AltS-StartStop", daemon=True)
    t.start()
    return t


# ---------------- brain (DOM) ----------------
SCAN_JS = ""  # 1.0.69: DOM/extension script path removed; Screen Vision/UIA only.


def chrome_user_data_dirs() -> list[Path]:
    """Likely DevTools user-data roots, with Adeon's managed Chrome first."""
    local = Path(os.environ.get("LOCALAPPDATA", ""))
    candidates = [
        _ADEON_CHROME_DATA,
        local / "Google" / "Chrome" / "User Data",
        local / "Google" / "Chrome Beta" / "User Data",
        local / "Google" / "Chrome Dev" / "User Data",
        local / "Google" / "Chrome SxS" / "User Data",
    ]
    out: list[Path] = []
    seen: set[str] = set()
    for item in candidates:
        key = os.path.normcase(os.path.abspath(str(item)))
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    return out


def _endpoint_http_live(port: int) -> bool:
    if int(port or 0) <= 0:
        return False
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{int(port)}/json/version", timeout=1.5) as r:
            return 200 <= int(getattr(r, "status", 200)) < 500
    except Exception:
        return False


def discover_chrome_debug_endpoint() -> tuple[str, int, str]:
    """Find a live local Chrome DevTools endpoint without navigating the browser."""
    global _debug_port, _debug_endpoint, _debug_user_data_dir

    for user_dir in chrome_user_data_dirs():
        active = user_dir / "DevToolsActivePort"
        try:
            if not active.is_file():
                continue
            lines = [x.strip() for x in active.read_text(encoding="utf-8", errors="ignore").splitlines() if x.strip()]
            if len(lines) < 2:
                continue
            port = int(lines[0])
            path = lines[1]
            if not (1 <= port <= 65535) or not path.startswith("/"):
                continue
            if not _endpoint_http_live(port):
                continue
            endpoint = f"ws://127.0.0.1:{port}{path}"
            _debug_port = port
            _debug_endpoint = endpoint
            _debug_user_data_dir = str(user_dir)
            return endpoint, port, str(user_dir)
        except Exception:
            continue

    # Compatibility fallback for a manually configured Chrome.
    if _endpoint_http_live(9222):
        try:
            with urllib.request.urlopen("http://127.0.0.1:9222/json/version", timeout=1.5) as r:
                info = json.loads(r.read().decode("utf-8", "ignore") or "{}")
            endpoint = str(info.get("webSocketDebuggerUrl") or "http://127.0.0.1:9222")
        except Exception:
            endpoint = "http://127.0.0.1:9222"
        _debug_port = 9222
        _debug_endpoint = endpoint
        _debug_user_data_dir = "manual-9222"
        return endpoint, 9222, "manual-9222"

    _debug_port = 0
    _debug_endpoint = ""
    _debug_user_data_dir = ""
    return "", 0, ""


def _legacy_chrome_port_live() -> bool:
    endpoint, port, _ = discover_chrome_debug_endpoint()
    return bool(endpoint and port)


def find_chrome_exe() -> str:
    for path in (
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
    ):
        if os.path.isfile(path):
            return path
    return ""


def _chrome_browser_commandline() -> str:
    """Best-effort command line for Chrome's browser process (not renderer children)."""
    try:
        ps = (
            "$p=Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'chrome.exe' -and "
            "$_.CommandLine -and $_.CommandLine -notmatch '--type=' } | Select-Object -First 1; "
            "if($p){[Console]::Write($p.CommandLine)}"
        )
        cp = subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, timeout=4,
            creationflags=0x08000000,
        )
        return (cp.stdout or "").strip()
    except Exception:
        return ""


def _extract_switch(commandline: str, name: str) -> str:
    text = str(commandline or "")
    # Supports --name=value, --name="value with spaces", and --name value.
    patterns = [
        rf'--{re.escape(name)}=(?:"([^"]+)"|([^\s]+))',
        rf'--{re.escape(name)}\s+(?:"([^"]+)"|([^\s]+))',
    ]
    for pattern in patterns:
        m = re.search(pattern, text, re.I)
        if m:
            return next((g for g in m.groups() if g), "")
    return ""


def _active_chrome_root_and_profile() -> tuple[Path | None, str]:
    """Return the user-data root/profile of the Chrome browser process that is open now."""
    cmd = _chrome_browser_commandline()
    user_arg = _extract_switch(cmd, "user-data-dir")
    profile_arg = _extract_switch(cmd, "profile-directory")
    local = Path(os.environ.get("LOCALAPPDATA", ""))
    root = Path(os.path.expandvars(user_arg)).expanduser() if user_arg else (local / "Google" / "Chrome" / "User Data")
    if not root.exists():
        return None, profile_arg.strip() or "Default"
    profile = profile_arg.strip() if profile_arg else ""
    if not profile:
        try:
            state = json.loads((root / "Local State").read_text(encoding="utf-8", errors="ignore"))
            profile = str(((state.get("profile") or {}).get("last_used")) or "Default").strip()
        except Exception:
            profile = "Default"
    if not profile or not (root / profile).exists():
        profile = "Default" if (root / "Default").exists() else (profile or "Default")
    return root, profile


def _normal_chrome_root_and_profile() -> tuple[Path | None, str]:
    """Locate the Chrome profile the user was using before Adeon restarts Chrome."""
    cmd = _chrome_browser_commandline()
    user_arg = _extract_switch(cmd, "user-data-dir")
    profile_arg = _extract_switch(cmd, "profile-directory")

    candidates: list[Path] = []
    if user_arg:
        candidates.append(Path(os.path.expandvars(user_arg)).expanduser())
    local = Path(os.environ.get("LOCALAPPDATA", ""))
    candidates.extend([
        local / "Google" / "Chrome" / "User Data",
        local / "Google" / "Chrome Beta" / "User Data",
        local / "Google" / "Chrome Dev" / "User Data",
        local / "Google" / "Chrome SxS" / "User Data",
    ])

    root = next((x for x in candidates if x.exists() and x.resolve() != _ADEON_CHROME_DATA.resolve()), None)
    if root is None:
        return None, "Default"

    profile = profile_arg.strip() if profile_arg else ""
    if not profile:
        try:
            state = json.loads((root / "Local State").read_text(encoding="utf-8", errors="ignore"))
            profile = str(((state.get("profile") or {}).get("last_used")) or "Default").strip()
        except Exception:
            profile = "Default"
    if not profile or not (root / profile).exists():
        profile = "Default" if (root / "Default").exists() else profile
    return root, profile or "Default"


def _chrome_running() -> bool:
    try:
        cp = subprocess.run(
            ["tasklist", "/FI", "IMAGENAME eq chrome.exe", "/FO", "CSV", "/NH"],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, timeout=3,
            creationflags=0x08000000,
        )
        out = (cp.stdout or "").lower()
        return "chrome.exe" in out
    except Exception:
        return False


def _close_chrome_windows_gracefully() -> None:
    """Ask visible Chrome windows to close so session/cookies are flushed before cloning."""
    try:
        WM_CLOSE = 0x0010
        EnumProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)

        def callback(hwnd, _lparam):
            try:
                cls = ctypes.create_unicode_buffer(256)
                user32.GetClassNameW(hwnd, cls, len(cls))
                if cls.value == "Chrome_WidgetWin_1" and user32.IsWindowVisible(hwnd):
                    user32.PostMessageW(hwnd, WM_CLOSE, 0, 0)
            except Exception:
                pass
            return True

        user32.EnumWindows(EnumProc(callback), 0)
    except Exception as e:
        log(f"Could not send Chrome a graceful close request: {e}")


def _wait_chrome_closed(timeout: float) -> bool:
    deadline = time.time() + max(0.5, timeout)
    while time.time() < deadline:
        if not _chrome_running():
            return True
        time.sleep(0.35)
    return not _chrome_running()


def _copy_profile_tree(source_root: Path, profile_name: str) -> bool:
    """Fast one-time bootstrap of login/session data into Adeon's CDP profile.

    The older build copied almost the whole Chrome profile and could spend minutes
    on cache, extensions, history, and other data Adeon does not need.  For the
    LR Writers hand-off we only copy the pieces that can carry the current profile
    identity, cookies/site storage and session state.  The user's original Chrome
    profile is never modified.
    """
    source_profile = source_root / profile_name
    if not source_profile.exists():
        log(f"Chrome profile bootstrap source is missing: {source_profile}")
        return False

    try:
        if _ADEON_CHROME_MARKER.exists() and (_ADEON_CHROME_DATA / profile_name).exists():
            log(f"Adeon Chrome profile already prepared ({profile_name}); preserving its current login/session.")
            return True
    except Exception:
        pass

    try:
        set_status_ticket(bot="STARTING", page="PREPARING CHROME", job="-", f5="OFF", mouse="OFF")
        started = time.time()
        log(f"Preparing fast Adeon Chrome profile from {source_profile}")
        _ADEON_CHROME_DATA.mkdir(parents=True, exist_ok=True)
        target_profile = _ADEON_CHROME_DATA / profile_name
        target_profile.mkdir(parents=True, exist_ok=True)

        # Chrome's encryption/profile metadata.  On the same Windows account this
        # lets the copied Cookies database remain usable when Chrome permits it.
        local_state = source_root / "Local State"
        if local_state.exists():
            try:
                shutil.copy2(local_state, _ADEON_CHROME_DATA / "Local State")
            except Exception as e:
                log(f"Fast profile copy skipped Local State while Chrome is live: {e}")

        # Small profile files that can matter for identity/login/site behavior.
        files = (
            "Preferences", "Secure Preferences", "Cookies", "Cookies-journal",
            "Login Data", "Login Data-journal", "Login Data For Account",
            "Web Data", "Web Data-journal", "Shortcuts", "Top Sites",
        )
        for name in files:
            src = source_profile / name
            dst = target_profile / name
            try:
                if src.is_file():
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(src, dst)
            except Exception as e:
                log(f"Fast profile copy skipped {name}: {e}")

        # Site/session storage.  These are normally far smaller than a full Chrome
        # profile and are the parts most likely to matter to an already logged-in
        # LR Writers session.
        dirs = (
            "Network", "Local Storage", "Session Storage", "Sessions", "WebStorage",
        )
        ignore = shutil.ignore_patterns(
            "Cache", "Code Cache", "GPUCache", "DawnCache", "GrShaderCache", "ShaderCache",
            "Crashpad", "BrowserMetrics", "Media Cache", "LOCK", "lockfile", "Singleton*", "*.tmp"
        )
        for name in dirs:
            src = source_profile / name
            dst = target_profile / name
            try:
                if src.is_dir():
                    shutil.copytree(src, dst, dirs_exist_ok=True, ignore=ignore)
            except Exception as e:
                log(f"Fast profile copy skipped {name}: {e}")

        # Copy only LR Writers-specific IndexedDB entries when present instead of
        # cloning every site's database. This keeps first activation fast.
        idx_src = source_profile / "IndexedDB"
        idx_dst = target_profile / "IndexedDB"
        try:
            if idx_src.is_dir():
                for child in idx_src.iterdir():
                    low = child.name.lower()
                    if "lrwriters" not in low and "liv-research" not in low:
                        continue
                    if child.is_dir():
                        shutil.copytree(child, idx_dst / child.name, dirs_exist_ok=True, ignore=ignore)
                    elif child.is_file():
                        idx_dst.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(child, idx_dst / child.name)
        except Exception as e:
            log(f"Fast profile copy skipped LR Writers IndexedDB: {e}")

        _write_json_atomic(_ADEON_CHROME_MARKER, {
            "source_root": str(source_root),
            "profile": profile_name,
            "prepared_at": time.time(),
            "mode": "fast-login-session-copy-v3-localappdata",
        })
        elapsed = time.time() - started
        log(f"Adeon Chrome profile prepared successfully in {elapsed:.1f}s: {target_profile}")
        return True
    except Exception as e:
        write_last_error("Adeon could not prepare the Chrome profile. See VIEW ACTIVITY LOG.")
        log(f"Chrome profile bootstrap failed: {e}")
        note_issue("CHROME_PROFILE_COPY", "Could not prepare Chrome profile for DevTools restart", "ERROR", str(e), throttle=0)
        return False


def _sync_latest_tabs_into_adeon(source_root: Path | None, source_profile_name: str, target_profile_name: str) -> None:
    """Copy only Chrome's just-flushed tab/session files into Adeon's managed profile.

    This is used when Adeon must restart a normal Chrome window for DevTools. It
    preserves the user's currently open work without replacing the rest of the
    already-prepared Adeon profile.
    """
    if source_root is None:
        return
    try:
        if source_root.resolve() == _ADEON_CHROME_DATA.resolve():
            return
    except Exception:
        pass
    source_profile = source_root / (source_profile_name or "Default")
    target_profile = _ADEON_CHROME_DATA / (target_profile_name or "Default")
    if not source_profile.exists() or not target_profile.exists():
        return
    try:
        src_sessions = source_profile / "Sessions"
        dst_sessions = target_profile / "Sessions"
        if src_sessions.is_dir():
            shutil.rmtree(dst_sessions, ignore_errors=True)
            shutil.copytree(src_sessions, dst_sessions, dirs_exist_ok=True)
        # Older Chrome builds/profile layouts can still expose these legacy files.
        for name in ("Current Session", "Current Tabs", "Last Session", "Last Tabs"):
            src = source_profile / name
            dst = target_profile / name
            if src.is_file():
                shutil.copy2(src, dst)
        log(f"Chrome tab/session state copied into Adeon profile from {source_profile}.")
    except Exception as e:
        log(f"Chrome tab/session sync skipped: {e}")


def _prepared_profile_name(default: str = "Default") -> str:
    try:
        data = json.loads(_ADEON_CHROME_MARKER.read_text(encoding="utf-8"))
        name = str(data.get("profile") or "").strip()
        if name and (_ADEON_CHROME_DATA / name).exists():
            return name
    except Exception:
        pass
    return default or "Default"


def chrome_port_live() -> bool:
    # Screen Vision / Windows accessibility only.
    return _vision_live(max_age=3.0) or _uia_feed_live(max_age=3.0)


def start_chrome(start_url: str = FIND_ORDERS, force_restart: bool = False) -> bool:
    """Hard safety lock: Adeon never launches/restarts Chrome or Thorium."""
    write_last_error(
        "Adeon will not open a browser. Open LR Writers in your existing Chrome or Thorium and Adeon will attach there."
    )
    note_issue(
        "CHROME_LAUNCH_BLOCKED",
        "A request to launch a browser was blocked by the existing-browser safety lock",
        "ERROR",
        throttle=0,
    )
    log("EXISTING BROWSER SAFETY: browser launch/restart request blocked.")
    return False


class Brain:
    """Screen Vision / Windows-accessibility reader for the already-open LR Writers browser."""
    def __init__(self) -> None:
        self._tab_id = 0
        self._window_id = 0
        self._last_record: dict = {}
        self._label_reload_pending = False
        self._labels_enabled = False
        self._using_uia = False
        self._using_vision = False
        self._uia_hwnd = 0
        self._labels_uia_probe_started = False
        # Hidden read-only reservation verifier only. This never opens a visible
        # Chrome window/profile and is not used for picker/labels interaction.
        self._pw = None
        self._probe_browser = None
        self._probe_context = None
        self._probe_page = None

    def _select(self) -> dict | None:
        # Labels are latency-sensitive. Windows Accessibility is the primary
        # read-only identity/page feed in labels mode because it updates in ~90 ms
        # and does not wait for OCR. Screen Vision is only a fallback when the
        # accessibility snapshot is unavailable/stale.
        if _LABELS_ONLY_MODE and self._using_uia:
            try:
                uia = _uia_read_snapshot(self._uia_hwnd) or {}
            except Exception:
                uia = {}
            if uia:
                rec = {
                    "tabId": 0, "windowId": int(self._uia_hwnd or 0),
                    "received_at": float(uia.get("uiaTs") or time.time()),
                    "url": str(uia.get("url") or ""),
                    "title": str(uia.get("pageTitle") or ""),
                    "snap": uia, "source": "windows-accessibility-fast-labels",
                }
                self._last_record = rec
                return rec
            if self._using_vision:
                vision = _vision_read_snapshot(self._uia_hwnd)
                if vision:
                    rec = {
                        "tabId": 0, "windowId": int(self._uia_hwnd or 0),
                        "received_at": float(vision.get("uiaTs") or time.time()),
                        "url": str(vision.get("url") or ""),
                        "title": str(vision.get("pageTitle") or ""),
                        "snap": vision, "source": "screen-vision-label-fallback",
                    }
                    self._last_record = rec
                    return rec
            return None

        if self._using_vision:
            vision = _vision_read_snapshot(self._uia_hwnd)
            if vision:
                rec = {
                    "tabId": 0, "windowId": int(self._uia_hwnd or 0),
                    "received_at": float(vision.get("uiaTs") or time.time()),
                    "url": str(vision.get("url") or ""),
                    "title": str(vision.get("pageTitle") or ""),
                    "snap": vision, "source": "screen-vision",
                }
                self._last_record = rec
                return rec
            return None

        if self._using_uia:
            snap = _uia_read_snapshot(self._uia_hwnd)
            if snap:
                rec = {
                    "tabId": 0, "windowId": int(self._uia_hwnd or 0),
                    "received_at": float(snap.get("uiaTs") or time.time()),
                    "url": str(snap.get("url") or ""),
                    "title": str(snap.get("pageTitle") or ""),
                    "snap": snap, "source": "windows-accessibility",
                }
                self._last_record = rec
                return rec
            return None
        return None

    def attach(self) -> bool:
        # Both Picker and Labels now use the same browser-independent Screen Vision
        # feed first. Labels are rendered by Adeon as Windows overlay controls, not
        # injected into LR Writers, so Browser Integration is no longer required.
        if True:
            hwnd = find_chrome_main("writer tool") or find_chrome_main("lr writers") or find_chrome_main("myaccount")
            if hwnd:
                if _LABELS_ONLY_MODE:
                    # 1.0.69 fast labels attach: start the 90 ms Windows Accessibility
                    # feed first. This avoids blocking label appearance/disappearance on
                    # a multi-second OCR pass. Screen Vision remains fallback-only.
                    log(f"LABELS FAST ATTACH: starting Windows Accessibility first for hwnd={hwnd}; OCR is fallback-only.")
                    if _uia_start_feed(int(hwnd)):
                        self._using_uia = True
                        self._using_vision = True
                        self._uia_hwnd = int(hwnd)
                        self._labels_uia_probe_started = True
                        deadline = time.time() + 4.0
                        while time.time() < deadline and not _stop:
                            snap = _uia_read_snapshot(self._uia_hwnd) or {}
                            useful = bool(
                                snap and (
                                    snap.get("url") or snap.get("rows") or snap.get("onMyOrders")
                                    or snap.get("onFind") or snap.get("loggedOut")
                                )
                            )
                            if useful:
                                log("LABELS FAST FEED READY: Windows Accessibility is primary; expected page/row reaction is sub-second.")
                                return True
                            time.sleep(0.05)
                        log("LABELS FAST FEED: accessibility warmup did not become useful in time; falling back to Screen Vision.")
                log(("SCREEN VISION LABELS" if _LABELS_ONLY_MODE else "SCREEN VISION PICKER") + ": reading the already-open browser from visible pixels; no Browser Integration heartbeat is required.")
                if not _LABELS_ONLY_MODE:
                    try:
                        focus_hwnd(int(hwnd))
                        time.sleep(0.18)
                    except Exception:
                        pass
                snap = _vision_read_snapshot(int(hwnd), force=True)
                useful = bool(snap and (snap.get("onFind") or snap.get("onMyOrders") or snap.get("navFind") or snap.get("rows") or snap.get("panelOpen")))
                if snap and useful:
                    self._using_vision = True
                    self._using_uia = True  # reuse the existing verified physical-screen click path
                    self._uia_hwnd = int(hwnd)
                    body_sample = re.sub(r"\s+", " ", str(snap.get("bodyTextExcerpt") or ""))[:180]
                    log(f"SCREEN VISION FEED READY: Windows OCR read the existing browser hwnd={hwnd}; sample={body_sample}")
                    if _LABELS_ONLY_MODE:
                        self._using_uia = True
                        if not self._labels_uia_probe_started:
                            self._labels_uia_probe_started = True
                            def _labels_uia_probe():
                                ok=False
                                try: ok=bool(_uia_start_feed(int(hwnd)))
                                except Exception: ok=False
                                if ok:
                                    log("LABEL IDENTITY BACKUP READY: Windows Accessibility is running beside Screen Vision to recover exact Order Numbers missed by OCR.")
                                else:
                                    log("LABEL IDENTITY BACKUP: Windows Accessibility was unavailable; Screen Vision identity tracking remains active.")
                            threading.Thread(target=_labels_uia_probe,name="AdeonLabelIdentityUIA",daemon=True).start()
                        log("SCREEN VISION LABELS READY: compact Windows overlay + dual Screen Vision/Accessibility identity tracking; LR DOM is not modified.")
                        return True
                    log("SCREEN VISION SAFETY: the LR browser must be foreground; Reserve/Accept/Reject require exact button text plus a verified LR order-detail context; 'Show reserved' can never count as Reserve.")
                    if not bool(snap.get("onFind")):
                        log("SCREEN VISION PICKER WAIT: LR is not on Find Orders. Adeon will not navigate, type, click, move the mouse, or F5 until the user returns to Find Orders.")
                    else:
                        send_f5(self)
                        time.sleep(0.45)
                    log("EXISTING BROWSER: Picker is using Screen Vision + native mouse/keyboard in the already-open browser.")
                    return True
                if snap:
                    sample=re.sub(r"\s+", " ", str(snap.get("bodyTextExcerpt") or ""))[:220]
                    log(f"SCREEN VISION: OCR is working but LR page state is not yet recognized. sample={sample}")
                else:
                    log("SCREEN VISION: no usable OCR snapshot yet; trying Windows accessibility as a secondary fallback.")

            if hwnd and _uia_start_feed(hwnd):
                self._using_uia = True
                self._uia_hwnd = int(hwnd)
                deadline = time.time() + 14.0
                snap = {}
                warmup_logged = False
                first_snapshot_at = 0.0
                while time.time() < deadline and not _stop:
                    current = _uia_read_snapshot(self._uia_hwnd)
                    if current:
                        snap = current
                        if not first_snapshot_at:
                            first_snapshot_at = time.time()
                        useful = bool(
                            current.get("onFind") or current.get("onMyOrders") or current.get("navFind")
                            or current.get("rows") or current.get("panelOpen")
                        )
                        if useful:
                            break
                        if not warmup_logged and time.time() - first_snapshot_at >= 1.5:
                            warmup_logged = True
                            log("WINDOWS ACCESSIBILITY WARMUP: browser chrome is visible; waiting for Chromium to expose the LR page tree before startup continues.")
                    time.sleep(0.15)
                useful = bool(
                    snap and (snap.get("onFind") or snap.get("onMyOrders") or snap.get("navFind")
                              or snap.get("rows") or snap.get("panelOpen"))
                )
                if snap and useful:
                    log(f"WINDOWS ACCESSIBILITY FEED READY: attached read-only to existing browser hwnd={self._uia_hwnd}; no extension/DevTools/browser restart is required.")
                    if _LABELS_ONLY_MODE:
                        log("EXISTING BROWSER: Labels are using the read-only Windows accessibility feed as a Screen Vision fallback.")
                        return True
                    if not bool(snap.get("onFind")):
                        log("PICKER START WAIT: LR is not on Find Orders. Adeon is attached but leaves the user's page, keyboard, mouse, and URL untouched until Find Orders returns.")
                    else:
                        send_f5(self)
                        time.sleep(0.45)
                    log("EXISTING BROWSER: Picker is using the read-only Windows accessibility feed in the already-open browser.")
                    return True
                _uia_stop_feed()

            # 1.0.69 is deliberately script-free with respect to LR Writers.
            # If Screen Vision and Windows accessibility are both unavailable, fail
            # closed rather than injecting/using a browser content script.
            write_last_error("Adeon could not read LR Writers through Screen Vision or Windows accessibility. No browser-extension path is present in 1.0.69.")
            set_status_ticket(bot="STOPPED", page="WAITING LR WRITERS", job=("LABEL" if _LABELS_ONLY_MODE else "SEARCHING"), f5="OFF", mouse="OFF")
            log("SCREEN VISION/UIA unavailable. No LR webpage script was injected.")
            return False


    def prepare_labels_tab(self, *, reload_current: bool = False) -> bool:
        rec = self._select()
        if not rec:
            return False
        snap = rec.get("snap") if isinstance(rec.get("snap"), dict) else {}
        self._labels_enabled = True

        # STRICTLY PASSIVE: starting Labels never F5s, navigates, types a URL,
        # changes tabs, or moves the mouse. The overlay appears only after the
        # exact My Orders / In Progress or Revisions URL is positively observed.
        url=str(snap.get("url") or "").lower()
        exact_my=bool(re.search(r"^https?://myaccount\.lrwriters\.com/myorders/(?:inprogress|revisions?)(?:[/?#]|$)",url,re.I))

        if self._using_vision or self._using_uia:
            self._label_reload_pending=False
            if exact_my:
                log("LABELS READY: My Orders / In Progress or Revisions is already open; no refresh or navigation was performed.")
            else:
                log("LABELS WAIT: return to My Orders / In Progress or Revisions when ready. Adeon will not touch browser navigation for Labels.")
            return True

    def apply_label_state(self, state: dict | None) -> bool:
        # Native Windows overlay owns all label rendering; nothing is injected into LR.
        self._labels_enabled = True
        return True

    def reconnect_cdp(self) -> bool:
        # Compatibility name retained for the existing health loop. Recover only
        # Screen Vision / Windows accessibility in place; never use a browser bridge.
        if self._using_vision:
            snap = _vision_read_snapshot(self._uia_hwnd, force=True)
            if snap:
                log("SCREEN VISION FEED: recovered in place; browser was not restarted.")
                return True
            return False
        if self._using_uia:
            if _uia_feed_live(2.5):
                log("WINDOWS ACCESSIBILITY FEED: recovered in place; browser was not restarted.")
                return True
            if self._uia_hwnd and _uia_start_feed(self._uia_hwnd):
                log("WINDOWS ACCESSIBILITY FEED: restarted locally; browser was not restarted.")
                return True
        return False

    def _chrome_cookies(self) -> list[dict]:
        return []


    def _ensure_probe_page(self) -> bool:
        # Current Adeon never launches a second/headless browser process.
        return False

    def _close_probe(self) -> None:
        self._probe_page = None
        self._probe_context = None
        self._probe_browser = None
        self._pw = None

    def fresh_reservation_probe(self, public_id: str, internal_id: str = "") -> dict:
        """No hidden browser fetches in Screen Vision-only mode; live visible checks remain authoritative."""
        return {"status": "unknown", "reason": "Screen Vision / Windows accessibility mode"}

    def maximize(self) -> None:
        # Keep the user's normal Chrome size/state. Only restore it if it is minimized.
        try:
            rec = self._select() or {}
            snap = rec.get("snap") if isinstance(rec.get("snap"), dict) else {}
            title = str(snap.get("pageTitle") or rec.get("title") or "")
            main = find_chrome_main(title)
            if main and bool(user32.IsIconic(main)):
                user32.ShowWindow(main, 9)
        except Exception:
            pass

    def reconnect(self) -> None:
        self._select()

    def read(self) -> dict:
        rec = self._select()
        if not rec:
            record_stat("brain_read_errors")
            return {}
        snap = dict(rec.get("snap") or {})
        snap.setdefault("url", str(rec.get("url") or ""))
        snap.setdefault("pageTitle", str(rec.get("title") or ""))
        snap["readerTabId"] = int(rec.get("tabId") or 0)
        snap["readerWindowId"] = int(rec.get("windowId") or 0)
        snap["readerReceivedAt"] = float(rec.get("received_at") or 0.0)
        record_stat("screen_reads")

        return snap

    def stay_on_find_orders(self) -> None:
        return

    def activate(self) -> str:
        rec = self._select()
        if not rec:
            return ""
        title = str((rec.get("snap") or {}).get("pageTitle") or rec.get("title") or "")
        if self._using_uia and not _LABELS_ONLY_MODE:
            try:
                main = int(self._uia_hwnd or 0) or find_chrome_main(title)
                if main:
                    focus_hwnd(main)
            except Exception:
                pass
            return title
        return title

    def validate_click(self, pos: dict | None, kind: str) -> bool:
        # Final safety invariant: Adeon never physically clicks Reject. Midnight
        # behavior is advisory only and uses warning cues + normal alerts.
        if str(kind or "").lower() == "midnight_reject":
            return False
        if not pos:
            return False
        rec = self._select()
        if not rec:
            return False
        if self._using_uia and not _LABELS_ONLY_MODE:
            snap = rec.get("snap") if isinstance(rec.get("snap"), dict) else {}
            current = None
            if kind == "reserve": current = snap.get("reserve")
            elif kind == "midnight_reject": current = snap.get("reject")
            elif kind == "nav_my": current = snap.get("navMy")
            elif kind == "nav_find": current = snap.get("navFind")
            elif kind == "nav_inbox": current = snap.get("navInbox")
            elif kind == "nav_progress": current = snap.get("navProgress")
            elif kind == "files_toggle": current = snap.get("filesToggle")
            elif kind == "still_here": current = snap.get("stillHere")
            elif kind == "row":
                want_order = str(pos.get("orderNo") or "").strip().upper()
                want_text = str(pos.get("text") or "")[:45]
                for row in snap.get("rows") or []:
                    if want_order and str(row.get("orderNo") or "").strip().upper() == want_order:
                        current = row; break
                    if not want_order and want_text and str(row.get("text") or "")[:45] == want_text:
                        current = row; break
            if not current:
                return False
            try:
                x1=float(current.get("screenLeft")); y1=float(current.get("screenTop"))
                x2=x1+float(current.get("screenW")); y2=y1+float(current.get("screenH"))
                sx=float(current.get("sx")); sy=float(current.get("sy"))
                if not (x1 <= sx <= x2 and y1 <= sy <= y2):
                    return False
            except Exception:
                return False
            # Safety invariant: Accept is never a permitted UIA target. Reject remains
            # forbidden except for the legacy explicit kind (currently never scheduled).
            name = str(current.get("uiaName") or "").strip().lower()
            if name in ("accept", "accept order"):
                return False
            if name in ("reject", "reject order") and kind != "midnight_reject":
                return False
            return True
        return False

    def remove_labels(self) -> None:
        # Native overlay teardown is handled by LabelOverlayManager.
        self._labels_enabled = False

    def close(self) -> None:
        try:
            self.remove_labels()
        except Exception:
            pass
        if self._using_uia and not self._using_vision:
            _uia_stop_feed()
        self._close_probe()


# ---------------- motor ----------------
_enum_keep = []


def chrome_handles(preferred_title: str = "") -> tuple[int, int]:
    try:
        main = find_chrome_main(preferred_title)
        rend = find_render(main) if main else 0
        return main, rend
    except Exception:
        return 0, 0


def _screen_rect(hwnd: int) -> tuple[int, int, int, int] | None:
    """Return a window rectangle in physical screen pixels."""
    if not hwnd:
        return None
    try:
        r = RECT()
        if not user32.GetWindowRect(hwnd, ctypes.byref(r)):
            return None
        left, top, right, bottom = int(r.left), int(r.top), int(r.right), int(r.bottom)
        if right <= left or bottom <= top:
            return None
        return left, top, right, bottom
    except Exception:
        return None


def _viewport_mapping(
    inner_w: float, inner_h: float, preferred_title: str = ""
) -> dict | None:
    """
    Map Chrome CSS viewport pixels to physical Windows screen pixels.

    DOM getBoundingClientRect() returns CSS pixels. Windows mouse APIs use
    physical screen pixels. Browser zoom, Windows DPI scaling, and a resized
    window mean those units are not always 1:1.
    """
    try:
        iw, ih = float(inner_w or 0), float(inner_h or 0)
        if iw < 100 or ih < 100:
            return None
        main, rend = chrome_handles(preferred_title)
        if not main or not rend:
            return None
        rr = _screen_rect(rend)
        mr = _screen_rect(main)
        if not rr or not mr:
            return None

        left, top, right, bottom = rr
        rw, rh = float(right - left), float(bottom - top)
        scale_x, scale_y = rw / iw, rh / ih

        # Broad valid range so unusual DPI/zoom settings still work, while
        # rejecting a clearly wrong render widget.
        if not (0.35 <= scale_x <= 3.5 and 0.35 <= scale_y <= 3.5):
            note_issue(
                "BAD_VIEWPORT_SCALE",
                "Physical/CSS viewport scale is not plausible, so mouse mapping was refused",
                "ERROR",
                f"css={iw:.0f}x{ih:.0f} render={rw:.0f}x{rh:.0f} scale={scale_x:.3f},{scale_y:.3f}",
                throttle=5.0,
            )
            return None

        # X and Y can differ slightly because of scrollbars, but a large
        # mismatch usually means we selected the wrong renderer.
        mismatch = abs(scale_x - scale_y) / max(scale_x, scale_y)
        if mismatch > 0.18:
            note_issue(
                "VIEWPORT_SCALE_MISMATCH",
                "Horizontal and vertical viewport scales disagree too much; click mapping was refused",
                "ERROR",
                f"scale_x={scale_x:.3f} scale_y={scale_y:.3f} render={rr} main={mr}",
                throttle=5.0,
            )
            return None

        return {
            "main": int(main),
            "render": int(rend),
            "left": left,
            "top": top,
            "right": right,
            "bottom": bottom,
            "scale_x": scale_x,
            "scale_y": scale_y,
            "inner_w": iw,
            "inner_h": ih,
            "render_rect": rr,
            "main_rect": mr,
        }
    except Exception as e:
        note_issue(
            "VIEWPORT_MAPPING_ERROR",
            "Could not calculate CSS-to-screen mouse mapping",
            "ERROR",
            str(e),
            throttle=5.0,
        )
        return None


def viewport_to_screen(
    vx: float,
    vy: float,
    preferred_title: str = "",
    inner_w: float = 0,
    inner_h: float = 0,
) -> tuple[int, int] | None:
    """Convert a DOM viewport point to a real Windows mouse coordinate."""
    m = _viewport_mapping(inner_w, inner_h, preferred_title)
    if not m:
        return None
    try:
        x = int(round(m["left"] + float(vx) * m["scale_x"]))
        y = int(round(m["top"] + float(vy) * m["scale_y"]))
        # A valid DOM point must map inside the actual renderer.
        if not (m["left"] <= x < m["right"] and m["top"] <= y < m["bottom"]):
            note_issue(
                "MAPPED_POINT_OUTSIDE_RENDER",
                "DOM point mapped outside Chrome's visible page area, so the click was refused",
                "ERROR",
                f"dom=({vx:.1f},{vy:.1f}) screen=({x},{y}) render={m['render_rect']}",
                throttle=3.0,
            )
            return None
        return x, y
    except Exception:
        return None


def _mapped_dom_rect(
    el: dict | None, snap: dict, preferred_title: str = ""
) -> tuple[int, int, int, int] | None:
    """Map a DOM element rectangle to physical screen pixels."""
    if not el:
        return None
    try:
        m = _viewport_mapping(
            float(snap.get("innerW") or 0),
            float(snap.get("innerH") or 0),
            preferred_title,
        )
        if not m:
            return None
        left = float(el.get("left"))
        top = float(el.get("top"))
        width = float(el.get("w") or 0)
        height = float(el.get("h") or 0)
        if width <= 0 or height <= 0:
            return None
        x1 = int(round(m["left"] + left * m["scale_x"]))
        y1 = int(round(m["top"] + top * m["scale_y"]))
        x2 = int(round(m["left"] + (left + width) * m["scale_x"]))
        y2 = int(round(m["top"] + (top + height) * m["scale_y"]))
        return x1, y1, x2, y2
    except Exception:
        return None


def forbidden(x: int, y: int, kind: str, inner_w: float, inner_h: float) -> bool:
    w, h = pyautogui.size()
    if x < 2 or y < 2 or x > w - 2 or y > h - 2:
        return True
    if kind in ("reserve", "midnight_reject"):
        return y < 180
    if kind in ("row", "idle", "files_toggle"):
        return y < 100
    if kind in ("nav_my", "nav_find", "nav_inbox", "nav_progress", "still_here"):
        return y < 35
    return True


def _near_dom_button(
    x: int,
    y: int,
    btn: dict | None,
    snap: dict,
    preferred_title: str,
    margin: int = 12,
) -> bool:
    rect = _mapped_dom_rect(btn, snap, preferred_title)
    if not rect:
        return False
    x1, y1, x2, y2 = rect
    return (x1 - margin) <= x <= (x2 + margin) and (y1 - margin) <= y <= (y2 + margin)



def motor_click(pos: dict | None, label: str, kind: str, snap: dict, brain: Brain) -> bool:
    """Physically click only freshly verified LR Writers action or navigation targets."""
    global _last_click
    if stop_requested_now():
        return False
    if str(kind or "").lower() == "midnight_reject":
        record_stat("click_refusals")
        note_issue("AUTO_REJECT_HARD_BLOCK", "Automatic Reject is permanently disabled; midnight orders keep the normal reservation/alert process", "INFO", str(label or "Reject"), throttle=30.0)
        return False
    if kind not in ("row", "reserve", "nav_my", "nav_find", "nav_inbox", "nav_progress", "files_toggle", "still_here"):
        record_stat("click_refusals")
        note_issue(
            "BLOCKED_CLICK_TYPE",
            "Blocked a forbidden click type",
            "ERROR",
            f"label={label} kind={kind}",
            throttle=0,
        )
        return False
    if not pos:
        record_stat("click_refusals")
        note_issue("NO_CLICK_COORDS", "Target had no usable coordinates", "WARN", label)
        return False

    # Bringing Chrome forward must never resize it. Then take a NEW DOM snapshot
    # so the physical mapping uses the viewport that exists at click time.
    title = brain.activate() or str(snap.get("pageTitle") or "")
    fresh = brain.read()
    if stop_requested_now():
        return False
    if not fresh:
        record_stat("click_refusals")
        note_issue("CLICK_FRESH_READ_FAILED", "Could not refresh DOM state immediately before click", "WARN", label)
        return False

    current = None
    if kind == "reserve":
        current = fresh.get("reserve")
    elif kind == "midnight_reject":
        current = fresh.get("reject")
    elif kind == "nav_my":
        current = fresh.get("navMy")
    elif kind == "nav_find":
        current = fresh.get("navFind")
    elif kind == "nav_inbox":
        current = fresh.get("navInbox")
    elif kind == "nav_progress":
        current = fresh.get("navProgress")
    elif kind == "files_toggle":
        current = fresh.get("filesToggle")
    elif kind == "still_here":
        current = fresh.get("stillHere")
    else:
        want_order = str(pos.get("orderNo") or "").strip().upper()
        want_id = str(pos.get("id") or "")
        want_text = str(pos.get("text") or "")
        for row in fresh.get("rows") or []:
            row_order = str(row.get("orderNo") or "").strip().upper()
            rid = str(row.get("id") or "")
            text = str(row.get("text") or "")
            if want_order and row_order == want_order:
                current = row
                break
            if want_id and rid == want_id:
                current = row
                break
            if not want_order and not want_id and want_text and text[:50] == want_text[:50]:
                current = row
                break

    if not current:
        record_stat("click_refusals")
        note_issue("STALE_TARGET", "Target disappeared or moved before click, so the click was blocked", "WARN", label)
        return False

    pos = current
    snap = fresh
    title = str(snap.get("pageTitle") or title)

    if not brain.validate_click(pos, kind):
        record_stat("click_refusals")
        note_issue("STALE_TARGET", "Fresh target did not validate in the active page reader, so the click was blocked", "WARN", label)
        return False

    inner_w = float(snap.get("innerW") or 0)
    inner_h = float(snap.get("innerH") or 0)
    using_uia = bool(snap.get("uia") or pos.get("uia"))
    vx = vy = 0.0
    if using_uia:
        try:
            x = int(round(float(pos.get("sx"))))
            y = int(round(float(pos.get("sy"))))
            tx1 = int(round(float(pos.get("screenLeft"))))
            ty1 = int(round(float(pos.get("screenTop"))))
            tx2 = int(round(tx1 + float(pos.get("screenW"))))
            ty2 = int(round(ty1 + float(pos.get("screenH"))))
            target_rect = (tx1, ty1, tx2, ty2)
        except Exception:
            record_stat("click_refusals")
            note_issue("UIA_SCREEN_POINT_MISSING", "Windows accessibility target had no usable screen rectangle", "ERROR", label)
            return False
        main = int(snap.get("uiaHwnd") or getattr(brain, "_uia_hwnd", 0) or find_chrome_main(title) or 0)
        main_rect = _screen_rect(main)
        if not main_rect:
            record_stat("click_refusals")
            note_issue("UIA_BROWSER_WINDOW_MISSING", "The existing browser window could not be verified before click", "ERROR", label)
            return False
    else:
        try:
            vx, vy = float(pos.get("vx")), float(pos.get("vy"))
        except Exception:
            record_stat("click_refusals")
            note_issue("NO_VIEWPORT_POINT", "Fresh target had no usable center point", "WARN", label)
            return False
        mapped = viewport_to_screen(vx, vy, title, inner_w, inner_h)
        if not mapped:
            record_stat("click_refusals")
            note_issue("NO_SAFE_CLICK_POINT", "Could not map the DOM target to a physical screen point", "ERROR", label)
            return False
        x, y = mapped
        target_rect = _mapped_dom_rect(pos, snap, title)
        if not target_rect:
            record_stat("click_refusals")
            note_issue("TARGET_RECT_MAPPING_FAILED", "Could not map the target rectangle to the screen", "ERROR", label)
            return False
        mapping = _viewport_mapping(inner_w, inner_h, title)
        if not mapping:
            record_stat("click_refusals")
            return False
        main = int(mapping["main"])
        main_rect = mapping["main_rect"]

    if forbidden(x, y, kind, inner_w, inner_h):
        record_stat("click_refusals")
        note_issue("FORBIDDEN_CLICK_POINT", "Mapped point failed the screen safety bounds", "ERROR", f"{label} ({x},{y})")
        return False

    tx1, ty1, tx2, ty2 = target_rect
    if not (tx1 <= x <= tx2 and ty1 <= y <= ty2):
        record_stat("click_refusals")
        note_issue(
            "TARGET_CENTER_OUTSIDE_RECT",
            "Calculated click point was not inside the target's physical rectangle",
            "ERROR",
            f"label={label} point=({x},{y}) rect={target_rect}",
            throttle=0,
        )
        return False

    # Accept is never a physical target. Reject remains blocked except for the
    # explicit legacy reject kind. UIA checks use physical accessibility rectangles.
    def near_target(btn: dict | None, margin: int = 12) -> bool:
        if not btn:
            return False
        if using_uia or btn.get("uia"):
            try:
                bx1=float(btn.get("screenLeft")); by1=float(btn.get("screenTop"))
                bx2=bx1+float(btn.get("screenW")); by2=by1+float(btn.get("screenH"))
                return bx1-margin <= x <= bx2+margin and by1-margin <= y <= by2+margin
            except Exception:
                return False
        return _near_dom_button(x, y, btn, snap, title, margin=margin)

    near_accept = near_target(snap.get("accept"))
    near_reject = near_target(snap.get("reject"))
    if near_accept or (near_reject and kind != "midnight_reject"):
        record_stat("click_refusals")
        note_issue(
            "NEAR_ACCEPT_REJECT",
            "Click blocked because the point overlaps a forbidden Accept/Reject target",
            "ERROR",
            f"{label} ({x},{y})",
            throttle=0,
        )
        return False

    ml, mt, mr, mb = main_rect
    if not (ml <= x < mr and mt <= y < mb):
        record_stat("click_refusals")
        note_issue(
            "MAPPED_POINT_OUTSIDE_CHROME",
            "Mapped target point was outside the existing browser window; click was refused",
            "ERROR",
            f"label={label} point=({x},{y}) main_rect={main_rect}",
            throttle=0,
        )
        return False

    if using_uia:
        note_issue(
            "UIA_SCREEN_COORDINATES_APPLIED",
            "Windows accessibility supplied the physical screen rectangle for this native click",
            "INFO",
            f"label={label} screen=({x},{y}) rect={target_rect}",
            throttle=60.0,
        )
    else:
        note_issue(
            "VIEWPORT_SCALE_APPLIED",
            "DOM coordinates were converted to real Windows pixels using the live viewport scale",
            "INFO",
            f"label={label} scale={mapping['scale_x']:.3f},{mapping['scale_y']:.3f} "
            f"dom=({vx:.1f},{vy:.1f}) screen=({x},{y})",
            throttle=60.0,
        )

    if stop_requested_now():
        return False

    with _click_lock:
        prepared = False
        try:
            prepared = _prepare_chrome_for_physical_click(main, x, y, label)
            if not prepared or stop_requested_now():
                record_stat("click_refusals")
                return False

            # Revalidate the same DOM point after Chrome has been exposed.
            if not brain.validate_click(pos, kind):
                record_stat("click_refusals")
                note_issue(
                    "LAST_SECOND_TARGET_CHANGE",
                    "Target changed immediately before click, so the click was blocked",
                    "WARN",
                    label,
                )
                return False

            before = pyautogui.position()
            move_seconds = random.uniform(0.035, 0.075)
            log(
                f"PHYSICAL MOUSE {label}: move ({int(before.x)},{int(before.y)}) -> "
                f"({x},{y}) in {move_seconds:.3f}s, then real mouse down/up"
            )
            pyautogui.moveTo(x, y, duration=move_seconds)
            if stop_requested_now():
                return False

            root = _root_window_at(x, y)
            if root != int(main):
                record_stat("click_refusals")
                shot = capture_diagnostic("target_became_occluded", min_interval=3.0)
                note_issue(
                    "TARGET_BECAME_OCCLUDED",
                    "Another window covered the verified target while the mouse was moving; click was cancelled",
                    "ERROR",
                    f"label={label} expected_hwnd={main} actual_hwnd={root} screenshot={shot}",
                    throttle=3.0,
                )
                return False

            if not brain.validate_click(pos, kind):
                record_stat("click_refusals")
                note_issue(
                    "TARGET_CHANGED_DURING_MOUSE_MOVE",
                    "Target changed while the mouse was moving, so the click was blocked",
                    "WARN",
                    label,
                )
                return False

            if stop_requested_now():
                return False
            pyautogui.mouseDown()
            try:
                time.sleep(0.045)
            finally:
                pyautogui.mouseUp()
            _last_click = time.time()
        finally:
            if prepared:
                time.sleep(0.025)
            _release_chrome_topmost(main)

    if kind == "reserve":
        record_stat("reserve_clicks")
    elif kind == "midnight_reject":
        record_stat("reject_clicks")
    elif kind in ("nav_my", "nav_find"):
        record_stat("nav_clicks")
    elif kind == "files_toggle":
        record_stat("panel_files_toggles")
    elif kind == "still_here":
        record_stat("still_here_clicks")
    else:
        record_stat("row_clicks")
    log(f"CLICK {label} (scaled-hwnd) at ({x}, {y})")

    # For action buttons, immediately read Chrome's passive click audit so the
    # log proves whether the browser received the OS-level mouse event as trusted.
    if kind in ("reserve", "midnight_reject"):
        expected = "Reserve" if kind == "reserve" else "Reject"
        context = "bot physical Reserve" if kind == "reserve" else "bot midnight-rule Reject"
        time.sleep(0.06)
        audit_snap = brain.read()
        audit = consume_click_audit(audit_snap, context=context, expected_label=expected)
        if not audit:
            code = "RESERVE_CLICK_AUDIT_MISSING" if kind == "reserve" else "REJECT_CLICK_AUDIT_MISSING"
            note_issue(
                code,
                f"{expected} mouse-down/up was sent but Chrome's click audit did not capture a new click event",
                "WARN",
                f"screen=({x},{y})",
                throttle=0,
            )
    return True


def drag_reserved_panel_scrollbar_cycle(snap: dict, brain: Brain, pass_number: int) -> bool:
    """Drag the reserved drawer's real scrollbar down/up once, or do absolutely nothing.

    Fail-closed rule: unless a visible, scrollable native scrollbar is positively
    present and mappable, this function does not focus Chrome and does not move,
    press, click, or drag the mouse at all.
    """
    global _last_click
    if _paused or stop_requested_now():
        return False
    prepared = False
    main = 0
    try:
        # Read first without activating Chrome. Missing/hidden scrollbar = no action.
        fresh = brain.read() or {}
        pos = fresh.get("panelScroll") or {}
        if not pos or not fresh.get("panelOpen"):
            log(f"RESERVED PANEL SCROLLBAR PASS {pass_number}: no verified visible scrollbar; no mouse action was performed.")
            return False

        top = float(pos.get("top") or 0)
        left = float(pos.get("left") or 0)
        width = float(pos.get("w") or 0)
        height = float(pos.get("h") or 0)
        scroll_top = float(pos.get("scrollTop") or 0)
        scroll_height = float(pos.get("scrollHeight") or 0)
        client_height = float(pos.get("clientHeight") or 0)
        scrollbar_width = float(pos.get("scrollbarWidth") or 0)
        overflow_y = str(pos.get("overflowY") or "").lower()
        maximum = max(0.0, scroll_height - client_height)
        if (width < 100 or height < 100 or maximum < 20 or scroll_height <= 0 or
                client_height <= 0 or scrollbar_width < 6 or overflow_y not in ("auto", "scroll")):
            log(f"RESERVED PANEL SCROLLBAR PASS {pass_number}: scrollbar verification failed; no mouse action was performed.")
            return False

        track_top = top + 4.0
        track_height = max(30.0, height - 8.0)
        thumb_height = max(24.0, min(track_height, track_height * (client_height / scroll_height)))
        travel = max(1.0, track_height - thumb_height)
        ratio = max(0.0, min(1.0, scroll_top / maximum))
        start_vx = left + width - max(3.0, scrollbar_width / 2.0)
        start_vy = track_top + ratio * travel + thumb_height / 2.0
        bottom_vy = track_top + travel + thumb_height / 2.0

        title = str(fresh.get("pageTitle") or "")
        mapped_start = viewport_to_screen(start_vx, start_vy, title, float(fresh.get("innerW") or 0), float(fresh.get("innerH") or 0))
        mapped_bottom = viewport_to_screen(start_vx, bottom_vy, title, float(fresh.get("innerW") or 0), float(fresh.get("innerH") or 0))
        if not mapped_start or not mapped_bottom:
            log(f"RESERVED PANEL SCROLLBAR PASS {pass_number}: scrollbar could not be mapped; no mouse action was performed.")
            return False

        # Only now is mouse/focus activity allowed.
        brain.activate()
        main, _ = chrome_handles(title)
        if not main:
            return False
        sx, sy = mapped_start
        bx, by = mapped_bottom
        if not _prepare_chrome_for_physical_click(main, sx, sy, f"reserved scrollbar pass {pass_number}"):
            return False
        prepared = True

        with _click_lock:
            if stop_requested_now():
                return False
            focus_hwnd(main)
            pyautogui.moveTo(sx, sy, duration=0.05)
            if stop_requested_now():
                return False
            pyautogui.dragTo(bx, by, duration=RESERVED_SCROLLBAR_DRAG_SECONDS, button="left")
            _last_click = time.time()
        time.sleep(0.12)

        down_snap = brain.read() or {}
        down_pos = down_snap.get("panelScroll") or {}
        down_top = float(down_pos.get("scrollTop") or scroll_top)
        if down_top <= scroll_top + 2 and scroll_top < maximum - 2:
            # No fallback movement. A failed drag ends this pass immediately.
            log(f"RESERVED PANEL SCROLLBAR PASS {pass_number}: downward drag was not confirmed; no fallback mouse action will be attempted.")
            return False

        live_top = float(down_pos.get("top") or top)
        live_left = float(down_pos.get("left") or left)
        live_width = float(down_pos.get("w") or width)
        live_height = float(down_pos.get("h") or height)
        live_scroll_height = float(down_pos.get("scrollHeight") or scroll_height)
        live_client_height = float(down_pos.get("clientHeight") or client_height)
        live_scrollbar_width = float(down_pos.get("scrollbarWidth") or scrollbar_width)
        if live_scrollbar_width < 6:
            log(f"RESERVED PANEL SCROLLBAR PASS {pass_number}: scrollbar disappeared after downward drag; no further mouse action was attempted.")
            return False
        live_max = max(1.0, live_scroll_height - live_client_height)
        live_track_top = live_top + 4.0
        live_track_height = max(30.0, live_height - 8.0)
        live_thumb_height = max(24.0, min(live_track_height, live_track_height * (live_client_height / live_scroll_height)))
        live_travel = max(1.0, live_track_height - live_thumb_height)
        live_ratio = max(0.0, min(1.0, down_top / live_max))
        live_vx = live_left + live_width - max(3.0, live_scrollbar_width / 2.0)
        live_vy = live_track_top + live_ratio * live_travel + live_thumb_height / 2.0
        top_vy = live_track_top + live_thumb_height / 2.0

        mapped_live = viewport_to_screen(live_vx, live_vy, str(down_snap.get("pageTitle") or title), float(down_snap.get("innerW") or fresh.get("innerW") or 0), float(down_snap.get("innerH") or fresh.get("innerH") or 0))
        mapped_top = viewport_to_screen(live_vx, top_vy, str(down_snap.get("pageTitle") or title), float(down_snap.get("innerW") or fresh.get("innerW") or 0), float(down_snap.get("innerH") or fresh.get("innerH") or 0))
        if not mapped_live or not mapped_top:
            return False
        lx, ly = mapped_live
        tx, ty = mapped_top

        with _click_lock:
            if stop_requested_now():
                return False
            focus_hwnd(main)
            pyautogui.moveTo(lx, ly, duration=0.05)
            if stop_requested_now():
                return False
            pyautogui.dragTo(tx, ty, duration=RESERVED_SCROLLBAR_DRAG_SECONDS, button="left")
            _last_click = time.time()
        time.sleep(0.12)

        up_snap = brain.read() or {}
        up_pos = up_snap.get("panelScroll") or {}
        up_top = float(up_pos.get("scrollTop") or down_top)
        if up_top >= down_top - 2 and down_top > 2:
            log(f"RESERVED PANEL SCROLLBAR PASS {pass_number}: upward return was not confirmed; no fallback mouse action will be attempted.")
            return False

        record_stat("panel_inspection_scrolls")
        log(f"RESERVED PANEL SCROLLBAR PASS {pass_number}: physical thumb dragged down then up, scrollTop={scroll_top:.0f}->{down_top:.0f}->{up_top:.0f}.")
        return True
    except Exception as e:
        log(f"RESERVED PANEL SCROLLBAR PASS {pass_number}: skipped after verification/error ({e}); no fallback mouse action.")
        return False
    finally:
        if prepared and main:
            _release_chrome_topmost(main)


def send_f5(brain: Brain) -> None:
    if _paused or stop_requested_now():
        return
    # Just before any keyboard refresh, check whether LR Writers has logged out.
    # Logout is a hard stop: never navigate, retry login, or press F5 afterward.
    try:
        pre = brain.read() or {}
        if bool(pre.get("loggedOut")):
            hard_stop_logout("LR Writers logout/login page detected before F5")
            return
    except Exception:
        pass
    with _click_lock:
        title = brain.activate()
        main, _ = chrome_handles(title)
        if not main:
            note_issue("F5_WINDOW_MISSING", "Refresh was skipped because controlled Chrome could not be found", "WARN", throttle=5.0)
            return
        try:
            user32.SetWindowPos(
                main, HWND_TOPMOST, 0, 0, 0, 0,
                SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW,
            )
            focus_hwnd(main)
            time.sleep(0.04)
            if stop_requested_now():
                return
            if int(user32.GetForegroundWindow() or 0) != int(main):
                note_issue("F5_NOT_FOREGROUND", "Refresh was skipped because Chrome could not get keyboard focus", "WARN", throttle=5.0)
                return
            pyautogui.press("f5")
        finally:
            _release_chrome_topmost(main)
    record_stat("f5")
    log("F5")


def _idle_point_to_screen(snap: dict, point: dict) -> tuple[int, int] | None:
    """Map one DOM-vetted idle point to the real Chrome render surface."""
    try:
        return viewport_to_screen(
            float(point.get("vx")),
            float(point.get("vy")),
            str(snap.get("pageTitle") or ""),
            float(snap.get("innerW") or 0),
            float(snap.get("innerH") or 0),
        )
    except Exception:
        return None


def idle_mouse(snap: dict, allow_click: bool = False) -> bool:
    """Move through a random DOM-vetted non-interactive point.

    If allow_click=True, make one physical click only on a point that the
    live page classified as inert background. Never background-click while
    an order panel is open.
    """
    global _last_idle_dir

    if _paused or stop_requested_now():
        return False
    if snap.get("panelOpen") or snap.get("reserve") or snap.get("accept") or snap.get("reject"):
        return False

    points = list(snap.get("idleClickPoints") or []) if allow_click else list(snap.get("idleMovePoints") or [])
    if not points:
        # Screen Vision intentionally has no DOM hit-test points. Restore the old
        # visible roaming behavior without inventing a click target: movement is
        # safe, but a blind background click remains forbidden.
        if bool(snap.get("vision")) and not allow_click:
            return startup_mouse_proof(snap, random.randint(0,5))
        return False

    random.shuffle(points)
    chosen = None
    for pt in points:
        mapped = _idle_point_to_screen(snap, pt)
        if not mapped:
            continue
        x, y = mapped
        if forbidden(x, y, "idle", float(snap.get("innerW") or 0), float(snap.get("innerH") or 0)):
            continue
        key = f"{x},{y}"
        if key == _last_idle_dir and len(points) > 1:
            continue
        chosen = (pt, x, y, key)
        break

    if not chosen:
        return False

    pt, x, y, key = chosen
    duration = random.uniform(0.35, 1.20)
    if stop_requested_now():
        return False
    pyautogui.moveTo(x, y, duration=duration)
    if stop_requested_now():
        return False
    log(
        f"IDLE MOUSE: moved across webpage to safe DOM point ({x},{y}) "
        f"in {duration:.2f}s tag={pt.get('tag') or '?'}"
    )
    _last_idle_dir = key

    if not allow_click:
        return True

    main, _ = chrome_handles()
    if not main:
        return False
    point_obj = POINT(x, y)
    actual = int(user32.WindowFromPoint(point_obj) or 0)
    GA_ROOT = 2
    root_actual = int(user32.GetAncestor(actual, GA_ROOT) or actual) if actual else 0
    root_main = int(user32.GetAncestor(main, GA_ROOT) or main)
    if root_actual != root_main:
        note_issue(
            "IDLE_CLICK_OCCLUDED",
            "Safe idle click skipped because Chrome did not own the physical point",
            "INFO",
            f"point=({x},{y}) actual={root_actual} expected={root_main}",
            throttle=30.0,
        )
        return False

    if stop_requested_now():
        return False
    pyautogui.mouseDown()
    time.sleep(random.uniform(0.035, 0.070))
    pyautogui.mouseUp()
    record_stat("idle_background_clicks")
    log(
        f"IDLE SAFE CLICK: physical mouse clicked verified inert webpage background "
        f"at ({x},{y}) tag={pt.get('tag') or '?'}"
    )
    return True




def is_network_error_snapshot(snap: dict | None) -> bool:
    """True only for browser/network error pages, never for an LR login/logout page."""
    if not snap:
        return False
    url = str(snap.get("url") or "").strip().lower()
    title = str(snap.get("pageTitle") or "").strip().lower()
    text = str(snap.get("bodyText") or snap.get("panelText") or "").strip().lower()
    if url.startswith("chrome-error://") or url.startswith("chrome://network-error"):
        return True
    if any(x in title for x in ("site can't be reached", "no internet", "offline", "network error")):
        return True
    if any(x in text for x in ("this site can’t be reached", "this site can't be reached", "no internet", "err_internet_disconnected", "err_network_changed")):
        return True
    return False


# ---------------- alerts ----------------
def send_gmail(title: str, message: str) -> bool:
    if not (GMAIL_WEBAPP_URL and GMAIL_WEBAPP_SECRET and GMAIL_TO):
        return False
    try:
        r = requests.post(
            GMAIL_WEBAPP_URL,
            json={"secret": GMAIL_WEBAPP_SECRET, "to": GMAIL_TO, "subject": title, "body": message},
            timeout=15,
        )
        ok = 200 <= r.status_code < 300
        log("Gmail: " + str(r.status_code))
        if not ok:
            note_issue("GMAIL_HTTP_ERROR", "Gmail alert returned a non-success status", "WARN", str(r.status_code), throttle=30)
        return ok
    except Exception as e:
        note_issue("GMAIL_FAILED", "Gmail alert delivery failed", "WARN", str(e), throttle=30)
        return False



def cancel_alert_keys(keys: list[str]) -> None:
    """Cancel queued reminder keys for a reservation that was accepted/rejected/cleared."""
    clean = [k for k in keys if k]
    if not clean:
        return
    with _alert_lock:
        before = len(_alert_cancelled)
        _alert_cancelled.update(clean)
        added = len(_alert_cancelled) - before
    if added:
        record_stat("alerts_cancelled", added)

def _alert_is_cancelled(key: str) -> bool:
    with _alert_lock:
        return key in _alert_cancelled

def _deliver_alert_worker(title: str, message: str, key: str) -> None:
    """Deliver Pushover/Gmail off the director thread so F5 never waits on network I/O."""
    push_ok = False
    mail_ok = False
    try:
        if _alert_is_cancelled(key):
            log(f"Alert cancelled before delivery: {title}")
            return
        try:
            if not (PUSHOVER_APP_TOKEN and PUSHOVER_USER_KEY):
                raise RuntimeError("Pushover is not configured in local Adeon Data")
            push_message = (message or title)[:1000]
            push_data = {
                "token": PUSHOVER_APP_TOKEN, "user": PUSHOVER_USER_KEY, "title": title[:80],
                "message": push_message, "sound": "siren",
            }
            if "<b>" in push_message or "</b>" in push_message:
                push_data["html"] = "1"
            r = requests.post(
                "https://api.pushover.net/1/messages.json",
                data=push_data, timeout=15,
            )
            push_ok = 200 <= r.status_code < 300
            log("Pushover: " + title + " (" + str(r.status_code) + ")")
            if not push_ok:
                note_issue("PUSHOVER_HTTP_ERROR", "Pushover returned a non-success status", "WARN", str(r.status_code), throttle=30)
        except Exception as e:
            note_issue("PUSHOVER_FAILED", "Pushover alert delivery failed", "WARN", str(e), throttle=30)

        if _alert_is_cancelled(key):
            log(f"Alert cancelled before Gmail delivery: {title}")
            return
        mail_ok = send_gmail(title, re.sub(r"<[^>]+>", "", message or title))
        with _alert_lock:
            if push_ok or mail_ok:
                _alerted.add(key)
                record_stat("alerts_sent")
            else:
                record_stat("alert_failures")
                note_issue("ALERT_DELIVERY_FAILED", "Both alert methods failed; bot will retry later", "WARN", title, throttle=30)
    finally:
        with _alert_lock:
            _alert_inflight.discard(key)


def send_alert(title: str, message: str, key: str) -> bool:
    """Queue an alert without blocking row scanning, mouse actions, or F5."""
    if _paused or stop_requested_now():
        return False
    if not key:
        return False
    now = time.time()
    with _alert_lock:
        if key in _alert_cancelled:
            return False
        if key in _alerted:
            return True
        if key in _alert_inflight:
            return False
        last_try = _alert_last_try.get(key, 0.0)
        if last_try and now - last_try < 30.0:
            return False
        _alert_last_try[key] = now
        _alert_inflight.add(key)

    threading.Thread(
        target=_deliver_alert_worker,
        args=(title, message, key),
        name="LR-Alert-" + re.sub(r"[^A-Za-z0-9_-]+", "_", key)[:30],
        daemon=True,
    ).start()
    log(f"Alert queued in background: {title}")
    return False



_loud_bell_wavs: dict[int, bytes] = {}


def _build_loud_bell_wav(level: int = 1) -> bytes:
    """Create a progressively more insistent but safety-capped local alarm WAV.

    Adeon does not force Windows hardware volume to maximum and does not generate
    ultrasonic or intentionally painful tones. The user's speaker volume remains
    the final loudness limit.
    """
    level = max(1, min(4, int(level or 1)))
    cached = _loud_bell_wavs.get(level)
    if cached is not None:
        return cached
    try:
        import io
        import math
        import struct
        import wave

        rate = 44100
        patterns = {
            1: ((0.00, 0.72, 1.44), 2.35, 0.44),
            2: ((0.00, 0.52, 1.04, 1.56, 2.08), 2.95, 0.52),
            3: ((0.00, 0.40, 0.80, 1.20, 1.60, 2.00, 2.40), 3.25, 0.60),
            4: ((0.00, 0.32, 0.64, 0.96, 1.28, 1.60, 1.92, 2.24, 2.56, 2.88), 3.75, 0.68),
        }
        strikes, duration, amplitude = patterns[level]
        frames = bytearray()
        total = int(rate * duration)
        for i in range(total):
            t = i / rate
            sample = 0.0
            for strike in strikes:
                dt = t - strike
                if 0.0 <= dt <= 0.62:
                    env = math.exp(-5.2 * dt)
                    sample += env * (
                        0.62 * math.sin(2.0 * math.pi * 784.0 * dt)
                        + 0.28 * math.sin(2.0 * math.pi * 1046.5 * dt)
                        + 0.14 * math.sin(2.0 * math.pi * 1318.5 * dt)
                    )
            sample = max(-0.72, min(0.72, sample * amplitude))
            frames += struct.pack('<h', int(sample * 32767))
        buf = io.BytesIO()
        with wave.open(buf, 'wb') as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(rate)
            wf.writeframes(bytes(frames))
        _loud_bell_wavs[level] = buf.getvalue()
    except Exception:
        _loud_bell_wavs[level] = b''
    return _loud_bell_wavs[level]


def _loud_bell_worker(key: str, level: int = 1) -> None:
    """Play one levelled local alarm without blocking the 100 ms picker loop."""
    level = max(1, min(4, int(level or 1)))
    try:
        if _alert_is_cancelled(key):
            return
        import winsound
        wav = _build_loud_bell_wav(level)
        if wav:
            winsound.PlaySound(wav, winsound.SND_MEMORY)
            return
        fallback = {
            1: ((784, 260), (1047, 300), (784, 360)),
            2: ((784, 260), (1047, 300), (1175, 300), (784, 380)),
            3: ((784, 230), (1047, 250), (1175, 260), (1047, 280), (784, 380)),
            4: ((784, 210), (1047, 220), (1175, 230), (1319, 240), (1047, 260), (784, 360)),
        }[level]
        for freq, ms in fallback:
            if _alert_is_cancelled(key):
                return
            winsound.Beep(freq, ms)
            time.sleep(0.05)
    except Exception as e:
        note_issue("LOUD_BELL_FAILED", "Laptop reservation bell could not play", "WARN", str(e), throttle=30)


def play_loud_reservation_bell(key: str, level: int = 1) -> None:
    if _stop or _paused or not key or _alert_is_cancelled(key):
        return
    level = max(1, min(4, int(level or 1)))
    threading.Thread(
        target=_loud_bell_worker,
        args=(key, level),
        name=f"Adeon-Reserve-Bell-L{level}",
        daemon=True,
    ).start()


def _critical_group_key(key: str) -> str:
    return str(key or '').split(':critical-', 1)[0]


def _cancel_pushover_receipt(receipt: str) -> bool:
    receipt = str(receipt or '').strip()
    if not receipt or not PUSHOVER_APP_TOKEN:
        return True
    try:
        r = requests.post(
            f"https://api.pushover.net/1/receipts/{receipt}/cancel.json",
            data={"token": PUSHOVER_APP_TOKEN},
            timeout=10,
        )
        ok = 200 <= r.status_code < 300
        log(f"Pushover emergency receipt cancel ({r.status_code})")
        return ok
    except Exception as e:
        note_issue("PUSHOVER_CRITICAL_CANCEL_FAILED", "Could not cancel the previous Pushover emergency retry", "WARN", str(e), throttle=30)
        return False


def cancel_critical_reservation_push(group_key: str) -> None:
    """Cancel the currently active Pushover emergency receipt for this reservation."""
    group = str(group_key or '').strip()
    if not group:
        return
    with _critical_receipt_lock:
        receipt = _critical_receipts.pop(group, '')
    if not receipt:
        return
    threading.Thread(
        target=_cancel_pushover_receipt,
        args=(receipt,),
        name="Adeon-Cancel-Critical",
        daemon=True,
    ).start()


def _deliver_critical_reservation_alert_worker(title: str, message: str, key: str) -> None:
    """Send one true Pushover emergency/critical alert for one escalation slot.

    Pushover emergency retry itself cannot be configured below 30 seconds. Adeon
    cancels the prior slot receipt before creating the next scheduled slot. The API
    cannot raise the phone's hardware volume, so frequency and siren urgency escalate.
    """
    push_ok = False
    group = _critical_group_key(key)
    try:
        if _alert_is_cancelled(key):
            log(f"Critical reservation alert cancelled before delivery: {title}")
            return

        # Cancel the previous emergency receipt before creating this 15-second slot.
        with _critical_receipt_lock:
            old_receipt = _critical_receipts.pop(group, '')
        if old_receipt:
            _cancel_pushover_receipt(old_receipt)
        if _alert_is_cancelled(key):
            return

        try:
            if not (PUSHOVER_APP_TOKEN and PUSHOVER_USER_KEY):
                raise RuntimeError("Pushover is not configured in local Adeon Data")
            push_data = {
                "token": PUSHOVER_APP_TOKEN,
                "user": PUSHOVER_USER_KEY,
                "title": title[:80],
                "message": (message or title)[:1000],
                "priority": "2",
                "retry": "30",
                "expire": "35",
                "sound": "siren",
            }
            r = requests.post("https://api.pushover.net/1/messages.json", data=push_data, timeout=15)
            push_ok = 200 <= r.status_code < 300
            receipt = ''
            if push_ok:
                try:
                    receipt = str((r.json() or {}).get('receipt') or '').strip()
                except Exception:
                    receipt = ''
            log("Pushover CRITICAL emergency: " + title + " (" + str(r.status_code) + ")")
            if not push_ok:
                note_issue("PUSHOVER_CRITICAL_HTTP_ERROR", "Critical Pushover alert returned a non-success status", "WARN", str(r.status_code), throttle=30)
            elif receipt:
                if _alert_is_cancelled(key):
                    # Reservation ended while the HTTP request was in flight.
                    _cancel_pushover_receipt(receipt)
                else:
                    with _critical_receipt_lock:
                        _critical_receipts[group] = receipt
        except Exception as e:
            note_issue("PUSHOVER_CRITICAL_FAILED", "Critical Pushover alert delivery failed", "WARN", str(e), throttle=30)

        with _alert_lock:
            if push_ok:
                _alerted.add(key)
                record_stat("alerts_sent")
            else:
                record_stat("alert_failures")
    finally:
        with _alert_lock:
            _alert_inflight.discard(key)


def send_critical_reservation_alert(title: str, message: str, key: str) -> bool:
    """Queue one true Pushover emergency/critical reservation alert."""
    if _paused or stop_requested_now() or not key:
        return False
    now = time.time()
    with _alert_lock:
        if key in _alert_cancelled:
            return False
        if key in _alerted:
            return True
        if key in _alert_inflight:
            return False
        last_try = _alert_last_try.get(key, 0.0)
        if last_try and now - last_try < 5.0:
            return False
        _alert_last_try[key] = now
        _alert_inflight.add(key)
    threading.Thread(
        target=_deliver_critical_reservation_alert_worker,
        args=(title, message, key),
        name="LR-Critical-" + re.sub(r"[^A-Za-z0-9_-]+", "_", key)[:30],
        daemon=True,
    ).start()
    log(f"Critical reservation alert queued: {title}")
    return False



def in_midnight_rule_window(dt: datetime | None = None) -> bool:
    """Use the PC's local clock. The rule is active from midnight until 08:00."""
    dt = dt or datetime.now()
    h = dt.hour + dt.minute / 60.0 + dt.second / 3600.0
    start = float(MIDNIGHT_RULE_START_HOUR)
    end = float(MIDNIGHT_RULE_END_HOUR)
    if start <= end:
        return start <= h < end
    return h >= start or h < end


def parse_remaining_minutes(text: str) -> float | None:
    """Parse only explicit relative-deadline wording; ignore generic '60 minutes - 300 words'."""
    t = re.sub(r"\s+", " ", str(text or "").lower().replace("’", "'")).strip()
    if not t:
        return None

    # Normalize natural singular phrases used by the site.
    t = re.sub(r"\ban hour\b", "1 hour", t)
    t = re.sub(r"\ba hour\b", "1 hour", t)
    t = re.sub(r"\ba day\b", "1 day", t)
    t = re.sub(r"\ban? minute\b", "1 minute", t)

    # Only consider text close to a relative-deadline cue. This avoids treating
    # assignment-production hints such as '60 minutes - 300 words' as deadlines.
    candidates: list[str] = []
    cue_patterns = [
        r"(?:in\s+)?[^|.;]{0,80}?\bfrom now\b",
        r"(?:in\s+)?[^|.;]{0,80}?\b(?:left|remaining)\b",
        r"\b(?:deadline|final ddl|ddl)\b[^|.;]{0,100}",
        r"\bin\s+\d+(?:\.\d+)?\s*(?:days?|d|hours?|hrs?|hr|h|minutes?|mins?|min|m)\b",
    ]
    for pat in cue_patterns:
        for m in re.finditer(pat, t, re.I):
            candidates.append(m.group(0))

    if not candidates:
        return None

    best: float | None = None
    for seg in candidates:
        days = hours = minutes = 0.0
        found = False
        for val, unit in re.findall(r"(\d+(?:\.\d+)?)\s*(days?|d|hours?|hrs?|hr|h|minutes?|mins?|min|m)\b", seg, re.I):
            found = True
            n = float(val)
            u = unit.lower()
            if u.startswith("d"):
                days += n
            elif u.startswith("h"):
                hours += n
            else:
                minutes += n
        if found:
            total = days * 1440.0 + hours * 60.0 + minutes
            if total >= 0 and (best is None or total < best):
                best = total
    return best


def deadline_source_for_row(row: dict | None) -> str:
    if not row:
        return ""
    return " ".join(str(row.get(k) or "") for k in ("deadlineText", "text"))


def _one_line(text: str) -> str:
    return re.sub(r"\s+", " ", str(text or "")).strip()


def _extract_named_section(raw: str, heading_pattern: str, stop_headings: tuple[str, ...]) -> str:
    m = re.search(heading_pattern, raw or "", re.I)
    if not m:
        return ""
    tail = (raw or "")[m.end():]
    cut = len(tail)
    low = tail.lower()
    for stop in stop_headings:
        i = low.find(stop.lower())
        if i >= 0:
            cut = min(cut, i)
    return tail[:cut].strip()


def _old_style_money(raw: str) -> str:
    """Match the original Tampermonkey notification price extraction."""
    lines = [_one_line(x) for x in str(raw or "").splitlines()[:60] if _one_line(x)]
    best = None
    best_score = -10**9
    for i, line in enumerate(lines):
        if "$" not in line or re.search(r"\(\s*\$\s*\d", line):
            continue
        m = re.search(r"\$\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)", line)
        if not m:
            continue
        try:
            value = float(m.group(1).replace(",", ""))
        except Exception:
            continue
        has_decimals = bool(re.search(r"\$\s*\d+\.\d{2}\b", line))
        score = (1000 if has_decimals else 0) - i
        if score > best_score:
            best_score = score
            best = value
    return "" if best is None else f"${best:.2f}"


def _preferred_earnings_money(*texts: str) -> str:
    """Use A+ earns when it is actually shown, otherwise use You'll earn.

    This intentionally does not infer A+ from an unrelated second dollar value.
    A+ wins only when its own label is present. If no A+ label/value is found,
    You'll earn is used. The generic legacy money parser is only a last fallback
    when neither labelled field exists in the supplied drawer text.
    """
    merged = "\n".join(str(x or "") for x in texts if str(x or "").strip())
    if not merged:
        return ""

    def labelled_value(labels: tuple[str, ...]) -> str:
        # Handle both "Label  $12.34" and "$12.34  Label" layouts, with a small
        # allowance for intervening table whitespace/text.
        label_re = "(?:" + "|".join(labels) + ")"
        pats = (
            rf"{label_re}[^$\n]{{0,80}}\$\s*([0-9][0-9,]*(?:\.[0-9]{{1,2}})?)",
            rf"\$\s*([0-9][0-9,]*(?:\.[0-9]{{1,2}})?)[^\n]{{0,80}}{label_re}",
        )
        for pat in pats:
            m = re.search(pat, merged, re.I)
            if not m:
                continue
            try:
                return f"${float(m.group(1).replace(',', '')):.2f}"
            except Exception:
                continue
        return ""

    a_plus = labelled_value((r"A\s*\+\s*(?:level\s*)?earns",))
    if a_plus:
        return a_plus
    you_earn = labelled_value((r"you\s*(?:'|’)?ll\s+earn", r"you\s+will\s+earn"))
    if you_earn:
        return you_earn
    return _old_style_money(merged)


def _old_style_size(raw: str) -> str:
    for pat, unit in (
        (r"\b(\d+)\s*pages?\b", "pages"),
        (r"\b(\d+)\s*slides?\b", "slides"),
        (r"\b(\d{2,6})\s*words?\b", "words"),
    ):
        m = re.search(pat, raw or "", re.I)
        if m:
            return f"{m.group(1)} {unit}"
    return ""


def _old_style_title(raw: str, task_no: str, hint: str = "") -> str:
    """Extract the human task title from the same panel text the old script used.

    Prefer the portion immediately after the task number and before Task summary.
    This avoids button-strip strings such as ReserveAccept and list/header text.
    """
    text = str(raw or "")
    stop_words = (
        "final ddl", "order info", "operator messages", "more order details",
        "order files", "upload final", "task summary", "full order description",
        "reserved time left", "reserved:", "reserveaccept", "reserve accept",
        "acceptreject", "accept reject", "reserve reject", "find orders",
        "my orders", "inbox", "my progress", "finances", "issue resolution", "help",
        "formatting style", "sources", "country of origin", "order files",
    )
    bad_exact = {
        "reserve", "accept", "reject", "order info", "operator messages",
        "more order details", "task summary", "full order description",
        "show on-line orders", "show reserved", "all deadlines", "all subjects", "all task types",
    }
    cuts = (
        r"\b\d+\s*words?\b", r"\b\d+\s*pages?\b", r"\b\d+\s*slides?\b",
        r"\b(?:days?|hours?)\s*from\s*now\b", r"\breserved\b",
    )

    # Work in the detail area before Task summary.  If the order number occurs
    # multiple times (row + drawer), the last occurrence before Task summary is
    # normally the open drawer copy, which is the one we want.
    pre = re.split(r"Task\s*summary\s*:?", text, maxsplit=1, flags=re.I)[0]
    if task_no:
        idx = pre.upper().rfind(task_no.upper())
        if idx >= 0:
            pre = pre[idx + len(task_no):]
    lines = [_one_line(x) for x in pre.splitlines() if _one_line(x)]

    def clean_candidate(line: str) -> str:
        candidate = _one_line(line)
        if task_no:
            candidate = re.sub(re.escape(task_no), "", candidate, flags=re.I).strip()
        low0 = candidate.lower().strip(" :-")
        compact = re.sub(r"\s+", "", low0)
        if not candidate or low0 in bad_exact:
            return ""
        if any(w in low0 for w in stop_words):
            return ""
        if compact in {"reserveaccept", "acceptreject", "reservereject", "reserveacceptreject"}:
            return ""
        if re.fullmatch(r"\$?\d+(?:\.\d+)?(?:\s*/?\s*(?:hour|hours|hrs|h|day|days|minutes|mins))?", low0):
            return ""
        if re.match(r"^(?:final ddl|deadline|reserved time left|you'?ll earn|a\+ level earns|size|type of work|subject)\b", low0):
            return ""
        if "$" in candidate and len(candidate) < 80:
            # Price/metadata lines are not titles.
            return ""
        dollar_idx = candidate.find("$")
        if dollar_idx > 0:
            candidate = candidate[:dollar_idx].strip()
        for pat in cuts:
            m = re.search(pat, candidate, re.I)
            if m and m.start() > 0:
                candidate = candidate[:m.start()].strip()
        candidate = _one_line(candidate).strip(" -:|")
        if len(candidate) < 4:
            return ""
        return candidate[:180]

    for line in lines:
        c = clean_candidate(line)
        if c:
            return c

    # Original-script style Topic fallback.
    m = re.search(r"\bTopic\s*:\s*([^\n]+)", text, re.I)
    if m:
        topic = _one_line(m.group(1))
        topic = re.sub(r"ATTACHED.*$", "", topic, flags=re.I).strip()
        if topic:
            return topic[:180]

    # Last fallback: row/hint text, but never button-strip garbage.
    for line in str(hint or "").splitlines():
        c = clean_candidate(line)
        if c:
            return c
    return task_no or "unknown"

def _old_style_deadline(raw: str, fallback_text: str = "") -> tuple[str, str]:
    """Return (display, Final DDL text), deliberately ignoring Reserved time left."""
    text = str(raw or "")
    ddl = ""
    m = re.search(r"Final\s*DDL\s*:\s*([^\n]+)", text, re.I)
    if m:
        ddl = _one_line(m.group(1))
    # Same order as the older Tampermonkey parser.
    m = re.search(r"(\d+(?:\.\d+)?)\s*hours?\s*from\s*now", text, re.I)
    if m:
        return (f"{float(m.group(1)):g}hrs", ddl)
    m = re.search(r"(\d+(?:\.\d+)?)\s*(?:minutes?|mins?)\s*from\s*now", text, re.I)
    if m:
        hrs = float(m.group(1)) / 60.0
        return (f"{hrs:.1f}".rstrip("0").rstrip(".") + "hrs", ddl)
    m = re.search(r"(\d+(?:\.\d+)?)\s*days?\s*from\s*now", text, re.I)
    if m:
        return (f"{float(m.group(1))*24:g}hrs", ddl)
    if re.search(r"\ba\s*day\s*from\s*now\b", text, re.I):
        return ("24hrs", ddl)
    if re.search(r"\ban?\s*hour\s*from\s*now\b", text, re.I):
        return ("1hrs", ddl)
    if re.search(r"\ba\s*minute\s*from\s*now\b", text, re.I):
        return ("0hrs", ddl)
    # Row text commonly includes '/ 9h' or '/ 48h'. Use it only as a deadline
    # fallback and never consume 'Reserved time left: 6:59'.
    fallback = _one_line(fallback_text)
    mh = re.search(r"(?:/|\b)(\d+(?:\.\d+)?)\s*h(?:rs?)?\b", fallback, re.I)
    if mh:
        return (f"{float(mh.group(1)):g}hrs", ddl)
    return (ddl or "unknown", ddl)


def _detail_snapshot_score(snap: dict | None) -> int:
    raw = str((snap or {}).get("panelText") or (snap or {}).get("panelDeepText") or "")
    if not raw:
        return -100000
    low = raw.lower()
    score = min(len(raw), 20000)
    if "task summary" in low:
        score += 12000
    if "full order description" in low:
        score += 12000
    if "final ddl" in low:
        score += 4000
    if "reserved time left" in low:
        score -= 9000
    return score


def _detail_body_segment(body: str, rid: str = "") -> str:
    """Choose the part of page text most likely to belong to the currently open order."""
    body = str(body or "")
    if not body:
        return ""
    positions = []
    rid_u = str(rid or "").strip().upper()
    body_u = body.upper()
    if rid_u:
        pos = body_u.find(rid_u)
        while pos >= 0:
            positions.append(pos)
            pos = body_u.find(rid_u, pos + 1)
    for m in _ORDER_NO_RE.finditer(body):
        positions.append(m.start())
    positions = sorted(set(positions))
    if not positions:
        for label in ("Task summary", "Full order description", "Final DDL"):
            pos = body.lower().find(label.lower())
            if pos >= 0:
                positions.append(pos)
    if not positions:
        return body[:16000]
    best = ""
    best_score = -10**9
    for pos in positions:
        seg = body[max(0, pos - 1200): min(len(body), pos + 18000)]
        score = _detail_snapshot_score({"panelText": seg})
        if rid_u and rid_u in seg.upper():
            score += 5000
        if score > best_score:
            best_score = score
            best = seg
    return best


def _best_detail_raw(snap: dict | None, rid: str = "") -> tuple[str, str]:
    """Return the richest pre-Reserve detail text available from the open drawer.

    In addition to the selected panel ancestor, use a body-text window anchored on
    Task summary / Full order description.  This is important because LR sometimes
    renders the action buttons in a sibling strip while the readable detail text is
    elsewhere in the same drawer.
    """
    snap = snap or {}
    panel = str(snap.get("panelText") or "")
    deep = str(snap.get("panelDeepText") or "")
    anchor = str(snap.get("detailAnchorText") or "")
    deep_anchor = str(snap.get("detailDeepAnchorText") or "")
    body = _detail_body_segment(str(snap.get("bodyText") or ""), rid)
    candidates = [x for x in (panel, deep, anchor, deep_anchor, body) if x.strip()]
    primary = max(candidates, key=lambda x: _detail_snapshot_score({"panelText": x}), default=panel)
    broad_parts = []
    for x in (primary, panel, deep, anchor, deep_anchor, body):
        x = str(x or "").strip()
        if x and x not in broad_parts:
            broad_parts.append(x)
    return primary, "\n".join(broad_parts)

def _meaningful_title(value: str) -> bool:
    t = _one_line(value).lower().replace(" ", "")
    if not t or t in {"reserve", "accept", "reject", "reserveaccept", "acceptreject", "reservereject"}:
        return False
    return len(t) >= 4


def capture_reservation_details(snap: dict | None, rid: str, hint: str = "", deadline_hint: str = "") -> dict:
    """Mirror the older Tampermonkey full-notification extraction as closely as possible.

    This parser is intentionally state-agnostic: it can consume the live panel both
    before and AFTER Reserve.  Adeon 1.0.18 deliberately feeds it the freshly
    reserved panel first, because that is the state the user confirmed contains the
    clearest complete order information.
    """
    snap = snap or {}
    raw, broad = _best_detail_raw(snap, rid)
    combined = raw + "\n" + broad + "\n" + str(hint or "")
    order_match = _ORDER_NO_RE.search(combined)
    task_no = order_match.group(0).upper() if order_match else str(rid or "").strip().upper()

    # Mirror the old Tampermonkey field order, but if the selected drawer text is
    # incomplete use the same page's deeper DOM text for the missing field only.
    price = _preferred_earnings_money(raw, broad)
    size = _old_style_size(raw) or _old_style_size(broad)

    # Keep the exact list-row values as a fallback. Use the same preferred earnings
    # rule everywhere: A+ earns when that value is present, otherwise You'll earn.
    row_match = None
    for row in snap.get("rows") or []:
        rno = str(row.get("orderNo") or "").strip().upper()
        rtext = str(row.get("text") or "").upper()
        if (task_no and (rno == task_no or task_no in rtext)) or (rid and rno == str(rid).strip().upper()):
            row_match = row
            break
    if row_match:
        try:
            preferred_pay = float(row_match.get("pay") or 0)
        except Exception:
            preferred_pay = 0.0
        if preferred_pay > 0:
            price = f"${preferred_pay:.2f}"
    title = _old_style_title(raw, task_no, "")
    if not _meaningful_title(title):
        title = _old_style_title(str(snap.get("panelDeepText") or ""), task_no, "")
    if not _meaningful_title(title):
        title = _old_style_title(str(hint or ""), task_no, "")
    if not _meaningful_title(title):
        title = task_no or "unknown"
    if size and size.lower() not in title.lower():
        title = f"{title} ({size})"

    deadline_display, ddl = _old_style_deadline(raw, deadline_hint or hint)
    if deadline_display == "unknown":
        deadline_display2, ddl2 = _old_style_deadline(broad, deadline_hint or hint)
        deadline_display = deadline_display2
        ddl = ddl or ddl2

    task_summary = _extract_named_section(
        raw, r"Task\s*summary\s*:?",
        ("Full order description", "Order files", "Upload final files", "Order Info", "Operator messages", "More order details"),
    ) or _extract_named_section(
        broad, r"Task\s*summary\s*:?",
        ("Full order description", "Order files", "Upload final files", "Order Info", "Operator messages", "More order details"),
    )
    full_desc = _extract_named_section(
        raw, r"Full\s*order\s*description\s*:?",
        ("Order files", "Upload final files", "Order Info", "Operator messages", "More order details"),
    ) or _extract_named_section(
        broad, r"Full\s*order\s*description\s*:?",
        ("Order files", "Upload final files", "Order Info", "Operator messages", "More order details"),
    )
    internal_id = str((row_match or {}).get("id") or "").strip()
    return {
        "taskNo": task_no or "unknown",
        "price": price,
        "title": title or "unknown",
        "deadline": deadline_display,
        "ddlText": ddl,
        "taskSummary": task_summary,
        "fullDesc": full_desc,
        "internalId": internal_id,
    }


def _reservation_detail_score(details: dict | None) -> int:
    d = details or {}
    score = 0
    task = str(d.get("taskNo") or "").strip()
    price = str(d.get("price") or "").strip()
    deadline = str(d.get("deadline") or d.get("ddlText") or "").strip()
    title = str(d.get("title") or "").strip()
    summary = str(d.get("taskSummary") or "").strip()
    full_desc = str(d.get("fullDesc") or "").strip()
    if _ORDER_NO_RE.fullmatch(task): score += 20
    if price: score += 10
    if deadline and deadline.lower() != "unknown": score += 15
    if _meaningful_title(title) and title.upper() != task.upper(): score += 20
    if summary: score += 30 + min(len(summary), 2000) // 200
    if full_desc: score += 35 + min(len(full_desc), 4000) // 250
    return score


def _reservation_details_complete(details: dict | None) -> bool:
    d = details or {}
    task = str(d.get("taskNo") or "").strip()
    title = str(d.get("title") or "").strip()
    deadline = str(d.get("deadline") or d.get("ddlText") or "").strip()
    return bool(
        _ORDER_NO_RE.fullmatch(task)
        and str(d.get("price") or "").strip()
        and deadline and deadline.lower() != "unknown"
        and _meaningful_title(title) and title.upper() != task.upper()
        and str(d.get("taskSummary") or "").strip()
        and str(d.get("fullDesc") or "").strip()
    )


def _merge_missing_reservation_details(primary: dict, fallback: dict) -> dict:
    """Fill only truly missing post-Reserve fields; never overwrite live reserved text."""
    out = dict(primary or {})
    fb = fallback or {}
    for key in ("taskNo", "price", "ddlText", "taskSummary", "fullDesc", "internalId"):
        if not str(out.get(key) or "").strip() and str(fb.get(key) or "").strip():
            out[key] = fb.get(key)
    if str(out.get("deadline") or "").strip().lower() in ("", "unknown"):
        if str(fb.get("deadline") or fb.get("ddlText") or "").strip():
            out["deadline"] = fb.get("deadline") or fb.get("ddlText")
    title = str(out.get("title") or "").strip()
    if not _meaningful_title(title) or title.upper() == str(out.get("taskNo") or "").strip().upper():
        fb_title = str(fb.get("title") or "").strip()
        if _meaningful_title(fb_title):
            out["title"] = fb_title
    return out


def build_reserved_pushover_message(details: dict) -> str:
    """Same field order/spacing as the older Tampermonkey full Accepted message, with Reserved wording."""
    import html as _html
    now = datetime.now().strftime("%H:%M")
    esc = lambda x: _html.escape(str(x or ""), quote=True)
    task_no = str(details.get("taskNo") or "unknown")
    price = str(details.get("price") or "")
    deadline = str(details.get("deadline") or details.get("ddlText") or "unknown")
    title = str(details.get("title") or "unknown")
    task_with_price = f"{esc(task_no)}</b> <b>{esc(price)}" if price else esc(task_no)
    header = (
        f"LR job reserved at <b>{esc(now)}</b>\n\n"
        f"With task number <b>{task_with_price}</b>\n\n"
        f"With final deadline <b>{esc(deadline)}</b>\n\n"
        f"Task title {esc(title)}\n\n"
    )
    body = ""
    summary = str(details.get("taskSummary") or "").strip()
    full_desc = str(details.get("fullDesc") or "").strip()
    if summary:
        body += "Task summary\n" + summary + "\n\n"
    if full_desc:
        body += "Full order description\n" + full_desc
    if not body.strip():
        body = "Order details were captured before Reserve, but no summary/description text was exposed by the page."
    max_body = max(0, 980 - len(header))
    safe_body = body if len(body) <= max_body else body[:max(0, max_body - 4)] + "\n..."
    msg = header + safe_body
    return msg if len(msg) <= 1024 else msg[:1020] + "\n..."

def is_tutoring_order_text(text: str) -> bool:
    """Fail closed on any panel/body text that identifies a tutoring order."""
    t = (text or "").lower()
    return bool("tutoring order" in t or re.search(r"(^|[^a-z])tutor(ing)?([^a-z]|$)", t))


def has_do_not_accept(text: str) -> bool:
    t = (text or "").lower().replace("’", "'").replace("‘", "'")
    return any(
        p in t
        for p in (
            "do not accept",
            "don't accept",
            "dont accept",
            "do not reserve",
            "don't reserve",
            "dont reserve",
            "do not take this order",
            "don't take this order",
            "dont take this order",
            "you will be fined",
            "you'll be fined",
        )
    )


_ORDER_NO_RE = re.compile(r"\b[A-Z]{1,6}\d{6,}-\d+\b", re.I)
_last_click_audit_ts = 0


def row_key(row: dict | None) -> str:
    """Stable public order identity when possible, otherwise the internal row id."""
    if not row:
        return ""
    order_no = str(row.get("orderNo") or "").strip()
    if order_no:
        return order_no.upper()
    text = str(row.get("text") or "")
    m = _ORDER_NO_RE.search(text)
    if m:
        return m.group(0).upper()
    rid = str(row.get("id") or "").strip()
    if rid:
        return rid
    return text[:80]


def _row_is_lr_notification_noise(text: str) -> bool:
    """Reject LR notification/banner text that can contain an order number.

    Screen Vision once read the "You have a new revision request ..." banner as
    a Find Orders row. That read was already fail-closed by the pay gate, but it
    should not enter the candidate list at all.
    """
    low=re.sub(r"\s+"," ",str(text or "")).strip().lower()
    return bool(
        "you have a new revision request" in low
        or low.startswith("new revision request in ")
        or " notification: new revision request " in (" "+low+" ")
    )


def consume_click_audit(snap: dict | None, context: str = "", expected_label: str = "") -> dict | None:
    """Consume the newest browser click audit event once and log isTrusted."""
    global _last_click_audit_ts
    click = (snap or {}).get("lastClick") or {}
    try:
        ts = int(click.get("ts") or 0)
    except Exception:
        ts = 0
    if not ts or ts <= _last_click_audit_ts:
        return None
    age_ms = int(time.time() * 1000) - ts
    if age_ms > 10000:
        _last_click_audit_ts = ts
        return None
    _last_click_audit_ts = ts
    trusted = bool(click.get("trusted"))
    text = str(click.get("text") or "").strip()
    if trusted:
        record_stat("trusted_native_clicks")
    else:
        record_stat("untrusted_clicks")
    log(
        f"DOM CLICK AUDIT | context={context or 'page'} target={text!r} "
        f"isTrusted={trusted} client=({int(click.get('clientX') or 0)},{int(click.get('clientY') or 0)})"
    )
    if expected_label and expected_label.lower() not in text.lower():
        note_issue(
            "CLICK_AUDIT_TARGET_MISMATCH",
            "Chrome received the physical click on a different labelled target than expected",
            "ERROR",
            f"expected={expected_label!r} actual={text!r} trusted={trusted}",
            throttle=0,
        )
    if expected_label and not trusted:
        note_issue(
            "CLICK_NOT_TRUSTED",
            "Chrome reported that the expected click was not a trusted native user-input event",
            "ERROR",
            f"expected={expected_label!r} actual={text!r}",
            throttle=0,
        )
    return click


def job_id(row: dict | None, snap: dict) -> str:
    # The open page/panel is more authoritative than some other eligible row.
    uid = str(snap.get("urlId") or "")
    if uid and uid.lower() not in ("all", "findorders"):
        return uid
    key = row_key(row)
    if key:
        return key
    return ""


def job_still_held(snap: dict, rid: str, hint: str) -> bool:
    """Strong reservation proof only. A row merely existing is never proof that it is still reserved."""
    if not snap or snap.get("acceptedGone"):
        return False
    rid_norm = str(rid or "").strip().upper()
    uid = str(snap.get("urlId") or "").strip().upper()
    url = str(snap.get("url") or "").upper()
    panel = str(snap.get("panelText") or "").upper()
    rows = snap.get("rows") or []
    keys = [row_key(r).upper() for r in rows]
    texts = [str(r.get("text") or "").upper() for r in rows]

    identity_matches = bool(rid_norm and (uid == rid_norm or rid_norm in url or rid_norm in panel))
    row_matches = bool(rid_norm and rid_norm in keys)
    hint_token = str(hint or "").strip().upper()[:24]
    hint_matches = bool(hint_token and any(hint_token in t for t in texts))

    # A verified Reject button tied to THIS order is the positive proof that the
    # reservation is still alive. A normal list row by itself is never enough.
    if snap.get("reject") and (identity_matches or row_matches or hint_matches):
        return True

    # Accepted state or the same order returning to Reserve are definite end states.
    if snap.get("reserve") and identity_matches and not snap.get("reject"):
        return False

    return False


def reservation_definitely_ended(snap: dict, rid: str) -> bool:
    """Return True only for a strong, same-order accepted/rejected/end-state signal."""
    if not snap:
        return False
    if snap.get("acceptedGone"):
        return True
    rid_norm = str(rid or "").strip().upper()
    if not rid_norm:
        return False
    uid = str(snap.get("urlId") or "").strip().upper()
    url = str(snap.get("url") or "").upper()
    panel = str(snap.get("panelText") or "").upper()
    identity_matches = bool(uid == rid_norm or rid_norm in url or rid_norm in panel)
    # Manual Reject normally returns this exact order to a Reserve state.
    return bool(identity_matches and snap.get("reserve") and not snap.get("reject"))


def _vision_verify_candidate_pay(brain, row: dict, *, strict_high: bool = True) -> tuple[bool, str]:
    """Fail-closed pay confirmation for Screen Vision before any row click.

    v36 never opened an order below MIN_PAY. Screen Vision therefore may not
    trust a single full-page OCR amount. Re-read only the earnings cell at
    multiple scales and require agreement before the physical row click.
    """
    if not isinstance(row, dict) or not row.get("vision"):
        return True, "non-vision"
    key=str(row.get("orderNo") or row_key(row) or "").strip().upper()
    try:
        candidate=float(row.get("pay") or 0.0)
        col_x=float(row.get("visionPayColumnScreenX") or row.get("visionPayScreenX") or 0.0)
        row_y=float(row.get("visionRowScreenY") or row.get("sy") or 0.0)
    except Exception:
        return False, "bad geometry"
    if not key or candidate < MIN_PAY:
        return False, f"candidate ${candidate:.2f} is below ${MIN_PAY:.2f}"
    if not bool(row.get("visionPayGeometryVerified")) or col_x <= 0 or row_y <= 0:
        return False, "earnings column was not geometrically verified"
    hwnd=int(getattr(brain,"_uia_hwnd",0) or 0)
    rect=_screen_rect(hwnd)
    if not rect:
        return False, "browser rectangle unavailable"
    try:
        if int(user32.GetForegroundWindow() or 0) != hwnd:
            return False, "LR browser is not foreground"
    except Exception:
        pass
    l,t,r,b=rect
    # Crop only the verified earnings column around this row. This avoids order
    # numbers, deadlines and headers being mistaken for earnings.
    crop_w=220; crop_h=64
    x1=max(l,int(round(col_x-crop_w/2))); y1=max(t,int(round(row_y-crop_h/2)))
    x2=min(r,x1+crop_w); y2=min(b,y1+crop_h)
    if x2-x1 < 80 or y2-y1 < 24:
        return False, "pay crop too small"
    try:
        from PIL import ImageOps, ImageEnhance, ImageFilter
        base=pyautogui.screenshot(region=(x1,y1,x2-x1,y2-y1))
    except Exception as e:
        return False, f"pay screenshot failed: {e}"

    def values_from(raw: dict) -> list[float]:
        text=str((raw or {}).get("text") or "")
        vals=[]
        for m in re.finditer(r"\$\s*([0-9]{1,4}(?:,[0-9]{3})*(?:\.[0-9]{2})?)",text):
            try: vals.append(float(m.group(1).replace(",","")))
            except Exception: pass
        return vals

    variants=[]
    try:
        variants.append(base.resize((base.width*2,base.height*2)))
        variants.append(ImageOps.autocontrast(base.convert("L")).resize((base.width*3,base.height*3)))
        sharp=ImageEnhance.Contrast(base).enhance(1.6).filter(ImageFilter.SHARPEN)
        variants.append(sharp.resize((base.width*3,base.height*3)))
    except Exception:
        variants=[base,base.resize((base.width*2,base.height*2)),base.resize((base.width*3,base.height*3))]

    reads=[]
    for idx,img in enumerate(variants,1):
        if stop_requested_now():
            return False, "stop requested"
        path=_BASE_DIR / f"Adeon Pay Verify {idx}.png"
        try:
            img.save(str(path),format="PNG")
            raw=_vision_ocr_image(path,timeout=2.4)
            vals=values_from(raw)
        except Exception:
            vals=[]
        if vals:
            # The crop is narrow; multiple different dollar amounts are unsafe.
            uniq=[]
            for v in vals:
                if not any(abs(v-u)<0.005 for u in uniq): uniq.append(v)
            if len(uniq)==1:
                reads.append(uniq[0])
            else:
                return False, f"ambiguous pay crop {uniq}"

    # Any clear low-pay reading is a hard rejection even when another OCR pass
    # claimed a much larger value. This specifically prevents $3 -> $300 errors.
    if any(v < MIN_PAY for v in reads):
        return False, f"independent pay read below minimum: {reads}"
    agree=[v for v in reads if abs(v-candidate)<0.005]
    required=3 if (strict_high and candidate>=100.0) else 2
    if len(agree) < required:
        return False, f"pay confirmation disagreed candidate=${candidate:.2f} reads={reads} required={required}"

    # One fresh full-window OCR frame must still show the same order/pay before
    # the click. For unusually high values require this extra independent check.
    if candidate>=100.0:
        fresh=_vision_read_snapshot(hwnd,force=True) or {}
        match=None
        for rr in fresh.get("rows") or []:
            if str(rr.get("orderNo") or "").strip().upper()==key:
                match=rr; break
        try: fresh_pay=float((match or {}).get("pay") or 0.0)
        except Exception: fresh_pay=0.0
        if not match or fresh_pay < MIN_PAY or abs(fresh_pay-candidate)>=0.005 or not bool(match.get("visionPayGeometryVerified")):
            return False, f"fresh full-frame high-pay confirmation failed fresh=${fresh_pay:.2f}"

    log(f"SCREEN VISION PAY CONFIRMED | {key} | ${candidate:.2f} | independent reads={reads}")
    return True, f"confirmed ${candidate:.2f}"


def _vision_verify_open_panel_pay(brain, snap: dict, expected_pay: float = 0.0) -> tuple[bool, str]:
    """Final Screen Vision earnings gate immediately before Reserve.

    The row was already independently checked before it was opened. This second
    gate verifies the open right-side drawer itself. If the drawer does not expose
    an explicit A+/You'll-earn value, Adeon fails closed and leaves Reserve for the
    user rather than guessing.
    """
    if not bool((snap or {}).get("vision")):
        return True,"non-vision"
    try:
        current=float((snap or {}).get("visionPanelPay") or 0.0)
        expected=float(expected_pay or 0.0)
    except Exception:
        return False,"panel pay parse failed"
    rid=str((snap or {}).get("visionPanelOrder") or (snap or {}).get("urlId") or "").strip().upper()
    if not rid or not bool((snap or {}).get("visionPanelContext")) or not bool((snap or {}).get("panelOpen")):
        return False,"open order drawer identity/context not verified"
    if current < MIN_PAY:
        return False,f"open drawer earnings ${current:.2f} are below/unknown ${MIN_PAY:.2f} minimum"
    if expected >= MIN_PAY and abs(current-expected) >= 0.005:
        return False,f"open drawer earnings ${current:.2f} disagree with verified row ${expected:.2f}"
    hwnd=int((snap or {}).get("uiaHwnd") or getattr(brain,"_uia_hwnd",0) or 0)
    fresh=_vision_read_snapshot(hwnd,force=True) if hwnd else {}
    fresh_rid=str((fresh or {}).get("visionPanelOrder") or (fresh or {}).get("urlId") or "").strip().upper()
    try:fresh_pay=float((fresh or {}).get("visionPanelPay") or 0.0)
    except Exception:fresh_pay=0.0
    if fresh_rid != rid or not bool((fresh or {}).get("visionPanelContext")) or not bool((fresh or {}).get("panelOpen")):
        return False,"fresh open-drawer identity confirmation failed"
    if fresh_pay < MIN_PAY or abs(fresh_pay-current) >= 0.005:
        return False,f"fresh open-drawer earnings confirmation disagreed: ${current:.2f} -> ${fresh_pay:.2f}"
    if expected >= MIN_PAY and abs(fresh_pay-expected) >= 0.005:
        return False,f"fresh drawer ${fresh_pay:.2f} disagrees with verified row ${expected:.2f}"
    log(f"SCREEN VISION OPEN-PANEL PAY CONFIRMED | {rid} | ${fresh_pay:.2f} | Reserve gate passed")
    return True,f"confirmed ${fresh_pay:.2f}"


def pick_row(rows, reserved_id: str, tapped: dict[str, float], opened_once: set[str], priority_keys: set[str] | None = None, new_only: bool = False):
    now = time.time()
    best = None
    reserved_norm = str(reserved_id or "").strip().upper()
    done_norm = {str(x).strip().upper() for x in _done}
    opened_norm = {str(x).strip().upper() for x in opened_once}
    priority_norm = {str(x).strip().upper() for x in (priority_keys or set()) if str(x).strip()}
    for r in rows or []:
        key = row_key(r)
        key_norm = key.strip().upper()
        if not key:
            continue
        if new_only and key_norm not in priority_norm:
            continue
        if r.get("tutor"):
            continue
        # If the list row itself already exposes a DO NOT ACCEPT / fine warning,
        # do not even open it, much less Reserve it. The panel is checked again
        # immediately before every Reserve click as a second hard gate.
        if has_do_not_accept(str(r.get("text") or "")):
            _done.add(key_norm)
            log(f"DO NOT ACCEPT warning visible in row {key}; skipping without Reserve.")
            continue
        pay = float(r.get("pay") or 0)
        pay_source = str(r.get("paySource") or "unknown")
        pay_kind = str(r.get("payKind") or "preferred earnings")
        audit_key = f"{key_norm}|{pay:.2f}|{pay_kind}|{pay_source}"
        if audit_key not in _pay_audit_seen:
            _pay_audit_seen.add(audit_key)
            decision = "ELIGIBLE" if pay >= MIN_PAY else "SKIP UNDER/UNKNOWN $6 EARNINGS LIMIT"
            log(f"PAY CHECK | {key} | {pay_kind}=${pay:.2f} | source={pay_source} | {decision}")
        if pay < MIN_PAY:
            continue
        if key_norm in done_norm:
            continue
        if reserved_norm and key_norm == reserved_norm:
            continue
        # Once a physical row click has been sent successfully for this exact
        # order during this session, never click that same row again. F5 does
        # all future refreshing. A different/new order can still be opened.
        if key_norm in opened_norm:
            continue
        last = tapped.get(key)
        if last and now - last < ROW_RETRY_SEC:
            continue
        if best is None or pay > float(best.get("pay") or 0):
            best = r
    return best


def next_reload(i: int, last: float | None = None) -> float:
    # A fresh random 3-5 second search delay each time. The real-F5 hard floor
    # independently guarantees that no physical refresh can happen sooner than 3s.
    lo, hi = RELOAD_FAST if i % (RELOAD_FAST_N + RELOAD_SLOW_N) < RELOAD_FAST_N else RELOAD_SLOW
    return random.uniform(lo, hi)


def critical_alert_profile(waited: float) -> tuple[int, float, float, int] | None:
    """Return (slot, due_at, next_cadence, level) for the latest critical slot.

    Schedule: 3:00-5:30 every 15s, 5:30-6:00 every 10s,
    6:00-6:30 every 7.5s, then every 5s until reservation end.
    """
    waited = max(0.0, float(waited or 0.0))
    if waited < RESERVE_CRITICAL_START:
        return None

    stage1_count = int(round((RESERVE_CRITICAL_ESCALATE - RESERVE_CRITICAL_START) / RESERVE_CRITICAL_CADENCE_1))
    stage2_count = int(round((RESERVE_CRITICAL_STAGE3 - RESERVE_CRITICAL_ESCALATE) / RESERVE_CRITICAL_CADENCE_2))
    stage3_count = int(round((RESERVE_CRITICAL_STAGE4 - RESERVE_CRITICAL_STAGE3) / RESERVE_CRITICAL_CADENCE_3))

    if waited < RESERVE_CRITICAL_ESCALATE:
        local = int((waited - RESERVE_CRITICAL_START) // RESERVE_CRITICAL_CADENCE_1)
        due_at = RESERVE_CRITICAL_START + local * RESERVE_CRITICAL_CADENCE_1
        return local, due_at, RESERVE_CRITICAL_CADENCE_1, 1
    if waited < RESERVE_CRITICAL_STAGE3:
        local = int((waited - RESERVE_CRITICAL_ESCALATE) // RESERVE_CRITICAL_CADENCE_2)
        due_at = RESERVE_CRITICAL_ESCALATE + local * RESERVE_CRITICAL_CADENCE_2
        return stage1_count + local, due_at, RESERVE_CRITICAL_CADENCE_2, 2
    if waited < RESERVE_CRITICAL_STAGE4:
        local = int((waited - RESERVE_CRITICAL_STAGE3) // RESERVE_CRITICAL_CADENCE_3)
        due_at = RESERVE_CRITICAL_STAGE3 + local * RESERVE_CRITICAL_CADENCE_3
        return stage1_count + stage2_count + local, due_at, RESERVE_CRITICAL_CADENCE_3, 3

    local = int((waited - RESERVE_CRITICAL_STAGE4) // RESERVE_CRITICAL_CADENCE_4)
    due_at = RESERVE_CRITICAL_STAGE4 + local * RESERVE_CRITICAL_CADENCE_4
    return stage1_count + stage2_count + stage3_count + local, due_at, RESERVE_CRITICAL_CADENCE_4, 4


# ---------------- health checks ----------------
def startup_self_check(brain: Brain) -> bool:
    ok = True

    # brain.attach() has already positively attached to the existing browser. Do
    # not fail merely because the cached Screen Vision liveness timestamp is a few
    # seconds old while the user is on another LR page. Prove startup from a fresh
    # readable snapshot below instead.

    # A just-sent F5 can leave Screen Vision between frames for a moment. One
    # missed OCR frame must never kill Picker. Retry the existing browser in place
    # for up to 10 seconds; no extra tab/window is opened and no extra F5 is sent.
    snap = {}
    deadline = time.time() + 10.0
    while time.time() < deadline and not _stop:
        snap = brain.read() or {}
        if snap and (snap.get("onFind") or snap.get("onMyOrders") or snap.get("rows") or snap.get("navFind")):
            break
        time.sleep(0.20)
    if not snap:
        note_issue(
            "SELF_CHECK_DOM",
            "Startup check could not read the LR Writers page after retrying the existing browser",
            "ERROR",
            throttle=0,
        )
        return False

    if bool(snap.get("loggedOut")):
        if _LABELS_ONLY_MODE:
            set_status_ticket(bot="CONNECTED", page="LABELS WAIT", job="WAITING LOGIN", f5="OFF", mouse="OFF")
            log("LABELS WAIT: LR Writers is logged out. Labels remain running in the background and will return automatically after manual login.")
        else:
            hard_stop_logout("LR Writers was already logged out when the bot started")
            return False

    url = str(snap.get("url") or "")
    url_low = url.lower()
    on_lr = bool("myaccount.lrwriters.com" in url_low or snap.get("onFind") or snap.get("onMyOrders"))
    if not on_lr:
        note_issue(
            "SELF_CHECK_PAGE",
            "Startup could not positively confirm an LR Writers page",
            "WARN",
            url or str(snap.get("pageTitle") or ""),
            throttle=0,
        )
        return False

    title = str(snap.get("pageTitle") or "")
    using_uia = bool(snap.get("uia"))
    main, rend = chrome_handles(title)
    if using_uia:
        main = int(snap.get("uiaHwnd") or main or 0)
        if not main:
            note_issue(
                "SELF_CHECK_WINDOW",
                "Could not identify the existing browser window for Windows accessibility mode",
                "ERROR", title, throttle=0,
            )
            ok = False
    elif not main or not rend:
        note_issue(
            "SELF_CHECK_WINDOW",
            "Could not identify the browser window and its page renderer",
            "ERROR", title, throttle=0,
        )
        ok = False

    inner_w = float(snap.get("innerW") or 0)
    inner_h = float(snap.get("innerH") or 0)
    if inner_w < 500 or inner_h < 300:
        note_issue(
            "SELF_CHECK_VIEWPORT",
            "Browser viewport looks unexpectedly small",
            "ERROR",
            f"{snap.get('innerW')}x{snap.get('innerH')}",
            throttle=0,
        )
        ok = False

    if using_uia:
        main_rect = _screen_rect(main) if main else None
        if not main_rect:
            note_issue("SELF_CHECK_UIA_RECT", "Could not read the existing browser's physical rectangle", "ERROR", throttle=0)
            ok = False
        else:
            probe = snap.get("reserve")
            probe_name = "Reserve"
            if not probe:
                rows = snap.get("rows") or []
                probe = rows[0] if rows else snap.get("navFind")
                probe_name = "ROW/NAV"
            if probe:
                try:
                    x=float(probe.get("sx")); y=float(probe.get("sy"))
                    x1=float(probe.get("screenLeft")); y1=float(probe.get("screenTop"))
                    x2=x1+float(probe.get("screenW")); y2=y1+float(probe.get("screenH"))
                    ml,mt,mr,mb=main_rect
                    if not (x1 <= x <= x2 and y1 <= y <= y2 and ml <= x < mr and mt <= y < mb):
                        raise ValueError("accessibility target is outside its verified browser rectangle")
                except Exception as e:
                    note_issue("SELF_CHECK_UIA_PROBE", "Windows accessibility target could not be safely mapped to the physical browser", "ERROR", f"{probe_name}: {e}", throttle=0)
                    ok = False
            log(f"{'Screen Vision' if bool(snap.get('vision')) else 'Windows accessibility'} mapping ready: physical browser feed {inner_w:.0f}x{inner_h:.0f}; no DOM injection or browser extension is required for Picker.")
    else:
        mapping = _viewport_mapping(inner_w, inner_h, title) if ok else None
        if not mapping:
            note_issue(
                "SELF_CHECK_MAPPING",
                "Could not establish a reliable DOM-to-physical mouse mapping",
                "ERROR",
                throttle=0,
            )
            ok = False
        else:
            log(
                "Viewport mapping ready: "
                f"CSS {inner_w:.0f}x{inner_h:.0f} -> render "
                f"{mapping['right']-mapping['left']}x{mapping['bottom']-mapping['top']} "
                f"scale {mapping['scale_x']:.3f},{mapping['scale_y']:.3f}"
            )
            probe = snap.get("reserve")
            probe_name = "Reserve"
            if not probe:
                rows = snap.get("rows") or []
                probe = rows[0] if rows else None
                probe_name = "ROW"
            if probe and probe.get("vx") is not None and probe.get("vy") is not None:
                p = viewport_to_screen(float(probe["vx"]), float(probe["vy"]), title, inner_w, inner_h)
                rect = _mapped_dom_rect(probe, snap, title)
                if not p or not rect:
                    note_issue("SELF_CHECK_PROBE_MAPPING", "Visible target could not be mapped to the physical browser", "ERROR", probe_name, throttle=0)
                    ok = False
                else:
                    x,y=p; x1,y1,x2,y2=rect
                    if not (x1 <= x <= x2 and y1 <= y <= y2):
                        note_issue("SELF_CHECK_PROBE_OUTSIDE", "Mapped target center was outside its physical target rectangle", "ERROR", f"{probe_name} point={p} rect={rect}", throttle=0)
                        ok = False

    update_last_state(snap, startup_check="passed" if ok else "failed")
    if ok:
        if bool(snap.get("onMyOrders")):
            mode_name = "My Orders / LABEL"
        elif bool(snap.get("onFind")):
            mode_name = "Find Orders"
        else:
            mode_name = "LR Writers / passive wait"
        source_name = "Screen Vision" if bool(snap.get("vision")) else ("Windows accessibility" if using_uia else "screen reader")
        log(f"Startup self-check PASSED. {source_name}, {mode_name}, and physical mouse safety mapping are ready.")
    return ok


def startup_mouse_proof(snap: dict, step: int = 0) -> bool:
    """Visible movement-only proof during the first ten active Picker seconds.

    It never clicks. It runs only while the exact Find Orders page is foreground
    and no order/reservation action is open, so it cannot steal another tab or
    activate a page control.
    """
    if _paused or stop_requested_now() or not snap or not bool(snap.get("onFind")):
        return False
    if snap.get("panelOpen") or snap.get("reserve") or snap.get("accept") or snap.get("reject"):
        return False
    hwnd=int(snap.get("uiaHwnd") or 0)
    if not hwnd:
        hwnd=int(find_chrome_main("writer tool") or find_chrome_main("lr writers") or 0)
    if not hwnd:
        return False
    try:
        if int(user32.GetForegroundWindow() or 0) != hwnd:
            return False
    except Exception:
        return False
    rect=_screen_rect(hwnd)
    if not rect:
        return False
    l,t,r,b=rect
    w=max(1,r-l); h=max(1,b-t)
    # Movement only: safe points inside the visible content area. No click is made.
    pattern=((0.30,0.34),(0.66,0.42),(0.40,0.56),(0.70,0.66),(0.34,0.50),(0.60,0.38))
    fx,fy=pattern[int(step or 0)%len(pattern)]
    x=int(l+max(80,min(w-80,w*fx)))
    y=int(t+max(155,min(h-70,h*fy)))
    try:
        before=pyautogui.position()
        pyautogui.moveTo(x,y,duration=0.22)
        log(f"STARTUP MOUSE PROOF: moved ({int(before.x)},{int(before.y)}) -> ({x},{y}); no click")
        return True
    except Exception:
        return False


# ---------------- director ----------------
def run_bot_session() -> None:
    global _stop_reason
    mode_name = "LABELS" if _LABELS_ONLY_MODE else "PICKER"
    set_status_ticket(bot="STARTING", page="CONNECTING", job=("LABEL" if _LABELS_ONLY_MODE else "SEARCHING"), f5="WAIT", mouse="WAIT", mode=mode_name)
    if _LABELS_ONLY_MODE:
        log("Adeon label-only session starting. Picker clicks, F5, and idle mouse activity are disabled.")
    else:
        log("Adeon session starting. Physical clicks: order row, Reserve, and exact still-there confirmation. Accept and automatic Reject are forbidden.")
    log(f"Live page scan target: every {DOM_SCAN_INTERVAL*1000:.0f} ms while active; F5 is scheduled 3-5 seconds while searching with a hard 3-second minimum between real presses, and is held completely during an active reservation. Temporary network loss never terminates the worker.")
    log(f"Midnight rule: {MIDNIGHT_RULE_START_HOUR:02d}:00-{MIDNIGHT_RULE_END_HOUR:02d}:00 local, under {MIDNIGHT_REJECT_UNDER_MINUTES/60:.0f}h -> Reject cue after {MIDNIGHT_REJECT_AFTER/60:.0f} min reserved; no automatic Reject.")
    brain = Brain()
    label_sync = LabelSyncManager() if _LABELS_ONLY_MODE else None
    label_overlay = LabelOverlayManager() if _LABELS_ONLY_MODE else None
    try:
        if not brain.attach():
            _stop_reason = "startup failed: Screen Vision / Windows accessibility unavailable"
            if not _APP_LAST_ERROR_FILE.exists():
                write_last_error("Adeon could not prepare/connect to Chrome. See VIEW ACTIVITY LOG.")
            note_issue("STARTUP_ABORT", "Adeon stopped because it could not prepare or attach safely to Chrome", "ERROR", throttle=0)
            return
        if _LABELS_ONLY_MODE:
            # Labels use only an already-open LR Writers tab and are fully passive.
            # Starting Labels never refreshes, navigates, or changes the active tab.
            brain.prepare_labels_tab(reload_current=False)
            if label_sync:
                # Pull canonical server state first, then flush any edits that were
                # safely queued while this laptop was offline. A protocol-2 server
                # rejects stale offline overwrites but preserves them in history.
                label_sync.poll_remote(force=True)
                label_sync.push_remote(force=True)
                label_sync.poll_remote(force=True)
                brain.apply_label_state(label_sync.snapshot())
        if not startup_self_check(brain):
            _stop_reason = "startup self-check failed"
            write_last_error("Adeon connected to Chrome, but its startup safety check failed. See VIEW ACTIVITY LOG.")
            note_issue("STARTUP_ABORT", "Bot stopped because startup self-check did not pass", "ERROR", throttle=0)
            return

        last_reload=time.time(); cycle=0; next_in=next_reload(0)
        label_mode_active=False
        last_find_recovery_try=0.0
        last_f5_press_at=0.0; burst_guard_until=0.0
        last_idle=time.time(); next_idle=random.uniform(*IDLE_MOVE)
        last_idle_click=time.time(); next_idle_click=random.uniform(*IDLE_CLICK)
        idle_active_started=time.time(); idle_pause_until=0.0
        last_reserve_try=0.0; last_row_key=None
        tapped: dict[str,float]={}; opened_once:set[str]=set(); vision_pay_confirmed:dict[str,tuple[float,float]]={}; refresh_pause_until=0.0; force_refresh=False; active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""; hold_missing_since=0.0; post_accept_ready=False; last_accepted_id=""
        seen_row_keys:set[str]=set(); new_row_keys:set[str]=set(); row_baseline_captured=False
        baseline_started=time.time(); baseline_union:set[str]=set(); baseline_last_keys:set[str]=set(); baseline_same_since=0.0
        blank_since=0.0; busy_since=0.0; last_health_log=time.time(); last_port_check=0.0
        reserved=False; reserved_at=0.0; reserved_id=""; reserved_hint=""; reserved_flags:set[str]=set()
        reservation_serial=0; reservation_alert_prefix=""; reserved_remaining_minutes:float|None=None; reserved_midnight_window=False; reserved_midnight_reject=False; last_midnight_reject_try=0.0
        reserved_details:dict={}; last_reservation_status_check=0.0; reservation_missing_checks=0; remote_absent_checks=0; pre_reserve_cache:dict[str,dict]={}
        late_reminder_slot=-1; late_reservation_alert_keys:set[str]=set()
        # One initial Reserved report per order per worker session. This is separate
        # from reminder keys so a trusted manual Accept can never cause the same
        # order to emit a second initial Reserved message if the old drawer lingers.
        reserved_notice_order_ids:set[str]=set()
        reserved_waiting_keys:set[str]=set()
        inspection_scrollbar_passes=0
        last_still_here_click=0.0
        startup_mouse_proof_started=time.time()
        startup_mouse_proof_last=0.0
        startup_mouse_proof_step=0
        if not _LABELS_ONLY_MODE:
            log("STARTUP MOUSE PROOF ARMED: for the first 10 active Find Orders seconds the mouse will visibly move without clicking.")

        def refresh_status_ticket(page_state: str = "ONLINE") -> None:
            now_ticket = time.time()
            if _paused:
                with _pause_lock:
                    reason = str(_pause_reason or "PAUSED")
                page_label = "LOGGED OUT" if "logout" in reason.lower() or "login" in reason.lower() else page_state
                job_label = (f"RESERVED {reserved_id[:16]}" if reserved and reserved_id else "SEARCHING")
                set_status_ticket(bot="PAUSED", page=page_label, job=job_label, f5="PAUSED", mouse="PAUSED")
                return
            job_label = (f"RESERVED {reserved_id[:16]}" if reserved and reserved_id else "SEARCHING")
            scheduled_left = next_in - (now_ticket - last_reload)
            burst_left = burst_guard_until - now_ticket
            f5_left = max(0.0, scheduled_left, burst_left)
            f5_label = "HOLD RESERVED" if reserved else f"{int(round(f5_left))}s NORMAL"
            if idle_pause_until and now_ticket < idle_pause_until:
                mins = max(1, int((idle_pause_until - now_ticket + 59.0) // 60.0))
                mouse_label = f"REST {mins}m"
            else:
                active_left = max(0.0, IDLE_ACTIVE_FOR - (now_ticket - idle_active_started))
                mins = max(1, int((active_left + 59.0) // 60.0))
                mouse_label = f"ACTIVE {mins}m"
            set_status_ticket(bot="CONNECTED", page=page_state, job=job_label, f5=f5_label, mouse=mouse_label)

        refresh_status_ticket("ONLINE")

        def maybe_f5() -> None:
            nonlocal last_reload, cycle, next_in, force_refresh, last_f5_press_at, burst_guard_until
            if _stop or _paused:
                return
            # Once Reserve is confirmed, do not refresh at all. Keep the live DOM
            # scanner/watchdog active and resume F5 only after Accept/Reject/timeout.
            if reserved:
                force_refresh = False
                return

            now_f5 = time.time()

            # Hard floor only: every actual F5 must be at least 3 seconds after
            # the previous actual F5, including queued/forced refreshes.
            if last_f5_press_at and now_f5 - last_f5_press_at < F5_HARD_MIN_GAP:
                return

            def note_f5_press(sent_at: float) -> None:
                nonlocal last_f5_press_at, burst_guard_until
                if last_f5_press_at:
                    actual_gap = sent_at - last_f5_press_at
                    burst_guard_until = 0.0
                last_f5_press_at = sent_at

            if force_refresh:
                # Newly detected orders outrank even a queued/forced F5.
                if now_f5 < refresh_pause_until:
                    return
                force_refresh = False
                send_f5(brain)
                sent_at = time.time()
                note_f5_press(sent_at)
                last_reload = sent_at
                cycle += 1
                next_in = random.uniform(*RESERVED_RELOAD) if reserved else next_reload(cycle, next_in)
                next_in = max(F5_HARD_MIN_GAP, next_in)
                mode = "reserved" if reserved else "normal"
                log(f"Queued forced F5 sent. Next scheduled F5 in {next_in:.1f}s ({mode} refresh mode)")
                return

            if now_f5 < refresh_pause_until or now_f5-_last_click < 1.20 or now_f5-last_reload < max(F5_HARD_MIN_GAP, next_in):
                return
            send_f5(brain)
            sent_at = time.time()
            note_f5_press(sent_at)
            last_reload=sent_at
            cycle+=1
            next_in = random.uniform(*RESERVED_RELOAD) if reserved else next_reload(cycle,next_in)
            next_in = max(F5_HARD_MIN_GAP, next_in)
            mode = "reserved" if reserved else "normal"
            log(f"Next F5 in {next_in:.1f}s ({mode} refresh mode)")

        def clear_reserved(why: str) -> None:
            nonlocal reserved,reserved_at,reserved_id,reserved_hint,reserved_flags,hold_missing_since
            nonlocal reservation_alert_prefix,reserved_remaining_minutes,reserved_midnight_window,reserved_midnight_reject,last_midnight_reject_try
            nonlocal last_reload,next_in,cycle,reserved_details,last_reservation_status_check,reservation_missing_checks,remote_absent_checks
            nonlocal late_reminder_slot,late_reservation_alert_keys
            nonlocal active_opened_id,active_opened_hint,active_opened_deadline_text
            nonlocal force_refresh,refresh_pause_until,reserved_waiting_keys
            nonlocal inspection_scrollbar_passes
            old_prefix = reservation_alert_prefix
            log(why)
            if reserved_id:
                _done.add(str(reserved_id).strip().upper())
                opened_once.add(str(reserved_id).strip().upper())
            if old_prefix:
                cancel_alert_keys([old_prefix+":still1", old_prefix+":still5", old_prefix+":reserved"] + list(late_reservation_alert_keys))
                cancel_critical_reservation_push(old_prefix)
            clear_reservation_state()
            reserved=False; reserved_at=0.0; reserved_id=""; reserved_hint=""; reserved_flags=set(); hold_missing_since=0.0
            reservation_alert_prefix=""; reserved_remaining_minutes=None; reserved_midnight_window=False; reserved_midnight_reject=False; last_midnight_reject_try=0.0
            reserved_details={}; last_reservation_status_check=0.0; reservation_missing_checks=0; remote_absent_checks=0; reserved_waiting_keys=set()
            late_reminder_slot=-1; late_reservation_alert_keys=set()
            inspection_scrollbar_passes=0
            # A reservation that ended must never leave the dashboard attached to
            # the old order. The next live DOM scan decides what is actually open.
            active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""
            # Return to search immediately when the reservation ends. The queued F5
            # still obeys the global 3-second minimum between real F5 presses.
            refresh_pause_until = 0.0
            force_refresh = True
            last_reload = time.time()
            next_in = next_reload(cycle, None)
            log("SEARCH MODE: reservation ended; new-order scanning is active again and a safe F5 is queued.")
            update_last_state(reserved=False,reserved_id="",reserved_remaining_minutes="",midnight_reject_pending=False,next_refresh_seconds=round(next_in,1))

        def remember_pre_reserve_snapshot(snap0: dict | None, rid_hint: str = "") -> None:
            snap0 = snap0 or {}
            raw0 = str(snap0.get("panelText") or "")
            if not raw0:
                return
            keys = set()
            if rid_hint:
                keys.add(str(rid_hint).strip().upper())
            m0 = _ORDER_NO_RE.search(raw0)
            if m0:
                keys.add(m0.group(0).upper())
            uid0 = str(snap0.get("urlId") or "").strip().upper()
            if uid0 and uid0 not in ("ALL", "FINDORDERS"):
                keys.add(uid0)
            for rr in snap0.get("rows") or []:
                rno = str(rr.get("orderNo") or "").strip().upper()
                if rno and (not keys or rno in keys or rno in raw0.upper()):
                    keys.add(rno)
                    iid = str(rr.get("id") or "").strip().upper()
                    if iid:
                        keys.add(iid)
            for key in keys:
                if key:
                    old_snap = pre_reserve_cache.get(key)
                    if old_snap is None or _detail_snapshot_score(snap0) >= _detail_snapshot_score(old_snap):
                        pre_reserve_cache[key] = dict(snap0)

        def gather_pre_reserve_details(expected_id: str, initial: dict | None, seconds: float = 0.35) -> dict:
            """Take several fresh DOM reads before Reserve and keep the richest exact-order drawer.

            This is intentionally DOM reading only: no F5 and no action click. It gives
            React/LR a short moment to finish mounting the same title, deadline, Task
            summary and Full order description that the older Tampermonkey script read.
            """
            nonlocal refresh_pause_until
            expected = str(expected_id or "").strip().upper()
            best = dict(initial or {})
            remember_pre_reserve_snapshot(best, expected)
            deadline = time.time() + max(0.2, seconds)
            refresh_pause_until = max(refresh_pause_until, deadline + 0.20)
            while time.time() < deadline and not _stop and not _paused:
                cur = brain.read() or {}
                if cur:
                    uid = str(cur.get("urlId") or "").strip().upper()
                    ptxt = (str(cur.get("panelText") or "") + "\n" + str(cur.get("panelDeepText") or "")).upper()
                    id_ok = (not expected) or uid == expected or expected in ptxt or f"/{expected}" in str(cur.get("url") or "").upper()
                    if id_ok:
                        remember_pre_reserve_snapshot(cur, expected)
                        if _detail_snapshot_score(cur) > _detail_snapshot_score(best):
                            best = dict(cur)
                        low = (str(best.get("panelText") or "") + " " + str(best.get("panelDeepText") or "")).lower()
                        if "task summary" in low and "full order description" in low and "final ddl" in low:
                            break
                time.sleep(0.10)
            return best

        def gather_post_reserve_details(expected_id: str, initial: dict | None, deadline_text: str = "", seconds: float = 3.2) -> tuple[dict, dict]:
            """Read the freshly RESERVED drawer repeatedly before any Pushover is sent.

            The reserved state is authoritative for notification extraction.  We read
            innerText, textContent and the anchored body text on every 100ms DOM pass,
            exactly like the warning scanner reads DO NOT ACCEPT.  No F5 occurs here.
            We stop early only when task number, price, deadline, title, Task summary
            and Full order description are all present.
            """
            nonlocal refresh_pause_until
            expected = str(expected_id or "").strip().upper()
            best_snap = dict(initial or {})
            best_details = capture_reservation_details(best_snap, expected, expected, deadline_text)
            best_score = _reservation_detail_score(best_details)
            end = time.time() + max(0.6, seconds)
            refresh_pause_until = max(refresh_pause_until, end + 0.25)
            while time.time() < end and not _stop and not _paused:
                cur = brain.read() or {}
                if cur:
                    panel_words = "\n".join([
                        str(cur.get("panelText") or ""),
                        str(cur.get("panelDeepText") or ""),
                        str(cur.get("detailAnchorText") or ""),
                        str(cur.get("detailDeepAnchorText") or ""),
                        str(cur.get("bodyText") or ""),
                    ])
                    uid = str(cur.get("urlId") or "").strip().upper()
                    id_ok = (
                        bool(cur.get("reject"))
                        or not expected
                        or uid == expected
                        or expected in panel_words.upper()
                        or f"/{expected}" in str(cur.get("url") or "").upper()
                    )
                    if id_ok:
                        details = capture_reservation_details(cur, expected, panel_words, deadline_text)
                        score = _reservation_detail_score(details)
                        if score > best_score:
                            best_score = score
                            best_snap = dict(cur)
                            best_details = details
                        if _reservation_details_complete(details):
                            best_snap = dict(cur)
                            best_details = details
                            log(
                                "POST-RESERVE DETAILS COMPLETE | "
                                f"task={details.get('taskNo')} price={details.get('price')} "
                                f"deadline={details.get('deadline')} title={details.get('title')} "
                                f"summary_chars={len(str(details.get('taskSummary') or ''))} "
                                f"full_desc_chars={len(str(details.get('fullDesc') or ''))}"
                            )
                            return best_snap, best_details
                time.sleep(DOM_SCAN_INTERVAL)

            # The live reserved drawer remains primary.  Only if LR genuinely omitted
            # a field from that drawer do we fill that one missing field from the rich
            # snapshot captured for the same order immediately before Reserve.
            pre_candidates = []
            for ck, cached in list(pre_reserve_cache.items()):
                if ck == expected or expected in str((cached or {}).get("panelText") or "").upper():
                    pre_candidates.append(cached)
            if pre_candidates:
                pre_best = max(pre_candidates, key=_detail_snapshot_score)
                pre_details = capture_reservation_details(pre_best, expected, expected, deadline_text)
                merged = _merge_missing_reservation_details(best_details, pre_details)
                if merged != best_details:
                    log("POST-RESERVE DETAIL FALLBACK | live reserved drawer was missing one or more fields; filled only missing fields from the same order's pre-Reserve snapshot.")
                best_details = merged
            return best_snap, best_details

        def mark_reserved(rid: str, hint: str, reserve_snap: dict|None=None, deadline_text: str="") -> None:
            nonlocal reserved,reserved_at,reserved_id,reserved_hint,reserved_flags,hold_missing_since
            nonlocal reservation_serial,reservation_alert_prefix,reserved_remaining_minutes,reserved_midnight_window,reserved_midnight_reject,last_midnight_reject_try
            nonlocal last_reload,next_in,reserved_details,last_reservation_status_check,reservation_missing_checks,remote_absent_checks
            nonlocal late_reminder_slot,late_reservation_alert_keys
            nonlocal inspection_scrollbar_passes,force_refresh
            reserved=True; reserved_at=time.time(); reserved_id=(rid or hint or "job").strip().upper(); reserved_hint=hint or reserved_id; reserved_flags=set(); hold_missing_since=0.0
            last_reservation_status_check=0.0; reservation_missing_checks=0; remote_absent_checks=0
            late_reminder_slot=-1; late_reservation_alert_keys=set()
            inspection_scrollbar_passes=0
            # Reservation hold: no F5 is allowed until this reservation ends.
            # The 100ms DOM scanner and 10-second reservation watchdog remain live.
            force_refresh = False
            last_reload = reserved_at
            next_in = 999999.0
            log("RESERVED F5 HOLD: refresh is disabled until this order is accepted, rejected, or no longer reserved.")
            reservation_serial += 1
            reservation_alert_prefix = f"{reserved_id}:{int(reserved_at)}:{reservation_serial}"
            last_midnight_reject_try=0.0
            source = " ".join([deadline_text or "", str((reserve_snap or {}).get("panelText") or ""), reserved_hint])
            reserved_remaining_minutes = parse_remaining_minutes(source)
            reserved_midnight_window = in_midnight_rule_window()
            reserved_midnight_reject = bool(
                reserved_midnight_window
                and reserved_remaining_minutes is not None
                and reserved_remaining_minutes < MIDNIGHT_REJECT_UNDER_MINUTES
            )
            # IMPORTANT: read the page AFTER Reserve has changed the order into its
            # reserved state.  Do not send Pushover until the live reserved drawer has
            # been re-read repeatedly and its old-script fields have been extracted.
            # This uses the same DOM text surfaces that warning detection uses.
            best_detail_snap, reserved_details = gather_post_reserve_details(
                reserved_id, reserve_snap or {}, deadline_text, seconds=3.2
            )
            log(
                "RESERVATION DETAILS CAPTURED FROM RESERVED PANEL | "
                f"task={reserved_details.get('taskNo') or 'unknown'} | "
                f"price={reserved_details.get('price') or 'missing'} | "
                f"deadline={reserved_details.get('deadline') or 'unknown'} | "
                f"title={reserved_details.get('title') or 'missing'} | "
                f"summary_chars={len(str(reserved_details.get('taskSummary') or ''))} | "
                f"full_desc_chars={len(str(reserved_details.get('fullDesc') or ''))}"
            )
            if not str(reserved_details.get("taskSummary") or "").strip() or not str(reserved_details.get("fullDesc") or "").strip():
                note_issue(
                    "RESERVATION_DETAIL_INCOMPLETE",
                    "Reserved panel did not expose every old-style notification section after repeated DOM reads",
                    "WARN",
                    f"task={reserved_details.get('taskNo') or reserved_id} title={reserved_details.get('title') or ''}",
                    throttle=0,
                )
            public_task_no = str(reserved_details.get("taskNo") or "").strip().upper()
            if _ORDER_NO_RE.fullmatch(public_task_no) and public_task_no != reserved_id:
                old_reserved_id = reserved_id
                reserved_id = public_task_no
                reservation_alert_prefix = f"{reserved_id}:{int(reserved_at)}:{reservation_serial}"
                log(f"RESERVATION ID NORMALIZED: {old_reserved_id} -> public task number {reserved_id}.")
            opened_once.add(reserved_id)
            record_stat("reservations_confirmed")
            update_last_state(
                reserved=True,reserved_id=reserved_id,reserved_hint=reserved_hint[:180],opened_once_count=len(opened_once),
                reserved_remaining_minutes=(round(reserved_remaining_minutes,1) if reserved_remaining_minutes is not None else "unknown"),
                midnight_window_at_reserve=reserved_midnight_window,midnight_reject_pending=reserved_midnight_reject,
            )
            if reserved_midnight_reject:
                log(f"MIDNIGHT RULE ADVISORY ARMED: {reserved_id} has about {reserved_remaining_minutes:.1f} min remaining; Reject cues will be shown, but Adeon will NOT click Reject. Normal reservation alerts continue.")
                # Local laptop cue, separate from Pushover: red decision ticket + two-tone bell.
                show_action_popup("REJECT IN 1 MINUTE", "reject", duration=3.0, bell=True)
            elif reserved_midnight_window and reserved_remaining_minutes is None:
                note_issue("MIDNIGHT_DEADLINE_UNKNOWN","Midnight window is active but remaining deadline could not be parsed; the short-deadline Reject advisory is not armed","WARN",reserved_hint,throttle=0)
                show_action_popup("ACCEPT", "accept")
            else:
                # The bot never clicks Accept. This is only the same small green
                # decision cue used by the older script to tell the user what to do.
                show_action_popup("ACCEPT", "accept")
            # Reservation Pushovers: full report now, one short reminder at 1 minute, then from 3:00 an escalating emergency Critical Alert + laptop alarm until the reservation ends.
            full_message = build_reserved_pushover_message(reserved_details)
            notice_id = str(reserved_id or "").strip().upper()
            if notice_id and notice_id in reserved_notice_order_ids:
                log(f"DUPLICATE RESERVED NOTICE SUPPRESSED: {notice_id} already sent its initial Reserved report in this worker session.")
            else:
                if notice_id:
                    # Mark before queuing so even a fast stale-DOM loop cannot queue it twice.
                    reserved_notice_order_ids.add(notice_id)
                send_alert("Reserved", full_message, reservation_alert_prefix+":reserved")
            save_reservation_state({
                "reserved_id": reserved_id, "reserved_hint": reserved_hint, "reserved_at": reserved_at,
                "reservation_alert_prefix": reservation_alert_prefix, "reminder_sent": False,
                "late_reminder_slot": -1,
                "alert_schedule_version": 3,
                "reserve_notice_started": True, "details": reserved_details,
                "remaining_minutes": reserved_remaining_minutes, "midnight_window": reserved_midnight_window,
                "midnight_reject": reserved_midnight_reject,
            })

        def panel_identity(snap: dict, fallback_id: str="", fallback_hint: str="") -> tuple[str,str]:
            uid=str(snap.get("urlId") or ""); rid=uid.upper() if uid and uid.lower() not in ("all","findorders") else (fallback_id or active_opened_id)
            hint=fallback_hint or active_opened_hint
            if not hint: hint=str(snap.get("panelText") or "").replace("\n"," ").strip()[:180]
            return rid or hint or "job", hint or rid or "job"

        def wait_reject(seconds: float=3.6) -> dict:
            nonlocal refresh_pause_until
            deadline=time.time()+seconds; refresh_pause_until=max(refresh_pause_until,deadline+0.75); last={}
            while time.time()<deadline and not _stop and not _paused:
                last=brain.read()
                if last: update_last_state(last,reserved=reserved,reserved_id=reserved_id)
                if last.get("reject") or last.get("acceptedGone"): return last
                time.sleep(0.16)
            return last

        def wait_for_panel_identity(expected_id: str, seconds: float=2.4) -> tuple[dict, bool]:
            """After a new row click, never act on the old panel. Return only when URL/panel identity matches the clicked order."""
            nonlocal refresh_pause_until
            expected = str(expected_id or "").strip().upper()
            deadline = time.time() + seconds
            # F5 must not interrupt the row -> matching panel -> Reserve handoff.
            refresh_pause_until = max(refresh_pause_until, deadline + 0.25)
            last = {}
            while time.time() < deadline and not _stop and not _paused:
                last = brain.read() or {}
                if not last:
                    time.sleep(0.06)
                    continue
                uid = str(last.get("urlId") or "").strip().upper()
                url = str(last.get("url") or "").upper()
                panel_text = str(last.get("panelText") or "").upper()
                url_matches = bool(expected and (uid == expected or f"/{expected}" in url))
                public_order = bool(_ORDER_NO_RE.fullmatch(expected))
                if bool(last.get("vision")):
                    # Screen Vision has no browser DOM URL. Its identity proof comes
                    # from the right-side order drawer only, never from the underlying
                    # list row. Require the exact clicked order number plus a verified
                    # order-detail context and an actionable drawer state.
                    identity_matches = bool(
                        expected and uid == expected and expected in panel_text
                        and bool(last.get("visionPanelContext"))
                        and bool(last.get("panelOpen"))
                    )
                else:
                    # Browser/DOM feeds retain the original v36 requirement.
                    identity_matches = bool(url_matches and ((expected in panel_text) if public_order else True))
                if identity_matches:
                    return last, True
                time.sleep(0.06)
            return last, False

        # Recover a reservation across app STOP/START. Before restoring any lock,
        # verify the live page. If the user accepted/rejected while the bot was off,
        # discard the stale state immediately and continue searching.
        persisted = load_reservation_state()
        if persisted:
            persisted_id = str(persisted.get("reserved_id") or "").strip().upper()
            persisted_hint = str(persisted.get("reserved_hint") or persisted_id)
            first_snap = brain.read() or {}
            still_held = job_still_held(first_snap, persisted_id, persisted_hint)
            if not still_held:
                time.sleep(0.7)
                second_snap = brain.read() or {}
                still_held = job_still_held(second_snap, persisted_id, persisted_hint)
            if still_held and persisted_id:
                reserved = True
                reserved_id = persisted_id
                reserved_hint = persisted_hint
                try:
                    reserved_at = float(persisted.get("reserved_at") or time.time())
                except Exception:
                    reserved_at = time.time()
                reservation_alert_prefix = str(persisted.get("reservation_alert_prefix") or f"{reserved_id}:{int(reserved_at)}:restored")
                reserved_details = persisted.get("details") if isinstance(persisted.get("details"), dict) else {}
                try:
                    v = persisted.get("remaining_minutes")
                    reserved_remaining_minutes = None if v is None else float(v)
                except Exception:
                    reserved_remaining_minutes = None
                reserved_midnight_window = bool(persisted.get("midnight_window"))
                reserved_midnight_reject = bool(persisted.get("midnight_reject"))
                if bool(persisted.get("reminder_sent")):
                    reserved_flags.add("1")
                try:
                    if int(persisted.get("alert_schedule_version", 0) or 0) == 3:
                        late_reminder_slot = int(persisted.get("late_reminder_slot", -1))
                    else:
                        # Older builds used different start times/cadences.
                        late_reminder_slot = -1
                except Exception:
                    late_reminder_slot = -1
                late_reservation_alert_keys = set()
                opened_once.add(reserved_id)
                last_reload = time.time()
                next_in = random.uniform(*RESERVED_RELOAD)
                last_reservation_status_check = 0.0
                reservation_missing_checks = 0
                restored_waited = max(0.0, time.time() - reserved_at)
                inspection_scrollbar_passes = sum(1 for t in RESERVED_SCROLLBAR_PASS_AT if restored_waited >= t)
                record_stat("reservation_state_restores")
                log(f"RESERVATION RESTORED: {reserved_id} is still reserved. Original timer retained; status will be checked every 10 seconds.")
                update_last_state(reserved=True, reserved_id=reserved_id, restored_reservation=True)
            else:
                if persisted_id:
                    _done.add(persisted_id)
                    opened_once.add(persisted_id)
                clear_reservation_state()
                log(f"RESERVATION RECONCILED ON START: {persisted_id or 'previous order'} is no longer reserved. Stale timer cleared; searching resumes.")

        while not _stop:
            try:
                scan_cycle_started = time.perf_counter()
                if app_stop_requested():
                    try:
                        _APP_STOP_FILE.unlink(missing_ok=True)
                    except Exception:
                        pass
                    request_stop("Adeon app deactivate requested")
                    break
                # Legacy pause code is kept only for direct-script compatibility; the installed app uses START/STOP only.
                # mouse movement/clicks, or new alert scheduling occurs. A resume request
                # is validated once against the live tab before any automation restarts.
                if _paused:
                    if _resume_requested:
                        with _pause_lock:
                            globals()["_resume_requested"] = False
                            resume_source = str(globals().get("_resume_source") or "hotkey")
                            globals()["_resume_source"] = ""
                        resume_snap = brain.read() or {}
                        resume_url = str(resume_snap.get("url") or "")
                        if resume_snap and not bool(resume_snap.get("loggedOut")) and "findorders" in resume_url.lower():
                            # Re-run the full mapping/window safety check after a logout or long pause.
                            # The paused flag stays set during the check, so no mouse/F5 action can leak through.
                            resume_ok = startup_self_check(brain)
                            if resume_ok:
                                with _pause_lock:
                                    globals()["_paused"] = False
                                    globals()["_pause_reason"] = ""
                                record_stat("soft_resumes")
                                last_reload=time.time(); next_in=next_reload(cycle,next_in); force_refresh=False
                                idle_active_started=time.time(); idle_pause_until=0.0
                                last_idle=time.time(); last_idle_click=time.time()
                                log(f"{resume_source} RESUME CONFIRMED: Find Orders is open, logged in, and the safety mapping passed. Bot activity is continuing now.")
                            else:
                                log(f"{resume_source} RESUME REFUSED: Find Orders was visible but the startup safety check failed. Bot remains paused.")
                        else:
                            if bool(resume_snap.get("loggedOut")):
                                hard_stop_logout(f"LR Writers logout/login page detected during {resume_source} resume check")
                                break
                            reason = f"not on Find Orders ({resume_url or 'unknown page'})"
                            log(f"{resume_source} RESUME REFUSED: {reason}. Bot remains paused until Find Orders is open and you press Ctrl+A or Alt+A again.")
                    refresh_status_ticket("ONLINE")
                    time.sleep(0.12)
                    continue

                if _LABELS_ONLY_MODE:
                    set_status_ticket(bot="CONNECTED", page="LABELS WAIT", job="LABEL", f5="OFF", mouse="OFF", mode="LABELS")
                    # Backward-compatible refresh flags are STATE-ONLY. Consuming one
                    # never F5s, navigates, moves the mouse, or changes the user's tab.
                    if _LABEL_REFRESH_FILE.exists():
                        try:
                            _LABEL_REFRESH_FILE.unlink(missing_ok=True)
                        except Exception:
                            pass
                        if label_sync:
                            label_sync.poll_remote(force=True)
                            label_sync.push_remote(force=True)
                            label_sync.poll_remote(force=True)
                            brain.apply_label_state(label_sync.snapshot())
                        log("LABELS STATE REFRESH: label data re-synced without touching the browser page.")
                else:
                    # Scan-first rule: read the newest DOM before any F5 decision.
                    refresh_status_ticket("ONLINE")
                if _paused or stop_requested_now():
                    continue
                snap=brain.read(); now=time.time()
                if not snap:
                    # Label editors are separate Adeon windows. While the user is
                    # typing in one, Thorium is no longer the foreground window, so
                    # Screen Vision intentionally pauses. Do NOT stall label saving
                    # or remote sync in that state. Drain the overlay edits even
                    # without a fresh browser frame and wait for Thorium focus to
                    # return before attempting another visual read.
                    if _LABELS_ONLY_MODE and label_sync and label_overlay:
                        local_changed=False
                        for order,value in label_overlay.drain_edits():
                            if label_sync.set_local_label(order,value):
                                local_changed=True
                                log(f"LABEL EDIT SAVED: {order} -> {value or '[blank]'}")
                        if local_changed:
                            label_sync.push_remote(force=False)
                        label_sync.poll_remote(force=False)
                        # The overlay owns the last confirmed row geometry, so remote
                        # labels can still update while its Entry has focus and Thorium
                        # is intentionally not the foreground window.
                        label_overlay.refresh_state(label_sync.snapshot())
                        time.sleep(0.12)
                        continue
                    if not blank_since: blank_since=now
                    elif now-blank_since>=3.0: note_issue("SCREEN_READER_BLIND","No usable Screen Vision/accessibility snapshot for at least 3 seconds; worker remains alive","WARN",f"blind_for={now-blank_since:.1f}s", throttle=30.0)
                    if blank_since and now-blank_since>=10.0:
                        record_stat("reconnects"); brain.reconnect()
                        set_status_ticket(bot="CONNECTED", page="WAITING NETWORK", job=("RESERVED " + str(reserved_id or "")) if reserved else "SEARCHING", f5="WAITING", mouse="OFF")
                    time.sleep(0.2); continue
                blank_since=0.0
                if bool(snap.get("loggedOut")):
                    update_last_state(snap,reserved=reserved,reserved_id=reserved_id,logged_out=True,soft_paused=False)
                    if _LABELS_ONLY_MODE:
                        # Labels are a persistent service, not a reservation bot. On
                        # logout they hide and wait; after manual login they resume on
                        # My Orders automatically without navigating or touching LR.
                        if label_overlay and label_sync:
                            label_overlay.update(snap, label_sync.snapshot())
                            label_sync.poll_remote(force=False)
                        set_status_ticket(bot="CONNECTED", page="LABELS WAIT", job="WAITING LOGIN", f5="OFF", mouse="OFF")
                        note_issue("LABELS_LOGGED_OUT_WAIT", "LR Writers is logged out; label service remains alive and will resume automatically after manual login", "INFO", throttle=30.0)
                        time.sleep(0.35)
                        continue
                    hard_stop_logout("LR Writers logout/login page detected")
                    break

                # Exact LR keep-alive exception requested by the user. In picker mode,
                # if the visible popup says "Are you still there?", physically click
                # only its exact "Yes, I'm here" button. Accept remains forbidden.
                if (not _LABELS_ONLY_MODE) and snap.get("stillHere"):
                    if now - last_still_here_click >= 1.0:
                        if motor_click(snap.get("stillHere"), "Yes, I'm here", "still_here", snap, brain):
                            last_still_here_click = time.time()
                            log("STILL-THERE POPUP: clicked the exact Yes, I'm here confirmation button.")
                            time.sleep(0.12)
                            continue

                if _LABELS_ONLY_MODE:
                    local_changed=False; remote_changed=False
                    # Apply edits from Adeon's Windows overlay first. Each edit is
                    # persisted/journalled before any network push, exactly like the
                    # original v36 label-sync path.
                    if label_sync and label_overlay:
                        for order,value in label_overlay.drain_edits():
                            if label_sync.set_local_label(order,value):
                                local_changed=True
                                log(f"LABEL EDIT SAVED: {order} -> {value or '[blank]'}")
                        remote_changed=label_sync.poll_remote(force=False)
                        if local_changed:
                            label_sync.push_remote(force=False)
                            # Pull once after a push so a protocol-2 conflict/revision
                            # is reflected in the visible overlay immediately.
                            label_sync.poll_remote(force=False)
                    # Labels never navigate the user's tab. They display only on
                    # the exact My Orders / In Progress or Revisions URL and otherwise wait silently.
                    label_url=str(snap.get("url") or "").lower()
                    exact_label_page=bool(re.search(r"^https?://myaccount\.lrwriters\.com/myorders/(?:inprogress|revisions?)(?:[/?#]|$)",label_url,re.I))
                    state=label_sync.snapshot() if label_sync else {"labels":{}}
                    if label_overlay:
                        label_overlay.update(snap,state)
                    if exact_label_page:
                        count=len(snap.get("rows") or [])
                        label_page_name=("REVISIONS" if re.search(r"/myorders/revisions?(?:[/?#]|$)",label_url,re.I) else "MY ORDERS")
                        set_status_ticket(bot="CONNECTED", page=label_page_name, job="LABEL", f5="OFF", mouse="LABEL", mode="LABELS")
                        update_last_state(
                            snap, label_mode=True, label_only=True, label_count=count, reserved=False, reserved_id="",
                            label_persistent_file=str(_LABEL_LOCAL_FILE),
                            label_sync=("ONLINE" if (label_sync and label_sync.configured()) else "LOCAL"),
                            label_overlay=True,
                        )
                    else:
                        set_status_ticket(bot="CONNECTED", page="LABELS WAIT", job="LABEL", f5="OFF", mouse="OFF", mode="LABELS")
                        update_last_state(
                            snap, label_mode=False, label_only=True, label_count=0, reserved=False, reserved_id="",
                            label_persistent_file=str(_LABEL_LOCAL_FILE),
                            label_sync=("ONLINE" if (label_sync and label_sync.configured()) else "LOCAL"),
                            label_overlay=True,
                        )
                    time.sleep(LABEL_SCAN_INTERVAL)
                    continue

                rows=snap.get("rows") or []
                current_row_keys = {row_key(r).strip().upper() for r in rows if row_key(r).strip()}
                if not row_baseline_captured:
                    # OCR can expose only a few of the already-present rows during
                    # its first frames. Build a union and require a stable page after
                    # the startup proof window instead of calling late-recognized old
                    # rows "new". This is intentionally conservative at activation.
                    baseline_union.update(current_row_keys)
                    if current_row_keys == baseline_last_keys:
                        if not baseline_same_since:
                            baseline_same_since = now
                    else:
                        baseline_last_keys = set(current_row_keys)
                        baseline_same_since = now
                    warm_for = now - baseline_started
                    stable_for = now - baseline_same_since
                    if warm_for >= 10.0 and stable_for >= 1.5:
                        seen_row_keys = set(baseline_union)
                        row_baseline_captured = True
                        log(f"NEW-ROW BASELINE STABLE: {len(seen_row_keys)} existing row(s) ignored after OCR warmup; only later arrivals are eligible for opening.")
                    else:
                        # No order can be opened until the startup inventory is stable.
                        new_row_keys.clear()
                else:
                    appeared = current_row_keys - seen_row_keys
                    if appeared:
                        # A sudden large batch is much more likely OCR recovering an
                        # existing table than many genuinely new orders in one 100-ms
                        # scan. Absorb the batch and wait for later true arrivals.
                        if len(appeared) >= 4 and now-baseline_started <= 30.0:
                            seen_row_keys.update(appeared)
                            log(f"OCR BASELINE RECOVERY: absorbed {len(appeared)} late-recognized existing row(s) during startup settling; none were opened as new.")
                        else:
                            new_row_keys.update(appeared)
                            seen_row_keys.update(appeared)
                            log("NEW ROW DETECTED: " + ", ".join(sorted(appeared)))
                    # A row that vanished is no longer actionable. It stays in seen_row_keys
                    # so an old row returning after F5 is not mistaken for a new job.
                    new_row_keys.intersection_update(current_row_keys)

                # NEW-ORDER REFRESH LOCK. Because this runs before maybe_f5(), a newly
                # detected eligible order can freeze refresh before F5 has a chance to
                # erase it. The following row -> panel -> Reserve handoff gets 10 seconds
                # of protection; its own verification helpers extend the lock as needed.
                if not reserved and new_row_keys:
                    protected_candidate = pick_row(rows, reserved_id, tapped, opened_once, new_row_keys, True)
                    if protected_candidate is not None:
                        pkey=str(row_key(protected_candidate) or "").strip().upper()
                        # Screen Vision may never trust one OCR pay read. Freeze F5
                        # briefly while the verified earnings cell is independently
                        # re-read, then keep the original 10-second v36 handoff lock
                        # only after the $6 rule has been proven.
                        if bool(protected_candidate.get("vision")):
                            refresh_pause_until=max(refresh_pause_until,time.time()+4.0)
                            cached=vision_pay_confirmed.get(pkey)
                            try: ppay=float(protected_candidate.get("pay") or 0.0)
                            except Exception: ppay=0.0
                            confirmed=bool(cached and time.time()-cached[1] <= 12.0 and abs(cached[0]-ppay)<0.005)
                            if not confirmed:
                                ok_pay, pay_reason=_vision_verify_candidate_pay(brain,protected_candidate)
                                if ok_pay:
                                    vision_pay_confirmed[pkey]=(ppay,time.time())
                                else:
                                    log(f"SCREEN VISION PAY BLOCK | {pkey or 'unknown'} | {pay_reason}; row will NOT be clicked.")
                                    # A confirmed low-pay observation is permanent for
                                    # this session. Uncertain OCR remains eligible for
                                    # later re-reading after another page refresh.
                                    if "below minimum" in pay_reason.lower():
                                        _done.add(pkey); new_row_keys.discard(pkey)
                                    protected_candidate=None
                        if protected_candidate is not None:
                            protect_until = time.time() + 10.0
                            if protect_until > refresh_pause_until:
                                refresh_pause_until = protect_until
                                log(
                                    "NEW ORDER REFRESH LOCK: eligible new order "
                                    + str(row_key(protected_candidate) or "job")
                                    + "; F5 frozen while row -> panel -> Reserve handoff runs."
                                )

                if not reserved and snap.get("panelOpen") and snap.get("reserve") and not snap.get("reject"):
                    try:
                        cache_rid, _cache_hint = panel_identity(snap)
                    except Exception:
                        cache_rid = ""
                    remember_pre_reserve_snapshot(snap, cache_rid)

                # Live-open reconciliation. Never keep JOB OPEN pinned to an order
                # after its panel was closed, accepted, rejected, or replaced.
                # This runs on every DOM scan, so the dashboard follows the live page
                # instead of remembering an old task number.
                if not reserved and active_opened_id:
                    live_panel_open = bool(snap.get("panelOpen"))
                    live_id, live_hint = panel_identity(snap) if live_panel_open else ("", "")
                    live_id_norm = str(live_id or "").strip().upper()
                    active_norm = str(active_opened_id or "").strip().upper()
                    if not live_panel_open or bool(snap.get("acceptedGone")):
                        old_open = active_opened_id
                        active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""
                        log(f"OPEN STATE CLEARED: {old_open} is no longer open on the live page.")
                    elif live_id_norm and active_norm and live_id_norm != active_norm:
                        old_open = active_opened_id
                        active_opened_id = live_id_norm
                        active_opened_hint = str(live_hint or live_id_norm)
                        active_opened_deadline_text = ""
                        log(f"OPEN STATE SWITCHED: {old_open} -> {active_opened_id} from the live DOM.")

                update_last_state(snap,reserved=reserved,reserved_id=reserved_id,active_opened_id=active_opened_id,opened_once_count=len(opened_once),next_refresh_seconds=round(max(0.0,next_in-(now-last_reload)),1),idle_mouse_paused=bool(idle_pause_until and now<idle_pause_until),idle_pause_remaining_seconds=round(max(0.0,idle_pause_until-now),1) if idle_pause_until else 0.0,logged_out=False,soft_paused=False)
                refresh_status_ticket("ONLINE")

                # Observe real user clicks without creating them. If you manually
                # click Accept, stop reservation alerts immediately and lock this
                # order so it can never be row-clicked again in this session.
                audit = consume_click_audit(snap, context="page")
                if audit and bool(audit.get("trusted")):
                    audit_text = str(audit.get("text") or "").strip().lower()
                    if audit_text in ("accept", "accept order"):
                        record_stat("manual_accepts")
                        accepted_id, _accepted_hint = panel_identity(snap)
                        last_accepted_id = str(accepted_id or "").strip().upper()
                        if last_accepted_id:
                            _done.add(last_accepted_id)
                            opened_once.add(last_accepted_id)
                            reserved_notice_order_ids.add(last_accepted_id)
                            new_row_keys.discard(last_accepted_id)
                        post_accept_ready = True
                        # No post-Accept delay. Cancel any row/panel pause and make the very next loop press F5.
                        refresh_pause_until = 0.0
                        force_refresh = True
                        if reserved:
                            log("Trusted manual Accept click detected. Reservation alerts stopped; old row stays locked. Immediate F5 queued; next NEW row may replace the still-open old panel.")
                            clear_reserved("You manually accepted the reserved order. No more alerts for it.")
                        else:
                            old_open = active_opened_id
                            active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""
                            log(f"Trusted manual Accept click detected. OPEN state cleared for {old_open or 'current order'}; immediate F5 queued and searching resumes.")
                        continue
                    if audit_text in ("reject", "reject order") and reserved:
                        record_stat("manual_rejects")
                        refresh_pause_until = 0.0
                        force_refresh = True
                        clear_reserved("Trusted manual Reject click detected. Reservation reminders were cancelled immediately; this order stays locked and will not be reserved again this session.")
                        continue

                if now-last_port_check>=15.0:
                    last_port_check=now
                    if brain._using_vision:
                        hwnd=int(brain._uia_hwnd or 0)
                        try: browser_front=bool(hwnd and int(user32.GetForegroundWindow() or 0)==hwnd)
                        except Exception: browser_front=False
                        # Screen Vision intentionally pauses while the browser is
                        # covered. That is not a lost integration and must not be
                        # reported as an error. Recover only when LR is foreground.
                        if browser_front and not _vision_live(max_age=4.5):
                            note_issue("SCREEN_VISION_STALE","Screen Vision stopped producing fresh frames while LR was foreground; recovering in place","WARN")
                            if brain.reconnect_cdp():
                                record_stat("reconnects")
                                blank_since = 0.0
                                refresh_status_ticket("ONLINE")
                                log("STABILITY RECOVERY: Screen Vision recovered in place; browser was not closed or reopened.")
                    elif brain._using_uia:
                        if not _uia_feed_live(max_age=4.5):
                            note_issue("ACCESSIBILITY_FEED_STALE","Windows accessibility feed stopped producing fresh frames; recovering in place","WARN")
                            if brain.reconnect_cdp():
                                record_stat("reconnects")
                                blank_since = 0.0
                                refresh_status_ticket("ONLINE")
                                log("STABILITY RECOVERY: Windows accessibility feed recovered in place; browser was not closed or reopened.")
                if snap.get("reserve") and snap.get("reject"): note_issue("AMBIGUOUS_RESERVE_REJECT","Reserve and Reject are visible at the same time","WARN",str(snap.get("url") or ""))
                if rows:
                    missing_keys=sum(1 for r in rows if not str(row_key(r) or "").strip())
                    if missing_keys==len(rows): note_issue("ROW_KEYS_MISSING","All visible order rows are missing usable Order Numbers; OCR/page layout may have changed","WARN",f"rows={len(rows)}")
                    zero_pay=sum(1 for r in rows if float(r.get("pay") or 0)<=0 and "$" in str(r.get("text") or ""))
                    if zero_pay: note_issue("PAY_PARSE_FAILED","A visible row contains a dollar amount but pay parsed as zero","WARN",f"rows={zero_pay}")
                if now-last_health_log>=60.0:
                    last_health_log=now; log(f"HEALTH OK | rows={len(rows)} reserved={reserved} issues={len(_issues)} reads={_stats.get('dom_reads',0)}")

                row_list_key="|".join(str(r.get("id") or r.get("text") or "")[:24] for r in rows)
                if row_list_key!=last_row_key:
                    last_row_key=row_list_key
                    if rows: log("Rows: "+" | ".join(f"${float(r.get('pay') or 0):.2f} {str(r.get('text') or '')[:34]}" for r in rows[:6]))
                    else: log("Rows: none")

                url=str(snap.get("url") or "")
                # Screen Vision can positively recognize the Find Orders table even
                # when the browser address text is absent from one OCR frame. Do not
                # leave/recover from Find Orders merely because URL OCR is blank.
                if "findorders" not in url.lower() and not bool(snap.get("onFind")):
                    # Temporary network loss must NEVER terminate the picker. Chrome/Thorium
                    # can replace the LR page with a browser error page while offline. Keep
                    # the worker/reservation state alive and use the normal search-mode F5
                    # recovery. A live reservation still keeps the absolute F5 hold.
                    if is_network_error_snapshot(snap):
                        record_stat("left_find_orders")
                        update_last_state(snap, reserved=reserved, reserved_id=reserved_id, network_wait=True)
                        set_status_ticket(bot="CONNECTED", page="WAITING NETWORK", job=("RESERVED " + str(reserved_id or "")) if reserved else "SEARCHING", f5="WAITING", mouse="OFF")
                        note_issue("NETWORK_WAIT", "Network/browser error page detected; Adeon stays alive and will recover automatically", "INFO", url[:250], throttle=30.0)
                        if (not reserved) and now-last_reload >= max(F5_HARD_MIN_GAP, next_in):
                            send_f5(brain)
                            last_reload=time.time()
                            next_in=random.uniform(NETWORK_RETRY_MIN, NETWORK_RETRY_MAX)
                            log(f"NETWORK RECOVERY: F5 sent; next retry in {next_in:.1f}s if still offline.")
                        elif reserved and now-last_reload >= max(F5_HARD_MIN_GAP, next_in):
                            note_issue("NETWORK_RESERVED_F5_HOLD", "Network error seen while reserved; F5 remains disabled until the reservation ends", "INFO", reserved_id, throttle=30.0)
                        time.sleep(DOM_SCAN_INTERVAL)
                        continue

                    # PASSIVE OFF-PAGE HOLD. If the user leaves Find Orders, Adeon
                    # must not rewrite the URL, click navigation, move the mouse, type,
                    # or F5. It stays alive and resumes only after the user returns.
                    record_stat("left_find_orders")
                    set_status_ticket(
                        bot="CONNECTED", page="WAITING FIND ORDERS",
                        job=("RESERVED " + str(reserved_id or "")) if reserved else "WAITING",
                        f5="OFF", mouse="OFF"
                    )
                    update_last_state(
                        snap, reserved=reserved, reserved_id=reserved_id,
                        waiting_for_find_orders=True, find_orders_recovery_wait=False
                    )
                    time.sleep(DOM_SCAN_INTERVAL)
                    continue

                # User-visible startup proof. The ten-second window begins when the
                # picker main loop becomes active; it never runs off Find Orders.
                if (not reserved) and (now-startup_mouse_proof_started <= STARTUP_MOUSE_PROOF_SECONDS):
                    if now-startup_mouse_proof_last >= STARTUP_MOUSE_PROOF_INTERVAL:
                        if startup_mouse_proof(snap,startup_mouse_proof_step):
                            startup_mouse_proof_last=time.time()
                            startup_mouse_proof_step += 1

                if label_mode_active:
                    label_mode_active=False
                    last_reload=time.time()
                    next_in=next_reload(cycle, None)
                    log("LABEL MODE ENDED: Find Orders is back. Picker searching/F5 schedule resumed automatically.")
                    update_last_state(snap, label_mode=False, label_count=0)

                if reserved:
                    waited=time.time()-reserved_at

                    # RESERVED-PANEL SCROLLBAR MOTION. There is no F5 while held.
                    # During the first minute Adeon touches only the visible scrollbar.
                    # It performs exactly two quick physical down-and-up thumb drags and
                    # does not use the mouse wheel or open any Files/accordion control.
                    if inspection_scrollbar_passes < len(RESERVED_SCROLLBAR_PASS_AT):
                        due_at = RESERVED_SCROLLBAR_PASS_AT[inspection_scrollbar_passes]
                        if waited >= due_at and waited < RESERVE_REMINDER_AFTER:
                            pass_number = inspection_scrollbar_passes + 1
                            drag_reserved_panel_scrollbar_cycle(snap, brain, pass_number)
                            inspection_scrollbar_passes += 1
                            snap = brain.read() or snap

                    # HARD RESERVATION HOLD: rows are still scanned every 100 ms, but
                    # while one order is genuinely reserved Adeon must not click/open
                    # any other job. New jobs simply wait in the list until the current
                    # reservation ends through manual Accept/Reject or expiry,
                    # or the 10-second reservation watchdog.
                    waiting_now=set()
                    current_norm=str(reserved_id or "").strip().upper()
                    done_now={str(x).strip().upper() for x in _done}
                    for wr in rows:
                        wk=row_key(wr).strip().upper()
                        if not wk or wk == current_norm or wk in done_now:
                            continue
                        if wr.get("tutor") or has_do_not_accept(str(wr.get("text") or "")):
                            continue
                        try:
                            if float(wr.get("pay") or 0) < MIN_PAY:
                                continue
                        except Exception:
                            continue
                        waiting_now.add(wk)
                    if waiting_now != reserved_waiting_keys:
                        reserved_waiting_keys = waiting_now
                        if reserved_waiting_keys:
                            log(f"RESERVED HOLD: {len(reserved_waiting_keys)} other eligible job(s) visible; none will be clicked until {reserved_id} is accepted/rejected or otherwise leaves reserved state.")
                        else:
                            log("RESERVED HOLD: no other eligible jobs are currently waiting.")

                    # Independent reservation watchdog. Every 10 seconds, verify that
                    # THIS exact order is still reserved. Two consecutive misses are
                    # required to survive a brief F5/DOM transition, then stale state
                    # is cleared and normal searching resumes automatically.
                    if now-last_reservation_status_check >= RESERVATION_STATUS_CHECK:
                        last_reservation_status_check = now
                        record_stat("reservation_status_checks")
                        # A phone Accept/Reject does not necessarily mutate the laptop's
                        # already-open reserved DOM. Use a fresh hidden authenticated read
                        # every 10 seconds so remote actions end reminders without touching
                        # or refreshing the user's visible order panel.
                        remote_probe = brain.fresh_reservation_probe(reserved_id, str(reserved_details.get("internalId") or ""))
                        remote_status = str(remote_probe.get("status") or "unknown")
                        if remote_status == "ended":
                            refresh_pause_until = 0.0
                            force_refresh = True
                            clear_reserved(f"Fresh 10-second server check confirmed {reserved_id} is no longer reserved ({remote_probe.get('source') or 'remote state'}). All reminders cancelled; searching resumes.")
                            continue
                        if remote_status == "absent":
                            remote_absent_checks += 1
                            log(f"REMOTE RESERVATION CHECK: {reserved_id} absent from fresh Find Orders ({remote_absent_checks}/2).")
                            if remote_absent_checks >= 2:
                                refresh_pause_until = 0.0
                                force_refresh = True
                                clear_reserved(f"Two fresh server checks confirmed {reserved_id} is absent from reserved orders. Remote Accept/Reject/expiry recognized; reminders cancelled.")
                                continue
                        elif remote_status == "held":
                            remote_absent_checks = 0
                            reservation_missing_checks = 0
                            hold_missing_since = 0.0
                            log(f"REMOTE RESERVATION CHECK: {reserved_id} still reserved ({remote_probe.get('source') or 'fresh read'}).")
                        held_now = job_still_held(snap,reserved_id,reserved_hint)
                        if reservation_definitely_ended(snap, reserved_id):
                            if snap.get("acceptedGone"):
                                last_accepted_id = str(reserved_id or "").strip().upper()
                                post_accept_ready = True
                            refresh_pause_until = 0.0
                            force_refresh = True
                            clear_reserved("10-second reservation check found a definite accepted/rejected end state. Stale reservation state cleared; searching resumes.")
                            continue
                        if held_now:
                            reservation_missing_checks = 0
                            hold_missing_since = 0.0
                        else:
                            reservation_missing_checks += 1
                            log(f"RESERVATION CHECK: {reserved_id} not confirmed reserved ({reservation_missing_checks}/2).")
                            if reservation_missing_checks >= 2:
                                old_id = reserved_id
                                refresh_pause_until = 0.0
                                force_refresh = True
                                clear_reserved(f"10-second reservation checks confirmed {old_id} is no longer reserved (accepted/rejected/expired). Stale timer cleared; searching resumes.")
                                continue

                    # If the deadline was not readable at the instant of reservation, try again
                    # from the live reserved panel/row while the midnight window snapshot is active.
                    if reserved_midnight_window and reserved_remaining_minutes is None:
                        live_source = str(snap.get("panelText") or "")
                        for rr in rows:
                            if row_key(rr).strip().upper() == str(reserved_id).strip().upper():
                                live_source += " " + deadline_source_for_row(rr)
                                break
                        maybe_minutes = parse_remaining_minutes(live_source)
                        if maybe_minutes is not None:
                            reserved_remaining_minutes = maybe_minutes
                            reserved_midnight_reject = maybe_minutes < MIDNIGHT_REJECT_UNDER_MINUTES
                            st = load_reservation_state()
                            if st:
                                st["remaining_minutes"] = maybe_minutes
                                st["midnight_reject"] = reserved_midnight_reject
                                save_reservation_state(st)
                            update_last_state(reserved_remaining_minutes=round(maybe_minutes,1),midnight_reject_pending=reserved_midnight_reject)
                            if reserved_midnight_reject:
                                log(f"MIDNIGHT RULE ADVISORY ARMED LATE: {reserved_id} has about {maybe_minutes:.1f} min remaining; a Reject cue is due at the 1-minute reservation mark, but Adeon will NOT click Reject.")

                    # Midnight short-deadline rule is ADVISORY ONLY. Keep the same
                    # local Reject cue, but never physically click Reject. The order
                    # remains reserved and follows the normal Pushover + Critical Alert
                    # sequence exactly like every other reservation.
                    if reserved_midnight_reject and waited >= MIDNIGHT_REJECT_AFTER and "midnight_reject_cue" not in reserved_flags:
                        reserved_flags.add("midnight_reject_cue")
                        log(f"MIDNIGHT RULE ADVISORY: 1 minute reached for {reserved_id}; showing the Reject cue only. Adeon will NOT click Reject.")
                        show_action_popup("REJECT", "reject", duration=2.2, bell=False)
                        update_last_state(midnight_reject_pending=True, midnight_reject_advisory_only=True)

                    # Reservation notifications:
                    # 1) full report at Reserve (sent in mark_reserved)
                    # 2) one short "still reserved" at 1 minute
                    # 3) from exactly 3:00 onward, Critical Alert stays active until the
                    #    reservation ends. It starts every 15 seconds and escalates from
                    #    5:30 to 10s, then 7.5s, then 5s. Each slot gets two fresh strong
                    #    checks first; clear_reserved() cancels all queued/live reminders.
                    if waited >= RESERVE_REMINDER_AFTER and "1" not in reserved_flags and reservation_alert_prefix:
                        reminder_key = reservation_alert_prefix+":still1"
                        if reminder_key in _alerted:
                            reserved_flags.add("1")
                            st = load_reservation_state()
                            if st:
                                st["reminder_sent"] = True
                                save_reservation_state(st)
                        else:
                            confirm1 = job_still_held(snap,reserved_id,reserved_hint)
                            confirm_snap = {}
                            if confirm1:
                                time.sleep(DOM_SCAN_INTERVAL)
                                confirm_snap = brain.read() or {}
                            confirm2 = bool(confirm_snap and job_still_held(confirm_snap,reserved_id,reserved_hint))
                            if confirm1 and confirm2 and reserved and reservation_alert_prefix:
                                send_alert("still reserved",f"still reserved {reserved_id}",reminder_key)
                            elif reservation_definitely_ended(confirm_snap or snap, reserved_id):
                                refresh_pause_until = 0.0
                                force_refresh = True
                                clear_reserved("1-minute reminder check found the order already accepted/rejected. Reminder cancelled; searching resumes.")
                                continue

                    # CRITICAL RESERVATION ALERT LOOP. Begins exactly at 3:00 and
                    # continues until the reservation ends. Frequency escalates from
                    # 5:30 onward: 15s -> 10s -> 7.5s -> 5s. Each slot gets two fresh
                    # same-order checks before either Pushover or the laptop alarm fires.
                    critical = critical_alert_profile(waited)
                    if critical and reservation_alert_prefix:
                        current_late_slot, due_at, next_cadence, alert_level = critical
                        if current_late_slot > late_reminder_slot:
                            late_key = reservation_alert_prefix + f":critical-{current_late_slot}"
                            confirm1 = job_still_held(snap,reserved_id,reserved_hint)
                            confirm_snap = {}
                            if confirm1:
                                time.sleep(DOM_SCAN_INTERVAL)
                                confirm_snap = brain.read() or {}
                            confirm2 = bool(confirm_snap and job_still_held(confirm_snap,reserved_id,reserved_hint))
                            if confirm1 and confirm2 and reserved and reservation_alert_prefix:
                                late_reminder_slot = current_late_slot
                                late_reservation_alert_keys.add(late_key)
                                mins = waited / 60.0
                                send_critical_reservation_alert(
                                    f"CRITICAL ALERT L{alert_level} - RESERVATION STILL ACTIVE",
                                    f"{reserved_id} is still reserved after {mins:.1f} minutes. Accept or reject it now. Critical alerts will continue until the reservation ends.",
                                    late_key,
                                )
                                play_loud_reservation_bell(late_key, alert_level)
                                st = load_reservation_state()
                                if st:
                                    st["late_reminder_slot"] = late_reminder_slot
                                    st["alert_schedule_version"] = 3
                                    st["critical_level"] = alert_level
                                    save_reservation_state(st)
                                log(
                                    f"CRITICAL RESERVATION ALERT L{alert_level}: Pushover emergency + "
                                    f"levelled laptop alarm at {waited:.1f}s; next cadence {next_cadence:g}s while still reserved."
                                )
                            elif reservation_definitely_ended(confirm_snap or snap, reserved_id):
                                refresh_pause_until = 0.0
                                force_refresh = True
                                clear_reserved("Critical alert check found the order already accepted/rejected/timed out. All remaining alerts cancelled; searching resumes.")
                                continue

                # Never select/click another row while the current reservation is alive.
                # The rows are still being scanned above so a waiting job is noticed, but
                # it cannot be opened until clear_reserved() returns the bot to SEARCHING.
                extra=None if reserved else pick_row(rows,reserved_id,tapped,opened_once,new_row_keys,True); panel=snap.get("panelText") or ""
                # After a trusted/manual Accept, LR Writers may leave the accepted order panel open.
                # If a different NEW eligible row exists, ignore only that stale old panel and click the new row once.
                post_accept_new_row = bool((not reserved) and post_accept_ready and extra and row_key(extra).strip().upper() != last_accepted_id)
                if reserved:
                    # Reservation logic above owns the session. During the first minute
                    # the ONLY automated mouse action is the two verified scrollbar-thumb
                    # down/up cycles above. No idle move, idle click, wheel, accordion,
                    # row click, or F5 path is allowed to fall through from here.
                    busy_since=0.0
                    refresh_status_ticket("ONLINE")
                    scan_elapsed = time.perf_counter() - scan_cycle_started
                    if scan_elapsed < DOM_SCAN_INTERVAL:
                        time.sleep(DOM_SCAN_INTERVAL - scan_elapsed)
                    continue
                elif post_accept_new_row:
                    busy_since=0.0
                    log(f"POST-ACCEPT NEW ROW: old panel may still be open, but new order {row_key(extra)} is available; opening it immediately with the physical mouse.")
                elif has_do_not_accept(panel):
                    rid,_=panel_identity(snap); log("DO NOT ACCEPT. Skipping this exact open order. Never clicking Accept.")
                    if rid:
                        rid_norm=str(rid).strip().upper(); _done.add(rid_norm); opened_once.add(rid_norm)
                    active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""; extra=pick_row(rows,reserved_id,tapped,opened_once,new_row_keys,True); busy_since=0.0
                elif snap.get("reject"):
                    busy_since=0.0
                    if not reserved:
                        rid,hint=panel_identity(snap); log("Reject is showing. Reserved. Never clicking Accept."); mark_reserved(rid,hint,snap,active_opened_deadline_text)
                elif snap.get("reserve"):
                    busy_since=0.0; pos=snap["reserve"]; rid,hint=panel_identity(snap)
                    if time.time()-last_reserve_try>=RESERVE_RETRY_SEC:
                        last_reserve_try=time.time()
                        if bool(snap.get("uia") or pos.get("uia")):
                            preview=(int(round(float(pos.get("sx") or 0))), int(round(float(pos.get("sy") or 0))))
                            log(f"Reserve verified by {'Screen Vision' if snap.get('vision') else 'Windows accessibility'} at {preview} — attempting")
                        else:
                            preview = viewport_to_screen(
                                float(pos.get("vx") or 0),
                                float(pos.get("vy") or 0),
                                str(snap.get("pageTitle") or ""),
                                float(snap.get("innerW") or 0),
                                float(snap.get("innerH") or 0),
                            )
                            log(
                                f"Reserve visible at DOM ({int(pos.get('vx') or 0)}, {int(pos.get('vy') or 0)}) "
                                f"mapped {preview} — attempting"
                            )
                        # HARD PRE-RESERVE WARNING GATE: re-read the live panel at the
                        # last possible moment. A DO NOT ACCEPT / fine warning means
                        # Reserve is forbidden, even if it appeared after the prior scan.
                        pre_reserve = gather_pre_reserve_details(rid, brain.read() or snap, 0.35)
                        if has_do_not_accept(pre_reserve.get("panelText") or ""):
                            log(f"DO NOT ACCEPT appeared immediately before Reserve for {rid}; Reserve cancelled and order locked out.")
                            rid_norm=str(rid or "").strip().upper()
                            if rid_norm:
                                _done.add(rid_norm); opened_once.add(rid_norm)
                            active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""
                            continue
                        if pre_reserve.get("reserve"):
                            pos = pre_reserve["reserve"]
                            snap = pre_reserve
                        if bool(snap.get("vision")):
                            cached=vision_pay_confirmed.get(str(rid or "").strip().upper())
                            expected_pay=float(cached[0]) if (cached and time.time()-cached[1] <= 20.0) else 0.0
                            ok_panel,panel_reason=_vision_verify_open_panel_pay(brain,snap,expected_pay)
                            if not ok_panel:
                                log(f"SCREEN VISION RESERVE BLOCKED | {str(rid or 'unknown').strip().upper()} | {panel_reason}")
                                continue
                            snap=brain.read() or snap
                            pos=snap.get("reserve") or pos
                        if motor_click(pos,"Reserve","reserve",snap,brain):
                            check=wait_reject(3.6)
                            if check.get("reject"):
                                rid2,hint2=panel_identity(check,rid,hint); log("Reject appeared. Reserved confirmed. Never clicking Accept."); mark_reserved(rid2,hint2,check,active_opened_deadline_text)
                            elif check.get("acceptedGone"): note_issue("RESERVE_STATE_UNEXPECTED","Page moved to accepted state while waiting for Reserve confirmation","WARN",rid,throttle=0)
                            else:
                                shot = capture_diagnostic("reserve_unconfirmed", min_interval=6.0)
                                note_issue(
                                    "RESERVE_UNCONFIRMED",
                                    "Reserve was clicked but Reject confirmation was not seen within 3.6 seconds",
                                    "WARN",
                                    f"{rid} screenshot={shot}",
                                    throttle=0,
                                )
                    continue
                elif snap.get("accept") or (snap.get("panelOpen") and snap.get("reserveDisabled")):
                    # An unreserved unresolved/stale panel must never pin Adeon to that
                    # order. Keep the row scanner alive; if another eligible job exists
                    # it may be opened, otherwise normal F5 searching continues.
                    if not busy_since:
                        busy_since=now
                    elif now-busy_since>=2.0:
                        note_issue("UNRESERVED_PANEL_IGNORED","Unreserved panel stayed unresolved; Adeon is continuing to search instead of staying fixed to it","INFO",str(snap.get("url") or ""),throttle=10.0)
                        if active_opened_id:
                            old_open=active_opened_id
                            active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""
                            log(f"SEARCH MODE: stopped displaying OPEN {old_open}; no active reservation exists, so row scanning continues.")
                else: busy_since=0.0

                if extra:
                    rid=row_key(extra); rid_norm=str(rid).strip().upper()
                    if bool(extra.get("vision")):
                        try: epay=float(extra.get("pay") or 0.0)
                        except Exception: epay=0.0
                        cached=vision_pay_confirmed.get(rid_norm)
                        confirmed=bool(cached and time.time()-cached[1] <= 12.0 and abs(cached[0]-epay)<0.005)
                        if not confirmed:
                            refresh_pause_until=max(refresh_pause_until,time.time()+4.0)
                            ok_pay,pay_reason=_vision_verify_candidate_pay(brain,extra)
                            if not ok_pay:
                                log(f"SCREEN VISION ROW CLICK BLOCKED | {rid_norm or 'unknown'} | {pay_reason}")
                                if "below minimum" in pay_reason.lower():
                                    _done.add(rid_norm); new_row_keys.discard(rid_norm)
                                extra=None
                            else:
                                vision_pay_confirmed[rid_norm]=(epay,time.time())
                    if extra:
                        rid=row_key(extra); new_row_keys.discard(str(rid).strip().upper()); log("Opening NEW row once "+str(extra.get("text") or "")[:50]); tapped[rid]=time.time()
                        active_opened_id=rid; active_opened_hint=str(extra.get("text") or rid); active_opened_deadline_text=deadline_source_for_row(extra); refresh_pause_until=max(refresh_pause_until,time.time()+2.5)
                    if extra and motor_click(extra,"ROW","row",snap,brain):
                        opened_once.add(str(rid).strip().upper())
                        log(f"ROW ONE-CLICK LOCK: {rid} will not be clicked again this session. F5 will refresh it; another new order can be opened only while no order is actively reserved.")
                        update_last_state(active_opened_id=active_opened_id,opened_once_count=len(opened_once))
                        # Critical stale-panel protection: do not inspect/click Reserve until the URL/panel identity
                        # proves that the newly clicked row has actually replaced any previously open panel.
                        opened, identity_ok = wait_for_panel_identity(rid, 2.4)
                        if not identity_ok:
                            note_issue(
                                "NEW_ROW_PANEL_IDENTITY_NOT_READY",
                                "New row was clicked, but the open panel never proved it belonged to that order; Reserve was not touched",
                                "WARN",
                                f"expected={rid} current_url={str((opened or {}).get('url') or '')}",
                                throttle=0,
                            )
                            snap=opened or snap; rows=snap.get("rows") or rows
                        else:
                            if post_accept_ready:
                                post_accept_ready=False
                                log(f"POST-ACCEPT PANEL SWITCH CONFIRMED: {rid}. Old accepted panel has been replaced by the new order.")
                            snap=opened or snap; rows=snap.get("rows") or rows; update_last_state(snap,active_opened_id=active_opened_id)
                        if identity_ok and is_tutoring_order_text(snap.get("panelText") or ""):
                            log(f"TUTORING ORDER HARD BLOCK after panel identity for {rid}; never reserving it.")
                            _done.add(str(rid).strip().upper()); opened_once.add(str(rid).strip().upper()); active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""
                        elif identity_ok and has_do_not_accept(snap.get("panelText") or ""):
                            log("DO NOT ACCEPT after open. Skipping this exact order."); _done.add(str(rid).strip().upper()); opened_once.add(str(rid).strip().upper()); active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""
                        elif identity_ok and snap.get("reject"):
                            if not reserved: log("Reject after open. Reserved."); mark_reserved(rid,str(extra.get("text") or rid),snap,deadline_source_for_row(extra))
                        elif identity_ok and snap.get("reserve"):
                            # HARD PRE-RESERVE WARNING GATE again after row-open identity proof.
                            pre_reserve = gather_pre_reserve_details(rid, brain.read() or snap, 0.35)
                            if is_tutoring_order_text(pre_reserve.get("panelText") or ""):
                                log(f"TUTORING ORDER detected immediately before Reserve for {rid}; skipping without Reserve.")
                                _done.add(str(rid).strip().upper()); opened_once.add(str(rid).strip().upper())
                                active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""
                                continue
                            if has_do_not_accept(pre_reserve.get("panelText") or ""):
                                log(f"DO NOT ACCEPT appeared immediately before Reserve for {rid}; skipping without Reserve.")
                                _done.add(str(rid).strip().upper()); opened_once.add(str(rid).strip().upper())
                                active_opened_id=""; active_opened_hint=""; active_opened_deadline_text=""
                                continue
                            if pre_reserve.get("reserve"):
                                snap = pre_reserve
                            if bool(snap.get("vision")):
                                try: expected_pay=float(extra.get("pay") or 0.0)
                                except Exception: expected_pay=0.0
                                ok_panel,panel_reason=_vision_verify_open_panel_pay(brain,snap,expected_pay)
                                if not ok_panel:
                                    log(f"SCREEN VISION RESERVE BLOCKED | {str(rid or 'unknown').strip().upper()} | {panel_reason}")
                                    continue
                                snap=brain.read() or snap
                                if not snap.get("reserve"):
                                    log(f"SCREEN VISION RESERVE BLOCKED | {rid} | Reserve disappeared during final pay verification")
                                    continue
                            pos=snap["reserve"]; log("Reserve appeared after row open — clicking"); last_reserve_try=time.time()
                            if motor_click(pos,"Reserve","reserve",snap,brain):
                                check=wait_reject(3.6)
                                if check.get("reject"):
                                    rid2,hint2=panel_identity(check,rid,str(extra.get("text") or rid)); log("Reject appeared. Reserved confirmed."); mark_reserved(rid2,hint2,check,active_opened_deadline_text)
                                elif check.get("acceptedGone"): note_issue("RESERVE_STATE_UNEXPECTED","Page moved to accepted state while waiting for Reserve confirmation","WARN",rid,throttle=0)
                                else:
                                    shot = capture_diagnostic("reserve_unconfirmed_after_open", min_interval=6.0)
                                    note_issue(
                                        "RESERVE_UNCONFIRMED",
                                        "Reserve clicked after opening row but confirmation was not seen",
                                        "WARN",
                                        f"{rid} screenshot={shot}",
                                        throttle=0,
                                    )
                        elif identity_ok:
                            note_issue("ROW_PANEL_NOT_READY","New row panel identity matched, but Reserve/Reject did not appear during initial wait","INFO",rid)

                # Idle-only mouse rhythm: roam/click normally for five minutes, then
                # stop ALL idle mouse activity for a random 3-20 minutes. Job row,
                # Reserve/Reject safety actions and F5 are NOT paused by this rest.
                idle_now = time.time()
                if idle_pause_until:
                    if idle_now >= idle_pause_until:
                        idle_pause_until = 0.0
                        idle_active_started = idle_now
                        last_idle = idle_now
                        last_idle_click = idle_now
                        next_idle = random.uniform(*IDLE_MOVE)
                        next_idle_click = random.uniform(*IDLE_CLICK)
                        log("IDLE MOUSE RESUMED after random rest; new 1-minute active window started.")
                elif idle_now - idle_active_started >= IDLE_ACTIVE_FOR:
                    rest_for = random.uniform(*IDLE_REST)
                    idle_pause_until = idle_now + rest_for
                    record_stat("idle_pause_cycles")
                    log(f"IDLE MOUSE PAUSED for {rest_for/60:.1f} minutes after 5 active minutes. F5 and real job clicks continue.")
                else:
                    if idle_now-last_idle>=next_idle:
                        idle_mouse(snap, allow_click=False)
                        last_idle=idle_now
                        next_idle=random.uniform(*IDLE_MOVE)

                    if idle_now-last_idle_click>=next_idle_click:
                        idle_mouse(snap, allow_click=True)
                        last_idle_click=idle_now
                        next_idle_click=random.uniform(*IDLE_CLICK)

                refresh_status_ticket("ONLINE")
                maybe_f5()
                # Target one live DOM/row scan every 100 ms during ordinary
                # operation. Action/reload transitions may briefly take longer, but
                # we never intentionally sleep past the 100 ms scan cadence here.
                scan_elapsed = time.perf_counter() - scan_cycle_started
                if scan_elapsed < DOM_SCAN_INTERVAL:
                    time.sleep(DOM_SCAN_INTERVAL - scan_elapsed)
            except KeyboardInterrupt:
                request_stop(); break
            except Exception:
                record_stat("loop_errors"); note_issue("LOOP_ERROR","Unexpected main-loop error; bot continued","ERROR",traceback.format_exc(),throttle=0); time.sleep(0.6)

        if _stop_reason=="normal shutdown": _stop_reason="stop flag requested"
        final_page = "LOGGED OUT" if "logout" in str(_stop_reason).lower() or "login" in str(_stop_reason).lower() else "OFF"
        set_status_ticket(bot="STOPPED", page=final_page, f5="OFF", mouse="OFF")
        log("Stopped.")
    finally:
        final_page = "LOGGED OUT" if "logout" in str(_stop_reason).lower() or "login" in str(_stop_reason).lower() else "OFF"
        set_status_ticket(bot="STOPPED", page=final_page, f5="OFF", mouse="OFF")
        try:
            if label_overlay:
                label_overlay.close()
        except Exception:
            pass
        try:
            if label_sync:
                label_sync.close()
        except Exception:
            pass
        try: brain.close()
        except Exception as e: note_issue("BRAIN_CLOSE_ERROR","Error while closing browser connection","WARN",str(e),throttle=0)
        write_shutdown_report(_stop_reason)


def reset_session_state() -> None:
    """Reset per-run state so every Alt+S START is a clean new bot session/report."""
    global SESSION_STARTED_AT, SESSION_ID, _SESSION_LOG, _REPORT_LOCAL, _REPORT_VISIBLE
    global _report_written, _stop_reason, _stop, _paused, _pause_reason, _resume_requested, _resume_source
    global _last_click, _last_idle_dir, _last_diag_shot, _debug_chrome_pid, _debug_port, _debug_endpoint, _debug_user_data_dir

    SESSION_STARTED_AT = time.time()
    SESSION_ID = datetime.now().strftime("%Y%m%d_%H%M%S")
    _SESSION_LOG = _REPORT_DIR / f"Adeon Session {SESSION_ID}.log"
    _REPORT_LOCAL = _REPORT_DIR / f"Adeon Report {SESSION_ID}.txt"
    _REPORT_VISIBLE = _VISIBLE_REPORT_DIR / f"Adeon Report {SESSION_ID}.txt"
    _report_written = False
    _stop_reason = "normal shutdown"
    _stop = False
    _paused = False
    _pause_reason = ""
    _resume_requested = False
    _resume_source = ""
    _last_click = 0.0
    _last_idle_dir = ""
    _last_diag_shot = 0.0
    _debug_chrome_pid = 0
    _debug_port = 0
    _debug_endpoint = ""
    _debug_user_data_dir = ""
    _done.clear()
    with _alert_lock:
        _alerted.clear()
        _alert_last_try.clear()
        _alert_inflight.clear()
        _alert_cancelled.clear()
    with _issue_lock:
        _issues.clear()
        _issue_last.clear()
    _last_state.clear()
    for key in list(_stats):
        _stats[key] = 0


def _session_thread_entry() -> None:
    global _controller_active
    try:
        run_bot_session()
    finally:
        with _controller_lock:
            _controller_active = False
        set_status_ticket(bot="STOPPED", page="OFF", job="-", f5="OFF", mouse="OFF")


def main() -> None:
    """Adeon Bot is worker-only. The visible controller is Adeon.exe / Adeon App.pyw.

    This deliberately removes the old source-controller mode that could leave a
    black Python/CMD window open. If this .py file is accidentally launched by
    itself, it simply asks Windows to open the Adeon app and exits.
    """
    global _stop
    dpi_aware()
    if _APP_WORKER_MODE:
        try:
            _APP_STOP_FILE.unlink(missing_ok=True)
            _APP_LAST_ERROR_FILE.unlink(missing_ok=True)
        except Exception:
            pass
        # Reset first so every lifecycle line belongs to the same report/log.
        reset_session_state()
        start_app_stop_watchdog()
        log("WORKER | Activate received; starting fresh Adeon worker.")
        log(f"WORKER | PID={os.getpid()} mode=app-worker base={_BASE_DIR}")
        # The visible Adeon app owns the persistent bottom-left dashboard so it
        # remains visible even after this worker is DEACTIVATED.
        set_status_ticket(bot="STARTING", page="CONNECTING", job=("LABEL" if _LABELS_ONLY_MODE else "SEARCHING"), f5="WAIT", mouse="WAIT", mode=("LABELS" if _LABELS_ONLY_MODE else "PICKER"))
        run_bot_session()
        return

    # Never run the legacy Alt+S/source-controller loop from the editable script.
    # Starting the source directly should result in the real Adeon app, not a terminal.
    try:
        base = _BASE_DIR
        exe = base / "Adeon.exe"
        app = base / "Adeon App.pyw"
        if exe.exists():
            subprocess.Popen(
                [str(exe)], cwd=str(base),
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
        elif app.exists():
            pyw = Path(sys.executable).with_name("pythonw.exe")
            runner = str(pyw if pyw.exists() else sys.executable)
            subprocess.Popen(
                [runner, str(app)], cwd=str(base),
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass
    return


if __name__ == "__main__":
    main()
