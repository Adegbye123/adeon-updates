from __future__ import annotations

import ctypes
from ctypes import wintypes
import http.client
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
import urllib.parse
import socket
import zipfile
from pathlib import Path
import tkinter as tk
from tkinter import messagebox


def base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def redirect_source_copy_to_installed_app() -> bool:
    """If someone opens the extracted source copy, use the installed Adeon shortcut/app instead."""
    if getattr(sys, "frozen", False):
        return False
    try:
        installed = Path(os.environ.get("LOCALAPPDATA", "")) / "Adeon" / "Adeon.exe"
        here = Path(__file__).resolve().parent
        if installed.is_file() and here != installed.parent.resolve():
            subprocess.Popen([str(installed)], cwd=str(installed.parent),
                             creationflags=0x08000000, stdin=subprocess.DEVNULL,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
    except Exception:
        pass
    return False


START_IN_BACKGROUND = "--background" in sys.argv

BASE = base_dir()
BOT = BASE / "Adeon Bot.py"
PYTHON_PATH_FILE = BASE / "Python Path.txt"
PICKER_PID_FILE = BASE / "Adeon Worker PID.txt"
LABELS_PID_FILE = BASE / "Adeon Labels Worker PID.txt"
PICKER_STOP_FILE = BASE / "Adeon Stop Request.flag"
LABELS_STOP_FILE = BASE / "Adeon Labels Stop Request.flag"
PICKER_RUNTIME_FILE = BASE / "Adeon Runtime.json"
LABELS_RUNTIME_FILE = BASE / "Adeon Labels Runtime.json"
LABELS_REFRESH_FILE = BASE / "Adeon Labels Refresh Request.flag"
PIN_HELP_FLAG = BASE / "Show Pin Help.flag"
ACTIVITY_LOG = BASE / "Adeon Activity.log"
LAST_ERROR_FILE = BASE / "Adeon Last Error.txt"

# Persistent data used by the built-in Labels service.
ADEON_DATA_DIR = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "Adeon Data"
LABELS_ENABLED_FILE = ADEON_DATA_DIR / "Labels Enabled.json"
SHOW_WINDOW_REQUEST_FILE = ADEON_DATA_DIR / "Show Adeon Window.flag"

# 1.0.71 is Screen Vision / Windows accessibility only. There is no localhost
# extension bridge, browser-pairing state, CRX payload, or LR content-script path.
def start_browser_bridge_server() -> None:
    app_log("Screen Vision / Windows accessibility mode active; no browser integration bridge is used.")


def browser_wait_help_text() -> str:
    if existing_lr_page_open():
        return "LR Writers is detected. Adeon will attach with Screen Vision / Windows accessibility only."
    return (
        "Open or switch to LR Writers in the Chrome or Thorium window you already use. "
        "Adeon will wait for that existing browser and will never open another window or profile."
    )

# Self-updater.  Every updater-enabled Adeon can jump directly to the newest
# published version; updates are full program-file releases, not incremental
# patches.  User data (Chrome Data, reports, logs, local state) is never part of
# an update package and is therefore preserved.
ADEON_VERSION = "1.0.72"
UPDATE_FEED_FILE = BASE / "Update Feed URL.txt"
OFFICIAL_UPDATE_FEED = "https://raw.githubusercontent.com/Adegbye123/adeon-updates/main/adeon/manifest.json"
UPDATE_HELPER = BASE / "Adeon Update Helper.py"
UPDATE_PENDING_FILE = BASE / "Adeon Pending Update.json"
UPDATE_STATUS_FILE = BASE / "Adeon Update Status.json"
UPDATE_STAGE_DIR = BASE / "Update Staging"
UPDATE_CHECK_INTERVAL = 5.0  # online clients poll the manifest every ~5 seconds

# Updater diagnostics are mirrored to Downloads so users can send one obvious
# file when update discovery or installation is not working.
def _downloads_dir() -> Path:
    try:
        p = Path(os.environ.get("USERPROFILE", str(Path.home()))) / "Downloads"
        p.mkdir(parents=True, exist_ok=True)
        return p
    except Exception:
        return Path.home()

UPDATE_DIAGNOSTIC_LOG = _downloads_dir() / "Adeon Update Diagnostic.log"


CREATE_NEW_PROCESS_GROUP = 0x00000200
DETACHED_PROCESS = 0x00000008
CREATE_NO_WINDOW = 0x08000000
PROCESS_SYNCHRONIZE = 0x00100000
WAIT_TIMEOUT = 0x00000102
SW_RESTORE = 9


def set_windows_app_identity() -> None:
    """Give Windows a stable Adeon identity so the taskbar uses Adeon's icon."""
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Adeon.Picker.DesktopApp")
    except Exception:
        pass


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8").strip()
    except Exception:
        return ""


def labels_enabled_preference() -> bool:
    """Persistent built-in Labels preference. Default ON for existing/new installs."""
    try:
        if not LABELS_ENABLED_FILE.exists():
            return True
        obj = json.loads(LABELS_ENABLED_FILE.read_text(encoding="utf-8"))
        if isinstance(obj, dict):
            return bool(obj.get("enabled", True))
        return bool(obj)
    except Exception:
        return True


def set_labels_enabled_preference(enabled: bool) -> None:
    try:
        ADEON_DATA_DIR.mkdir(parents=True, exist_ok=True)
        tmp = LABELS_ENABLED_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps({"enabled": bool(enabled), "updated_at": time.time()}, indent=2), encoding="utf-8")
        tmp.replace(LABELS_ENABLED_FILE)
    except Exception as e:
        app_log(f"Labels preference save failed: {e}")


def app_log(message: str) -> None:
    try:
        stamp = time.strftime("%Y-%m-%d %H:%M:%S")
        with ACTIVITY_LOG.open("a", encoding="utf-8") as fh:
            fh.write(f"[{stamp}] APP | {str(message)}\n")
    except Exception:
        pass


def update_diag(message: str) -> None:
    try:
        stamp = time.strftime("%Y-%m-%d %H:%M:%S")
        with UPDATE_DIAGNOSTIC_LOG.open("a", encoding="utf-8") as fh:
            fh.write(f"[{stamp}] {str(message)}\n")
    except Exception:
        pass


def _pid_file(mode: str = "picker") -> Path:
    return LABELS_PID_FILE if str(mode).lower() == "labels" else PICKER_PID_FILE

def _stop_file(mode: str = "picker") -> Path:
    return LABELS_STOP_FILE if str(mode).lower() == "labels" else PICKER_STOP_FILE

def _runtime_file(mode: str = "picker") -> Path:
    return LABELS_RUNTIME_FILE if str(mode).lower() == "labels" else PICKER_RUNTIME_FILE

def worker_pid(mode: str = "picker") -> int:
    try:
        return int(read_text(_pid_file(mode)) or "0")
    except Exception:
        return 0


def pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        k32 = ctypes.windll.kernel32
        h = k32.OpenProcess(PROCESS_SYNCHRONIZE, False, int(pid))
        if not h:
            return False
        try:
            return int(k32.WaitForSingleObject(h, 0)) == WAIT_TIMEOUT
        finally:
            k32.CloseHandle(h)
    except Exception:
        return False


def runtime_state(mode: str = "picker") -> dict:
    try:
        obj = json.loads(_runtime_file(mode).read_text(encoding="utf-8"))
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def _window_title(hwnd: int) -> str:
    """Return a top-level Windows window title."""
    try:
        user32 = ctypes.windll.user32
        length = int(user32.GetWindowTextLengthW(hwnd))
        if length <= 0:
            return ""
        buf = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buf, length + 1)
        return str(buf.value or "")
    except Exception:
        return ""


def _window_process_name(hwnd: int) -> str:
    """Best-effort executable name for a top-level window."""
    try:
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        pid = wintypes.DWORD(0)
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if not pid.value:
            return ""
        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        hproc = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid.value)
        if not hproc:
            return ""
        try:
            size = wintypes.DWORD(1024)
            buf = ctypes.create_unicode_buffer(size.value)
            ok = kernel32.QueryFullProcessImageNameW(hproc, 0, buf, ctypes.byref(size))
            if not ok:
                return ""
            return Path(buf.value).name.lower()
        finally:
            kernel32.CloseHandle(hproc)
    except Exception:
        return ""


def _title_is_lr(title: str) -> bool:
    title = str(title or "").strip().lower()
    return bool(
        title and (
            "writer tool" in title
            or "lr writers" in title
            or "lrwriters" in title
            or "myaccount.lrwriters.com" in title
        )
    )


def foreground_window_title() -> str:
    """Return the title of the Windows foreground window."""
    try:
        hwnd = int(ctypes.windll.user32.GetForegroundWindow() or 0)
        return _window_title(hwnd) if hwnd else ""
    except Exception:
        return ""


def foreground_is_lr_page() -> bool:
    """True while the actual foreground window is an LR Writers browser page."""
    return _title_is_lr(foreground_window_title())


def find_existing_lr_browser_window() -> tuple[int, str, str]:
    """Find an LR Writers tab already open in Chrome or Thorium.

    IMPORTANT: this enumerates existing top-level windows instead of checking only
    the foreground window. Clicking Adeon's ACTIVATE PICKER / ON LABELS buttons
    necessarily gives Adeon focus, so a foreground-only check incorrectly turns
    a visible LR tab into "WAITING FOR LR".
    """
    try:
        user32 = ctypes.windll.user32
        found: list[tuple[int, int, str, str]] = []
        foreground = int(user32.GetForegroundWindow() or 0)

        @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        def enum_proc(hwnd, _lparam):
            try:
                hwnd_i = int(hwnd)
                if not user32.IsWindowVisible(hwnd_i):
                    return True
                title = _window_title(hwnd_i)
                if not _title_is_lr(title):
                    return True
                proc = _window_process_name(hwnd_i)
                # Prefer the browsers Adeon explicitly supports. Keep a title-only
                # fallback so a renamed Chromium/Thorium executable still works.
                browser_score = 3 if proc in ("thorium.exe", "chrome.exe", "chromium.exe") else 1
                if hwnd_i == foreground:
                    browser_score += 4
                found.append((browser_score, hwnd_i, title, proc))
            except Exception:
                pass
            return True

        user32.EnumWindows(enum_proc, 0)
        if not found:
            return (0, "", "")
        found.sort(key=lambda item: item[0], reverse=True)
        _, hwnd, title, proc = found[0]
        return (int(hwnd), str(title), str(proc))
    except Exception:
        return (0, "", "")


def existing_lr_page_open() -> bool:
    """True when LR Writers is already open in a supported existing browser."""
    hwnd, _title, _proc = find_existing_lr_browser_window()
    return bool(hwnd)


def native_refresh_existing_lr() -> bool:
    """Activate and refresh the LR Writers tab that is ALREADY open.

    No browser, window, tab, profile, or URL is created. Adeon only brings the
    existing LR browser window to the foreground and sends the normal Ctrl+R
    keystroke to that already-open tab. The picker mouse/Reserve system is not
    changed by this helper.
    """
    hwnd, title, proc = find_existing_lr_browser_window()
    if not hwnd:
        return False
    try:
        user32 = ctypes.windll.user32
        SW_RESTORE = 9
        VK_CONTROL = 0x11
        VK_R = 0x52
        KEYEVENTF_KEYUP = 0x0002

        # Because the user just clicked Adeon, Adeon owns foreground permission
        # and can hand focus straight back to the existing browser window.
        try:
            user32.ShowWindow(hwnd, SW_RESTORE)
        except Exception:
            pass
        try:
            user32.SetForegroundWindow(hwnd)
        except Exception:
            pass
        time.sleep(0.12)

        # Do not send Ctrl+R unless the LR window is now actually foreground.
        if int(user32.GetForegroundWindow() or 0) != int(hwnd):
            app_log(
                f"Existing LR window found but Windows did not grant focus; refresh skipped. "
                f"process={proc or '?'} title={title[:80]}"
            )
            return False

        user32.keybd_event(VK_CONTROL, 0, 0, 0)
        time.sleep(0.03)
        user32.keybd_event(VK_R, 0, 0, 0)
        time.sleep(0.03)
        user32.keybd_event(VK_R, 0, KEYEVENTF_KEYUP, 0)
        user32.keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)
        app_log(
            f"Existing LR Writers tab refreshed once with native Ctrl+R. "
            f"process={proc or '?'} title={title[:80]}"
        )
        return True
    except Exception as e:
        app_log(f"Native existing-tab refresh skipped: {e}")
        return False


def pythonw_path() -> str:
    p = read_text(PYTHON_PATH_FILE)
    if p and Path(p).is_file():
        return p
    exe = Path(sys.executable)
    if exe.name.lower().startswith("python"):
        pw = exe.with_name("pythonw.exe")
        return str(pw if pw.exists() else exe)
    return "pythonw.exe"





def update_feed_url() -> str:
    raw = read_text(UPDATE_FEED_FILE).strip()
    if not raw or raw.startswith("#") or "OWNER/REPOSITORY" in raw:
        return OFFICIAL_UPDATE_FEED
    return raw




def manifest_feed_candidates(feed: str) -> list[str]:
    """Return public GitHub manifest URLs that can have independent CDN cache keys.

    GitHub's raw CDN can briefly serve an older branch view after the Contents API
    has accepted a commit.  Adeon probes equivalent public endpoints and uses the
    newest valid manifest it sees.  No private token is required on client laptops.
    """
    out = []
    def add(url: str):
        url = str(url or '').strip()
        if url and url not in out:
            out.append(url)
    add(feed)
    try:
        u = urllib.parse.urlparse(feed)
        if u.netloc.lower() == 'raw.githubusercontent.com':
            parts = [x for x in u.path.split('/') if x]
            if len(parts) >= 4:
                owner, repo, branch = parts[0], parts[1], parts[2]
                rel = '/'.join(parts[3:])
                add(f'https://raw.githubusercontent.com/{owner}/{repo}/refs/heads/{branch}/{rel}')
                add(f'https://github.com/{owner}/{repo}/raw/refs/heads/{branch}/{rel}')
                add(f'https://github.com/{owner}/{repo}/raw/{branch}/{rel}')
    except Exception:
        pass
    return out


def fetch_newest_manifest(feed: str) -> tuple[dict, str]:
    """Read equivalent public feeds and return the highest valid Adeon version."""
    best = None
    best_url = ''
    errors = []
    for i, url in enumerate(manifest_feed_candidates(feed)):
        try:
            # The primary feed keeps the full retry/fallback behavior. Alternate
            # cache paths use a shorter timeout so the 5-second polling loop stays responsive.
            timeout = 8.0 if i == 0 else 4.0
            obj = fetch_json_url(url, timeout=timeout)
            if str(obj.get('product') or '') != 'Adeon LR Picker':
                continue
            ver = str(obj.get('version') or '').strip()
            if not ver:
                continue
            update_diag(f'MANIFEST SOURCE | url={url} version={ver}')
            if best is None or version_tuple(ver) > version_tuple(str(best.get('version') or '0')):
                best = obj
                best_url = url
        except Exception as e:
            errors.append(f'{url}: {e}')
            update_diag(f'MANIFEST SOURCE FAILED | url={url} error={e}')
    if best is None:
        raise RuntimeError('No public update feed responded with a valid manifest' + (f' | {errors[-1]}' if errors else ''))
    return best, best_url

def fetch_manifest_quick(feed: str) -> tuple[dict, str]:
    """Fast single-endpoint probe used by the 5-second background poll.

    The previous build could keep the update state busy for many seconds because
    every automatic poll used the full retry/fallback routine across several
    GitHub URLs.  That made CHECK FOR UPDATE look unclickable.  Background
    checks now probe just one cache-busted public endpoint with a short timeout.
    Manual checks still use the robust multi-endpoint routine.
    """
    candidates = manifest_feed_candidates(feed)
    if not candidates:
        raise RuntimeError('No update feed is configured')
    # Rotate equivalent GitHub URLs between polls so a stale CDN edge does not
    # permanently hide a newly published manifest.
    idx = int(time.time() // max(1.0, UPDATE_CHECK_INTERVAL)) % len(candidates)
    url = candidates[idx]
    request_url = _cache_busted_url(url)
    req = urllib.request.Request(
        request_url,
        headers={
            "User-Agent": f"Adeon-LR-Picker/{ADEON_VERSION}",
            "Cache-Control": "no-cache, no-store",
            "Pragma": "no-cache",
            "Connection": "close",
        },
    )
    try:
        try:
            with urllib.request.urlopen(req, timeout=2.5) as resp:
                data = resp.read(1024 * 1024 + 1)
        except Exception as first_error:
            # The user's Windows log repeatedly showed urllib TLS/read timeouts even
            # though the public GitHub feed itself was live. Use Windows curl as an
            # immediate alternate transport for the lightweight background probe.
            update_diag(f'FAST MANIFEST urllib failed; trying curl | url={url} error={first_error}')
            data = _curl_public_https(request_url, 4.0, 1024 * 1024)
        if len(data) > 1024 * 1024:
            raise RuntimeError('Update manifest exceeded the allowed size')
        obj = json.loads(data.decode('utf-8-sig'))
        if not isinstance(obj, dict):
            raise RuntimeError('Update manifest is not a JSON object')
        if str(obj.get('product') or '') != 'Adeon LR Picker':
            raise RuntimeError('Update feed is for a different product')
        update_diag(f'FAST MANIFEST SOURCE | url={url} version={obj.get("version","")}')
        return obj, url
    except Exception as e:
        update_diag(f'FAST MANIFEST FAILED | url={url} error={e}')
        raise

def version_tuple(value: str) -> tuple[int, ...]:
    parts = []
    for piece in str(value or "0").strip().lstrip("vV").split("."):
        digits = "".join(ch for ch in piece if ch.isdigit())
        parts.append(int(digits or 0))
    while len(parts) < 4:
        parts.append(0)
    return tuple(parts[:4])


def is_newer_version(candidate: str, current: str = ADEON_VERSION) -> bool:
    return version_tuple(candidate) > version_tuple(current)


def _cache_busted_url(url: str) -> str:
    text = str(url or "")
    sep = "&" if "?" in text else "?"
    return f"{text}{sep}adeon_cb={int(time.time() * 1000)}"


def _curl_public_https(url: str, timeout: float, max_bytes: int) -> bytes:
    """Public-read fallback for Windows machines where urllib/TLS is interrupted."""
    curl = shutil.which("curl.exe") or shutil.which("curl")
    if not curl:
        raise RuntimeError("curl fallback is not available")
    cmd = [
        curl, "-L", "--fail", "--silent", "--show-error",
        "--connect-timeout", str(max(3, min(15, int(timeout)))),
        "--max-time", str(max(5, int(timeout))),
        "-H", "Cache-Control: no-cache, no-store",
        "-H", "Pragma: no-cache",
        "-A", f"Adeon-LR-Picker/{ADEON_VERSION}",
        url,
    ]
    cp = subprocess.run(cmd, capture_output=True, timeout=max(8, timeout + 5), creationflags=CREATE_NO_WINDOW)
    if cp.returncode != 0:
        err = cp.stderr.decode("utf-8", errors="replace").strip()
        raise RuntimeError(f"curl failed ({cp.returncode}): {err[:300]}")
    data = bytes(cp.stdout or b"")
    if len(data) > max_bytes:
        raise RuntimeError("Update response exceeded the allowed size")
    return data


def _public_https_bytes(url: str, timeout: float, max_bytes: int, purpose: str) -> bytes:
    if not str(url).lower().startswith("https://"):
        raise RuntimeError(f"{purpose} must use HTTPS")
    attempts = 4
    last = None
    for attempt in range(1, attempts + 1):
        request_url = _cache_busted_url(str(url))
        req = urllib.request.Request(
            request_url,
            headers={
                "User-Agent": f"Adeon-LR-Picker/{ADEON_VERSION}",
                "Cache-Control": "no-cache, no-store",
                "Pragma": "no-cache",
                "Connection": "close",
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = resp.read(max_bytes + 1)
            if len(data) > max_bytes:
                raise RuntimeError("Update response exceeded the allowed size")
            if attempt > 1:
                update_diag(f"NETWORK RECOVERED | {purpose} succeeded on attempt {attempt}/{attempts}")
            return data
        except urllib.error.HTTPError as e:
            last = e
            # 4xx responses other than timeout/rate-limit are not transient.
            if e.code not in (408, 429, 500, 502, 503, 504):
                raise RuntimeError(f"{purpose} HTTP {e.code}")
        except (urllib.error.URLError, http.client.RemoteDisconnected, ConnectionResetError,
                ConnectionAbortedError, TimeoutError, socket.timeout, OSError) as e:
            last = e
        except RuntimeError:
            raise
        if attempt < attempts:
            delay = min(8.0, 1.0 * (2 ** (attempt - 1)))
            update_diag(f"NETWORK RETRY | {purpose} attempt={attempt}/{attempts} reason={last} waiting={delay:.1f}s")
            time.sleep(delay)

    # GitHub raw/public downloads need no secret, so curl is a safe alternate
    # transport when Python's urllib connection is being interrupted locally.
    try:
        update_diag(f"NETWORK FALLBACK | {purpose} trying Windows curl after urllib retries")
        return _curl_public_https(_cache_busted_url(str(url)), timeout, max_bytes)
    except Exception as curl_error:
        update_diag(f"NETWORK FALLBACK FAILED | {purpose} | {curl_error}")
        raise RuntimeError(f"{purpose} connection failed after retries: {last or curl_error}")


def fetch_json_url(url: str, timeout: float = 12.0) -> dict:
    data = _public_https_bytes(url, timeout, 1024 * 1024, "Update manifest")
    obj = json.loads(data.decode("utf-8-sig"))
    if not isinstance(obj, dict):
        raise RuntimeError("Update manifest is not a JSON object")
    return obj


def download_bytes(url: str, timeout: float = 45.0) -> bytes:
    return _public_https_bytes(url, timeout, 100 * 1024 * 1024, "Update package")


def flash_taskbar(hwnd: int, count: int = 8) -> None:
    """Flash Adeon's own taskbar button so an available update is visible."""
    try:
        class FLASHWINFO(ctypes.Structure):
            _fields_ = [
                ("cbSize", ctypes.c_uint),
                ("hwnd", ctypes.c_void_p),
                ("dwFlags", ctypes.c_uint),
                ("uCount", ctypes.c_uint),
                ("dwTimeout", ctypes.c_uint),
            ]
        info = FLASHWINFO(ctypes.sizeof(FLASHWINFO), int(hwnd), 0x00000003 | 0x0000000C, int(count), 0)
        ctypes.windll.user32.FlashWindowEx(ctypes.byref(info))
    except Exception:
        pass


def cleanup_legacy_controllers() -> None:
    """Close obsolete console-based LR/Adeon controllers without touching app workers."""
    try:
        ps = (
            "$me=$PID; "
            "$ps=Get-CimInstance Win32_Process | Where-Object { "
            "$_.ProcessId -ne $me -and $_.CommandLine -and "
            "((($_.CommandLine -match 'Adeon Bot\\.py') -and ($_.CommandLine -notmatch '--app-worker')) "
            "-or ($_.CommandLine -match 'LR Picker Bot\\.py') "
            "-or ($_.CommandLine -match 'lr_mouse_bot\\.py') "
            "-or ($_.CommandLine -match 'lr_alt_s_launcher\\.pyw')) }; "
            "foreach($p in $ps){ try { Invoke-CimMethod -InputObject $p -MethodName Terminate | Out-Null } catch {} }"
        )
        subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5,
            creationflags=0x08000000,
        )
    except Exception:
        pass

def launch_worker(mode: str = "picker") -> tuple[bool, str]:
    mode = "labels" if str(mode).lower() == "labels" else "picker"
    if pid_alive(worker_pid(mode)):
        if mode == "labels":
            app_log("Labels launch requested but labels worker is already active.")
            return True, "Labels already active"
        app_log("Picker launch requested but picker worker is already active.")
        return True, "Picker already active"
    if not BOT.exists():
        return False, f"Missing {BOT.name}"
    for p in (_stop_file(mode), LAST_ERROR_FILE):
        try:
            p.unlink(missing_ok=True)
        except Exception:
            pass
    try:
        args = [pythonw_path(), str(BOT), "--app-worker"]
        if mode == "labels":
            args.append("--labels-only")
        proc = subprocess.Popen(
            args,
            cwd=str(BASE),
            creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP,
            close_fds=True,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        _pid_file(mode).write_text(str(proc.pid), encoding="utf-8")
        app_log(f"Worker launched. PID={proc.pid}. mode={mode}. Waiting for the existing Chrome/Thorium LR Writers session.")
        if mode == "labels":
            return True, "Turning labels on in the existing LR Writers tab..."
        return True, "Connecting to the existing Chrome/Thorium LR Writers tab..."
    except Exception as e:
        app_log(f"Worker launch failed: {e}")
        return False, str(e)


def request_stop(mode: str = "picker") -> tuple[bool, str]:
    mode = "labels" if str(mode).lower() == "labels" else "picker"
    pid = worker_pid(mode)
    if not pid_alive(pid):
        try:
            _pid_file(mode).unlink(missing_ok=True)
        except Exception:
            pass
        return True, "Already stopped"
    try:
        _stop_file(mode).write_text(str(time.time()), encoding="utf-8")
        app_log(f"Deactivate requested for {mode} worker PID={pid}.")
        return True, "Stopping..."
    except Exception as e:
        return False, str(e)


def bring_existing_adeon_to_front() -> bool:
    """Restore the already-running Adeon window if Windows can find it."""
    try:
        user32 = ctypes.windll.user32
        # Exact title first, then enumerate because update notices can temporarily
        # append text to the title (for example "Adeon  •  UPDATE AVAILABLE").
        hwnd = int(user32.FindWindowW(None, "Adeon") or 0)
        if not hwnd:
            found = []
            EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
            @EnumWindowsProc
            def enum_proc(h, _lp):
                try:
                    n = user32.GetWindowTextLengthW(h)
                    if n <= 0:
                        return True
                    buf = ctypes.create_unicode_buffer(n + 1)
                    user32.GetWindowTextW(h, buf, n + 1)
                    title = str(buf.value or "")
                    if title == "Adeon" or title.startswith("Adeon  •"):
                        found.append(int(h))
                except Exception:
                    pass
                return True
            user32.EnumWindows(enum_proc, 0)
            if found:
                hwnd = int(found[0])
        if hwnd:
            user32.ShowWindow(hwnd, SW_RESTORE)
            user32.SetForegroundWindow(hwnd)
            return True
    except Exception:
        pass
    return False


def request_existing_adeon_window() -> None:
    """Tell a hidden background Adeon instance to show its main control window."""
    try:
        ADEON_DATA_DIR.mkdir(parents=True, exist_ok=True)
        SHOW_WINDOW_REQUEST_FILE.write_text(str(time.time()), encoding="utf-8")
    except Exception:
        pass


def _terminate_stale_adeon_desktop_processes() -> None:
    """Kill only other Adeon.exe desktop processes when the mutex has no usable UI.

    This is a recovery path for a crashed/hidden stale desktop process. It never
    targets Adeon Bot workers, Chrome/Thorium, or the updater helper.
    """
    if not getattr(sys, "frozen", False):
        return
    try:
        me = int(os.getpid())
        ps = (
            "$me=" + str(me) + "; "
            "$ps=Get-CimInstance Win32_Process | Where-Object { "
            "$_.ProcessId -ne $me -and $_.Name -ieq 'Adeon.exe' }; "
            "foreach($p in $ps){ try { Invoke-CimMethod -InputObject $p -MethodName Terminate | Out-Null } catch {} }"
        )
        subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            timeout=4, creationflags=CREATE_NO_WINDOW,
        )
    except Exception:
        pass


def single_instance_or_focus() -> object | None:
    """Allow one Adeon desktop process without making the app look dead.

    A Windows-startup copy can be intentionally hidden. A second normal launch now
    first requests that hidden copy to show itself. If the mutex exists but no
    Adeon UI responds, the stale desktop process is cleared and the mutex is
    reacquired instead of silently exiting forever.
    """
    try:
        k32 = ctypes.windll.kernel32
        for attempt in range(2):
            k32.SetLastError(0)
            mutex = k32.CreateMutexW(None, False, "Local\\AdeonPickerAppMutex")
            err = int(k32.GetLastError())
            if err != 183:  # ERROR_ALREADY_EXISTS
                return mutex

            request_existing_adeon_window()
            for _ in range(8):
                if bring_existing_adeon_to_front():
                    if mutex:
                        try: k32.CloseHandle(mutex)
                        except Exception: pass
                    return None
                time.sleep(0.10)

            # No window responded. Close this handle before killing the stale owner,
            # otherwise this process itself would keep the named mutex alive.
            if mutex:
                try: k32.CloseHandle(mutex)
                except Exception: pass
            if attempt == 0:
                _terminate_stale_adeon_desktop_processes()
                time.sleep(0.35)
                continue
            return object()
        return object()
    except Exception:
        return object()


class AdeonApp:
    def __init__(self) -> None:
        set_windows_app_identity()
        start_browser_bridge_server()
        self.root = tk.Tk()
        self.root.title("Adeon")
        self.root.geometry("350x540")
        self.root.resizable(False, False)
        self.root.configure(bg="#f7f8f7")
        self.root.protocol("WM_DELETE_WINDOW", self.hide_to_background)
        self._labels_recovery_next_at = 0.0
        self._labels_recovery_failures = 0
        self._background_show_requested = False
        if START_IN_BACKGROUND:
            self.root.after(350, self.initial_background_hide)
        try:
            ico = BASE / "Adeon.ico"
            if ico.exists():
                self.root.iconbitmap(default=str(ico))
                # Re-apply after Windows has created the native window handle.
                self.root.after(250, lambda: self.root.iconbitmap(default=str(ico)))
        except Exception:
            pass

        top = tk.Frame(self.root, bg="#f7f8f7")
        top.pack(pady=(18, 4))

        logo = tk.Canvas(top, width=48, height=48, bg="#f7f8f7", highlightthickness=0)
        logo.pack(side="left", padx=(0, 9))
        logo.create_oval(2, 2, 46, 46, fill="#12863a", outline="#12863a")
        logo.create_text(24, 24, text="A", fill="white", font=("Segoe UI", 24, "bold"))

        tk.Label(
            top, text="ADEON", bg="#f7f8f7", fg="#111111",
            font=("Segoe UI", 19, "bold")
        ).pack(side="left")

        self.status = tk.Label(
            self.root, text="STOPPED", bg="#f7f8f7", fg="#c62828",
            font=("Segoe UI", 13, "bold")
        )
        self.status.pack(pady=(6, 5))

        # Clean browser-connection progress indicator. While Adeon is finding LR,
        # pairing Browser Integration, or waiting for the heartbeat, the dashboard
        # shows one moving bar instead of cycling through technical status messages.
        self.connect_progress = tk.Canvas(
            self.root, width=260, height=9, bg="#e1e5e2",
            highlightthickness=0, bd=0
        )
        self.connect_progress_bar = self.connect_progress.create_rectangle(
            -72, 0, 0, 9, fill="#12863a", outline=""
        )
        self._connect_progress_running = False
        self._connect_progress_x = -72

        self.version_label = tk.Label(
            self.root, text=f"INSTALLED VERSION  {ADEON_VERSION}", bg="#f7f8f7", fg="#777777",
            font=("Segoe UI", 8)
        )
        self.version_label.pack(pady=(0, 8))

        self.update_status = tk.Label(
            self.root, text="UPDATE  •  CHECKING", bg="#f7f8f7", fg="#777777",
            font=("Segoe UI", 8, "bold")
        )
        self.update_status.pack(pady=(0, 4))

        self.update_button = tk.Button(
            self.root, text="CHECK FOR UPDATE", width=25, height=1,
            font=("Segoe UI", 9, "bold"), command=lambda: self.check_for_updates(force=True),
            relief="flat", cursor="hand2", bg="#e8ece9", fg="#1f1f1f",
            activebackground="#d7ddd9", activeforeground="#111111"
        )
        self.update_button.pack(pady=(0, 8))

        # Persistent bottom-left dashboard owned by Adeon.exe itself. It is a real
        # Tk window with native text widgets, not an image. The rounded shape is
        # applied with a Windows region so the text remains crisp at normal DPI.
        self.ticket = tk.Toplevel(self.root)
        self.ticket.overrideredirect(True)
        self.ticket.attributes("-topmost", True)
        try:
            self.ticket.attributes("-alpha", 1.0)
        except Exception:
            pass
        self._ticket_width, self._ticket_height = 252, 126
        sh = int(self.ticket.winfo_screenheight() or 1080)
        self.ticket.geometry(f"{self._ticket_width}x{self._ticket_height}+18+{max(8, sh-self._ticket_height-58)}")
        self.ticket.configure(bg="#fff7d6")

        tframe = tk.Frame(self.ticket, bg="#fff7d6", bd=0, highlightthickness=0)
        tframe.pack(fill="both", expand=True, padx=1, pady=1)

        header_row = tk.Frame(tframe, bg="#fff7d6")
        header_row.pack(fill="x", padx=(12, 7), pady=(8, 2))
        self.ticket_header = tk.Label(
            header_row, text="ADEON  •  STOPPED", anchor="w", justify="left",
            bg="#fff7d6", fg="#c62828", font=("Bahnschrift SemiBold", 10, "bold")
        )
        self.ticket_header.pack(side="left", fill="x", expand=True)
        self.ticket_close = tk.Button(
            header_row, text="×", command=self.minimize_dashboard,
            bg="#fff7d6", fg="#111111", activebackground="#f3e7b3", activeforeground="#111111",
            relief="flat", bd=0, highlightthickness=0, cursor="hand2",
            font=("Segoe UI", 12, "bold"), padx=3, pady=0,
        )
        self.ticket_close.pack(side="right")
        # Latch minimization on mouse-down, not only Button command/release. The
        # dashboard visibility timer can run between press/release, so handling the
        # press guarantees one click always becomes the round restore object.
        self.ticket_close.bind("<ButtonPress-1>", self._ticket_close_pressed)

        body = tk.Frame(tframe, bg="#fff7d6")
        body.pack(fill="both", expand=True, padx=12, pady=(3, 8))
        self.ticket_value_labels = {}
        for r, key in enumerate(("JOB", "F5", "MOUSE")):
            left = tk.Label(
                body, text=key, anchor="w", bg="#fff7d6", fg="#111111",
                font=("Bahnschrift SemiBold", 9, "bold")
            )
            left.grid(row=r, column=0, sticky="w", pady=2)
            value = tk.Label(
                body, text="-" if key == "JOB" else "OFF", anchor="w",
                bg="#fff7d6", fg="#111111", font=("Bahnschrift SemiBold", 9, "bold")
            )
            value.grid(row=r, column=1, sticky="w", padx=(28, 0), pady=2)
            self.ticket_value_labels[key] = value
        body.grid_columnconfigure(1, weight=1)

        self.ticket_restore = tk.Toplevel(self.root)
        self.ticket_restore.overrideredirect(True)
        self.ticket_restore.attributes("-topmost", True)
        self.ticket_restore.configure(bg="#fff7d6")
        self.ticket_restore.geometry(f"32x32+18+{max(8, sh-32-58)}")
        self.ticket_restore_button = tk.Button(
            self.ticket_restore, text="A", command=self.restore_dashboard,
            bg="#c62828", fg="white", activebackground="#a91f1f", activeforeground="white",
            relief="flat", bd=0, highlightthickness=0, cursor="hand2",
            font=("Bahnschrift SemiBold", 10, "bold")
        )
        self.ticket_restore_button.pack(fill="both", expand=True)
        self.ticket_restore.withdraw()

        drag = {"x": 0, "y": 0}
        def ticket_drag_start(event):
            drag["x"], drag["y"] = int(event.x), int(event.y)
        def ticket_drag_move(event):
            self.ticket.geometry(f"+{int(event.x_root)-drag['x']}+{int(event.y_root)-drag['y']}")
        for widget in (tframe, header_row, self.ticket_header, body, *self.ticket_value_labels.values()):
            widget.bind("<ButtonPress-1>", ticket_drag_start)
            widget.bind("<B1-Motion>", ticket_drag_move)
        self.root.after(50, self.apply_dashboard_rounding)

        self.toggle = tk.Button(
            self.root, text="ACTIVATE PICKER", width=25, height=2,
            font=("Segoe UI", 11, "bold"), command=self.toggle_picker,
            relief="flat", cursor="hand2", bg="#12863a", fg="white",
            activebackground="#0e6d2e", activeforeground="white"
        )
        self.toggle.pack()

        self.labels_button = tk.Button(
            self.root, text="ON LABELS", width=25, height=1,
            font=("Segoe UI", 9, "bold"), command=self.toggle_labels,
            relief="flat", cursor="hand2", bg="#dfeee3", fg="#176b34",
            activebackground="#cfe5d5", activeforeground="#145a2d"
        )
        self.labels_button.pack(pady=(7, 0))

        self.pair_button = tk.Button(
            self.root, text="PAIR BROWSER INTEGRATION", width=25, height=1,
            font=("Segoe UI", 9, "bold"), command=self.pair_browser_integration,
            relief="flat", cursor="hand2", bg="#e7b94a", fg="#111111",
            activebackground="#d9a62c", activeforeground="#111111"
        )
        # Hidden unless LR is found but no browser-extension heartbeat arrives.
        self.pair_button.pack_forget()

        self.log_button = tk.Button(
            self.root, text="VIEW ACTIVITY LOG", width=25, height=1,
            font=("Segoe UI", 9, "bold"), command=self.open_activity_log,
            relief="flat", cursor="hand2", bg="#e8ece9", fg="#1f1f1f",
            activebackground="#d7ddd9", activeforeground="#111111"
        )
        self.log_button.pack(pady=(8, 0))

        self.end_button = tk.Button(
            self.root, text="END ADEON", width=25, height=1,
            font=("Segoe UI", 9, "bold"), command=self.close_everything,
            relief="flat", cursor="hand2", bg="#eeeeee", fg="#555555",
            activebackground="#dddddd", activeforeground="#222222"
        )
        self.end_button.pack(pady=(6, 0))

        self.note = tk.Label(
            self.root,
            text="Adeon attaches only to LR Writers already open in Chrome or Thorium. It never opens a browser window or profile.",
            bg="#f7f8f7", fg="#555555", font=("Segoe UI", 8),
            wraplength=292, justify="center"
        )
        self.note.pack(pady=(12, 0))

        self.hotkey_note = tk.Label(
            self.root, text="ALT+S also toggles START / STOP",
            bg="#f7f8f7", fg="#777777", font=("Segoe UI", 8)
        )
        self.hotkey_note.pack(pady=(5, 0))

        self.last_event = tk.Label(
            self.root, text="Log: waiting", bg="#f7f8f7", fg="#555555",
            font=("Segoe UI", 7), wraplength=320, justify="center"
        )
        self.last_event.pack(pady=(8, 0))

        self.busy = False
        self.last_alive = False
        self._hotkey_exit = threading.Event()
        self._hotkey_thread_id = 0
        self._hotkey_registered = False
        self._picker_forced_red = False
        self._last_runtime_page = ""
        self._closing = False
        self._ticket_visible = True
        self._ticket_user_minimized = False
        self._ticket_internal_focus_until = 0.0
        self._last_picker_connected_at = 0.0
        self._browser_connect_mode = ""
        self._browser_connect_started_at = 0.0
        self._stop_connect_progress()
        self._browser_helper_opened = False
        self._browser_native_refresh_attempted = False
        self._browser_pairing_needed = False
        self._browser_pairing_detail = ""
        self.pending_update: dict | None = None
        self.update_checking = False
        self.update_installing = False
        self.manual_update_requested = False
        self.last_update_check = 0.0
        self.last_update_notified = ""
        update_diag(f"ADEON START | installed={ADEON_VERSION} feed={update_feed_url() or '[not configured]'}")
        self.root.after(200, self.refresh)
        self.root.after(2200, lambda: self.check_for_updates(force=True))
        self.root.after(5000, self.periodic_update_check)
        self.root.after(900, self.show_last_update_result)
        self.start_global_alt_s_hotkey()
        self.root.after(700, self.maybe_show_pin_help)
        # Labels are a persistent built-in service. Unless the user explicitly
        # pressed STOP LABELS, keep them alive independently of the Adeon window.
        self.root.after(1200, self.ensure_labels_background_service)
        self.root.after(120, self.poll_show_window_request)
        # Never block first paint on a PowerShell cleanup scan.
        self.root.after(900, lambda: threading.Thread(target=cleanup_legacy_controllers, daemon=True).start())

    def apply_dashboard_rounding(self) -> None:
        """Give the native dashboard/restore pill rounded Windows edges."""
        try:
            for win, radius in ((self.ticket, 22), (self.ticket_restore, 32)):
                hwnd = int(win.winfo_id())
                win.update_idletasks()
                w = max(1, int(win.winfo_width()))
                h = max(1, int(win.winfo_height()))
                rgn = ctypes.windll.gdi32.CreateRoundRectRgn(0, 0, w + 1, h + 1, radius, radius)
                ctypes.windll.user32.SetWindowRgn(hwnd, rgn, True)
        except Exception:
            pass

    def _ticket_close_pressed(self, event=None):
        self.minimize_dashboard()
        return "break"

    def minimize_dashboard(self) -> None:
        # One click is authoritative. Once latched, no periodic foreground/visibility
        # refresh may reopen the large card or hide the round restore object.
        self._ticket_user_minimized = True
        self._ticket_internal_focus_until = time.time() + 2.0
        self._ticket_visible = False
        try:
            self.ticket.withdraw()
            self.ticket_restore.deiconify()
            self.ticket_restore.lift()
            self.ticket_restore.attributes("-topmost", True)
            self.ticket_restore.update_idletasks()
            self.apply_dashboard_rounding()
            self.root.after(40, self.update_ticket_visibility)
        except Exception:
            pass

    def restore_dashboard(self) -> None:
        self._ticket_user_minimized = False
        try:
            self.ticket_restore.withdraw()
            if foreground_is_lr_page():
                self.ticket.deiconify()
                self.ticket.lift()
                self._ticket_visible = True
                self.apply_dashboard_rounding()
        except Exception:
            pass

    def show_last_update_result(self) -> None:
        try:
            if not UPDATE_STATUS_FILE.exists():
                return
            obj = json.loads(UPDATE_STATUS_FILE.read_text(encoding="utf-8"))
            UPDATE_STATUS_FILE.unlink(missing_ok=True)
            if not isinstance(obj, dict):
                return
            if obj.get("ok"):
                installed = str(obj.get('version') or ADEON_VERSION)
                update_diag(f"LAST INSTALL RESULT | success version={installed}")
                self.version_label.config(text=f"INSTALLED VERSION  {installed}")
                self.update_status.config(text=f"INSTALLED VERSION  {installed}  •  UP TO DATE", fg="#12863a")
                self.set_message(f"Updated successfully to {installed}.")
                app_log(f"Update completed successfully: {obj}")
            else:
                update_diag(f"LAST INSTALL RESULT | failed details={obj}")
                self.set_message("The last update could not be installed. Adeon restored the previous version.")
                app_log(f"Update failed and rollback was attempted: {obj}")
        except Exception as e:
            app_log(f"Could not read update result: {e}")

    def periodic_update_check(self) -> None:
        try:
            self.check_for_updates(force=False)
        finally:
            self.root.after(5000, self.periodic_update_check)

    def check_for_updates(self, force: bool = False) -> None:
        if self.update_installing:
            update_diag("CHECK SKIPPED | update installation is in progress")
            if force:
                self.set_message("An update is already being installed.")
            return
        if self.update_checking:
            update_diag(f"CHECK REQUESTED WHILE BUSY | force={force}")
            if force:
                # Give immediate visual feedback instead of making the button
                # appear dead.  The in-flight check will update the result.
                self.manual_update_requested = True
                self.update_status.config(text="UPDATE  •  CHECKING NOW", fg="#777777")
                self.update_button.config(text="CHECKING...", state="normal")
                self.set_message("Checking for the newest Adeon version now...")
            return
        feed = update_feed_url()
        update_diag(f"CHECK START | installed={ADEON_VERSION} force={force} feed={feed or '[not configured]'}")
        if not feed:
            update_diag("CHECK RESULT | update channel is not configured")
            self.update_status.config(text="UPDATE  •  CHANNEL NOT SET", fg="#777777")
            self.update_button.config(text="CHECK FOR UPDATE", state="normal", bg="#e8ece9", fg="#1f1f1f")
            if force:
                self.set_message("Update channel is not configured yet. The administrator only needs to configure it once.")
            return
        now = time.time()
        if not force and now - self.last_update_check < UPDATE_CHECK_INTERVAL:
            return
        self.last_update_check = now
        self.update_checking = True
        self.manual_update_requested = bool(force)
        if force:
            self.update_status.config(text="UPDATE  •  CHECKING NOW", fg="#777777")
            # Do not disable the button.  A disabled Tk button looked like it
            # could not be clicked on slower networks.
            self.update_button.config(text="CHECKING...", state="normal")
            self.set_message("Checking for the newest Adeon version...")
        threading.Thread(target=self._check_update_thread, args=(feed, force), daemon=True).start()

    def _check_update_thread(self, feed: str, force: bool) -> None:
        try:
            update_diag(f"FETCH MANIFEST | {feed} mode={'manual' if force else 'fast-background'}")
            if force:
                manifest, manifest_source = fetch_newest_manifest(feed)
            else:
                manifest, manifest_source = fetch_manifest_quick(feed)
            update_diag(f"MANIFEST SELECTED | source={manifest_source} version={manifest.get('version','')}")
            product = str(manifest.get("product") or "")
            version = str(manifest.get("version") or "").strip()
            package_url = str(manifest.get("package_url") or "").strip()
            sha256 = str(manifest.get("sha256") or "").strip().lower()
            update_diag(f"MANIFEST RECEIVED | product={product or '[blank]'} version={version or '[blank]'} package_url={package_url or '[blank]'} sha256={'present' if len(sha256)==64 else 'invalid/missing'}")
            if product and product.lower() not in ("adeon", "adeon lr picker"):
                raise RuntimeError("The update feed is for a different product")
            if not version or not package_url or len(sha256) != 64:
                raise RuntimeError("Update manifest is incomplete")
            if is_newer_version(version):
                update_diag(f"CHECK RESULT | UPDATE AVAILABLE installed={ADEON_VERSION} available={version}")
                self.root.after(0, lambda: self._update_available(manifest))
            else:
                update_diag(f"CHECK RESULT | UP TO DATE installed={ADEON_VERSION} published={version}")
                self.root.after(0, lambda v=version: self._update_current(v))
        except Exception as e:
            msg = str(e)
            update_diag(f"CHECK FAILED | {msg}")
            app_log(f"Update check failed: {msg}")
            self.root.after(0, lambda m=msg, manual=force: self._update_check_failed(m, manual))

    def _update_available(self, manifest: dict) -> None:
        self.update_checking = False
        self.manual_update_requested = False
        self.pending_update = dict(manifest)
        ver = str(manifest.get("version") or "")
        update_diag(f"UI NOTICE | showing update available {ver}")
        self.update_status.config(text=f"AVAILABLE VERSION  {ver}", fg="#b45f06")
        self.set_message(f"Installed {ADEON_VERSION}. Version {ver} is available. Tap INSTALL UPDATE to apply it.")
        self.update_button.config(
            text=f"INSTALL UPDATE {ver}", state="normal", command=self.install_update,
            bg="#f2a100", fg="white", activebackground="#d18b00", activeforeground="white"
        )
        self.root.title("Adeon  •  UPDATE AVAILABLE")
        if self.last_update_notified != ver:
            self.last_update_notified = ver
            app_log(f"Update available: {ver}. Taskbar notification triggered.")
            try:
                flash_taskbar(self.root.winfo_id(), 10)
                self.root.bell()
            except Exception:
                pass
            self.show_update_toast(ver, str(manifest.get("summary") or ""))

    def _update_current(self, published_version: str = "") -> None:
        published = str(published_version or ADEON_VERSION).strip() or ADEON_VERSION
        update_diag(f"UI STATUS | installed={ADEON_VERSION} published={published} up_to_date=true")
        self.update_checking = False
        self.manual_update_requested = False
        self.pending_update = None
        self.update_status.config(text=f"INSTALLED {ADEON_VERSION}  •  PUBLISHED {published}  •  UP TO DATE", fg="#12863a")
        self.update_button.config(
            text="CHECK FOR UPDATE", state="normal", command=lambda: self.check_for_updates(force=True),
            bg="#e8ece9", fg="#1f1f1f", activebackground="#d7ddd9", activeforeground="#111111"
        )
        self.root.title("Adeon")

    def _update_check_failed(self, message: str, manual: bool = True) -> None:
        update_diag(f"UI STATUS | update check failed manual={manual}: {message}")
        requested_during_background = bool(self.manual_update_requested and not manual)
        self.update_checking = False
        self.manual_update_requested = False
        # If the user tapped CHECK while a quick background probe was already
        # running and that quick probe failed, immediately honor the user's
        # request with the full robust manual check.
        if requested_during_background:
            update_diag("MANUAL CHECK ESCALATION | quick background probe failed; starting robust manual check")
            self.update_button.config(text="CHECKING...", state="normal")
            self.root.after(25, lambda: self.check_for_updates(force=True))
            return
        # Background 5-second probes are intentionally quiet. A momentary
        # network miss must not make the app look broken or lock the button.
        if not manual:
            self.update_button.config(
                text="CHECK FOR UPDATE", state="normal", command=lambda: self.check_for_updates(force=True),
                bg="#e8ece9", fg="#1f1f1f"
            )
            return
        self.update_status.config(text="UPDATE  •  CHECK FAILED", fg="#9a6a00")
        self.update_button.config(
            text="CHECK FOR UPDATE", state="normal", command=lambda: self.check_for_updates(force=True),
            bg="#e8ece9", fg="#1f1f1f"
        )
        self.set_message("Could not reach the update service. See Downloads\\Adeon Update Diagnostic.log for details.")

    def show_update_toast(self, version: str, summary: str) -> None:
        try:
            toast = tk.Toplevel(self.root)
            toast.title("Adeon Update")
            toast.attributes("-topmost", True)
            toast.resizable(False, False)
            toast.configure(bg="#fff6df")
            w, h = 320, 120
            sw, sh = toast.winfo_screenwidth(), toast.winfo_screenheight()
            toast.geometry(f"{w}x{h}+{max(10, sw-w-20)}+{max(10, sh-h-70)}")
            tk.Label(toast, text=f"ADEON UPDATE {version} AVAILABLE", bg="#fff6df", fg="#8a5200", font=("Segoe UI", 10, "bold")).pack(pady=(12, 3))
            txt = (summary or "Open Adeon from the taskbar and tap INSTALL UPDATE.")[:120]
            tk.Label(toast, text=txt, bg="#fff6df", fg="#333333", font=("Segoe UI", 8), wraplength=285, justify="center").pack()
            tk.Button(toast, text="OPEN ADEON", command=lambda: (self.root.deiconify(), self.root.lift(), self.root.focus_force(), toast.destroy()), bg="#12863a", fg="white", relief="flat").pack(pady=(8, 0))
            toast.after(12000, lambda: toast.destroy() if toast.winfo_exists() else None)
        except Exception:
            pass

    def install_update(self) -> None:
        if self.update_installing or not self.pending_update:
            return
        if not UPDATE_HELPER.exists():
            self.set_message("Update helper is missing. Reinstall the updater-enabled Adeon package once.")
            return
        self.update_installing = True
        manifest = dict(self.pending_update)
        ver = str(manifest.get("version") or "")
        update_diag(f"INSTALL REQUESTED | installed={ADEON_VERSION} target={ver}")
        self.update_status.config(text=f"UPDATE  •  DOWNLOADING {ver}", fg="#b45f06")
        self.update_button.config(text="DOWNLOADING UPDATE...", state="disabled")
        self.set_message("Downloading and verifying the Adeon update. No other action is needed.")
        threading.Thread(target=self._stage_update_thread, args=(manifest,), daemon=True).start()

    def _stage_update_thread(self, manifest: dict) -> None:
        try:
            package_url = str(manifest.get("package_url") or "")
            expected = str(manifest.get("sha256") or "").lower()
            update_diag(f"DOWNLOAD START | version={manifest.get('version','')} url={package_url}")
            data = download_bytes(package_url)
            update_diag(f"DOWNLOAD COMPLETE | bytes={len(data)}")
            actual = hashlib.sha256(data).hexdigest().lower()
            if actual != expected:
                raise RuntimeError("Downloaded update failed the SHA-256 integrity check")
            update_diag(f"VERIFY OK | sha256={actual}")
            if UPDATE_STAGE_DIR.exists():
                shutil.rmtree(UPDATE_STAGE_DIR, ignore_errors=True)
            UPDATE_STAGE_DIR.mkdir(parents=True, exist_ok=True)
            zip_path = UPDATE_STAGE_DIR / "Adeon Update.zip"
            zip_path.write_bytes(data)
            extract_dir = UPDATE_STAGE_DIR / "payload"
            extract_dir.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(zip_path, "r") as zf:
                for name in zf.namelist():
                    pp = Path(name)
                    if pp.is_absolute() or ".." in pp.parts:
                        raise RuntimeError("Update archive contains an unsafe path")
                zf.extractall(extract_dir)
            for required in ("Adeon App.pyw", "Adeon Bot.py", "Adeon.ico"):
                if not (extract_dir / required).is_file():
                    raise RuntimeError(f"Update package is missing {required}")
            pending = {
                "version": str(manifest.get("version") or ""),
                "summary": str(manifest.get("summary") or ""),
                "payload": str(extract_dir),
                "target": str(BASE),
                "app_pid": os.getpid(),
                "created_at": time.time(),
            }
            UPDATE_PENDING_FILE.write_text(json.dumps(pending, indent=2), encoding="utf-8")
            # Always let an incoming version carry its own updater rules. This prevents
            # a newly added support file from being omitted by an older installed helper.
            staged_helper = extract_dir / "Adeon Update Helper.py"
            helper_to_run = staged_helper if staged_helper.is_file() else UPDATE_HELPER
            app_log(f"Update {pending['version']} downloaded and verified. Starting update helper.")
            update_diag(f"STAGED | update {pending['version']} verified; helper={helper_to_run}")
            subprocess.Popen(
                [pythonw_path(), str(helper_to_run), "--apply", str(UPDATE_PENDING_FILE)],
                cwd=str(extract_dir if staged_helper.is_file() else BASE), creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP,
                close_fds=True, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
            self.root.after(0, self._exit_for_update)
        except Exception as e:
            msg = str(e)
            update_diag(f"INSTALL FAILED | {msg}")
            app_log(f"Update staging failed: {msg}")
            self.root.after(0, lambda: self._update_stage_failed(msg))

    def _update_stage_failed(self, message: str) -> None:
        self.update_installing = False
        self.update_status.config(text="UPDATE  •  INSTALL FAILED", fg="#c62828")
        self.update_button.config(text="TRY UPDATE AGAIN", state="normal", command=self.install_update, bg="#f2a100", fg="white")
        self.set_message(f"Update was not installed: {message[:110]}")

    def _exit_for_update(self) -> None:
        self.set_message("Installing update. Adeon will restart automatically.")
        self.close_everything()

    def open_activity_log(self) -> None:
        try:
            if not ACTIVITY_LOG.exists():
                app_log("Activity log opened before any worker activity.")
            os.startfile(str(ACTIVITY_LOG))
        except Exception as e:
            try:
                subprocess.Popen(["notepad.exe", str(ACTIVITY_LOG)])
            except Exception:
                messagebox.showerror("Adeon", f"Could not open the activity log.\n\n{e}")

    def latest_log_line(self) -> str:
        try:
            lines = ACTIVITY_LOG.read_text(encoding="utf-8", errors="replace").splitlines()
            return lines[-1] if lines else "Log: waiting"
        except Exception:
            return "Log: waiting"

    def initial_background_hide(self) -> None:
        """Hide the Windows-startup instance only when no foreground launch asked to see it."""
        if getattr(self, "_background_show_requested", False):
            self.show_main_window()
        else:
            self.hide_to_background()

    def show_main_window(self) -> None:
        """Make Adeon visibly open even when it was started hidden at Windows login."""
        self._background_show_requested = True
        try:
            self.root.deiconify()
            try: self.root.state("normal")
            except Exception: pass
            self.root.lift()
            try:
                self.root.attributes("-topmost", True)
                self.root.after(350, lambda: self.root.attributes("-topmost", False))
            except Exception:
                pass
            try: self.root.focus_force()
            except Exception: pass
        except Exception:
            pass

    def poll_show_window_request(self) -> None:
        try:
            if SHOW_WINDOW_REQUEST_FILE.exists():
                try: SHOW_WINDOW_REQUEST_FILE.unlink(missing_ok=True)
                except Exception: pass
                self.show_main_window()
        except Exception:
            pass
        finally:
            try:
                if not getattr(self, "_closing", False):
                    self.root.after(150, self.poll_show_window_request)
            except Exception:
                pass

    def hide_to_background(self) -> None:
        """Hide the control window without stopping Picker or the persistent Labels service."""
        try:
            self.root.withdraw()
            app_log("Adeon window hidden to background; Picker/Labels continue running. Use END ADEON for a full shutdown.")
        except Exception:
            pass

    def ensure_labels_background_service(self) -> None:
        """Keep one persistent Labels worker alive without restart storms."""
        try:
            if not getattr(self, "_closing", False) and labels_enabled_preference():
                pid = worker_pid("labels")
                if pid_alive(pid):
                    self._labels_recovery_failures = 0
                    self._labels_recovery_next_at = 0.0
                    return
                now = time.time()
                if now < float(getattr(self, "_labels_recovery_next_at", 0.0) or 0.0):
                    return
                if existing_lr_page_open():
                    ok, msg = launch_worker("labels")
                    if ok:
                        # Give the new persistent worker time to arm itself. 1.0.71
                        # no longer exits when the browser is merely unreadable, but
                        # this also protects older/stale installations during update.
                        self._labels_recovery_next_at = now + 8.0
                        app_log("Persistent Labels service auto-started/recovered in the existing LR browser.")
                    else:
                        self._labels_recovery_failures = int(getattr(self, "_labels_recovery_failures", 0) or 0) + 1
                        delay = min(30.0, 5.0 + 5.0 * self._labels_recovery_failures)
                        self._labels_recovery_next_at = now + delay
                        app_log(f"Persistent Labels auto-start deferred for {delay:.0f}s: {msg}")
        except Exception as e:
            self._labels_recovery_failures = int(getattr(self, "_labels_recovery_failures", 0) or 0) + 1
            self._labels_recovery_next_at = time.time() + min(30.0, 5.0 + 5.0 * self._labels_recovery_failures)
            app_log(f"Persistent Labels service check failed: {e}")
        finally:
            try:
                if not getattr(self, "_closing", False):
                    self.root.after(2500, self.ensure_labels_background_service)
            except Exception:
                pass

    def close_everything(self) -> None:
        """Fully exit Adeon and stop both independent workers. Chrome stays open.

        Normal title-bar X does NOT call this; it only hides the control window so
        the built-in Labels service can remain alive. END ADEON and update installs
        use this full shutdown path.
        """
        if getattr(self, "_closing", False):
            return
        self._closing = True
        try:
            app_log("END ADEON/full shutdown requested; stopping picker + labels workers and exiting completely.")
        except Exception:
            pass

        try:
            self._hotkey_exit.set()
            if self._hotkey_thread_id:
                ctypes.windll.user32.PostThreadMessageW(int(self._hotkey_thread_id), 0x0012, 0, 0)
        except Exception:
            pass

        for mode in ("picker", "labels"):
            pid = worker_pid(mode)
            if pid_alive(pid):
                try:
                    _stop_file(mode).write_text(str(time.time()), encoding="utf-8")
                except Exception:
                    pass
                deadline = time.time() + 2.5
                while time.time() < deadline and pid_alive(pid):
                    time.sleep(0.10)
                if pid_alive(pid):
                    try:
                        subprocess.run(
                            ["taskkill", "/PID", str(pid), "/T", "/F"],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=4,
                            creationflags=0x08000000,
                        )
                    except Exception:
                        pass
            for q in (_pid_file(mode), _stop_file(mode), _runtime_file(mode)):
                try:
                    q.unlink(missing_ok=True)
                except Exception:
                    pass
        try:
            LABELS_REFRESH_FILE.unlink(missing_ok=True)
        except Exception:
            pass

        for win in (getattr(self, "ticket_restore", None), getattr(self, "ticket", None)):
            try:
                if win is not None:
                    win.destroy()
            except Exception:
                pass
        try:
            self.root.quit()
        except Exception:
            pass
        try:
            self.root.destroy()
        except Exception:
            pass

    def maybe_show_pin_help(self) -> None:
        if not PIN_HELP_FLAG.exists():
            return
        try:
            PIN_HELP_FLAG.unlink(missing_ok=True)
        except Exception:
            pass
        try:
            self.root.deiconify()
            self.root.lift()
            self.root.focus_force()
        except Exception:
            pass
        messagebox.showinfo(
            "Pin Adeon",
            "Adeon is installed and open.\n\n"
            "Right-click the green A icon on the Windows taskbar and choose ‘Pin to taskbar’.\n\n"
            "After that, you can open Adeon from the taskbar and press ACTIVATE PICKER."
        )

    def _start_connect_progress(self) -> None:
        try:
            if not self.connect_progress.winfo_ismapped():
                self.connect_progress.pack(pady=(0, 8), after=self.status)
            if not self._connect_progress_running:
                self._connect_progress_running = True
                self._connect_progress_x = -72
                self._animate_connect_progress()
        except Exception:
            pass

    def _animate_connect_progress(self) -> None:
        if self._closing or not self._connect_progress_running:
            return
        try:
            width = 260
            bar_width = 72
            self._connect_progress_x += 7
            if self._connect_progress_x > width:
                self._connect_progress_x = -bar_width
            x = self._connect_progress_x
            self.connect_progress.coords(self.connect_progress_bar, x, 0, x + bar_width, 9)
        except Exception:
            pass
        try:
            self.root.after(28, self._animate_connect_progress)
        except Exception:
            pass

    def _stop_connect_progress(self) -> None:
        self._connect_progress_running = False
        try:
            self.connect_progress.pack_forget()
        except Exception:
            pass

    def set_message(self, msg: str) -> None:
        self.note.config(text=str(msg or "")[:150])

    def _set_pair_button_visible(self, visible: bool) -> None:
        # 1.0.71 is Screen Vision/UIA only. The legacy extension-pair button
        # must never appear because no browser content script is installed.
        try:
            if self.pair_button.winfo_ismapped():
                self.pair_button.pack_forget()
        except Exception:
            pass

    def _show_browser_pairing_state(self, mode: str, state: str, hits: list[str] | None = None) -> None:
        # Legacy hook retained only so older UI state cannot crash after an update.
        self._set_pair_button_visible(False)
        self._show_browser_wait_state(mode, existing_lr_page_open())

    def pair_browser_integration(self) -> None:
        messagebox.showinfo(
            "Adeon",
            "Adeon 1.0.71 uses Screen Vision / Windows accessibility only. No browser extension or LR webpage script is installed.",
            parent=self.root,
        )

    def _launch_after_browser_ready(self, mode: str) -> None:
        mode = "labels" if str(mode).lower() == "labels" else "picker"
        ok, msg = launch_worker(mode)
        self.set_message(msg)
        if ok:
            if mode == "picker":
                self.busy = True
                self.root.after(1200, self.clear_start_busy)
            else:
                self.root.after(800, self.refresh)
        else:
            self.busy = False

    def _finish_browser_connect(self, mode: str, ok: bool) -> None:
        if self._closing:
            return
        if self._browser_connect_mode != mode:
            return
        self._browser_connect_mode = ""
        self._browser_connect_started_at = 0.0
        self._stop_connect_progress()
        self._browser_helper_opened = False
        self._browser_native_refresh_attempted = False
        self._browser_pairing_needed = False
        self._browser_pairing_detail = ""
        self._set_pair_button_visible(False)
        self.busy = False
        if ok:
            self.note.config(
                text=("Adeon found LR Writers. Picker will read the visible browser with Screen Vision and use native mouse/keyboard."
                      if mode == "picker" else
                      "Adeon found LR Writers in your existing browser and is connecting Labels."),
                fg="#555555",
            )
            app_log(f"Existing LR Writers browser is ready. Continuing requested mode={mode} automatically.")
            self._launch_after_browser_ready(mode)
        else:
            # Defensive path. Adeon never launches/restarts a browser.
            self.note.config(text=browser_wait_help_text(), fg="#a85b00")
            self.set_message("Still waiting for LR Writers in your existing Chrome or Thorium. No browser was opened.")
            app_log(f"Passive browser wait ended without a live LR Writers link for mode={mode}.")

    def _show_browser_wait_state(self, mode: str, lr_seen: bool) -> None:
        if self._closing or self._browser_connect_mode != mode:
            return
        target = "My Orders" if mode == "labels" else "Find Orders"
        if lr_seen:
            self._start_connect_progress()
            self.status.config(text="CONNECTING", fg="#b27800")
            self.note.config(text="", fg="#555555")
        else:
            self.status.config(text="WAITING FOR LR", fg="#b27800")
            self.note.config(
                text=(
                    f"WAITING FOR LR WRITERS: open or switch to LR Writers in the Chrome or Thorium window you want Adeon to use. "
                    f"Adeon will attach automatically and will not open any browser window or tab."
                ),
                fg="#8a6500",
            )
            self.set_message(f"Waiting for LR Writers in existing Chrome/Thorium before starting {mode.upper()}...")

    def _cancel_browser_wait(self, mode: str) -> None:
        if self._browser_connect_mode != mode:
            return
        self._browser_connect_mode = ""
        self._browser_connect_started_at = 0.0
        self._stop_connect_progress()
        self._browser_helper_opened = False
        self._browser_native_refresh_attempted = False
        self._browser_pairing_needed = False
        self._browser_pairing_detail = ""
        self._set_pair_button_visible(False)
        self.busy = False
        self.note.config(
            text="Adeon attaches only to LR Writers already open in Chrome or Thorium. It never opens a browser window or profile.",
            fg="#555555",
        )
        self.set_message(f"{mode.upper()} browser wait cancelled.")
        app_log(f"Passive existing-browser wait cancelled for mode={mode}.")

    def _browser_connect_worker(self, mode: str) -> None:
        # Screen Vision/UIA only: never navigate, refresh, type into, pair, or
        # modify the user's browser. Wait for an already-open LR Writers window
        # and then start the requested detached worker.
        app_log(f"Existing-browser attachment wait started for mode={mode}; Chrome and Thorium are accepted.")
        last_seen_state = None
        while not self._closing and self._browser_connect_mode == mode:
            lr_hwnd, lr_title, lr_proc = find_existing_lr_browser_window()
            lr_window_open = bool(lr_hwnd)
            if lr_window_open:
                app_log(
                    f"SCREEN VISION {mode.upper()}: existing LR browser found; Screen Vision is sufficient. "
                    f"process={lr_proc or '?'} title={lr_title[:80]}"
                )
                self.root.after(0, lambda m=mode: self._finish_browser_connect(m, True))
                return
            if last_seen_state is not False:
                last_seen_state = False
                self.root.after(0, lambda m=mode: self._show_browser_wait_state(m, False))
            time.sleep(0.20)

    def ensure_browser_then_launch(self, mode: str) -> None:
        mode = "labels" if str(mode).lower() == "labels" else "picker"
        if self._browser_connect_mode:
            if self._browser_connect_mode == mode:
                self._cancel_browser_wait(mode)
            else:
                self.set_message(
                    f"{self._browser_connect_mode.upper()} is already waiting for the existing LR Writers browser session."
                )
            return
        # A previous worker error is historical and must not overwrite the live
        # passive browser-wait message while neither worker is running.
        try:
            LAST_ERROR_FILE.unlink(missing_ok=True)
        except Exception:
            pass
        self._browser_helper_opened = False
        self._browser_pairing_needed = False
        self._browser_pairing_detail = ""
        self._set_pair_button_visible(False)
        self._browser_connect_mode = mode
        self._browser_connect_started_at = time.time()
        self._start_connect_progress()
        self.busy = (mode == "picker")
        initial_lr_seen = bool(existing_lr_page_open())
        self.status.config(text=("CONNECTING" if initial_lr_seen else "WAITING FOR LR"), fg="#b27800")
        self._show_browser_wait_state(mode, initial_lr_seen)
        threading.Thread(target=self._browser_connect_worker, args=(mode,), daemon=True).start()

    def toggle_picker(self) -> None:
        if self.busy and not self._browser_connect_mode:
            return
        app_log("ACTIVATE/DEACTIVATE PICKER button or Alt+S toggle received.")
        pid = worker_pid("picker")
        if pid_alive(pid):
            self._picker_forced_red = True
            ok, msg = request_stop("picker")
            self.set_message(msg)
            if ok:
                self.busy = True
                self.update_ticket(False, {"bot": "STOPPED", "job": "-", "f5": "OFF", "mouse": "OFF"})
                threading.Thread(target=self.wait_for_stop, args=(pid, "picker"), daemon=True).start()
        else:
            self._picker_forced_red = False
            self.ensure_browser_then_launch("picker")

    def toggle_labels(self) -> None:
        # Labels are a persistent built-in service. STOP LABELS is the explicit
        # opt-out and is remembered across app restarts. ON LABELS re-enables the
        # service; hiding/minimizing the Adeon window never changes this setting.
        app_log("ON/OFF LABELS button received.")
        pid = worker_pid("labels")
        pref_on = labels_enabled_preference()
        if pid_alive(pid) or self._browser_connect_mode == "labels" or pref_on:
            set_labels_enabled_preference(False)
            if pid_alive(pid):
                ok, msg = request_stop("labels")
                self.set_message(msg)
                if ok:
                    threading.Thread(target=self.wait_for_stop, args=(pid, "labels"), daemon=True).start()
            elif self._browser_connect_mode == "labels":
                self._cancel_browser_wait("labels")
                self.set_message("Labels are OFF. Press ON LABELS to enable the persistent label service again.")
            else:
                self.set_message("Labels are OFF. Press ON LABELS to enable the persistent label service again.")
            return
        set_labels_enabled_preference(True)
        self.ensure_browser_then_launch("labels")

    def clear_start_busy(self) -> None:
        self.busy = False

    def wait_for_stop(self, pid: int, mode: str = "picker") -> None:
        deadline = time.time() + 12.0
        while time.time() < deadline and pid_alive(pid):
            time.sleep(0.25)
        if pid_alive(pid):
            try:
                subprocess.run(
                    ["taskkill", "/PID", str(pid), "/T", "/F"],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5,
                    creationflags=0x08000000,
                )
            except Exception:
                pass
        for q in (_pid_file(mode), _stop_file(mode), _runtime_file(mode)):
            try:
                q.unlink(missing_ok=True)
            except Exception:
                pass
        self.busy = False

    def start_global_alt_s_hotkey(self) -> None:
        """Register Alt+S with Windows so a short keypress cannot be missed.

        The previous key-state poll could miss a quick chord. WM_HOTKEY is
        event-driven and remains reliable even while Chrome has focus.
        """
        HOTKEY_ID = 0xADE0
        MOD_ALT = 0x0001
        MOD_NOREPEAT = 0x4000
        VK_S = 0x53
        WM_HOTKEY = 0x0312

        def worker() -> None:
            registered = False
            try:
                user32 = ctypes.windll.user32
                kernel32 = ctypes.windll.kernel32
                self._hotkey_thread_id = int(kernel32.GetCurrentThreadId())
                registered = bool(user32.RegisterHotKey(None, HOTKEY_ID, MOD_ALT | MOD_NOREPEAT, VK_S))
                self._hotkey_registered = registered
                if not registered:
                    app_log("ALT+S global hotkey could not be registered. The main picker button still works.")
                    try:
                        self.root.after(0, lambda: self.hotkey_note.config(
                            text="ALT+S unavailable on this PC • use ACTIVATE/DEACTIVATE PICKER"
                        ))
                    except Exception:
                        pass
                    return
                app_log("ALT+S global hotkey registered with Windows.")
                msg = wintypes.MSG()
                while not self._hotkey_exit.is_set():
                    rv = int(user32.GetMessageW(ctypes.byref(msg), None, 0, 0))
                    if rv <= 0:
                        break
                    if int(msg.message) == WM_HOTKEY and int(msg.wParam) == HOTKEY_ID:
                        try:
                            self.root.after(0, self.toggle_picker)
                        except Exception:
                            break
            except Exception as e:
                app_log(f"ALT+S global hotkey failed: {e}")
            finally:
                self._hotkey_registered = False
                if registered:
                    try:
                        ctypes.windll.user32.UnregisterHotKey(None, HOTKEY_ID)
                    except Exception:
                        pass

        threading.Thread(target=worker, name="AdeonAltSHotkey", daemon=True).start()

    def update_ticket_visibility(self) -> None:
        """Show the dashboard only on LR Writers, while respecting user minimization."""
        try:
            should_show = foreground_is_lr_page()
            internal_focus = bool(getattr(self, "_ticket_internal_focus_until", 0.0) > time.time())
            if self._ticket_user_minimized:
                self.ticket.withdraw()
                self._ticket_visible = False
                # Minimized means minimized until the user explicitly restores it.
                # Keep the compact red/green object visible even if Adeon briefly owns
                # foreground focus after the X click or the user changes windows.
                self.ticket_restore.deiconify()
                self.ticket_restore.lift()
                self.apply_dashboard_rounding()
                return
            if not should_show:
                if self._ticket_visible:
                    self.ticket.withdraw()
                    self._ticket_visible = False
                self.ticket_restore.withdraw()
                return
            self.ticket_restore.withdraw()
            if not self._ticket_visible:
                self.ticket.deiconify()
                self.ticket.lift()
                self._ticket_visible = True
                self.apply_dashboard_rounding()
        except Exception:
            pass

    def update_ticket(self, alive: bool, runtime: dict) -> None:
        try:
            raw_state = str(runtime.get("bot") or "").upper() if alive else "STOPPED"
            if raw_state == "CONNECTED":
                self._last_picker_connected_at = time.time()
            # Do not visually blink away from CONNECTED during a short F5/DOM
            # transition. This only smooths the display; worker liveness remains real.
            if alive and raw_state != "CONNECTED" and self._last_picker_connected_at and time.time() - self._last_picker_connected_at < 5.0:
                state = "CONNECTED"
            else:
                state = raw_state or ("CONNECTING" if alive else "STOPPED")
            if state == "CONNECTED":
                color = "#138a36"
            elif state == "STOPPED":
                color = "#c62828"
            else:
                color = "#8a6500"
            job = str(runtime.get("job") or ("SEARCHING" if alive else "-"))
            f5 = str(runtime.get("f5") or ("WAIT" if alive else "OFF"))
            mouse = str(runtime.get("mouse") or ("WAIT" if alive else "OFF"))
            self.ticket_header.config(text=f"ADEON  •  {state}", fg=color)
            # The minimized A is a strict picker-health light. Green means the
            # picker is genuinely CONNECTED now. OFF, connecting, browser-link
            # loss, or any worker fault is red. Labels do not control this light.
            fault_page = str(runtime.get("page") or "").upper()
            fault_tokens = ("ERROR", "FAILED", "OFF", "LOGGED OUT", "BROWSER LINK OFF", "WAITING NETWORK")
            has_fault = any(tok in fault_page for tok in fault_tokens)
            restore_ok = bool(alive and raw_state == "CONNECTED" and not has_fault and not self._picker_forced_red)
            self.ticket_restore_button.config(
                bg=("#12863a" if restore_ok else "#c62828"),
                activebackground=("#0e6d2e" if restore_ok else "#a91f1f"),
                fg="white", activeforeground="white"
            )
            self.ticket_value_labels["JOB"].config(text=job, fg="#111111")
            self.ticket_value_labels["F5"].config(text=f5, fg="#111111")
            self.ticket_value_labels["MOUSE"].config(text=mouse, fg="#111111")
        except Exception:
            pass

    def refresh(self) -> None:
        picker_pid = worker_pid("picker")
        picker_alive = pid_alive(picker_pid)
        picker_runtime = runtime_state("picker")
        labels_pid = worker_pid("labels")
        labels_alive = pid_alive(labels_pid)
        labels_runtime = runtime_state("labels")

        self.update_ticket_visibility()
        self.update_ticket(picker_alive, picker_runtime)

        bot_state = str(picker_runtime.get("bot") or "").upper()
        page_state = str(picker_runtime.get("page") or "").upper()
        self._last_runtime_page = page_state or self._last_runtime_page
        labels_state = str(labels_runtime.get("bot") or "").upper()
        labels_page = str(labels_runtime.get("page") or "").upper()

        try:
            latest = self.latest_log_line()
            if len(latest) > 135:
                latest = latest[-135:]
            self.last_event.config(text=latest)
        except Exception:
            pass

        # Picker controls are based only on the picker worker. Labels never stop it.
        if picker_alive and bot_state == "CONNECTED":
            self._stop_connect_progress()
            self.status.config(text="CONNECTED", fg="#12863a")
            self.toggle.config(text="DEACTIVATE PICKER", bg="#c62828", fg="white", activebackground="#a91f1f")
            self.busy = False
        elif picker_alive:
            self._start_connect_progress()
            self.status.config(text="CONNECTING", fg="#b27800")
            self.toggle.config(text="DEACTIVATE PICKER", bg="#c62828", fg="white", activebackground="#a91f1f")
        else:
            if self._browser_connect_mode:
                try:
                    self.last_event.config(text="")
                except Exception:
                    pass
                elapsed = max(0.0, time.time() - float(self._browser_connect_started_at or time.time()))
                lr_seen_now = bool(existing_lr_page_open())
                if lr_seen_now:
                    self._start_connect_progress()
                    self.status.config(text="CONNECTING", fg="#b27800")
                    if self._browser_pairing_needed and elapsed >= 45.0:
                        self._set_pair_button_visible(True)
                    else:
                        self._set_pair_button_visible(False)
                else:
                    self._start_connect_progress()
                    self.status.config(text="WAITING FOR LR", fg="#b27800")
                self.toggle.config(text="CANCEL PICKER WAIT", bg="#e7b94a", fg="#111111", activebackground="#d9a62c")
            else:
                self._stop_connect_progress()
                self._set_pair_button_visible(False)
                self.status.config(text="STOPPED", fg="#c62828")
                self.toggle.config(text="ACTIVATE PICKER", bg="#12863a", fg="white", activebackground="#0e6d2e")
            try:
                PICKER_PID_FILE.unlink(missing_ok=True)
            except Exception:
                pass
            if not self._browser_connect_mode:
                self.busy = False

        # Labels are a true toggle. Any live labels worker shows a red STOP
        # control. Leaving My Orders only hides/waits; it never changes the tab.
        if labels_alive:
            self.labels_button.config(text="STOP LABELS", bg="#c62828", fg="white", activebackground="#a91f1f", activeforeground="white")
            if labels_page == "MY ORDERS":
                self.set_message("Labels are on for My Orders / In Progress and Revisions.")
            elif labels_page == "LABELS WAIT":
                self.set_message("Labels are waiting. Return to My Orders / In Progress or Revisions; Adeon will not navigate the tab for you.")
        else:
            if self._browser_connect_mode == "labels":
                self.labels_button.config(text="STOP LABELS", bg="#c62828", fg="white", activebackground="#a91f1f", activeforeground="white")
            elif labels_enabled_preference():
                self.labels_button.config(text="STOP LABELS", bg="#c62828", fg="white", activebackground="#a91f1f", activeforeground="white")
                self.set_message("Labels service is ON and waiting for an existing LR Writers browser.")
            else:
                self.labels_button.config(text="ON LABELS", bg="#dfeee3", fg="#176b34", activebackground="#cfe5d5", activeforeground="#145a2d")
            try:
                LABELS_PID_FILE.unlink(missing_ok=True)
            except Exception:
                pass

        if not picker_alive and not labels_alive and not self._browser_connect_mode:
            last_error = read_text(LAST_ERROR_FILE)
            if last_error:
                self.set_message(last_error[:150])
            elif self.last_alive and not self.busy:
                self.set_message("STOPPED. Your Chrome/Thorium browser remains untouched.")
        elif picker_alive and bot_state == "CONNECTED" and not labels_alive:
            self.set_message("CONNECTED to LR Writers. ON LABELS is available separately below.")

        if (picker_alive and bot_state == "CONNECTED") or (labels_alive and labels_state == "CONNECTED"):
            if time.time() - self.last_update_check >= UPDATE_CHECK_INTERVAL:
                self.check_for_updates(force=False)

        self.last_alive = picker_alive
        self.root.after(300, self.refresh)

    def run(self) -> None:
        self.root.mainloop()


if __name__ == "__main__":
    if redirect_source_copy_to_installed_app():
        raise SystemExit(0)
    set_windows_app_identity()
    _mutex = single_instance_or_focus()
    if _mutex is not None:
        app_log("Adeon app opened.")
        AdeonApp().run()
