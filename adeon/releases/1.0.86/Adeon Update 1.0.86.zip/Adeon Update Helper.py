from __future__ import annotations

import ctypes
import json
import ast
import os
import shutil
import subprocess
import sys
import tempfile
import time
import traceback
import winreg
from pathlib import Path
import tkinter as tk

CREATE_NO_WINDOW = 0x08000000
SW_SHOWNORMAL = 1

EXTENSION_ID = 'efnloiohfchcnkmiindjmlbmnmbdkifo'
EXTENSION_VERSION = '1.0.33'


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding='utf-8').strip()
    except Exception:
        return ''


def pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        k32 = ctypes.windll.kernel32
        h = k32.OpenProcess(0x00100000, False, int(pid))
        if not h:
            return False
        try:
            return int(k32.WaitForSingleObject(h, 0)) == 0x00000102
        finally:
            k32.CloseHandle(h)
    except Exception:
        return False


def python_exe(target: Path) -> Path:
    p = Path(read_text(target / 'Python Path.txt') or sys.executable)
    if p.name.lower() == 'pythonw.exe':
        candidate = p.with_name('python.exe')
        if candidate.exists():
            return candidate
    return p


def write_status(target: Path, ok: bool, version: str, message: str) -> None:
    try:
        (target / 'Adeon Update Status.json').write_text(
            json.dumps({'ok': bool(ok), 'version': version, 'message': message, 'time': time.time()}, indent=2),
            encoding='utf-8',
        )
    except Exception:
        pass


def write_support_warning(target: Path, message: str) -> None:
    """Record non-fatal support-file problems without rolling back core Adeon."""
    try:
        with (target / 'Adeon Update Support Warnings.txt').open('a', encoding='utf-8') as f:
            f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message}\n")
    except Exception:
        pass

def migrate_legacy_private_settings(target: Path) -> None:
    """Move credentials embedded by older builds into local user data before replacement."""
    old_bot = target / 'Adeon Bot.py'
    if not old_bot.is_file():
        return
    try:
        source = old_bot.read_text(encoding='utf-8', errors='ignore')
        tree = ast.parse(source)
    except Exception:
        return
    wanted = {
        'PUSHOVER_USER_KEY': 'pushover_user_key',
        'PUSHOVER_APP_TOKEN': 'pushover_app_token',
        'GMAIL_TO': 'gmail_to',
        'GMAIL_WEBAPP_URL': 'gmail_webapp_url',
        'GMAIL_WEBAPP_SECRET': 'gmail_webapp_secret',
    }
    found = {}
    for node in getattr(tree, 'body', []):
        if not isinstance(node, ast.Assign) or len(node.targets) != 1 or not isinstance(node.targets[0], ast.Name):
            continue
        name = node.targets[0].id
        if name not in wanted:
            continue
        try:
            value = ast.literal_eval(node.value)
        except Exception:
            continue
        if isinstance(value, str) and value.strip():
            found[wanted[name]] = value.strip()
    if not found:
        return
    data_dir = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'Adeon Data'
    data_dir.mkdir(parents=True, exist_ok=True)
    dest = data_dir / 'Notifications.json'
    current = {}
    try:
        if dest.is_file():
            obj = json.loads(dest.read_text(encoding='utf-8-sig'))
            if isinstance(obj, dict):
                current = obj
    except Exception:
        current = {}
    changed = False
    for key, value in found.items():
        if not str(current.get(key) or '').strip():
            current[key] = value
            changed = True
    if changed or not dest.exists():
        tmp = dest.with_suffix('.tmp')
        tmp.write_text(json.dumps(current, indent=2), encoding='utf-8')
        os.replace(tmp, dest)
        write_support_warning(target, 'Migrated legacy embedded notification settings into local Adeon Data.')


def copy_program_files(src: Path, target: Path) -> None:
    try:
        (target / 'Label Sync Secret.txt').unlink(missing_ok=True)
    except Exception:
        pass
    # Core runtime files must copy successfully or the update cannot continue.
    core = [
        'Adeon App.pyw', 'Adeon Bot.py', 'Adeon.ico', 'Adeon Update Helper.py',
    ]
    for name in core:
        sp = src / name
        if not sp.is_file():
            raise RuntimeError(f'Update package is missing required core file: {name}')
        shutil.copy2(sp, target / name)

    # AD.ico is cosmetic and must never block a valid update. Preserve the
    # currently installed blue AD icon when the staged package omits it, or
    # use the packaged Adeon.ico as a final fallback.
    staged_ad_icon = src / 'AD.ico'
    installed_ad_icon = target / 'AD.ico'
    if staged_ad_icon.is_file():
        shutil.copy2(staged_ad_icon, installed_ad_icon)
    elif not installed_ad_icon.is_file():
        fallback_icon = src / 'Adeon.ico'
        if fallback_icon.is_file():
            shutil.copy2(fallback_icon, installed_ad_icon)

    # Support files are repairable/preservable. In particular the accessibility
    # PowerShell feed is already embedded byte-for-byte inside Adeon Bot and is
    # self-restored at runtime. Security software may remove .ps1 files between
    # the copy and verification step, so that must never roll back an otherwise
    # healthy Adeon update.
    support = [
        'Adeon Accessibility Feed.ps1', 'Adeon Page Lock Feed.ps1', 'Adeon Screen Vision OCR.ps1', 'Read Me Adeon.txt', 'Built In Label Sync URL.txt',
        'Configure Label Sync.bat', 'Configure Notifications.bat', 'Migrate Adeon Private Settings.ps1', 'Label Sync Setup.txt', 'Uninstall AD.bat', 'AD Health Check.bat', 'AD Health Check.ps1',
        'Adeon Label Sync Server.gs', 'Label Sync Manifest Example.txt',
    ]
    for name in support:
        sp = src / name
        if not sp.is_file():
            write_support_warning(target, f'Incoming support file is absent from staged package: {name}')
            continue
        try:
            # Never erase a working package-level label endpoint with an empty
            # fallback from a later release. Persistent per-device Label Sync URL.txt
            # already lives outside the program folder and is never touched here.
            if name == 'Built In Label Sync URL.txt':
                incoming = sp.read_text(encoding='utf-8', errors='ignore').strip()
                existing = target / name
                current = existing.read_text(encoding='utf-8', errors='ignore').strip() if existing.is_file() else ''
                if current and not incoming:
                    continue
            shutil.copy2(sp, target / name)
        except Exception as e:
            # Support files must never make a healthy core update roll back.
            # Accessibility helpers have runtime recovery paths; label state/secrets
            # live persistently under %LOCALAPPDATA%\Adeon Data.
            write_support_warning(target, f'Could not copy support file {name}: {e}')



def _set_reg_string(root, key_path: str, name: str, value: str) -> None:
    with winreg.CreateKeyEx(root, key_path, 0, winreg.KEY_SET_VALUE | winreg.KEY_QUERY_VALUE) as key:
        winreg.SetValueEx(key, name, 0, winreg.REG_SZ, str(value))


def register_browser_integration() -> None:
    # Removed in 1.0.65. Updates never register a browser extension.
    return


def _integration_complete(folder: Path) -> bool:
    return False


def copy_browser_integration(src: Path, target: Path) -> None:
    # Removed in 1.0.65. Never copy or register LR webpage scripts.
    remove_legacy_browser_integration(target)
    return


def remove_legacy_browser_integration(target: Path) -> None:
    """Best-effort removal of the old LR content-script integration.

    Current Adeon uses Screen Vision/UIA only. This removes Adeon-owned unpacked files
    and user-level registrations so future LR pages receive no Adeon content script.
    Machine policy is also removed when the updater happens to have permission.
    """
    local=Path(os.environ.get('LOCALAPPDATA',''))
    for folder in (target/'Adeon Browser Integration', local/'Adeon Browser Integration'):
        try: shutil.rmtree(folder, ignore_errors=True)
        except Exception: pass
    for name in ('Enable Browser Integration.bat','Register Browser Integration.ps1','Pair Existing Browser Integration.ps1','Browser Integration Path.txt'):
        try: (target/name).unlink(missing_ok=True)
        except Exception: pass
    # External-extension registration.
    for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
        for key_path in (
            rf'Software\Google\Chrome\Extensions\{EXTENSION_ID}',
            rf'Software\Wow6432Node\Google\Chrome\Extensions\{EXTENSION_ID}',
        ):
            try: winreg.DeleteKey(hive,key_path)
            except OSError: pass
    # Remove only policy values that mention Adeon's extension ID; preserve all
    # unrelated browser policy entries.
    for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
        for base in (r'Software\Policies\Chromium',r'Software\Policies\Thorium'):
            for leaf in ('ExtensionInstallForcelist','ExtensionInstallAllowlist'):
                path=base+'\\'+leaf
                try:
                    with winreg.OpenKey(hive,path,0,winreg.KEY_QUERY_VALUE|winreg.KEY_SET_VALUE) as key:
                        vals=[]; i=0
                        while True:
                            try: vals.append(winreg.EnumValue(key,i)); i+=1
                            except OSError: break
                        for name,value,_typ in vals:
                            if EXTENSION_ID.lower() in str(value or '').lower():
                                try: winreg.DeleteValue(key,name)
                                except OSError: pass
                except OSError:
                    pass


def verify_required_install(target: Path) -> None:
    # Only the executable runtime is fatal. Support files must never trap Adeon
    # in an update/rollback loop. Picker accessibility and label helper files all have independent recovery/persistent-data paths.
    required = (
        'Adeon App.pyw', 'Adeon Bot.py', 'Adeon.ico', 'Adeon Update Helper.py',
    )
    missing = [name for name in required if not (target / name).is_file()]
    if missing:
        raise RuntimeError('Required Adeon core files are missing after update: ' + ', '.join(missing))

    # Surface support health for diagnostics only. Never roll back the core app
    # because a helper .txt/.bat/.ps1/extension file was removed or unavailable.
    optional = (
        'Adeon Accessibility Feed.ps1', 'Adeon Page Lock Feed.ps1', 'Adeon Screen Vision OCR.ps1', 'Built In Label Sync URL.txt',
        'Configure Label Sync.bat', 'Configure Notifications.bat', 'Migrate Adeon Private Settings.ps1', 'Label Sync Setup.txt', 'Uninstall AD.bat', 'AD Health Check.bat', 'AD Health Check.ps1',
    )
    absent = [name for name in optional if not (target / name).is_file()]
    if absent:
        write_support_warning(target, 'Non-fatal support files absent after update: ' + ', '.join(absent))


def pythonw_exe(target: Path) -> Path:
    raw = read_text(target / 'Python Path.txt')
    p = Path(raw) if raw else Path(sys.executable)
    if p.name.lower() == 'python.exe':
        pw = p.with_name('pythonw.exe')
        if pw.is_file():
            return pw
    if p.is_file():
        return p
    exe = Path(sys.executable)
    pw = exe.with_name('pythonw.exe')
    return pw if pw.is_file() else exe


def python_exe(target: Path) -> Path:
    raw = read_text(target / 'Python Path.txt')
    p = Path(raw) if raw else Path(sys.executable)
    if p.name.lower() == 'pythonw.exe':
        candidate = p.with_name('python.exe')
        if candidate.is_file():
            return candidate
    if p.is_file():
        return p
    return Path(sys.executable)


def build_exe(target: Path, progress=None) -> None:
    """Build the blue AD desktop executable as an onedir app.

    Onedir avoids the self-extracting onefile startup path that can be blocked or
    delayed by Windows Security.  The dynamic Adeon worker/support files remain in
    the stable parent install directory and are discovered by Adeon App.pyw.
    """
    py = python_exe(target)
    if not py.is_file():
        raise RuntimeError('Installed Python runtime is missing; cannot build AD.exe.')
    if progress:
        progress('Building the updated AD app...')
    build = Path(tempfile.gettempdir()) / f'AD Update Build {os.getpid()}'
    shutil.rmtree(build, ignore_errors=True)
    (build / 'dist').mkdir(parents=True, exist_ok=True)
    (build / 'work').mkdir(parents=True, exist_ok=True)
    (build / 'spec').mkdir(parents=True, exist_ok=True)
    icon = target / 'AD.ico'
    if not icon.is_file():
        icon = target / 'Adeon.ico'
    cmd = [
        str(py), '-m', 'PyInstaller', '--noconfirm', '--clean', '--onedir', '--windowed', '--noupx',
        '--name', 'AD', '--icon', str(icon),
        '--distpath', str(build / 'dist'), '--workpath', str(build / 'work'), '--specpath', str(build / 'spec'),
        str(target / 'Adeon App.pyw'),
    ]
    proc = subprocess.run(cmd, cwd=str(target), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                          creationflags=CREATE_NO_WINDOW, timeout=300)
    built = build / 'dist' / 'AD'
    exe = built / 'AD.exe'
    if proc.returncode != 0 or not exe.is_file():
        raise RuntimeError('Could not build the updated AD.exe')
    final = target / 'AD Desktop'
    staged = target / 'AD Desktop New'
    shutil.rmtree(staged, ignore_errors=True)
    shutil.copytree(built, staged)
    old = target / 'AD Desktop Old'
    shutil.rmtree(old, ignore_errors=True)
    if final.exists():
        final.replace(old)
    staged.replace(final)
    shutil.rmtree(old, ignore_errors=True)
    shutil.rmtree(build, ignore_errors=True)


def _run_shortcut_refresh(target: Path, startup_only: bool) -> None:
    exe = str(target / 'AD Desktop' / 'AD.exe').replace("'", "''")
    icon_path = target / 'AD.ico'
    if not icon_path.is_file():
        icon_path = target / 'Adeon.ico'
    icon = str(icon_path).replace("'", "''")
    work = str(target).replace("'", "''")
    if startup_only:
        ps = (
            "$w=New-Object -ComObject WScript.Shell; $startup=$w.SpecialFolders.Item('Startup'); "
            "if($startup){{$p=Join-Path $startup 'AD Labels.lnk'; $s=$w.CreateShortcut($p); "
            f"$s.TargetPath='{exe}'; $s.Arguments='--background'; $s.WorkingDirectory='{work}'; $s.IconLocation='{icon},0'; $s.Save()}}; "
            "$old=Join-Path $startup 'Adeon Labels.lnk'; if(Test-Path $old){Remove-Item -Force $old}"
        )
    else:
        ps = (
            "$w=New-Object -ComObject WScript.Shell; $desktop=$w.SpecialFolders.Item('Desktop'); "
            "$programs=$w.SpecialFolders.Item('Programs'); "
            "if($programs){{$p=Join-Path $programs 'AD.lnk'; $s=$w.CreateShortcut($p); "
            f"$s.TargetPath='{exe}'; $s.WorkingDirectory='{work}'; $s.IconLocation='{icon},0'; $s.Save(); "
            "$old=Join-Path $programs 'Adeon.lnk'; if(Test-Path $old){Remove-Item -Force $old}}}; "
            "if($desktop){{$p=Join-Path $desktop 'AD.lnk'; $s=$w.CreateShortcut($p); "
            f"$s.TargetPath='{exe}'; $s.WorkingDirectory='{work}'; $s.IconLocation='{icon},0'; $s.Save(); "
            "$old=Join-Path $desktop 'Adeon.lnk'; if(Test-Path $old){Remove-Item -Force $old}}}"
        )
    subprocess.run(['powershell.exe','-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-Command',ps],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=12, creationflags=CREATE_NO_WINDOW)


def register_windows_app(target: Path, version: str) -> None:
    """Register AD in Windows Installed apps for the current user."""
    key_path = r'Software\Microsoft\Windows\CurrentVersion\Uninstall\AD'
    exe = target / 'AD Desktop' / 'AD.exe'
    icon = target / 'AD.ico'
    if not icon.is_file():
        icon = target / 'Adeon.ico'
    uninstall = target / 'Uninstall AD.bat'
    with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE) as key:
        winreg.SetValueEx(key, 'DisplayName', 0, winreg.REG_SZ, 'AD')
        winreg.SetValueEx(key, 'DisplayVersion', 0, winreg.REG_SZ, str(version or ''))
        winreg.SetValueEx(key, 'DisplayIcon', 0, winreg.REG_SZ, str(icon))
        winreg.SetValueEx(key, 'InstallLocation', 0, winreg.REG_SZ, str(target))
        comspec = os.environ.get('COMSPEC', 'cmd.exe')
        winreg.SetValueEx(key, 'UninstallString', 0, winreg.REG_SZ, f'"{comspec}" /c ""{uninstall}""')
        winreg.SetValueEx(key, 'NoModify', 0, winreg.REG_DWORD, 1)
        winreg.SetValueEx(key, 'NoRepair', 0, winreg.REG_DWORD, 1)


def ensure_main_shortcuts(target: Path) -> None:
    try:
        _run_shortcut_refresh(target, False)
    except Exception as e:
        write_support_warning(target, f'Could not refresh Adeon shortcuts: {e}')


def ensure_startup_shortcut(target: Path) -> None:
    try:
        _run_shortcut_refresh(target, True)
    except Exception as e:
        write_support_warning(target, f'Could not create persistent Labels startup shortcut: {e}')


def relaunch(target: Path) -> None:
    exe = target / 'AD Desktop' / 'AD.exe'
    if not exe.is_file():
        raise RuntimeError('AD.exe is missing after update.')
    try:
        (Path(os.environ.get('LOCALAPPDATA', '')) / 'Adeon Data' / 'Show Adeon Window.flag').unlink(missing_ok=True)
    except Exception:
        pass
    time.sleep(1.5)
    subprocess.Popen([str(exe)], cwd=str(target), creationflags=CREATE_NO_WINDOW,
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


class UpdateWindow:
    def __init__(self) -> None:
        self.root = tk.Tk()
        self.root.title('AD Update')
        self.root.geometry('410x180')
        self.root.resizable(False, False)
        self.root.configure(bg='#f7f8f7')
        self.root.attributes('-topmost', True)
        try:
            ico = Path(os.environ.get('LOCALAPPDATA', '')) / 'Adeon' / 'AD.ico'
            if ico.exists():
                self.root.iconbitmap(default=str(ico))
        except Exception:
            pass
        tk.Label(self.root, text='AD UPDATE', bg='#f7f8f7', fg='#12863a', font=('Segoe UI', 16, 'bold')).pack(pady=(20, 10))
        self.label = tk.Label(self.root, text='Preparing update...', bg='#f7f8f7', fg='#333333', font=('Segoe UI', 10), wraplength=360)
        self.label.pack(pady=(0, 12))
        self.step = tk.Label(self.root, text='1 / 3', bg='#f7f8f7', fg='#777777', font=('Segoe UI', 9, 'bold'))
        self.step.pack()
        self.root.update_idletasks()

    def set(self, text: str, step: int | None = None) -> None:
        try:
            self.label.config(text=text)
            if step is not None:
                self.step.config(text=f'{step} / 3')
            self.root.update()
        except Exception:
            pass

    def close(self) -> None:
        try:
            self.root.destroy()
        except Exception:
            pass


def stop_all_old_adeon_processes(target: Path) -> None:
    """Best-effort cleanup of duplicate Adeon app/workers left by older builds.

    Older builds could allow overlapping Adeon.exe instances.
    A duplicate process can keep Adeon.exe/Python source files locked and can
    spawn multiple persistent Labels workers. The updater owns the maintenance
    window, so terminate only Adeon.exe and Adeon Bot.py --app-worker processes
    whose command line belongs to this installed target.
    """
    try:
        subprocess.run(
            ['taskkill', '/IM', 'AD.exe', '/T', '/F'],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            timeout=8, creationflags=CREATE_NO_WINDOW,
        )
    except Exception:
        pass
    try:
        subprocess.run(
            ['taskkill', '/IM', 'Adeon.exe', '/T', '/F'],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            timeout=8, creationflags=CREATE_NO_WINDOW,
        )
    except Exception:
        pass
    try:
        target_text = str(target).replace("'", "''")
        ps = (
            "$root='" + target_text + "'; "
            "$me=$PID; "
            "$ps=Get-CimInstance Win32_Process | Where-Object { "
            "$_.ProcessId -ne $me -and $_.CommandLine -and "
            "$_.CommandLine -like ('*' + $root + '*') -and ("
            "($_.CommandLine -match 'Adeon Bot\\.py' -and $_.CommandLine -match '--app-worker') -or "
            "($_.CommandLine -match 'Adeon App\\.pyw')) }; "
            "foreach($p in $ps){ try { Invoke-CimMethod -InputObject $p -MethodName Terminate | Out-Null } catch {} }"
        )
        subprocess.run(
            ['powershell', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', ps],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            timeout=10, creationflags=CREATE_NO_WINDOW,
        )
    except Exception:
        pass
    time.sleep(0.6)



def apply_update(pending_path: Path) -> int:
    ui = UpdateWindow()
    pending = json.loads(pending_path.read_text(encoding='utf-8'))
    target = Path(pending['target']).resolve()
    payload = Path(pending['payload']).resolve()
    version = str(pending.get('version') or '')
    app_pid = int(pending.get('app_pid') or 0)
    backup = target / 'Update Backup' / f"before {version or 'update'} {time.strftime('%Y%m%d %H%M%S')}"
    backup.mkdir(parents=True, exist_ok=True)
    program_names = ['Adeon.exe', 'Adeon App.pyw', 'Adeon Bot.py', 'Adeon.ico', 'Adeon Update Helper.py', 'Adeon Accessibility Feed.ps1', 'Adeon Page Lock Feed.ps1', 'Adeon Screen Vision OCR.ps1', 'Read Me Adeon.txt', 'Built In Label Sync URL.txt', 'Configure Label Sync.bat', 'Configure Notifications.bat', 'Migrate Adeon Private Settings.ps1', 'Label Sync Setup.txt', 'Uninstall AD.bat', 'AD Health Check.bat', 'AD Health Check.ps1', 'Adeon Label Sync Server.gs', 'Label Sync Manifest Example.txt']

    try:
        ui.set('Stopping the current Adeon session safely...', 1)
        deadline = time.time() + 25
        while pid_alive(app_pid) and time.time() < deadline:
            time.sleep(0.2)
            ui.root.update()
        if pid_alive(app_pid):
            subprocess.run(['taskkill', '/PID', str(app_pid), '/T', '/F'], stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, timeout=8, creationflags=CREATE_NO_WINDOW)
            time.sleep(0.8)

        # Older builds could leave a second Adeon.exe or Labels worker alive.
        # Clear only Adeon-owned duplicates before replacing program files so
        # updates cannot fail with WinError 32 and cannot relaunch duplicate workers.
        stop_all_old_adeon_processes(target)

        migrate_legacy_private_settings(target)

        # Remove the old content-script integration first. Even if the core update
        # later rolls back, the previous Adeon build can still use Screen Vision and no old
        # extension files are restored by this updater.
        remove_legacy_browser_integration(target)

        for name in program_names:
            src = target / name
            if src.is_file():
                shutil.copy2(src, backup / name)

        ui.set('Installing the new Adeon files...', 2)
        copy_program_files(payload, target)
        remove_legacy_browser_integration(target)
        verify_required_install(target)
        build_exe(target, lambda m: ui.set(m, 2))
        ensure_main_shortcuts(target)
        ensure_startup_shortcut(target)
        register_windows_app(target, version)

        (target / 'Adeon Version.json').write_text(
            json.dumps({'version': version, 'updated_at': time.time()}, indent=2), encoding='utf-8'
        )
        ui.set('Update installed. Restarting Adeon...', 3)
        write_status(target, True, version, 'Update installed successfully')
        try:
            pending_path.unlink(missing_ok=True)
        except Exception:
            pass
        time.sleep(0.8)
        relaunch(target)
        time.sleep(1.0)
        ui.close()
        return 0
    except Exception as e:
        err = str(e)
        # Preserve an exact local reason before rollback. This makes a future
        # updater failure diagnosable instead of showing only the generic UI.
        try:
            (target / 'Adeon Update Failure.txt').write_text(
                f'Version: {version}\nTime: {time.strftime("%Y-%m-%d %H:%M:%S")}\nError: {err}\n\n{traceback.format_exc()}',
                encoding='utf-8',
            )
        except Exception:
            pass
        ui.set('Update failed. Restoring the previous Adeon version...', 3)
        try:
            for name in program_names:
                old = backup / name
                if old.is_file():
                    shutil.copy2(old, target / name)
        except Exception as rollback_error:
            err += f' | rollback error: {rollback_error}'
        write_status(target, False, version, err)
        time.sleep(1.0)
        try:
            relaunch(target)
        except Exception:
            pass
        time.sleep(1.5)
        ui.close()
        return 1


def main() -> int:
    if len(sys.argv) >= 3 and sys.argv[1] == '--apply':
        return apply_update(Path(sys.argv[2]))
    return 2


if __name__ == '__main__':
    raise SystemExit(main())
